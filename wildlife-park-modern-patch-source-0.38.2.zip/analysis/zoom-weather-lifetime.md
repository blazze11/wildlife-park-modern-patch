# Intermediate zoom weather/lifetime repair — 11 October 2026

The user confirmed the bottom-bar bug was fixed, but weather was absent at intermediate levels and two crashes occurred. The two crashes have not been independently captured or reproduced. Static inspection identified a concrete use-after-free in the custom redraw that could account for them.

Native finish-render frees renderer+0x10 at base VA 0x412A16 (call 0x59AACA), expansion 0x412FC6 (call 0x5C706A), then deletes renderer+0x24 and cleans image resources (0x419C50 / 0x41B730) before returning. The previous outer zoom wrapper subsequently reused renderer+0x10 as the weather blitter delegate. Its presence as a nonzero pointer did not make it valid. The previous mocks kept the object alive, so their successful result did not cover native lifetime correctness.

The correction introduces a hook immediately before original cleanup: base VA 0x41295C, expansion 0x412F0C. It only acts during an intermediate zoom pass belonging to the active renderer.

1. Flush the pending world batch (base renderer+0x38, expansion +0x3C) with its original delegated worker if present, or the original span-copy convention otherwise. Reset worker and end pointer exactly as native cleanup does; this prevents a duplicate world flush.
2. Resample the completed virtual world into the physical target and mark this frame as sampled.
3. Bind and queue rain/snow through the existing native weather drawing objects, while the delegate and image cache are still alive.
4. Resume native cleanup. It flushes the now-empty world batch, flushes weather spans, frees the delegate and logical clipping rectangle, and cleans image cache resources in the original order.
5. The outer wrapper restores resolution/viewport/mouse state and avoids a second sample that would overwrite weather. Frame-local context pointers are cleared. It never dereferences a drawing object after render return.

Texture files and the accepted snow artwork are unchanged. The fixed HUD height, aligned row pitch and source-buffer initialization remain intact. Native endpoints 50/100/200 retain their original paths.

Validation executes actual compiled 32-bit patch code with engine mocks at original and rebased addresses in both games. The revised mock renderer queues a final world pixel, invokes the new finish hook helper, completes a deferred weather pixel, poisons its released delegate pointer, and checks that the outer wrapper neither uses the pointer nor overwrites the weather pixel. Both direct-copy and delegated world workers are exercised across all intermediate zoom levels; enabled/disabled weather, scale limits, reset, mouse mapping, row padding, source initialization and global/viewport restoration also pass. In-game visibility and crash stability still require user testing. No claim is made that both reported crashes are proven to share this cause.

Current installed hashes and backup paths are retained in zoom-weather-lifetime-installation.json. The executable builder regenerates the corrected zoom section from the weather-menu baseline; original sections are preserved except the declared hooks and overwritten relocation. The unsafe prior C source is retained as zoom_steps_before_weather_lifetime_fix.c for comparison.

User testing subsequently confirmed that the game appears to run and weather is fixed. This is a successful test report, not a long-duration crash-stability measurement. Windowed/fullscreen switching still produces a slow black-screen transition, also at 100% zoom.

The 100% path calls native rendering directly and bypasses offscreen allocation, sampling and custom weather drawing. Focused disassembly of the current base executable confirms that mode changes still use the native reset path at 0x5C63A0/0x5C66E0. The surface-recovery loop at 0x680090 retains the previously installed mode-reapplication hook at 0x6800EE and a 200 ms Sleep on an unsuccessful recovery iteration at 0x680136. These observations identify possible delay sites; they do not establish that the loop is entered during the reported transition or distinguish engine recreation time from Wine/display switching. No display patch was installed on this evidence alone. Transition duration and runtime timing remain unresolved.
