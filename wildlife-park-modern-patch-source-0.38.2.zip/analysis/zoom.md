# Zoom button investigation — 11 October 2026

Read-only investigation; no executable or asset patch installed.

The three buttons are absolute presets, not incremental actions. Base gameplay UI members +0x6C68/+0x7038/+0x7408 carry ZoomIn/ZoomOut/ZoomNormal tooltip keys. Event-0x0E registration at VA 0x50EF76 onwards points to callbacks 0x512B80/0x512BB0/0x512BE0. Those call the existing UI action helper with identifiers 6/7/8 and call zoom selector 0x409050 with modes 1/2/0 respectively.

| Button | Selector mode | Scale |
| --- | --- | --- |
| Zoom in | 1 | 2.0 / 200% |
| Zoom out | 2 | 0.5 / 50% |
| Normal | 0 | 1.0 / 100% |

Selector 0x409050 stores mode at controller+0xBC, scale at controller+0xC0 and calls 0x40E500 on controller+0x64. That setter writes scale to view+0x14. Selector mode 3 also writes 0.25, but none of these buttons or the inspected keyboard path reaches it. It is not a verified usable fourth zoom level.

Keyboard handlers at 0x519EF9–0x519F56 use the same selector: + advances 50%→100%→200%; − advances 200%→100%→50%. Their comparisons assume original integer modes. Hooking only the mouse buttons would not update keyboard behavior.

The view calls renderer initialization 0x411D70 from 0x40E55B, passing its scale. Renderer initialization compares the floating scale exactly with 0.5 (constant 0x704470) and 2.0 (0x704984); it installs different families of drawing vtables for these sizes. Half-size uses its own objects, double-size selects filtered/unfiltered objects according to byte 0xCAF1D3. Configuration read/write references associate that byte with LodZoomfilter. Other scale values fall through to the ordinary drawing-object family, rather than selecting an arbitrary-ratio scaler. Buffer setup also converts scale through 0x59AF88 before multiplying dimensions. Several paths thus need attention; merely changing preset floats is not supported by this evidence.

Wild Creatures has the same zoom selector structure at 0x408CC0 and setter 0x40E180, with the same field offsets and four constants. Expansion tooltip references are at 0x520F04/0x520F35/0x520F66. The expansion rendering and picking graph was not comprehensively traced.

A reasonable future implementation would retain the existing buttons as minus / reset / plus and introduce a bounded step table such as 50%, 62.5%, 75%, 87.5%, 100%, 112.5% ... 200%. This is a design proposal, not a tested patch. It needs a general world-render scaling path, correct viewport/camera bounds, and matching mouse-picking/build-placement coordinates. Scaling only the world view while retaining the HUD at native size is another possible architecture, not yet implemented or benchmarked. Arbitrary intermediate ratios may soften pixel art and add rendering cost. No claim of working smooth zoom or independent zoom-specific sprite files is made.

Evidence:

- REA/Hopper batch ev_5d8cbaea8ada7a14d81dfb8212a534d62ccce2f9593063889b3d68ecb42c1612 covers the three callbacks. Its pseudocode misidentifies stack parameters; focused machine-code inspection establishes actual constants and calls.
- REA/Hopper batch ev_5d444b3b41b450e9c49823ac524be7d4f798e6a19a83be1236e49165cf4c2668 covers selector, scale setter and renderer initialization. Typed float constants and branch directions were checked against disassembly and PE bytes.
- Full inline records retained in zoom-buttons-evidence.json and zoom-renderer-evidence.json.
- Analysis subject WLP_widescreen_weather_menu.EXE SHA256 2fe9f1d75866c80096a369e9c705736677178f4f7529c54323ed0f4d24eee882. Expansion counterpart WLPADD1_widescreen_weather_menu.EXE SHA256 8951a55ded77c912aad4ed2688677b5aa9fc880861373ce6b95620176e6c15a6.
- Static analysis only. No game execution, runtime click/coordinate capture, scaling prototype or performance measurement.
