# F2 native button states — 0.37.5

Based on immutable 0.37.4, which the user confirmed scrolls correctly and renders transparent frame corners.

The 0.37.3 button override wrapped virtual slot +0x20 (layout), while native state refresh uses slot 0. Its palette setup omitted the normal color at button +0x5cc, leaving black. The custom hover color also used reversed color bytes. 0.37.5 sets all six native color descriptors to white, with hover BGR bytes 40 d7 ff (warm gold), and restores native layout and pointer enter/leave methods. The real slot-0 update handles normal, focus, hover and pressed palette selection; drawing stays transparent. Native evidence: base 0x6677a0, 0x6684b0 and original button virtual table.

An additional native picture widget uses shared GUI entry 99, the original 40×40 close button states: frame 0 normal, 2 hovered and 1 pressed. It is attached after the background during construction and before the existing controls. The original close widget retains input and callback behavior. Its native state update selects the picture frame; the picture setter invalidates only when the frame changes. The picture has constructor, detach and guarded destructor ownership.

The heading receives the exact font interface used by Spielziel: global font object 0xccfd18 / 0xe5f440, virtual interface offset +0x14, native font setter 0x5ea670 / 0x6181a0. Heading bounds remain (30,17,426,21).

Native executable harnesses passed at image bases 0x400000 and 0x14000000 for both games. They exercise initial and repeated color state selection, close hover/press/release frames, native font argument, object lifecycle guards, restored method addresses and stack balance. Dependencies are mocked; live Wine visual testing remains with the user. Source section preservation checks ensure the existing scrolling fix is untouched. See f2-button-style-verification.json and f2-button-style-installation.json for verified bytes and backups.

## Correction — 0.37.6

The user confirmed 0.37.5 works, with the hover and pressed textures reversed. Runtime visual evidence supersedes the original frame identification above: frame 1 is hover, frame 2 pressed. The correction swaps only the two immediate values in the close state hook. Exact binary comparisons verify two changed bytes per game, with all remaining bytes identical.
