# Intermittent unsupported video mode: investigation

## Identified cause and installed correction

The expansion trace records three failures of an explicit 800×600×16 request.
The game's widescreen mode resolves (indices 85 for 32-bit and 55 for 16-bit),
but the launcher request resolves to mode zero. This is a table lookup failure:
the previous widescreen patch replaced the sole 800×600 entry at 16-bit depth.
The trace's enumerated list contains 800×600×16, so the driver offers that mode.
The launcher's windowed dynamic fallback masks the missing lookup in some paths;
the settings transition still reports the failure and restores the prior state.

`tools/patch_launcher_mode.py` restores 800×600 engine and DirectDraw entries
at all five depths using the existing 512×384 slots. The width filter already
excluded 512, so those driver slots were unavailable in the widescreen builds.
The new thunk runs before the existing widescreen thunk and leaves its four
choices intact. Neither the 87-entry engine table nor 70-entry enumeration
capacity is enlarged. Original error handling, focus/audio fixes and the
launcher's own windowed dimensions are retained.

Both corrected builds are installed; temporary logging hooks are removed.
Earlier working builds remain in `.pre-video-diagnostic.bak`; diagnostic builds
are additionally saved as `.video-diagnostic.bak` beside the executables.
The captured expansion trace is preserved in
`analysis/VideoModeTrace-addon-before-launcher-fix.bin`.

Verification independently reads the original engine table from disassembly,
applies the emitted MOV instructions, checks all 25 descriptor/table pairs and
depths, and replays the captured 2560×1440×32 → 800×600×16 → 2560×1440×16 →
800×600×16 requests. Each now resolves to a valid index. Existing injected
widescreen, focus, enumeration and audio sections remain byte-identical.
Deterministic output, PE bounds and the new jump chain also passed checks.
Results are in `analysis/launcher-mode-verification.json`.

Current artifacts:

- `WLP_widescreen_launcher_fixed.EXE`, SHA-256
  `e828e5d3e0c2ee9a44e767bb3a7154d0bd87ac7307034bec5346ac99ad72ea10`
- `WLPADD1_widescreen_launcher_fixed.EXE`, SHA-256
  `91d0ccfb7d185fdc35e92ddf0e2b08d8f4203ef0b75255e744fddf160c82581f`

The user confirmed both games work across repeated resolution changes,
fullscreen/windowed switching and game/launcher transitions. The following sections describe
the earlier investigation and diagnostic installation.

11 October 2026. User confirms expansion widescreen, focus and audio fixes work.
Both games can show "Video mode not supported!" during settings transitions.
The precise reproduced sequence is: open launcher, Einstellungen, change the
game's windowed setting to fullscreen; launcher goes black, audio stops, dialog
appears. Dismissing restores launcher and music; checkbox shows changed setting,
but starting gameplay still produces windowed mode.

The launcher should always remain windowed at its own resolution. Preserve that
behavior; the requested fix concerns applying game settings and returning to
the launcher. Do not force the launcher itself into widescreen/fullscreen.

Current DisplayModes.log lists all four widescreen modes at 8/16/32-bit depth,
33 registered modes total. This does not prove every transition succeeds.
Config.ini currently requests 2560×1440, depth 32, DirectDraw, windowed mode.

The high-level mode change saves previous dimensions and flags, attempts the
requested configuration, and restores the prior state on failure. The graphics
selector reports error class 22 (0x16). Failing lookup, no registered backend
for the requested index, or driver registration failure need a runtime snapshot
to distinguish. No error handling or renderer behavior has been bypassed.

## Diagnostic installation

Both installed executables now retain all working patches and add two logging
hooks, built by `tools/trace_video_modes.py`. Mode requests and the central error
reporter append fixed 2050-byte records to the game installation root:

- `VideoModeTrace-base.bin`
- `VideoModeTrace-addon.bin`

Each records arguments/caller, requested/current graphics dimensions/depth/flags,
engine error, DirectDraw count/caps/memory, all 70 driver enumeration records and
87 abstract backend registrations. No user save data is recorded. The logger
preserves registers, flags, stack and Win32 last-error state; original displaced
instructions execute and return to their original continuations.

Installed previous working builds are backed up alongside the executables as
`WLP.EXE.pre-video-diagnostic.bak` and `WLPADD1.EXE.pre-video-diagnostic.bak`.
Workspace working builds and original expansion backup remain available.

Static checks confirm deterministic builds, valid PE section bounds, only the
two hook sites and PE headers changed in existing bytes, no relocation overlap,
mapped imports and correct initialized-data / zero-filled-data address shifts.
Injected code was disassembled and checked for stack layout and API arguments.
Runtime capture is pending. Close and relaunch either game, reproduce the exact
sequence, dismiss the dialog, and exit before decoding the trace.

Decode with `python3 tools/trace_video_modes.py /absolute/path/VideoModeTrace-base.bin`
(or the addon trace).

Diagnostic SHA-256:

- Base: `7f3c15f09c5f59a4921fcf9aee140261b06251e7ab2d3b74074e9b97b6aa4b42`
- Expansion: `7927a0dbb4ff204d806d99dd542a98d55384a25263118288dc329acd43cd4a0a`

This installation is diagnostic, not a claimed fix for the transition failure.
