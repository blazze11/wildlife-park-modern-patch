# F2 button label correction — 0.38.1

User reported long white captions, text outside the visual center, and an opaque background around the second texture variant in 0.38.0. They requested shorter black captions without color changes on hover/click, and centered alignment.

Based directly on immutable 0.38.0. Caption string storage remains at the original addresses, shortened and zero-padded: Cheats einschalten → Cheats: Aus, Cheats ausschalten → Cheats: An (current status); Wetter: Auto, Wetter: Schnee, Wetter: Regen, Wetter: Aus; Landschaft. Original weather/cheat callbacks therefore keep dynamic state labels using the same existing references.

A post-attachment/state-update wrapper sets all six color descriptors on the three action buttons to RGB black and preserves all native image-state dispatch. It reapplies caption bounds (4,0,112,28) with both alignment fields +0x2c8/+0x2cc set to native center value 1, after the previous update. Native text alignment routines 0x63ea60/0x63ebf0 center when those fields are 1; inset bounds center the glyphs in the light inner artwork rather than the lower shadow padding. Header and keybind labels remain white. Close updates chain unchanged.

The weather picture now references shared GUI133, the same working variant as buttons one and three, replacing its GUI134 variant. All three retain native 120×34 size, normal0/pressed1/hover2 states. No texture assets or archives are modified in this revision.

Verification: source-section preservation checks; unique string replacements without moved references; exact weather-entry immediate replacement; native ABI mock harness tests all three palettes/foreground through normal/hover/press/release cycles, caption bounds/alignment after simulated native layout resets, close-update chaining, and stack balance at two image bases for both games. In-game appearance awaits user validation after restart. Installation verifies backups, live/current hashes and all unrelated game files unchanged.
