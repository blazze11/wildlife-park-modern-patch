# Calendar timing at higher TPS

2026-10-13. Installed candidate patch version **0.30.1** for WLP.EXE and WLPADD1.EXE. Native code verification passed. The user subsequently reported that one mission worked with the patch. The confirmation did not specify the mission identity or TPS; it does not establish coverage of every mission.

## Confirmed cause and deadline connection

Base calendar routine `0x4EAFF0` runs from the simulation update path. At `0x4EB069` it reads minute byte `[calendar+0x1D]`, adds **8**, and writes it back. It never reads TPS for this increment. On crossing 60 it advances the hour byte at +0x1C and reduces minutes modulo 60; at 24 hours it advances the day at +0x1B, and its existing day/month rollover advances the month at +0x1A and elapsed-month counter at +0x43C. The expansion has the same increment at `0x4FAA39`.

Consequently increasing tick frequency from 25 to 60 accelerates calendar minutes from nominally 200 to 480 per real second. After the integer normal-speed reset to a 16 ms interval, the nominal unpatched rate can instead reach 500 minutes/second. These rates are arithmetic, not measured throughput; DynSpeed/workload can slow execution.

The base deadline branch at `0x4ED603` compares elapsed-month byte +0x43C with configured month-limit byte +0x1A1 when the time-limit flag at +0x8A is enabled. If elapsed months exceeds the limit, it takes the existing failure branch at `0x4ED9D5`. The mission briefing code at `0x54C1BC` formats this same limit using `FinalTime` and `Month`/`Months` strings. We preserve that comparison, the game's existing boundary rules, and the configured four-month limit reported by the user.

The shipped `Int/All/Level/level7.wlp` was decoded using the existing game LZW decoder after its CMP0 header. The decoded record contains `Shirkan` at offset 0x312E3B. The binary level schema was not reconstructed sufficiently to independently extract and verify its month-limit field; four months is from the user's briefing observation. `analysis/shirkan-level7-decoded.bin` is an analysis copy; the shipped mission was not changed.

REA evidence: `tps-calendar-rea.json`, ID `ev_edf5cbb4b974ba4a96e8f57c359792d11962b5c8aeb7315b94347e4e04801ede`, Ghidra 12.1.4, bound to the 0.30.0 base executable. It corroborates the fixed +8 increment and calendar rollovers. The deadline branch and expansion hook were checked with ordinary objdump/pefile; do not attribute them to that REA dossier.

## Candidate fix

Replace only the eleven-byte minute-increment sequence with a jump to a new `.wlptime` section. The original hour comparison/branch and all following date, financial, mission and weather logic remain unchanged.

For TPS >= 25, keep a small fractional accumulator:

```text
accumulator += 200
whole_minutes, accumulator = divmod(accumulator, TPS)
calendar.minute += whole_minutes
```

Examples: 25 TPS gives 8 minutes/tick, 50 gives 4, and 60 cycles through 3, 3, 4 without losing the fraction. At 255 some ticks add zero minutes. Lower/zero TPS retains the original +8 behavior; this patch does not validate or repair unsupported configuration values or the engine's zero-TPS divisions.

The accumulator is keyed by calendar-object pointer and TPS and resets when either changes. It is transient and not serialized. Save/reload or allocation reuse can retain/lose a fraction smaller than one in-game minute; this is a limitation of the candidate. No save-file format changed.

The thunk preserves all registers except the original low-byte AL/DL outputs. It leaves execution at the original CMP AL,60, so that instruction determines the rollover branch and arithmetic flags. The appended code derives its image base from a call/pop anchor and has no unresolved assembler relocations. No original section bytes change except the declared eleven-byte hook in each executable; all previous patches remain byte-identical. Existing PE relocations do not cover the overwritten instructions.

The fix normalizes the calendar relative to configured TPS. It does not redesign the timer, adjust existing object duration caches after a live TPS switch, or guarantee identical economics/difficulty across every TPS. The existing 60 TPS integer normal-speed interval remains 16 ms rather than 16.667 ms, so that mode can still run about 4.17% above nominal speed. Speed controls retain their effect: 2x/3x increase tick frequency and therefore calendar progression too, subject to the existing integer timing and load behavior.

## Verification and installation

`tools/verify_tps_calendar.py` executed the actual generated hook and original hour CMP/JB on native x86. It checked 25, 50, 60, 120 and 255 TPS, returning to 25, totaling **64,200 ticks per executable/load-address combination**. Both executables were checked at image bases 0x400000 and 0x14000000: **256,800 total ticks**. Each 120 nominal-second segment advanced exactly 24,000 in-game minutes. It checked AL/DL outputs, preservation of other register bits/registers and stack, and correct original hour-branch selection. Hour rollover's notification/date side effects were mocked; whole-game execution was not part of these checks.

Evidence files: `tps-calendar-candidate.json`, `tps-calendar-verification.json`, and `tps-calendar-installation.json`. Tools: `patch_tps_calendar.py`, `verify_tps_calendar.py`, `install_tps_calendar.py`. The builder uses immutable 0.30.0 sources so it remains reproducible after installation.

Installed 0.30.1 hashes:

- WLP.EXE: `bd97135f81460321edacbaf91949c7d2ed313a510adf4d8e6fbfd385872be0de`
- WLPADD1.EXE: `141f6fdefb06fb1a4ff5c9aae9df560b994965f1a560ccfce85bc195665bd19e`

Exact backups are retained at `archive/game-backups/0.30.0/pre-tps-calendar/WLP.EXE` and `WLPADD1.EXE`, and immutable 0.30.0 snapshots remain in `builds/versions/0.30.0`. Current copies, version index and installed-file inventory were refreshed. No setting, mission file, asset or save was directly modified. The already running process continues executing its loaded older image until restart.

## Recommended starting point and remaining test

Use **50 TPS, normal (1x) speed** as the first smoother-play candidate. It doubles update frequency over 25 while using an exact 20 ms interval; the patched calendar then retains nominal original pacing. This is an engineering recommendation to try, not a measured personal preference or a proven complete difficulty balance.

25 TPS at normal speed remains the original reference. 60 is available for comparison with this patch but retains the small integer timer discrepancy. Raising TPS is a smoothness/update-rate choice; changing 1x/2x/3x is a progression-speed choice. For timed missions use normal speed first and compare calendar progression rather than trying to infer pace from animal animation alone.

Playtest sequence: close the game, set TPS=50 after exit (the game may save its live TPS on exit), restart, and start the Shirkan mission afresh at normal speed. Check visible calendar progression and whether the four-month deadline affords roughly the original planning time. Compare with 25 at normal speed. Neither the patch nor this investigation restores calendar time already consumed during previous faster runs. The user subsequently reported one successful mission test. Smoothness, broader mission balance, and calendar/hourly-event behavior across other scenarios remain outside that confirmed coverage.
