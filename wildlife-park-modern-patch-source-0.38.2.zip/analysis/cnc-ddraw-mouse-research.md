## Last background-input experiment reverted

The user reported that the background filter did not work and that the cursor
still appears outside, and explicitly requested reverting the last change.
Both installed EXEs have been restored from `.pre-background-mouse-filter.bak`
to the preceding lifecycle builds. Restored SHA-256 values verified:

- Base: ddb8fedbe49a615491dd933b0d7edd3d282bceb3d113c0668dd6039ee3d4439c
- Expansion: b225be3403c1b2bcdf8782bd459835190c1fccd5d04ee55ba84acbd65208e6fc

The inactive-hover issue remains unresolved. No replacement experiment installed.

## Inactive hover input filter (11 October 2026)

The user reports that moving the pointer across the inactive game window still
scrolls it after the lifecycle revision. Neutralizing position at the end of
the pump did not prevent new mouse events from reaching game subscribers.

The native message pump handles WM_MOUSEMOVE at base RVA 0x244120 / expansion
0x2722c0. It assigns mouse-event flag 0x20, then converts and dispatches input
through the engine before TranslateMessage/DispatchMessage and WndProc.
A new `--background-filter` hook intercepts this branch. During live gameplay,
when GetForegroundWindow differs from the actual graphics HWND, it neutralizes
the retained GUI position and skips internal mouse-event conversion. It resumes
at TranslateMessage/DispatchMessage (base 0x244271 / expansion 0x272411),
preserving normal window/focus processing. Focused mouse movement and launcher
input execute the original branch. Missing API/window state falls through.

Both installed builds contain this filter plus the previous capture cache,
resolution/layout invalidation, client system-cursor handling and neutral
background position helper. No disk tracing is present. The intended result
is that hovering over an inactive native window cannot retrigger edge scrolling.
Actual Proton behavior still requires user confirmation.

255 emitted-code mocked scenarios passed per executable, including background
branch filtering, focused pass-through, launcher exclusion, HWND fallback,
100 consecutive inactive hover events bypassing gameplay input, register/stack/
flags/last-error preservation, hook relocation checks and previous fix sections.
Previous lifecycle builds are `.pre-background-mouse-filter.bak`.

Installed SHA-256:
- Base: 6d5e5e469adab27aa31a2b39f44a4f224bd058c48cc72a6c7cfac40f1ccb555a
- Expansion: b6f6bc83173422aed3a111df779c15221bbb2fd3dee4a489a9e066fde3504927

## Resolution-change cursor and background edge-scroll revision

User reports that changing resolution exposes the system cursor near window
edges until the window is dragged, and that scrolling continues without focus.
Both installed games now use `--lifecycle` in addition to the preceding
window-events/focused-gameplay/cache-rectangle options.

Capture caches both the desktop rectangle and actual HWND. WM_CREATE, WM_MOVE,
WM_SIZE, WM_SHOWWINDOW, WM_WINDOWPOSCHANGED and WM_DISPLAYCHANGE invalidate
the cached rectangle and defer the refresh until after the original WndProc
runs. The next pump reacquires capture even with identical bounds. This closes
the old cache's window-recreation/layout gap without restoring per-pump grabs.

WM_SETCURSOR with HTCLIENT is consumed only while the gameplay capture is
owned, using SetCursor(NULL) to hide the system cursor. Non-client messages
retain original handling. ShowCursor's global counter is untouched. The hook
restores registers/flags/last error and discards the two original SEH pushes
before returning TRUE with the original stdcall argument cleanup.

On background gameplay updates/focus-release paths, a helper gets the actual
client center and feeds it to the original GUI mouse dispatcher only when its
current mouse position differs. It retains the current GUI surface, sends
source_kind=0, and does not move the desktop cursor or pause simulation. This
is intended to clear the retained edge position through the normal GUI update
notification. It requires a live world, valid HWND and GUI surface, and skips
focused gameplay. Original dispatcher verified by disassembly at base RVA
0x24edf0 / expansion 0x278ed0; GUI object globals differ by 0x1ec988.

149 emitted-code mocked checks passed per game: previous capture/focus cases,
unchanged-rectangle call suppression, window identity/layout invalidation,
center notification once on background input, HTCLIENT cursor hiding,
non-client handling, state preservation and unchanged previous fix sections.
No tracing section is present. Runtime results remain pending.

Installed SHA-256:
- Base: ddb8fedbe49a615491dd933b0d7edd3d282bceb3d113c0668dd6039ee3d4439c
- Expansion: b225be3403c1b2bcdf8782bd459835190c1fccd5d04ee55ba84acbd65208e6fc

Previous cached builds are preserved as `.pre-mouse-lifecycle.bak`.

## Capture performance revision (11 October 2026)

The user confirmed cursor confinement works, but edge scrolling still lags
after disk tracing was removed. The previous capture patch called ClipCursor
on every pump and window message, even for identical rectangles. This may
repeatedly update Proton/Wine's pointer grab; that explanation is a hypothesis
until the user tests this revision.

Both games now use `--window-events --focused-gameplay --cache-rectangle`.
The patch stores the last successfully captured desktop rectangle. While it
owns capture and the rectangle is unchanged, it skips ClipCursor. Geometry
changes update the rectangle; focus loss releases capture and clears ownership,
so refocus reacquires even with identical bounds. No disk tracing is included.

Mocked emitted-code validation passed 135 scenarios per game, including 100
unchanged updates making no additional ClipCursor calls, a combined move/resize,
focus-loss release, refocus capture, register/stack/flags/last-error preservation
and unchanged earlier fix sections. Runtime performance remains to be tested.
Backups of the user-confirmed capturing builds are `.pre-mouse-cache.bak`.

Installed SHA-256:
- Base: 6e2f070057cb98b89343fdfced69a921bccb9acc4b1f144d0436fd88eec3639f
- Expansion: 0e77ad341f4292e583a08cc3cf94e5a5e6f14c479e805cb1d047880d8e899995


## Runtime cause found; corrected capture installed (11 October 2026)

The expansion trace contains 178,942 records, with zero ClipCursor calls.
Foreground matched the object-specific HWND and the world pointer became
nonzero in gameplay, but active graphics flags stayed 0x6200 in both launcher
and gameplay. The assumed windowed bit 0x80 was false, so the old guard always
rejected capture. This establishes a patch bug, not a Proton clipping failure.

Both installed executables now use the window-event patch with
`--focused-gameplay`, removing that invalid graphics-bit check. Capture depends
on the focused actual game window and live-world pointer; fullscreen gameplay
also receives its client rectangle. Launcher/no-world and focus loss release
capture. The diagnostic section and all per-pump disk logging are absent.
The former diagnostic produced an 11.45 MB log and likely explains the reported
scrolling lag, although performance needs confirmation on the new build.

31 emitted-code mocked scenarios passed per executable, including real traced
flags 0x6200, zero global HWND, launcher exclusion and focus-loss release. Prior
fix sections are unchanged. Actual mouse capture still needs a user test.

Installed SHA-256:
- Base: 8747a3d0cf7537252d99570ed8175e5de018347503ae80c4e21391ff98bed2f3
- Expansion: 9848d22881383a8f4d3806f967eb7c5220f22810cd8e96c793a33dd4cc3e7b38

# Mouse confinement: rollback and cnc-ddraw comparison

## Second experiment also had no effect; real runtime trace installed

The user confirmed the second cursor experiment still allows the pointer to
leave the window. Static/mocked execution did not establish real capture.
`tools/trace_mouse_runtime.py` now instruments that build without changing its
capture policy. Both installed executables are the runtime diagnostic builds.

`MouseCaptureTrace-base.bin` / `MouseCaptureTrace-addon.bin` append 64-byte
snapshots at the game installation root. Each records foreground HWND, global
HWND, object-specific HWND, live-world pointer, active flags, ownership/busy
state, resolved ClipCursor API pointer, call counter, return value, last error
and last ClipCursor argument. All four actual ClipCursor call sites are
intercepted; the original API still executes, and its EAX result is preserved.
Snapshots are taken before the cursor update, so the next record reflects its
result. No save-game contents are logged. Decode using
`python3 tools/trace_mouse_runtime.py /absolute/path/MouseCaptureTrace-addon.bin`.

Both injected API interception paths (capture/release) were executed with
mocked APIs and retained behavior, registers, stack, flags and last error.
PE section bounds were checked. Actual capture status remains unknown until
the user reproduces the problem and exits.

The last experiments are backed up as `.pre-mouse-trace.bak`. The confirmed
working pre-cursor versions still exist as `.pre-mouse-events.bak` and
`.pre-mouse-confinement.bak`.

Diagnostic SHA-256:

- Base: `e42bbfae2e7727643cc328756e0ea49b9c9a52d4425e81a90b9aed957e534fcd`
- Expansion: `e5af4acedd4a6034301069107d2b3592046efb6c3e184c74bba6d369f5893204`

## Second experiment, explicitly requested after rollback

The user requested trying the cnc-ddraw approach after confirming the reverted
games still work. Both installed executables now use a second experiment,
`WLP_widescreen_mouse_events.EXE` / `WLPADD1_widescreen_mouse_events.EXE`.
This adapts the window-event approach without replacing the DirectDraw renderer
or installing the cnc-ddraw DLL.

The cursor update now mirrors the game's own HWND getter: graphics-object
field +0x90bc first, global HWND fallback. A hook in the original window-message
dispatcher triggers updates for window/mouse messages and immediate release
on WM_KILLFOCUS, inactive WM_ACTIVATE / WM_ACTIVATEAPP, cancellation, window
destruction and beginning a window move/resize. The message-pump path still
refreshes the rectangle; original focus/audio handlers remain intact.

Window-message hook RVA: base 0x271a47, expansion 0x29f657. These are the
relocation-free six-byte FS-load instructions after the two initial SEH pushes.
The wrapper preserves registers/flags, calls a shared cursor update/release
helper, executes the original FS-load, and resumes the original dispatcher.
Its message offsets were verified against the original function's stack layout.

The real Win32/Proton behavior still needs testing. Mocked execution checks
passed 28 paths per game, including different foreground and global window
handles, the object-specific HWND and fallback, mouse movement/click, focus
gain, immediate application/window deactivation and destruction. Register,
stack, flags and last-error preservation, PE bounds, relocation overlap and
unchanged previous fix sections also passed.

Previous user-confirmed builds are backed up beside the executables as
`WLP.EXE.pre-mouse-events.bak` / `WLPADD1.EXE.pre-mouse-events.bak`.

Second-experiment SHA-256:

- Base: `e8a73d9b3ecb056dd52849814256f60aa81c4bc4d6adca2386faad9407a89d25`
- Expansion: `c93c6197bd224eae055605a2bc3a12075b7d6d59e474387e621b82fece2fa4e3`

Reproduce with `tools/patch_mouse_confinement.py --window-events` and verify
with `tools/verify_mouse_confinement.py --window-events`, passing the previous
launcher-fixed source and second-experiment output as positional arguments.
The following records describe the earlier rollback and source investigation.

11 October 2026. The user reported that the direct cursor patch made no visible
difference and requested reverting to the previous executables first. Both
installed executables were restored from `.pre-mouse-confinement.bak` and their
SHA-256 values verified:

- WLP.EXE: `e828e5d3e0c2ee9a44e767bb3a7154d0bd87ac7307034bec5346ac99ad72ea10`
- WLPADD1.EXE: `91d0ccfb7d185fdc35e92ddf0e2b08d8f4203ef0b75255e744fddf160c82581f`

No replacement cursor experiment or wrapper is installed. Existing resolution,
launcher, focus/audio fixes and the user-confirmed Intro=0 remain active.

## Primary-source observations

Source: https://github.com/FunkyFr3sh/cnc-ddraw

- `src/mouse.c`: mouse_lock maps its known rendering-window rectangle to the
  desktop and uses real_ClipCursor. mouse_unlock clears clipping and releases
  capture. It also reconciles cursor position and visibility with its renderer.
  https://github.com/FunkyFr3sh/cnc-ddraw/blob/master/src/mouse.c
- `src/wndproc.c`: WM_ACTIVATEAPP deactivation calls mouse_unlock; window/click
  paths govern locking. It has separate handling for dialogs, resizing and
  Wine window behavior.
  https://github.com/FunkyFr3sh/cnc-ddraw/blob/master/src/wndproc.c
- `src/winapi_hooks.c`: fake_GetCursorPos maps desktop coordinates to game
  coordinates and clamps them while locked; fake_ClipCursor tracks renderer
  bounds and invokes the real API when capture is active.
  https://github.com/FunkyFr3sh/cnc-ddraw/blob/master/src/winapi_hooks.c
- README requires the game to use its fullscreen DirectDraw mode; windowed mode
  is then supplied by the wrapper. Wine also needs a ddraw override. Thus merely
  installing the DLL while retaining WLP's native windowed backend is not an
  equivalent test. No installation or Wine configuration was changed here.
  https://github.com/FunkyFr3sh/cnc-ddraw#instructions

## Possible flaw in our unsuccessful patch

The patch compared GetForegroundWindow against global VA 0xe52fb0, reused from
the fullscreen audio recovery. The base game's own window getter at 0x5c8e40
instead first returns graphics-object field +0x90bc when nonzero; only otherwise
does it call 0x682180, which returns that global HWND. Consequently, the patch's
guard may reject native windowed gameplay before ClipCursor runs. This remains
a hypothesis until actual window handles/guard outcomes are captured; mocked
tests assumed these handles were identical and could not detect the mismatch.

Next investigation should identify the actual active window and execute from
its activation/mouse message paths, with real ClipCursor return values captured.
Do not claim Wine rejects ClipCursor based on the previous test: the patch may
never have reached the API. Installing the full wrapper would also change the
renderer and windowing behavior, beyond just confining the pointer.
