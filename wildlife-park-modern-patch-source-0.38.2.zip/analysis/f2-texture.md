# F2 native texture skin — 0.36.0

Based on the user-confirmed 0.35.2 gameplay texture correction. Both executable snapshots are retained unchanged under builds/versions/0.35.2.

The F2 root panel uses shared GUI entry 81 (plain wood-and-rope board); four existing buttons use entry 89 (plain wooden plaque). The native scaled image drawing method draws the existing artwork into each widget’s existing local bounds. Shortcut text uses RGB 240/232/216 for contrast. The panel remains 300 × 530 with the same controls and layout.

Only the F2 root and four F2 button primary drawing slots are replaced in cloned 32-slot virtual tables after the existing attachment hook completes. Every other slot retains the native function pointer. The original drawing method runs first, retaining native canvas setup and fallback rendering. Texture acquisition uses the shared GUI bank’s virtual-base interface, frame zero, image acquisition, scaled blit and matching release. It guards a missing bank, failed acquisition, missing image and invalid dimensions.

The executable change consists of one five-byte attachment call and an appended relocatable `.wlpf2sk` section. Existing-section preservation checks passed. The GUI/Pictures texture files are not altered, so 0.35.2’s corrected frame indices remain intact.

Verification executes the actual emitted x86 thunks with native-ABI mocks for both games at image bases 0x400000 and 0x14000000. It checks all unchanged virtual table entries, assigned F2 widgets, label RGB and neighboring byte, correct bank receiver/frame/index, image and rectangle/blit arguments, balanced stack, original drawing call and release behavior for all failure paths. These checks verify patch logic and calling conventions; they do not render the game. Visual appearance and input interaction require a game restart and user validation.

Evidence: f2-texture-rea-evidence.json records the native picture renderer analysis. Candidate hashes, native checks and installation inventory are in f2-texture-candidate.json, f2-texture-verification.json and f2-texture-installation.json. The installation backs up both executables and verifies all other game files unchanged.
