# F2 cheat window and custom-window feasibility

11 October 2026. Read-only investigation of the user-selected patched games.
Installed executable hashes verified unchanged at the end:

- WLP.EXE: 45c4b1861c5ede62bcf4a8b9c466d48e33d75de7774e18823ff67bbbeab848f8
- WLPADD1.EXE: 66694a6a20d1e5d298de65d2efcdcd9a5c016c2bd25c94920f1496d98bb8a566

## What the code does

The base-game keyboard dispatcher compares its internal key word with 0x3c00
(F2's scan-code representation). That branch at VA 0x519a4c leads to 0x519ad1.
It reads the gameplay UI owner's member +0xa854. If null, it allocates 0x1624
bytes, calls the dialog constructor 0x507d70, stores its pointer, and calls
0x508660 with the gameplay UI owner as parent. If already non-null, it calls
0x5088b0 to detach child controls, invokes a deleting destructor through the
vtable, and clears the owner's pointer. Gameplay UI teardown also cleans this
pointer at 0x511490. This is an engine GUI object, with its own lifetime, rather
than evidence of an OS edit dialog or external console.

The constructor initializes an engine window base and embedded controls:

| Control | Offset in dialog | Constructor (base VA) |
| --- | --- | --- |
| Label | +0x288 | 0x5f2b80 |
| OK button | +0x5b8 | 0x667700 |
| Cancel button | +0xbf0 | 0x667700 |
| Text input | +0x1228 | 0x6659c0 |

Setup at 0x508660 positions a 300x100 window using the generic bounds setter
0x5f5fc0(x,y,width,height), initially (0,0,300,100). These are setup coordinates;
the actual screen position/parent effects have not been observed at runtime.
The controls have explicit bounds:

- Label: (10,15,270,20), literal `CheatCode:`.
- Input: (10,35,270,20).
- OK: (10,65,80,20), caption from localized `STDQUEST_OK`.
- Cancel: (200,65,80,20), caption from localized `STDQUEST_CANCEL`.

The generic event registration helper 0x644490 allocates a 0x20-byte listener
record containing an event selector, callback descriptor and receiver. Setup
registers event 0x0c on the input with 0x5088f0, and event 0x0e on the buttons
with 0x508910 and 0x508b10. Parent attachment uses 0x5ea150; control-specific
helpers also participate. Setup sends an engine event 0x12 to request input
focus for the text field. Exact meanings of every other setup/style helper
remain unclassified; they should be preserved in an initial prototype.

The input callback tests character byte +0x42 for 0x0d (Enter) and calls the
same handler as OK. That handler reads the expected `CheatCode` string through
the existing dictionary/localization accessor, copies the field text using
0x5f2c80, lowercases both strings, and compares their contents AND lengths.
On an exact match it sets byte 0xcaf1d5 to 1. A failed match does not set the
flag, and does not explicitly clear a previously enabled flag in this handler.
It then calls the common engine close helper 0x5ea980 and frees temporary text.
Cancel explicitly sets the same flag to zero before closing.

The flag is subsequently read in gameplay update/input handling, including
the `cheat modus` indicator (0x512834) and additional keyboard handling at
0x519775 / 0x51ac16. The complete set of resulting cheats was not traced:
the relevant finding is that submission enables a mode, not that the field
parses and executes arbitrary commands. The actual accepted code's value was
not recovered from packed dictionary assets. No cheat was executed.

The close helper checks attachment, sends an engine event describing the
window, then calls a detach/close helper. It does not itself show a direct heap
delete. Closing and deleting are distinct paths in the observed code; the
timing of event-driven deletion needs runtime verification before reuse.

## Expansion correspondence

Targeted disassembly confirms the same layout and behavior in Wild Creatures.
Addresses are VAs in image base 0x400000; subtract that base for RVAs.

| Path | Base | Expansion |
| --- | --- | --- |
| F2 comparison | 0x519a4c | 0x52c22c |
| F2 create/delete branch | 0x519ad1 | 0x52c2b1 |
| Owner dialog pointer | +0xa854 | +0xa89c |
| Dialog constructor | 0x507d70 | 0x519a70 |
| Setup / attach | 0x508660 | 0x519dd0 |
| Detach controls | 0x5088b0 | 0x51a020 |
| Enter callback | 0x5088f0 | 0x51a060 |
| Submit callback | 0x508910 | 0x51a080 |
| Cancel callback | 0x508b10 | 0x51a280 |
| Cheat-mode byte | 0xcaf1d5 | 0xe3b49e |
| Common close helper | 0x5ea980 | 0x6184b0 |

## What could be reused

Inference from the identified construction and listener APIs: a custom engine
panel with labels, editable text and buttons is feasible. The first prototype
can reuse this control composition and replace captions, bounds and callbacks.
Actions could update patch settings or invoke existing game routines. This
requires native code changes; no general scripting or external layout loader
was demonstrated for this window. Lists, sliders, resizing and controller
navigation were not established by this investigation.

For an independent panel, use separate ownership/storage and callbacks so
opening/closing it does not change cheat mode or share the cheat dialog's
object pointer. Preserve the existing allocation, parent/event registration,
focus and destruction conventions. A low-scope proof would show custom text
and one action button, then verify repeated open/close, world unload, keyboard
focus and both games before adding more controls. No prototype is installed.

## Evidence and limits

- REA batch evidence ev_db7fa4928e360d85b4a27253c7e195c557f1be52ee918de0209f4aed4f24ab0d
  resolves selector 0x508690 to setup 0x508660 and selector 0x508900 to Enter
  callback 0x5088f0. The large gameplay update decompilation was not used to
  infer complete cheat behavior; focused disassembly corroborates the flag.
- REA batch evidence ev_5ca05cd0b6aacf01d87093bdbf28e1bd829580fb660eab8d5dbb9d25c26ab460
  covers constructor, submit, cancel, bounds and event-registration helpers.
  Complete inline record saved in `cheat-window-evidence.json` beside this file.
- REA xref evidence ev_418fa859fce349b4617fcf2a9081e61ede8089c36f97041047b40afbca4a07c7
  confirms the branch reference 0x519a51 -> 0x519ad1.
- Provider: Hopper; shipped-artifact static analysis and decompiler inference.
  Decompiled types, stack variables and some loop forms are imperfect; precise
  addresses, offsets, calling sequence and comparisons were checked with
  objdump. Expansion mappings are independently inspected assembly.
- No game execution, runtime event trace, custom panel or executable edit was
  performed. Feasibility is a supported implementation inference, not a
  successful custom-window runtime demonstration.
