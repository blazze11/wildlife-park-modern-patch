# Independent debug tools — 0.31.0

**Rejected and reverted on 2026-10-13.** The user reported 0.31 did not work at all. Both games now use exact 0.30.1 executables; see debug-tools-rollback-installation.json. The following describes the archived experiment, not the current installation.

Previously installed in Wildlife Park and Wild Creatures, based on immutable 0.30.1. Installation, final hashes and exact baseline backups are recorded separately in debug-tools-installation.json. In-game appearance and German keyboard behavior require a restart and gameplay test; native mocks cannot establish those outcomes.

## Controls

- F2: independent **FPS**, **TPS**, and **Framezeit** An/Aus buttons. All start disabled on a new process. Existing cheats, shortcut table and weather controls remain.
- Physical German **^** key (scan code 0x29): toggle the small console. Esc or `close` closes it. Type a command and press Enter; Backspace edits the line.
- Commands: `help`, `fps on/off`, `tps on/off`, `timing on/off`, `debug on/off`, `status`, `clear`, `close`. `debug on` enables all three readouts. Commands affect diagnostic display state only.

Feedback for saving, loading, screenshots and cheat mode moves to the bottom left, retains its existing four-second lifetime, and is replaced by a new message. The independent debug readouts appear in green at the bottom right. Console output and input occupy the lower part of the screen when open.

FPS counts completed world-render calls, rather than monitor presentations. TPS counts simulation updates that pass the native pause gate; its second number is configured TPS, so the readout can show the effect of game-speed multipliers. Frame time is elapsed sample time divided by completed render calls, in integer milliseconds. Sampling uses real time in 500 ms windows with unsigned timer-wrap arithmetic. Initial or inactive counters may display zero.

The console dynamically maps the physical ^ key using MapVirtualKeyA, uses its own press/release latch, and checks the game's foreground HWND. It suppresses the native gameplay keyboard callback and direct key-poll function while open. The command alphabet is deliberately limited to ordinary letters and spaces; this is a small diagnostic command parser rather than a scripting environment. It does not activate the native developer flag or alter TPS, mission time, saves, or configuration.

## Implementation and evidence

Native leftovers are documented in [developer-leftovers.md](developer-leftovers.md). The original FPS display estimates update throughput. The independent counters avoid relying on that estimate. No reusable general console was established in the bounded native search.

`tools/debug_hud.py` reuses the existing feedback queue and owned native label at GUI root +0x620. It moves the label's clip rectangle to a bottom strip, draws notifications with the label's existing style, temporarily sets debug text to green and restores color, alignment and flags afterward. Its generic label-draw dispatcher chains the existing F2 shortcut-table draw hook for other labels.

The native label painter skips its draw call when its caption is empty (base 0x5F2CED–0x5F2D03 compares against the empty string and jumps past drawing). An inactive notification therefore uses a single-space placeholder, so enabling a debug readout or the console can still reach the custom draw hook. The label remains hidden when all features and feedback are inactive.

`tools/debug_panel.py` extends the F2 allocation with three native button objects. Construction, attachment, callback registration, detachment and destruction chain the accepted weather patch. The panel becomes 300×550; the close button moves to y=525.

`tools/debug_console.py` appends an independent command parser, chains the HUD's render wrapper, and hooks the existing keyboard callback and direct key polling. Relocation entries covering replaced absolute operands are disabled; new code derives its image base dynamically.

Native base message routing establishes event +0x28 as the registered selector: constructor 0x642C67 stores it and dispatcher 0x64438D–0x644392 compares it before callback invocation. WM_KEYDOWN produces selector 0x0C (first press and repeats); WM_KEYUP produces 0x0D. The existing game callback registers 0x0C. Console input accepts that selector, so release events cannot type a second character. Scan and character fields are corroborated by original game shortcut comparisons and message translation at 0x643930–0x643AB3. These observations are static and still need actual German keyboard confirmation.

`tools/patch_debug_tools.py` combines the modules and checks that every existing section remains byte-identical apart from declared hook/layout/relocation changes. Earlier calendar timing code remains intact. `tools/install_debug_tools.py` requires both game baselines and successful component verification before an atomic replacement with rollback backups.

Native x86 verification uses mocked engine and Win32 dependencies at original and rebased image addresses. Results are in debug-hud-verification.json, debug-panel-verification.json and debug-console-verification.json. These tests cover measurement arithmetic, message expiry, geometry, style restoration, fallback drawing, callbacks and object lifecycle, command bounds, key toggling/focus and register/stack behavior. They do not substitute for an in-game test of clipping, font placement or event delivery.
