# Cheat toggle and temporary action feedback

The user reported the cheat-mode indicator stayed visible after disabling
cheats, and requested replacing the input with a button plus action feedback.
The original update writes the cheat indicator when enabled but has no else
branch to clear/hide it (base VA 0x512834..0x512861; addon 0x524844..0x524871).
The user clarified that messages only need to disappear, without a fade.

The F2 window retains its 300x500 layout and German shortcut table. The heading
is now Cheats. The former OK button becomes a 270x20 toggle at (10,35), with
caption Cheats einschalten / Cheats ausschalten reflecting the real mode byte.
Its callback flips that byte directly and refreshes the caption, keeping the
panel open. The original edit object remains constructed/destructed for class
lifetime compatibility but is neither attached nor focused, so its input field
is absent. The Cancel button becomes Schließen and closes without changing
cheat mode. Previous F2-F12 routing remains intact.

The old permanent indicator block is replaced with a temporary-message update.
The same engine label, GUI root+0x620 at (0,66), is widened from 100x16 to 400x20.
Messages use the existing label style/color. German messages confirm cheat on
or off, park saved, park loaded and screenshot saved. Error messages are queued
when the original save/load or bitmap-writer routine reports failure. One
message is shown at a time; a newer action replaces the previous message and
restarts its four-second timer. Expiration sets an empty string and hides the
label, fixing the stale cheat text. Timer subtraction handles DWORD wrapping.

Messages are queued as integer IDs in a writable injected section. Save/load
hooks do not hold GUI pointers, since loading may rebuild the gameplay root.
Timing starts in the next GUI update, after synchronous file work. When the
live root changes, old active feedback is discarded and any new pending result
is presented on that root. The queue and lifetime state are process-local.

Actual completion hooks (VA):

| Operation | Base CALL / original callee | Expansion CALL / original callee |
| --- | --- | --- |
| Save | 0x408fe5 / 0x406530 | 0x408c63 / 0x406430 |
| Load | 0x408ad9 / 0x4066a0 | 0x408869 / 0x406580 |
| Bitmap screenshot | 0x51bcd7 / 0x67d450 | 0x52e6a7 / 0x6ab040 |

Save/load callees are thiscall(filename), return AL success and RET4. Wrappers
copy that argument, execute the original operation and preserve its results
and flags while queueing feedback. The screenshot writer is cdecl with six
arguments, returns EAX=1 on its successful path and zero if opening the file
fails. Its wrapper copies all six arguments and leaves original caller cleanup
intact. Notifications use native operation results; they do not independently
validate each filesystem write after a native screenshot success result.

All modified absolute-address operands have their old relocation entries
neutralized. New code derives data addresses from its runtime image base;
native calls and hooks use relative displacements. Existing sections remain
unchanged except the listed hooks, caption heading and five relocation entries.
No save content, filenames, screenshot filenames or game textures are modified.

Evidence: REA ev_e3dc9347fac0cd611d489ee05a595a0ad5d52c375946b61f7442ee87913500d2
and ev_62fdf90117583582628a865a122ff91678722791de5fceb2aefd40297e1c2eda,
saved in action-feedback-evidence.json. Native call signatures, stale-indicator
block, save/load success paths and expansion correspondence were corroborated
with objdump. Save/load tracing was performed as an independent read-only
subtask. This is static/native-harness evidence, not a game-runtime test.

Rebuild with tools/patch_action_feedback.py from the immediately preceding
*_widescreen_cheat_menus.EXE builds. Outputs: *_widescreen_feedback.EXE.
Native verification: tools/verify_action_feedback.py. Actual in-game rendering,
menu interactions and file operation feedback remain for user confirmation.

## Validation and installation

Both executables passed 60 actual-x86 scenarios at each of two image bases.
The mocked harness covers cheat toggles/captions, close without disabling,
file-operation argument/result forwarding, all eight German messages, 3999ms
versus 4000ms clearance, timer wrap, GUI root replacement, stack/register/flag
behavior and prior section payload preservation. The generated executables
were installed with atomic replacement and verified byte-for-byte. Backups:
.EXE.pre-action-feedback.bak. Restart the games to load these executables.
Actual gameplay UI appearance and operation messages await user confirmation.
