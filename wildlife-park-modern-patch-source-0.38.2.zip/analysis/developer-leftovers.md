# Native developer facilities

Inspected immutable patch baseline 0.30.1, both WLP.EXE and WLPADD1.EXE. These findings are static byte/disassembly observations, not an in-game test.

| Feature | Base preferred VA | Expansion preferred VA | Finding |
| --- | --- | --- | --- |
| Developer flag | 0xCAF1B4 | 0xE3B47C | Gates editor and gameplay behavior; separate from cheat mode. |
| Original FPS flag | 0xCAF1E0 | 0xE3B4B0 | Read from `[Optionen] SF`; native label is owner +0x950. |
| Original FPS sample | 0xCCA0BC | 0xE578A4 | A uint16 estimate based on time elapsed over 128 gameplay updates. |
| FPS formatting | 0x512748 | 0x524758 | `FPS <current> (max <peak>)`; peak field owner +0xC568 / +0xC5B0. |

The base sampling branch at 0x512717–0x512742 calculates `1000 / ((elapsed_ms >> 7) + 1)` when the gameplay tick count's low seven bits are zero. This is not evidence of an independently counted display presentation rate. New instrumentation should count completed world-render calls separately from simulation ticks, and document that render throughput can differ from monitor presents.

The developer flag gates F5 at 0x4089C0 (calls 0x409A20, cycles five states), F7 at 0x408A03 (calls 0x409AC0, cycles four states and pause handling), and F9 mode changes near 0x408941 (calls 0x401E30). It also bypasses normal keyboard menus at 0x519768 and permits terrain/animal edits and money changes. It should not be enabled as an incidental debug overlay setting. The bounded search of 32 direct flag references found reads/comparisons, and no direct write or enabling key.

No reusable general command console or `^` binding was established. The only `console` literal found was the CRT error about opening a console device. Imports include GetStdHandle and OutputDebugStringA, but not AllocConsole or AttachConsole. The original F2 edit control compares a cheat string; it is not a command parser. See [cheat-window.md](cheat-window.md) for its retained REA evidence and control ABI. `Profiler.log`, `ProfilerInterval`, `PF` and a TProfile.cpp path survive, but the inspected references do not establish an interactive profiler.

These are bounded negative findings: indirect references, stripped implementations or uninspected executable paths could contain additional tools. New debug facilities use their own state and leave the native developer flag untouched.

Native developer-mode activation is now explicitly exposed by the user-requested F2 toggle in 0.32.0, based on 0.30.1. See [native-developer-mode.md](native-developer-mode.md) for evidence, controls and verification limits. The rejected 0.31 independent debug facilities are no longer installed.
