# Expansion renderer mapping for incremental zoom

Read-only native disassembly of `WLPADD1_widescreen_weather_menu.EXE`, compared with the base executable, 11 October 2026. No game files modified by this investigation.

| Meaning | Base VA | Expansion VA |
| --- | --- | --- |
| View render | 0x40E510 | 0x40E190 |
| Renderer initialization | 0x411D70 | 0x4121B0 |
| Finish rendering | 0x412440 | 0x4129F0 |
| View camera/viewport calculation | 0x40DEE0 | 0x40DD00 |
| View scale setter | 0x40E500 | 0x40E180 |
| Physical screen width / height | 0x73ABB8 / 0x73ABBC | 0x76DD68 / 0x76DD6C |
| Mode index used by view calculation | 0x73AC48 | 0x76DDF8 |
| Viewport width table | 0x73AC4C | 0x76DDFC |
| Viewport height table | 0x73AC5C | 0x76DE0C |
| Subtract HUD height flag | 0x73AC42 | 0x76DDF2 |
| Global renderer pointer | 0xE5696C | 0x10432E4 |
| World graph pointer | 0xE56988 | 0x1043300 |

The view calls initialization at expansion 0x40E1DB and finish rendering at 0x40E1F8. View+0x14 holds float scale; view+0x18 is a pointer to the current drawing target; view+0x40/+0x44 store the two mouse arguments to the render routine. Renderer+0x20 receives the target descriptor and renderer+0x4C receives scale. The descriptor has width at +4, height at +8, byte pitch at +0xC and RGB565 pixel pointer at +0x10. Renderer+0x24 is a separately allocated clipping object, whose extent initialization rounds the float zoom to an integer before multiplying target dimensions.

Renderer initialization copies the mouse coordinates to +0x50/+0x54, clamps against descriptor dimensions, computes the corresponding pixel address at +0x58 and writes a 0x07E0 picking sentinel there. A post-render framebuffer scaler therefore also needs the inverse coordinate transform on these arguments. Scaling visuals alone would not give reliable picking.

Expansion finish rendering uses descriptor dimensions for full-screen lighting and precipitation. Its rain/snow flags are renderer+0x4005E/+0x4005F, whereas the base uses +0x4005A/+0x4005B. Precipitation rendering at 0x412E72–0x412F0C sets a clip to descriptor width and height, then draws the weather resource with the renderer's current drawing family.

Important implementation boundaries:

- Expansion view layout differs beyond +0xA0: the calculation writes viewport-height word at +0xF8 and scaled tile-size words at +0xFC/+0xFE; base uses +0xF4 and +0xF8/+0xFA. Do not copy a fixed-size view memory block between profiles.
- The expansion render path is structurally comparable, but constants and offsets are not uniformly shifted across functions.
- A native-100% offscreen view at a 50% final zoom needs a target around twice the physical width and height. Existing 2560×1440 weather artwork will not inherently cover a 5120×2880 offscreen target. Weather should be drawn at physical dimensions separately or otherwise be tiled/handled explicitly.
- View calculation reads viewport mode tables independently of target dimensions. Merely swapping the descriptor does not establish correct culling or camera bounds.
- Mouse arguments need conversion before renderer initialization; cached view coordinates used outside the rendering call may require additional handling.
- Static evidence establishes mappings and dependencies, not in-game alignment or performance.
