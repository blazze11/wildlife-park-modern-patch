# TPS investigation and live 60 TPS experiment

Investigated 2026-10-13 against base WLP.EXE, patch version 0.30.0.
Analyzed executable SHA-256: `2fe9f1d75866c80096a369e9c705736677178f4f7529c54323ed0f4d24eee882`.
No executable or asset patch was installed. A user-requested live memory experiment changed the running base game from 25 to 60 TPS.

## Findings

TPS is an unsigned byte at VA `0x73AC89`, initialized to `0x19` (25) in the executable's initialized data. Config key `TPS` is at `0x73AD2C`. The configuration reader stores the parsed integer's low byte at `0x40C464`; the writer converts that byte back to text at `0x40A532` and writes the TPS key at `0x40A564`. Missing/empty TPS leaves the initialized value unchanged. The inspected parser path has no nonzero/range guard before the byte store; oversized values can truncate, and zero reaches division sites. This is static instruction evidence, not a tested malformed configuration.

The first Config.ini read during this investigation contained TPS=60. The user clarified that they changed it to 25 before starting this game instance; a later file read confirmed TPS=25. Live memory likewise read 25. These captures were made at different times, not evidence of ignored configuration.

TPS supplies timing throughout the simulation. The bounded direct-address search found 33 literal occurrences of its global address in the current base executable. This covers direct references found in file bytes and corroborated in objdump assembly; indirect/aliased uses can exist. `tps-direct-references.txt` retains the disassembly contexts.

## Timer, normal speed and accelerated speed

The live owner pointer is stored at `0xCCC454`. Fields relative to the pointed-to object:

| Offset | Observed use |
| --- | --- |
| +0x558 | Timer object passed to the timer interval setter |
| +0x5E0 | Timer floating-point interval (timer object +0x88) |
| +0x5E4 | Timer phase/accumulator cleared when interval changes (timer object +0x8C) |
| +0x5F0 | Base integer interval in milliseconds |

Initialization near `0x501F1A` computes integer `1000 / TPS` for the base interval. Timer startup near `0x503F2B` separately computes floating-point `1000.0 / TPS`. Thus startup at TPS=60 can use approximately 16.667 ms while its base field is already 16 ms.

Normal-speed reset `0x506CA0` computes integer `1000 / TPS`, updates the base field, and sets the active timer to that integer converted to float. Callers include `0x40672F`, `0x5129C1`, and `0x51ADA6`.

Speed setter `0x506C70` computes integer `1000 / requested_rate`, updates the same base field, and sets the timer interval. The controls near `0x5129E0` and `0x5129F7` supply `TPS * 3` and `TPS * 2` respectively. TPS therefore supplies the baseline for these speed controls as well as normal timing.

| TPS | Floating startup interval | Interval after integer normal-speed reset | Nominal timer frequency after reset |
| --- | --- | --- | --- |
| 25 | 40 ms | 40 ms | 25/s |
| 50 | 20 ms | 20 ms | 50/s |
| 60 | 16.667 ms | 16 ms | 62.5/s |

Nominal frequencies are arithmetic, not measured throughput. Scheduler behavior, workload, pause state and dynamic speed can alter observed execution. TPS is not established as a render FPS setting by this investigation.

## DynSpeed

DynSpeed is another unsigned byte, at `0x73AC8E`, initialized to 1 and read/written through the config key at `0x73AD20`. The running instance read 1.

At the beginning of `0x5114D0`, if DynSpeed is enabled and the flags at `[this+0xC564]+0x44` do not have bits 0/1 set, the code takes elapsed time from WINMM `timeGetTime` (IAT `0x704350`), divides that elapsed integer by 4, and calls `0x506CE0` on the timer owner. The exact meanings of these flag bits were not recovered.

For a positive argument, `0x506CE0` computes approximately:

```text
candidate_ms = int(argument) * (1 / 67) * base_ms
candidate_ms = min(candidate_ms, 130)
active_interval_ms = max(candidate_ms, base_ms)
```

This lengthens the interval when elapsed time between these calls grows. At the investigated base intervals (40 or 16 ms), it can slow the timer down but does not select an interval shorter than the base. It does not rewrite TPS. Do not infer a precise render-frame relationship from this bounded trace.

REA/Ghidra corroboration: `tps-rea-dynamic-timing.json`, Evidence `ev_e036a2ccd5f44f8d8a9b69a7499b61ae3c56ca97dd0ab56380d9ffc685e90471`. Ghidra's recovered signature calls the argument float, but assembly and the caller demonstrate an integer argument converted with FILD. Treat the pseudocode as recovered analysis, not source. The smaller timing setters and other reference sites were inspected with ordinary pefile/objdump tools, not represented as REA Evidence.

## Other uses and limits of hot switching

Multiple sites calculate deadlines/durations as multiples of TPS or divide TPS by an object-specific rate:

- `0x4083B3`: a threshold of `5 * TPS` and a periodic divisor of `4 * TPS`.
- `0x49D49C`: compares elapsed ticks with `60 * TPS`.
- `0x4B9AA0`: caches TPS multiples including 5, 60, and 15 in global duration tables.
- `0x4C9D50`: caches TPS, 3*TPS and 2*TPS as 16-bit values.
- Sites such as `0x472314`, `0x473062`, `0x474CAA`, `0x480B06`, and `0x481CA9`: calculate `TPS / object_rate`, store it as an interval and use it to form deadlines.
- `0x47CDF4` and `0x47CF20`: divide TPS by an object-specific floating-point value, convert to integer, and enforce a minimum of one tick.

These observations establish duration/scheduling arithmetic; the exact gameplay names of all affected object classes remain unresolved. A full hot-switch implementation must address already initialized tables and existing object countdowns/deadlines. Rewriting the global alone is insufficient. A higher TPS cannot simply be assumed to make all gameplay 2.4 times faster because durations are scaled by TPS too, and cached/live state may temporarily disagree.

## Live experiment authorized by the user

Initial attachment read TPS=25 and DynSpeed=1. In the subsequent experiment, the running process's Windows PID was `0x138`; owner pointer was `0x01DE0F60`. Runtime addresses/PIDs must be rediscovered after restart.

WineDbg default mode could read memory, but raw untyped set commands returned `No type or type mismatch`, and basic casts did not resolve. Readback verified those attempts changed no values. The debugger was detached between investigations.

`tools/live_tps_test.py` used WineDbg's GDB remote mode and a bounded local protocol client. Before writing it checked the live normal-speed function bytes against the analyzed executable, read the TPS/base interval, and required the expected 25/40 baseline. It saved each original memory value and contains rollback on a failed write/readback. It computes addresses from the live pointer rather than hard-coding the heap allocation.

Verified writes:

| Runtime address | Before | After |
| --- | --- | --- |
| 0x73AC89 | TPS 25 | TPS 60 |
| 0x01DE1550 | Base interval 40 | Base interval 16 |
| 0x01DE1540 | Active interval 40.0 | Active interval 16.0 |
| 0x01DE1544 | Phase 38.0 | Phase 0.0 |

The seven neighboring bytes after TPS were read before and after and remained unchanged. Remote detach returned OK; WineDbg exited. `tps-live-test.json` retains before/after values, write readbacks and detach acknowledgement; `tps-remote-debugger.log` retains the server log.

No existing object durations or global duration tables were recalculated in this experiment. Visual smoothness, real tick throughput, progression rates, stability over time and save/reload behavior have not been measured. This is a verified runtime memory change, not a verified fully coherent TPS hot-switch feature.

We did not directly edit Config.ini. However, the game's config writer serializes the current TPS byte, so the game may persist TPS=60 when it next writes its settings. Do not promise that restarting necessarily restores 25 without checking the file.
