# Native tutorial layout controls

Read-only follow-up, 2026-10-13. The earlier broad description of UI layout controls was too general: the identified path edits the game's tutorial/help callouts, not arbitrary HUD widgets. No executable or installation file was changed in this investigation.

## Scope and candidate controls

The base-game constructor registers native key event 0x0C with callback 0x566150 at 0x564ECD. That callback requires the developer flag and modifier mask 0x140 (the engine's Ctrl mask, also used by normal Ctrl shortcuts). It changes the position entry for the current tutorial step:

| Key | Static behavior |
| --- | --- |
| Ctrl+Left / Right | Subtract/add 4 to the current step's horizontal position entry. |
| Ctrl+Up / Down | Subtract/add 4 to its vertical position entry. |
| Ctrl+N | Advances to the next tutorial step within the current group. |
| Ctrl+Space | Toggles a per-step 0/1 display property applied through 0x55E8C0; its exact visual meaning is not established. |

To investigate in-game, the likely applicable context is an active, focused tutorial/help callout with developer mode enabled. Native callback registration is established; actual focus/event delivery and visible movement have not been tested. This is not a drag-and-drop HUD editor.

## Why this is the tutorial system

The updater 0x565840 uses the current step index at 0xCD37B8 and pairs of coordinates starting at 0xCD34F8. Its resource-name table at 0xC91AC4 contains Intro1, Save, Load, RotateRight, Extro1, Intro2, Extro2, Intro3, Extro3, Intro4, Trapper2, and other tutorial task identifiers. Four step lists at 0x70EB68, 0x70EB88, 0x70EB98 and 0x70EBAC correspond to groups of 30, 16, 17 and 21 entries. The gameplay update checks its dirty flag and refreshes the embedded tutorial object at owner +0xA858 (0x512696).

The coordinate entries affect the tutorial window position through the native setter at 0x565D3E. After editing, the handler sets the dirty flag, computes coordinates and a display-property value, and emits a description via OutputDebugStringA. That is a debugger output stream, not a visible in-game export dialog.

## Persistence and usefulness

The nearby load/save functions (0x566340 / 0x5663D0) serialize the tutorial group, group position and current step identifier: 4 + 1 + 4 bytes. They do not serialize the edited coordinate array. The native initializer writes default coordinates. No normal export/save of edited positions was established; treat changes as session-only until verified otherwise. Persistent changes would require explicitly patching the defaults or adding an export/import mechanism.

This could help reposition tutorial callouts for widescreen. Moving the gameplay bars, F2 controls or arbitrary windows would require a separate mechanism. No implementation or new version was requested or installed in this follow-up.

## Expansion correspondence and evidence

Wild Creatures has the same developer-gated Ctrl arrow/N/Space callback at 0x590A40, with flag read 0x590A4E, current step at 0xE64C58, coordinate pairs at 0xE64BB0 and display-property bytes at 0xE1CDE0. These matching branches are GNU objdump observations; complete expansion tutorial serialization and resource correspondence were not traced.

REA/Hopper records retained in tutorial-layout-rea-evidence.json:

- ev_103868c9b5b5408b8f80fce1ead82372abd1c23ac55511491f13d3a2c62b5a37: native updater 0x565840 and coordinate-table use.
- ev_e53683cf4e391158f0aed21a1b132d9dd1b632d46dfad8c3605638155d0643ad: tutorial group selection at 0x565F90.
- ev_c9e5807ba996cc83ab8e78e2eb906aba671d3e697a0a941fc06d3854a5616a2a: tutorial step advancement at 0x566030.

Hopper did not identify the callback itself as a procedure in the earlier lookup. Its instructions and constructor registration were therefore examined directly with GNU objdump and pefile; these observations are not REA Evidence. Focused disassembly is retained in tutorial-layout-disassembly.txt. All conclusions are static observations or explicitly marked inferences; no game interaction was performed.
