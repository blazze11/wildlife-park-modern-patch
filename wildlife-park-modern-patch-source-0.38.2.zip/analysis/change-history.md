User confirmed the price fix, but work-area buttons needed the separate
toolbar event counter patched. Both games now have real-time toolbar hold
timing (400 ms then 120 ms), preserving the confirmed price patch. 196 native
x86 checks passed per game at two bases; work-area GUI behavior awaits testing.
Backups: .EXE.pre-toolbar-repeat.bak. Details: analysis/toolbar-repeat.md.

Both games have real-time numeric button repeat timing: an immediate step,
400 ms before the first repeat, then 120 ms between steps. Work-area and price
callback arithmetic remains intact. Initial work-area attribution was incorrect;
see the toolbar follow-up above. 312 native x86 checks passed per game at
two bases; complete GUI behavior awaits user testing. Backups:
.EXE.pre-button-repeat.bak. Details: analysis/button-repeat.md.

Both games now use a German cheat on/off button in F2, with Schließen
leaving cheat state unchanged. The actual cheat text input is no longer
attached or focused. Stale permanent cheat-mode text is replaced by temporary
German feedback for cheat toggles, completed saving/loading and screenshots,
including native operation failure results. Messages clear after four seconds
(no fade, per user clarification). 60 native x86 scenarios passed at two image
bases per game, covering callbacks, file result forwarding, timer boundaries,
wrap and new GUI roots. In-game confirmation remains. Backups:
.EXE.pre-action-feedback.bak. Details: analysis/action-feedback.md.

Cheat mode confirmed by the user after entering PANTHERA TIGRIS, but original
input routing blocked all function-key menus. Both games now route F2-F12
to normal menus even in cheat mode; other keys retain original cheat routing.
The original F2 Abbrechen button clears cheat mode and is now accessible.
262144 actual x86 routing cases passed per game across mode off/on and two
image bases. In-game menu/disable behavior awaits user confirmation. Backups:
.EXE.pre-cheat-menus.bak. Details: analysis/cheat-menu-fix.md.

F2 panel confirmed working by the user in-game. Both games now use German
keybind captions and German key names, encoded as single-byte Windows text
for umlauts. Rendering instructions and all earlier section payloads remain
unchanged. German data folder Deu is installed; both resource configurations
reference it and no English language folder was found. Backups of working
English panels: .EXE.pre-german-keybind-panel.bak.

Both games now have a 300x500 F2 panel with the original cheat controls and
a two-column table of documented gameplay shortcuts plus numbered object
bookmarks. Actual x86 mocked drawing/ABI checks passed at two image bases for
both games, including wrapped label markers and ordinary-label fallback.
In-game appearance awaits user testing. Backups: .pre-keybind-panel.bak.
Details: analysis/keybind-panel.md.

Save-name format updated in both installed games to the user's requested
Save_YYYY_MM_DD_HH_MM_SS, using local time and zero-padded fields.
Timestamp saving was confirmed working by the user before this format edit.
Eight mocked native x86 checks passed per game for the new format.

Both installed games now use timestamp defaults: Save(YYYYMMDD-HHMMSS-mmm).
The user confirmed numbered defaults repeatedly showed Save(1), so filename
numbering checks have been replaced by local date/time including milliseconds.
The textbox remains editable and original saving is retained. Eight native
mocked timestamp checks passed per game; in-game save/reload awaits confirmation.
Details: analysis/default-save-name.md.

Both games now prefill the save-name dialog with the first unused Save(n).
Existing Save(n).sav files are skipped and the field remains editable.
The original save process is retained. Native x86 mocked verification passed
for both builds; in-game save/reload still needs confirmation. Details:
analysis/default-save-name.md. Backups: .pre-default-save-name.bak.

Current mouse status: last background-input filter reverted at the user's
request after it failed runtime testing. Both installed games are restored to
the preceding lifecycle builds, with hashes verified. Background hover scrolling
and the reported cursor issue remain unresolved.

Current mouse status: both games now filter native WM_MOUSEMOVE input before
it reaches internal gameplay subscribers while the game window is inactive.
The previous post-pump neutral-position helper alone allowed hover movement
to retrigger scrolling. Existing cursor capture and resolution lifecycle fixes
remain included. 255 mocked checks passed per executable; inactive hover behavior
awaits user confirmation. Details: analysis/cnc-ddraw-mouse-research.md.

Current mouse status: both games now have lifecycle-aware capture installed.
Resolution/layout events invalidate the cache, window identity is tracked,
and the system cursor is hidden for focused gameplay client-area cursor events.
Background gameplay receives a neutral center position through the original
GUI mouse dispatcher to stop retained edge scrolling. 149 mocked checks passed
per executable; actual resolution transitions and background scrolling await
user confirmation. Details: analysis/cnc-ddraw-mouse-research.md.

Current mouse status: the user confirmed confinement works in the focused-gameplay
build, but scrolling still lags. Both games now have a cached-rectangle capture
build installed, skipping redundant ClipCursor calls for unchanged bounds while
retaining move/resize and focus handling. 135 mocked checks passed per game;
scrolling performance awaits runtime confirmation.

Current mouse status: both games have the corrected focused-gameplay cursor
capture build installed. Runtime tracing proved the previous graphics-bit guard
prevented every ClipCursor call (flags 0x6200). That guard and the disk tracing
are now removed. Mocked validation passed 31 paths per game; real capture and
scrolling performance await user confirmation. See analysis/cnc-ddraw-mouse-research.md.

# Wildlife Park Gold widescreen changes

Current cursor investigation: both attempted confinement patches had no runtime
effect. Installed builds now trace actual capture guards and ClipCursor calls
using `tools/trace_mouse_runtime.py`, with no new capture-policy changes. Logs
are `MouseCaptureTrace-base.bin` / `MouseCaptureTrace-addon.bin` in the install
root. User-confirmed pre-cursor backups remain. See
`analysis/cnc-ddraw-mouse-research.md` for current state and diagnostic hashes.

Latest installation is the user-requested second cursor experiment:
`WLP_widescreen_mouse_events.EXE` / `WLPADD1_widescreen_mouse_events.EXE`.
It adapts cnc-ddraw's activation/message approach and uses the game's own HWND
selection logic; it does not install a replacement renderer. Mocked execution
checks passed; actual cursor behavior is awaiting user testing. Backups and
source research are in `analysis/cnc-ddraw-mouse-research.md`.

Current installed executables have been restored to the user-confirmed
`WLP_widescreen_launcher_fixed.EXE` and `WLPADD1_widescreen_launcher_fixed.EXE`.
The mouse-confinement attempt had no effect under Proton and was reverted at
the user's request. Widescreen, launcher transitions, focus/audio fixes and
`Intro=0` remain. Research into cnc-ddraw's cursor handling is ongoing.

Latest installed executables are now `WLP_widescreen_mouse_fixed.EXE` and
`WLPADD1_widescreen_mouse_fixed.EXE`, adding mouse confinement during focused
windowed gameplay with release on focus loss. Static and mocked x86 execution
checks passed; Proton runtime validation is pending. Details and backups are in
`analysis/mouse-confinement.md`. The user confirmed `Intro=0` skips startup videos.

The user subsequently confirmed both launcher-fixed executables work across
repeated resolution changes, fullscreen/windowed switching and game/launcher
transitions. On 11 October 2026 the shared `Config.ini` `[Optionen] Intro` was
changed from 1 to 0 to skip the Deep Silver publisher logo and other startup
movies using the existing game setting. Backup: `Config.ini.before-no-intro.bak`
in the installation root. Cold-start verification of the video setting is pending.

Latest installed executables are `WLP_widescreen_launcher_fixed.EXE` and
`WLPADD1_widescreen_launcher_fixed.EXE`. They restore the launcher's missing
800×600 mode alongside the four widescreen choices. This corrects the lookup
failure captured during launcher transitions; static verification passed and
live transition testing is pending. See `analysis/video-mode-transition.md`.

Wild Creatures: the equivalent executable fixes were ported and installed in
WLPADD1.EXE on 11 October 2026. Static checks passed; expansion runtime testing
is pending. Backup, addresses, hashes and reproduction are recorded in
`analysis/addon-widescreen.md`.

Final state confirmed by the user on 11 October 2026, under Heroic / GE-Proton11-7.

## Final files

| Workspace file | Install as |
| --- | --- |
| WLP_widescreen_v8_audio_test.EXE | Int/Win32/Program/VC6/WLP.EXE |
| GUI.alb | Int/All/Pictures/GUI.alb |
| Pictures.cont | Int/All/Pictures.cont |

Installation root: `/path/to/Wildlife Park Gold`.

The workspace GUI.alb and Pictures.cont hashes match the previously generated
GUI_all_bars_2560.alb and corrected Pictures_weather_2560_v2.cont respectively.
Keep original backups when installing or sharing these files.

## Resolution support and labels

The original two-address edit changed resolution dimensions but left other
engine tables inconsistent. The final executable updates the menu dimension
arrays, abstract graphics-mode lookup and DirectDraw descriptors together.
The four selectable modes are:

- 1280 × 720 — 16:9
- 1280 × 800 — 16:10, intended for Steam Deck
- 1920 × 1080 — 16:9
- 2560 × 1440 — 16:9

The options menu displays matching resolution labels. DirectDraw mode
enumeration filters irrelevant widths while retaining the original 70-record
storage limit, allowing the required modes and depths to reach the game.
The user confirmed resolution switching and the main menu / launcher behavior
work. Steam Deck hardware itself has not been tested in this session.

## Fullscreen rendering and focus recovery

Gameplay retains the RGB565 / 16-bit format its renderer expects. Before
restoring a lost fullscreen surface, the executable reapplies the current
width, height and depth through DirectDraw, then performs the original Restore
call and error handling. The user confirmed correct colors, no duplicated
rendering, working Alt-Tab, and fast fullscreen/windowed switching.

The attempted 32-bit gameplay change was rejected because it produced wrong
colors and duplicated rendering; it is absent from the final executable.

## Wider interface artwork

The GUI archive was decoded and its three fixed-width backgrounds extracted.
The user extended these PNGs to 2560 pixels wide:

- bottom_bar_2560.png — 2560 × 115, GUI entry 0
- bottom_overlay_2560.png — 2560 × 50, GUI entry 1
- top_bar_2560.png — 2560 × 49, GUI entry 104

The edited images were repacked into GUI.alb, retaining the game's pixel format
and transparency keys. This fills the uncovered side regions of the top and
bottom bars. It extends the artwork; it does not scale every UI control.

## Rain and snow coverage

The drawing code already clips weather to the full framebuffer, but its source
animation frames were only 1600 × 1200. Misc.alb inside Pictures.cont contains
rain at entry 5 and snow at entry 6, each with ten animation frames.

All twenty frames were extended to 2560 × 1440 by repeating and cropping the
original sparse RGB565 artwork, retaining transparency and animation order.
Misc.alb was repacked into Pictures.cont. All following absolute archive offsets
were updated, and all 5,568 unrelated members verified byte-for-byte unchanged.
The user confirmed weather now works.

The first weather container caused loading to stall because its shifted
directory offsets were not updated. That builder error was corrected; the
final Pictures.cont is the corrected v2 archive.

## Fullscreen startup sound

The diagnostic trace showed that audio initialized and started successfully,
then a later focus-loss event suspended playback. Alt-Tab back in restarted it.
The one-time startup reset in v7 did not fix this.

V8 checks for stale suspension after the main window-message pump. When audio
is enabled and initialized but suspended, and the game is the desktop foreground
window, it invokes the existing audio focus-regain routine. It caches the
GetForegroundWindow API pointer and guards against recursive recovery.
Existing focus handlers and audio-volume settings are preserved. The user
confirmed v8 fixes fullscreen startup sound.

## File identities

```
WLP_widescreen_v8_audio_test.EXE
864fd20600dd5f84d0655712f4475e55ef6f04c6f5c969d32f941e58a0ed8d18

GUI.alb
7c230f52432c82312bc17617b200141729111badb9cbce0369235ba526491af7

Pictures.cont
24a838141af33ab921c9ded23605124faae790f14389befff2438cb36a5fe377
```

## Tools and records

Executable patchers are in `tools/patch_widescreen.py`,
`tools/patch_mode_enumeration.py`, `tools/patch_focus_recovery.py`,
`tools/patch_resolution_choices.py`, and `tools/patch_audio_foreground.py`.
Image extraction/repacking uses `tools/extract_alb.py`,
`tools/replace_alb_frame.py`, and `tools/expand_weather.py`.

Detailed records: `analysis/widescreen.md`, `analysis/weather/findings.md`,
and `analysis/audio-startup.md`. Earlier sections describe intermediate,
sometimes unsuccessful builds; this summary describes the final working state.
Runtime validation was performed by the user. Broader stability and other
Proton versions/hardware have not been established.
