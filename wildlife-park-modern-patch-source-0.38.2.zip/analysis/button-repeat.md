# Numeric button repeat timing

The accepted feedback build was the input for this patch. The old numeric
callbacks increment an 8-bit counter per event, wait 16 events, then act every
second event. This makes a short click repeat quickly on a fast event loop.

Base numeric object-value callback: VA 0x531f00, value update begins 0x531f58.
Base price callback: VA 0x5490c0, value update begins 0x54910d.
Expansion equivalents: 0x546c60 / 0x546cb0 and 0x5706f0 / 0x57073d.
The shared object-value callback appears in eight base-game panel vtables and the
price callback in three. Their original arithmetic, limits, and refresh routines
remain intact. The existing release callback at 0x531ff0 clears the held flag
at object +0x1d5c; that remains the source of press/release state.

The new .wlprept section gates these callbacks with timeGetTime. A fresh press
acts immediately, first repeat waits 400 ms, later repeats wait 120 ms. Timers
also restart when the receiving panel or action/direction changes. Each call
can perform at most one action, with no accumulated repeats after a stall.
Unsigned elapsed subtraction handles clock rollover. No simulation-speed or
frame-count value enters the new timing. Only the old counter prefixes are
replaced. Ten obsolete HIGHLOW relocations are neutralized per executable.

tools/verify_button_repeat.py executes the actual injected x86 thunks with
mocked clock and continuation callbacks at two image bases: 312 checks per
game passed. Covers dense events, first and later repeat boundaries, rapid
release/repress, different panels/directions, stalls, rollover, register and
stack preservation. Checks every existing PE section for unrelated changes.
This is native code verification; the complete GUI behavior needs an in-game
test of work areas and entrance/shop prices. User runtime testing subsequently
confirmed price +/- works, but work-area toolbar +/- does not use these handlers.
The earlier work-area attribution was incorrect; see toolbar-repeat.md for the
separate toolbar handler and follow-up patch.

Installed atomically with .EXE.pre-button-repeat.bak backups.
Build and installer: tools/patch_button_repeat.py [--install].

SHA256:
- WLP: 8e967b4baa6bcd1d92cb5365d569ba4264b42fcadce9dfa009485b97e69f0f5d
- WLPADD1: e55b3ab73ab532c32122072b94360f27b0e3444925078dbdb4329980f0e11b66

REA evidence for the old handlers is retained in button-repeat-evidence.json.
