# Experimental startup audio recovery

User reports no sound until one Alt-Tab cycle after loading, with weather working.
The current DirectDraw log does not establish the runtime audio suspension state.

In v6, 0x6735a0 takes a focus-state argument: 1 sets audio engine +0x90
to 1 (suspended), 2 clears it. WM_SETFOCUS / WM_KILLFOCUS routes at
0x671b54 / 0x671b8c and graphics callbacks at 0x6463da / 0x646423 use it.
0x673610 refuses to create playback while +0x90 is nonzero.
Startup at 0x64519e initializes audio, and 0x6451b0 enables it via
0x673670, which changes the enable bit but does not reconcile suspension.

`tools/patch_audio_startup.py` builds `WLP_widescreen_v7_audio_test.EXE`
from verified v6. It wraps the startup enable call, forwards its argument,
and invokes the existing focus-regain audio routine once if GetActiveWindow
returns the graphics HWND at 0xe52fb0. Registers, return value and flags are
preserved after the original call; the wrapper consumes the original argument.
Addresses in the new thunk use module-relative offsets.

This is a hypothesis test, not a confirmed fix. It does not recover a suspension
that occurs later during loading. GetActiveWindow checks the calling thread's
active window, not the desktop foreground window. It is used only at startup.
Existing focus loss / regain handlers are unchanged.

Static validation: PE parses; disassembly confirms branch/call destinations and
stack forwarding; all existing bytes match v6 except the five-byte startup call
and required PE header fields / new section header. Runtime testing is pending.
No installed files were changed. Keep v6 for rollback.

Output SHA256: 6c206ccc4458399047bb5c8d543dab022b68f4daf65db328e65b325b466f0b2e

## v7 runtime result and diagnostic build

User confirmed v7 does not change the behavior. Starting windowed works;
starting fullscreen requires Alt-Tab or a windowed/fullscreen cycle. Original
Pictures.cont has the same issue. The v7 active-window guard may have skipped
recovery, or suspension may occur later, or playback needs a full backend restart.
The result does not identify which explanation is correct.

`tools/trace_audio.py` builds `WLP_widescreen_audio_diagnostic.EXE` directly
from v6. It logs entry into focus-state changes, sound-enable changes, backend
playback start and backend playback stop with `WLP_AUDIO` messages through
OutputDebugStringA. Each event records enabled, suspended, initialized, and
playback flags before the original routine. Arguments 1/2/other are logged for
focus and enable events. All registers, flags and the stack are restored before
executing the displaced instructions. This build changes no audio policy.

DirectSound backend preference is confirmed in 0x679b50: flag 2 tries DirectSound
first, with flag 1 permitting WaveOut fallback. 0x679d10 starts the selected
backend and 0x679d70 stops it. 0x67bd50 creates DirectSound and calls
SetCooperativeLevel on the engine HWND with default level 2; 0x67b770 creates
and starts its primary and secondary buffers.

Diagnostic SHA256: 5baadc650a9dff01489e695d41497062b20da504d4038069e2c90347572c7d26
Static checks confirmed PE parsing, hook destinations, displaced instructions,
and preservation of all other v6 bytes except required section/header metadata.
No installed files were changed; runtime trace remains needed.

For one diagnostic run, use Heroic environment variables:

```
PROTON_LOG=1
WINEDEBUG=+timestamp,+pid,+tid,+debugstr,+dsound,+winmm,+mmdevapi
```

Start fullscreen, load a map and wait a few seconds while silent. Alt-Tab out
and back once, verify audio, then quit. Preserve /path/to/user/steam-default.log
before another launch overwrites it. Restore previous logging variables afterward.

## Captured runtime and v8 hypothesis test

Saved copies: `analysis/audio-diagnostic.log` and
`analysis/audio-diagnostic-after-alt-tab.log`. The supplied file grew during
analysis; the later snapshot includes the regain event.

Trace timeline (Wine timestamps):
- 5502.498: audio enabled, initialized=1, suspended=0; playback starts.
- 5502.777: focus regain with playback=1, suspended=0.
- 5506.749: focus-loss argument=1, sets suspension and stops playback.
- 5514.819: another focus-loss argument=1, already suspended.
- 5534.874: focus-regain argument=2, clears suspension and restarts playback.
  The game's audio worker then repeatedly locks/fills the DirectSound buffer.
- 5537.257: focus loss stops playback again.

The first trace was sent just after loading without sound; user then supplied
the trace after Alt-Tab. This supports a later focus suspension rather than a
failure to initialize DirectSound. The trace does not establish the source of
the startup focus loss. The audio worker also reports a scheduler critical
section wait at 0xe51860; it subsequently progresses after regain, so this alone
does not establish a permanent deadlock.

`tools/patch_audio_foreground.py` builds `WLP_widescreen_v8_audio_test.EXE`
from v6, not from v7 or the diagnostic build. It hooks the main event pump
epilogue at 0x644295. If sound is enabled, initialized and suspended, it checks
the desktop foreground HWND via GetForegroundWindow, resolved once through
existing GetModuleHandleA/GetProcAddress imports. If the HWND equals the game
graphics HWND, it calls the existing audio focus-regain routine. A reentrancy
guard protects nested message processing. Other windows leave suspension alone.
The normal enable bit, audio-volume settings and focus handlers are preserved.

This remains a runtime hypothesis test: static validation confirms PE parsing,
guard branches, stack/register preservation, displaced epilogue and return
destination, and unchanged original bytes except the six-byte hook and PE
metadata. The new section is writable for the API cache and reentrancy flag.
Only successful recovery emits a single WLP_AUDIO debug message. Installed
files are unchanged.

v8 SHA256: 864fd20600dd5f84d0655712f4475e55ef6f04c6f5c969d32f941e58a0ed8d18

User confirmed v8 works on 11 October 2026. Fullscreen startup sound recovery
is therefore runtime-confirmed in the user's current environment.
