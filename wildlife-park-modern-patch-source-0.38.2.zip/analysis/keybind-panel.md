# F2 keybind panel

11 October 2026. Installed in WLP.EXE and WLPADD1.EXE.

The F2 panel is now 300x500 engine pixels. The original CheatCode input,
OK and Cancel controls remain at their original positions. A key/action table
starts at y100: header and 30 shortcut rows, with 12-pixel spacing. English
captions use the installed Gold manual's Hotkeys section (printed page 42),
plus F2 and the numbered object bookmarks traced at base VA 0x519782.
The table covers documented gameplay shortcuts; internal cheat/debug actions
are not described as normal gameplay shortcuts. Num means numeric keypad.
Shift +/- changes price or work area according to the selected object.

Implementation reuses the original label; no controls or lifetime changes are
introduced. Its bounds become (10,15,270,475), and its text is an identifying
marker. Four original CALL sites redirect to a new read/execute .wlpkeys
section. Root/label bounds thunks change only the height argument. The label
setter thunk supplies the marker. The shared label drawing call recognizes
only that exact marker (including the engine's possible trailing CR/LF) and
uses the original text renderer to draw CheatCode plus 63 table cells/title.
Every other label falls through to the original renderer. Each cell receives
its own rectangle, so columns do not depend on space padding or font width.
Pointers and calls derive from the runtime image base; no new relocations.

Base CALL RVAs: 0x10868c, 0x1086fd, 0x108709, 0x1f2d67.
Expansion CALL RVAs: 0x119dfc, 0x119e6d, 0x119e79, 0x220e97.
Bounds/setter/draw RVAs: base 0x1f5fc0/0x1f2c40/0x23e430;
expansion 0x2241c0/0x220d80/0x26e300, independently checked in assembly.

REA renderer evidence ev_9ae214e07069b945844055f19acc71863e26f73a1ab58d68b860331f5a69ab3b
and wrap evidence ev_904b695edd5655eac9c68b550ddea47c54cd7839229004479dba2464d5529951
are saved in keybind-panel-renderer-evidence.json. Hopper static decompilation
was corroborated with objdump, including renderer RET8 and bounds RET16.

tools/verify_keybind_panel.py executes actual injected x86 code in a Linux ELF
with mocked engine methods. Both games passed at image bases 0x400000 and
0x10000000: height arguments, translated rectangles and strings for 63 draws,
CRLF/LF marker variants, null/empty/short/unrelated/near-match label fallback,
stack cleanup, preserved registers and flags. Rebuilding is deterministic;
all prior section payloads remain identical except the four specified CALLs.
Existing relocation entries do not touch the modified CALLs. This verifies
native assembly and ABI behavior, not font appearance or actual GUI events.
The user still needs to check F2 appearance, cheat entry, close/reopen and
return-to-launcher behavior in both games. No game runtime was launched.

Original timestamp-format binaries remain in the workspace and are backed up
alongside the installed executables as .EXE.pre-keybind-panel.bak.
All prior accepted patches remain present, including the requested revert of
the failed background mouse filter.

## German localization

The user confirmed the panel works in-game. Installed German captions in both
games, including Strg/Umsch/Entf/Leertaste/Pos1/Ende/Bild auf/ab. Strings use
CP1252 bytes for umlauts; assembler byte directives avoid UTF-8 input. English
rebuilds remain available with --language en; default is now de. Rendering code
was verified byte-identical to the confirmed English build, and every earlier
section payload is unchanged. All German string payloads were checked, and
installed hashes match the generated artifacts. No new runtime behavior was
introduced. Both resource.ini and Resource_Addon1.ini select Deu data, and no
English language folder exists in this installation. Backups of the confirmed
English panel are .EXE.pre-german-keybind-panel.bak.
