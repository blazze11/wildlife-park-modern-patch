## User-requested timestamp format installed

The user confirmed timestamp defaults work and requested
Save_Year_Month_Day_Hour_Minute_Second. Both installed games now use
Save_YYYY_MM_DD_HH_MM_SS (local time, 24-hour clock, zero-padded fields),
e.g. Save_2026_10_11_14_35_08. Milliseconds and parentheses are removed.
The name is 24 characters. This has one-second resolution as requested;
dialogs opened during an identical clock second receive the same default.
Original string copying and saving behavior are retained.

Eight native x86 mocked executions per game passed, including zero padding,
new year/midnight, end-of-day and seconds changing, with register/stack/flags/
last-error checks at two image bases. Original section payloads unchanged
except the save-dialog CALL, PE bounds and relocation overlap checks passed.
Backups: .pre-save-format.bak.
Base SHA-256: 45c4b1861c5ede62bcf4a8b9c466d48e33d75de7774e18823ff67bbbeab848f8
Expansion SHA-256: 66694a6a20d1e5d298de65d2efcdcd9a5c016c2bd25c94920f1496d98bb8a566

## Timestamp defaults replace failed numbered-file detection

User runtime test confirmed that Save(1) prefills correctly but is repeated
even after it is saved. The relative GetFileAttributesA check did not detect
the real save location; the exact location mismatch is not established. The
user requested timestamps instead. Both installed games now use the timestamp
variant (`--timestamp`), rebuilt from the preceding lifecycle builds so the
numbered filename checking code is removed.

Default format: Save(YYYYMMDD-HHMMSS-mmm), e.g.
Save(20261011-143508-123). GetLocalTime supplies local year/month/day/hour/
minute/second/milliseconds each time the dialog opens. The 25-character ASCII
name avoids Windows filename separators and includes milliseconds to distinguish
closely spaced dialogs. The field stays editable; accepting follows the original
string-copy setter and save routine. No save files or configuration were edited.
The timestamp is not a mathematical uniqueness guarantee if the clock repeats
an identical millisecond, but normal sequential save dialogs receive new names.

Eight actual x86 executions per game with mocked time/dialog APIs passed at two
image bases. Fixtures cover zero padding, midnight/new year, 999 milliseconds,
and two timestamps one millisecond apart. ABI/stack/register/flags/last-error
preservation, prior section payloads, hook relocation exclusion and PE bounds
passed. Runtime save/reload remains for user verification.

Previous numbered builds: .pre-timestamp-save.bak.
Installed SHA-256:
- Base: d5aa867731c276782ffbc0cd801eb87017dfcfa41d82dce9af5cfd7b13055d3b
- Expansion: 084165a62fbe28e5076df882ce172033dd9a17d3865c48779ceede07fc17e886

# Numbered default save names

Both installed games now prefill the save-name dialog with the first unused
Save(n), starting at 1. The player can accept using controller controls or edit
the text. The wrapper checks Save(n).sav using GetFileAttributesA in the current
directory, matching the game's relative filename passed into its save writer.
Existing entries (including directories) are skipped. Only file/path-not-found
errors permit a candidate; other errors retain the original remembered-name
initialization. Opening/cancelling the dialog does not create a save file.

The hook replaces only the dialog initialization CALL: base RVA 0x137cef,
expansion 0x14cb5f. Original string-copy setters are 0x120b50 / 0x1343b0 and
match byte-for-byte after normalizing their relative calls. It builds a temporary
three-pointer game string (begin, end, allocation-end) and calls that original
setter inside the wrapper's frame. The original modal dialog, confirmation,
filename normalization/extension, serialization and overwrite handling remain
unchanged. Each opening chooses a new free name, rather than automatically
reusing the last saved name.

REA Hopper static evidence: SaveName string
ev_008f77a02d5d11f741b0ee15bc8bf1080e7a8bdd9c269571ba7ae139a5c848d3;
dialog, setter and saving decompilation
ev_e3c1b3828231731b4941d53d7c23c046c77236375ec89defe8d6f8d42a9f1f0f.
Disassembly corroborates the string layout and precise call sites. Decompiled
register/stack typing is imperfect; the patch uses the assembly calling convention.
The REA session has been closed.

Verification: 12 actual x86 executions per game with mocked Win32/file and
setter APIs in a temporary Linux ELF. Covers missing first slot, existing slots,
1/2/10/100/1000 numbering, non-not-found error fallback, original string layout,
EAX return, registers, flags, last-error and stack cleanup, at two image bases.
The sandbox blocked 32-bit syscalls, so these tests ran with approved escalation.
They did not run the game or create saves. Original section payloads are
unchanged except the five-byte CALL; PE bounds and relocation overlap verified.
Actual UI behavior and save/reload on Proton remain unverified pending user test.

Build: tools/patch_default_save_name.py
Verify: tools/verify_default_save_name.py
Installed backups: .pre-default-save-name.bak (preceding mouse lifecycle builds).
Base SHA-256: 76274ab130487af34b8eb5c36f4ecd315decd83eaea5f57e260bd0b9788ded40
Expansion SHA-256: 03f253ff99ec46f8150eb554840ba2041dff4261ac5ea8a34486a35fa597d0c7
