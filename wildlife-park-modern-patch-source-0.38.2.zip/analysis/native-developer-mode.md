# Native developer mode — 0.32.0

**Superseded by 0.33.0 at the user's request.** Developer activation is removed; the current build uses 0.30.1 plus an isolated F2 theme-cycle button. See [theme-cycle.md](theme-cycle.md).

Built directly from the immutable 0.30.1 executables. The rejected 0.31 HUD and console are not included.

After restarting either game, open F2 and click **Entwicklermodus: Aus** to enable the native mode. The caption becomes **Entwicklermodus: An**; click again to disable it. The flag starts at zero in both executables and is not persisted by this patch. Opening and closing F2 does not change the flag; reopening refreshes the caption from its actual value. Existing weather and cheat controls remain.

## Findings and limits

Both games retain a byte-sized native developer flag: preferred VA 0xCAF1B4 in Wildlife Park, 0xE3B47C in Wild Creatures. It is separate from the cheat-mode byte. Static examination of the exact 0.30.1 binaries confirms it gates native keyboard and editing behavior. This is an existing game facility, not a replacement debug overlay or command console.

The base game's native input routine 0x4088D0 gates F5, F7 and F9 with this flag. F5 calls 0x409A20, cycling five native states; F7 calls 0x409AC0, cycling four states after a pause-related call; F9 invokes native mode transitions through 0x401E30. Their visible gameplay effects have not been established by an in-game test. These keys can behave differently while developer mode is on. Native editing paths can change terrain, animal values and money; disabling the flag does not undo actions performed in that mode or reset its other state variables.

REA evidence from the 0.30.1 base executable is retained in native-developer-rea-evidence.json:

- ev_c69c79cd3e84297042316a9ec65e31403c9047045bfe15d0a0a5ad1a4cc9c7fc: native key polling and developer flag gates at 0x4088D0.
- ev_be865dd03ad7421e600db02734338bb409d4f21bb9af021d577a2e2e7183eb28: five-state cycle at 0x409A20.
- ev_f9732fcc89a4140a76c582cfb91a1490a42adcfa124f683fa80260809ad2e90f: four-state cycle at 0x409AC0.
- ev_1d052f87930c3d43eea187359756f992bda3296dc6fc396f8698ee5090be96f7: 32 analyzed direct references to the native flag.

These are shipped-artifact static observations from Hopper. The provider does not expose complete function body ranges; decompiled types and arithmetic remain inferred. Targeted GNU objdump disassembly independently confirms the flag read and keyboard bypass in both games at 0x519768 / 0x52BF48. Earlier bounded investigation is in developer-leftovers.md. No claim is made that every developer feature has been identified or gameplay-tested.

## Implementation and verification

One native button is appended to the F2 object's allocation, chaining its existing weather constructor, attachment, detachment and destructor. The F2 window grows from 300x500 to 300x530, with the toggle at (10,475,270,20) and the close button moved from y=475 to y=505. The shortcut table and existing controls retain their positions.

The callback normalizes the native byte to 0 or 1 and changes only that byte. The original input path bypasses the normal F2 menu while developer mode is enabled. An image-relative trampoline therefore routes only the exact F2 event word 0x3C00 to the existing normal menu dispatcher, preserving ordinary developer input and the original byte load for other keys. Its replaced absolute-address relocation is removed; all appended code resolves addresses relative to the actual image base.

Native 32-bit engine mocks pass for both executables at image bases 0x400000 and 0x14000000. They exercise constructor, attachment, listener registration, toggle on/off, neighboring-byte isolation, noncanonical true values, caption refresh on reopening, detach, destruction and duplicate-destruction guard, stack ABI, and F2 versus ordinary key routing. Section preservation checks verify that existing executable sections remain byte-identical except for declared hooks, allocation/layout operands and the replaced loader relocation. These mocks do not establish actual game rendering or event delivery; in-game confirmation is pending.

Rebuild and verify with `python3 tools/patch_native_dev_mode.py --verify`. The native ELF harness may require permission to execute outside the Codex sandbox. The one-shot installer requires exact 0.30.1 live/current files, matching candidate hashes and successful native verification records. Installation hashes and baseline backup paths are in native-developer-installation.json. All 325 other installation files were verified unchanged during installation.

## Follow-up: observed keys and remaining facilities

User gameplay observations (2026-10-13) clarify the native rendering controls:

- F9 cycles asset/theme presets, including jungle and desert. This replaces the earlier vague description of internal game/editor states.
- F5 cycles ground rendering settings, including checkerboard and hidden ground.
- F7 hides objects or changes their brightness.

These are user-observed behavior, not inferred from decompiler arithmetic. No further executable change was made during this follow-up.

Additional bounded inspection of all 32 reported direct developer-flag references in the base 0.30.1 executable, and callers of its getter at 0x4663D0, found:

- Selected-object relationship text: native code builds FOLLOWING, FLEEING and INTERACTING labels and sets highlight bits on related objects (0x45CEB2 and 0x466734). Text is assigned to the gameplay owner's embedded label string at +0x40C. This is potentially useful for animal AI investigation. The corresponding label object at owner +0x2F0 has visibility initialized from the developer flag during UI construction at 0x510B17. The current F2 toggle only changes the flag; it does not refresh that pre-existing label's visibility. Runtime visibility and complete interaction semantics remain unverified.
- Interaction-point diagnostics: code constructs messages including Belegte Interaktionspunkte, used/free status and IsoPos coordinates (0x4664A8, 0x4856FD, 0x4858C2). However, it passes those messages to 0x665420, which consists solely of RET in 0.30.1. Merely enabling developer mode cannot restore this disabled output. REA ev_6bd943a6f26f40f3711658594cb8c01e4e39b7636849066ff7f2042ed42360af traces the message construction; ev_277c0d4cb0d485fa523c9c963e414eb08569363348ca1d8b9b9b64a76cd6f702 confirms the empty sink.
- Selected-object mutation shortcuts: the keyboard path shared with cheat mode at 0x51AC0D changes money by the native 10000 constant, modifies terrain bytes, and modifies multiple animal/object parameters. Animal branches refer to AnimalStarve, Underweight and Injury events. Exact field meanings and all modifier/key combinations are not fully mapped; these are editing/cheating facilities rather than performance instrumentation.
- Native UI layout adjustment: the developer-gated path near 0x56615E recognizes arrow keys, space and N with modifier mask 0x140, adjusts stored coordinate pairs by four pixels, and emits a diagnostic description through imported OutputDebugStringA (IAT 0x70423C). Control applicability and persistence are not established. This output is a debugger stream, not an in-game command console.
- Repeated developer-gated allocation branches in 0x4607E0 and the flag-getter callers relate to object/animal creation and extra editing behavior. No general-purpose console or performance profiler was established by these inspected paths.

GNU objdump/pefile observations are retained in native-developer-remaining-disassembly.txt; they are not REA Evidence. Additional REA records are in native-developer-additional-evidence.json, including an unavailable function lookup for the UI-layout path. REA ev_def94f005eae8c34b35fde6f52b7b369f1860fc08d109ab089aa8159712658f8 identifies the flag getter and analyzed caller functions. This bounded search does not rule out unrelated or indirect developer facilities elsewhere. Expansion parity for these newly described facilities has not been established.
