# Theme cycle — 0.33.0

Built directly from immutable 0.30.1 at the user's explicit request. Replaces the 0.32.0 developer-mode build. Both installed/current copies match the archived 0.33.0 snapshot; no 0.31 instrumentation or 0.32 developer activation is included.

After restarting the game, open F2 and click **Landschaft wechseln** to invoke the native theme cycle observed by the user with developer F9. Each click performs one native transition. The original F9 keyboard binding is retained from 0.30.1; this addition is accessed through the F2 button.

## Native behavior and evidence

The user observed that native developer F9 cycles game assets between theme presets, including jungle and desert. The isolated button invokes the same theme setter, without enabling developer mode or its F5/F7 rendering tests, editing controls or keyboard bypasses.

The base native F9 path reads the current world's field +0x10404C and computes 0 -> 3 -> 1 -> 0; other nonzero values transition to 1. The callback preserves that exact transition logic. It obtains the world from RVA 0xA56988 in Wildlife Park / 0xC43308 in Wild Creatures, guards a null world, and calls the native setter at preferred VA 0x401E30 / 0x401D50. The native routines perform resource and world refreshes. The order's named theme mapping was not established; this preserves the original F9 cycle rather than inventing a five-theme sequence.

REA/Hopper evidence in theme-cycle-rea-evidence.json:

- ev_75117327d8e552980c486e73d5bdf9bb0eb56c30d93b3574e9ef926df01356be: base theme setter at 0x401E30 writes the theme field, updates native resource selection and calls native refresh routines.
- ev_c51493c08fcdbda92b437b6fd9d29ad145c1f7eb1720ebbee4f3f6863f24ccc3: native resource selection at 0x433C60 updates six resource-selector globals.

Targeted GNU objdump disassembly corroborates the base transition at 0x40895D and matching expansion transition at 0x4086ED. These are static observations; user gameplay evidence establishes the original F9 feature, while actual F2 button appearance/resource refresh needs a new in-game test.

## Patch and validation

One native button is appended to the existing F2/weather lifecycle. It occupies (10,475,270,20); the F2 window is 300x530 and its close button moves to y=505. Existing controls retain their placement. Button construction, callback registration, attachment, detachment and destruction chain the accepted 0.30.1 implementation.

Both games passed native 32-bit engine mocks at image bases 0x400000 and 0x14000000. Checks cover lifecycle and stack ABI, caption setup, each native transition, other-state fallback, null-world handling, native setter receiver/argument and volatile-register clobbering, and an unchanged developer flag with neighboring-byte sentinels. The mocks do not exercise the actual game's asset reload or visible rendering. Native section preservation checks confirm unchanged existing sections except declared F2 allocation, lifecycle hooks and size operands. No keyboard hook or relocation removal is needed.

Rebuild and verify: `python3 tools/patch_theme_cycle.py --verify`. The 32-bit harness may require permission outside the sandbox. The one-shot installer requires live/current 0.32.0 hashes, reproducible candidates built from 0.30.1, and matching native verification records. Installation/backup hashes are in theme-cycle-installation.json. All 326 other installation files were verified unchanged; settings, saves and GUI assets were not modified by installation. Persistence of a theme selected through the native game routine has not been separately established.
