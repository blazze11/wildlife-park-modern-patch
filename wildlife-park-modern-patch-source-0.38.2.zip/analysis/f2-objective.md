# F2 Spielziel frame redesign — 0.37.1

The user rejected 0.36.0’s stretched panel, opaque green corners, cream text and button textures. This build returns to the accepted 0.35.2 executables as the patch source and replaces the F2 appearance with native widgets. No texture archive is edited.

## Layout

Shared GUI entry 39 is the original Spielziel frame, 524 × 378 pixels. A native picture widget renders it at those exact dimensions through the game’s original picture painter, including its color-key and clipping setup. The F2 root does not paint a flat rectangle. Background-first native widget order preserves control hit testing.

The root uses the same current-mode width/height tables and centering calculation as Spielziel: ((width − 524) / 2, (height − 378) / 2). The frame and coordinates apply equally to the base game and expansion, using each binary’s own engine addresses.

The upper area contains the existing cheat toggle, weather selector and landscape selector as white text controls. Hover changes the text to gold; the native press/click callbacks remain unchanged. The baked frame close icon retains the existing F2 close action at Spielziel’s (464, 9, 40, 40) position. The header reads “Cheats und Tastenbelegung”.

The native upper scrollbar is at (480, 50, 28, 137). All upper controls fit, so its range is zero. The lower native scrollbar is at (480, 220, 28, 115). Shortcut text occupies (30, 230, 426, 108), displaying the white column header and eight action rows. Scrolling advances one row, with a bounded range of 0–22 covering all 30 actions. The native scrollbar arrows, thumb, dragging and event handling use shared GUI entries 41 and 42. An event callback invalidates the root after scrolling.

## Implementation and preservation

The F2 allocation gains one native picture, one title label, two native scrollbars and six native image-state objects. The constructor and virtual-base destruction chain own all ten objects; detachment runs before close. Both root and button virtual tables are cloned, preserving all slots except the root/button drawing slots and the button enter/leave slots. Hover wrappers call the original handlers and preserve their return values; button drawing changes caption color and requests repaint only when it changes. Alpha/style bytes are preserved.

The existing label-render hook recognizes only the F2-specific marker. Other game labels fall through to the previous renderer, preserving gameplay UI and the accepted key-table infrastructure. No original resource indices or image payloads are changed. The 0.35.2 texture-index correction, menu switch, hover signs, theme selector and accepted 0.30.1 fixes remain.

0.37.0 is an immutable, uninstalled first draft. 0.37.1 contains the verified corrections to detach receiver, callback ABI, background widget order and caption invalidation.

## Verification and limits

Actual emitted x86 thunks execute against native-ABI mocks for both games at image bases 0x400000 and 0x14000000. Checks cover construction, virtual tables, frame selection/size, native scrollbar states, centering at 800 × 600, 1280 × 720, 1920 × 1080 and 2560 × 1440; white/gold pointer enter/leave without pressing; press independence and neighboring style bytes; first, middle, last, negative and oversized scroll values; every visible string and cell rectangle; ordinary-label fallback; native attach/detach, balanced stacks and destruction guards.

Existing-section preservation checks passed. The installer verifies candidate bytes against a fresh rebuild, checks live 0.36.0 hashes, backs up both executables, stages replacement with rollback and verifies every other game file unchanged. See f2-objective-installation.json for the inventory and hashes.

Static native evidence is retained in f2-objective-rea-evidence.json (objective setup and picture renderer). Candidate and native verification results are in f2-objective-candidate.json and f2-objective-verification.json. Mock execution verifies patch logic and native calling conventions; it does not render the game. Restart and in-game appearance/input validation are still required.
