# F2 caption vertical offset — 0.38.2

User supplied direct comparisons with the original weather buttons and requested the F2 captions a little higher. Move the shared caption inset from (4,0,112,28) to (4,-3,112,28). Both games use the same shared correction for all three F2 action labels, including state refresh after clicks.

Based on accepted 0.38.1. Exactly one byte changes per executable: the sign-extended push immediate for caption y changes from 0 to -3. The unique native bounds-call instruction sequence is verified, both source SHA-256 identities are checked, and a full binary comparison confirms every other byte remains identical. Label text, black palettes, horizontal centering, button textures, geometry and all previous behavior remain unchanged. No additional runtime test is warranted for this literal adjustment; in-game visual alignment awaits user confirmation.
