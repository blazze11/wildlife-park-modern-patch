# Focus-aware windowed mouse confinement

Rejected in runtime testing on 11 October 2026: the user reported no change in
mouse behavior. Reverted in both installed games at the user's request;
SHA-256 readback confirms the previous user-confirmed launcher-fixed builds.
The following describes the unsuccessful experimental patch, retained only
as an investigation artifact. Its mocked tests did not prove runtime efficacy.

`tools/patch_mouse_confinement.py` chains the existing post-message-pump audio
fix with a cursor update and hooks the existing audio focus-loss routine for
immediate release when the main loop suspends. Original instructions, focus
handlers and the audio recovery code remain intact.

Cursor clipping applies when all three conditions hold:

- The desktop foreground window equals the game's graphics HWND.
- The live game-world pointer is nonzero (the launcher is left unconstrained).
- The active graphics configuration has windowed bit 0x80 set.

GetClientRect obtains the playable client area; ClientToScreen maps both corners
to desktop coordinates; ClipCursor confines the mouse to that rectangle. The
rectangle updates every message-pump cycle, so moving/resizing the window is
handled. Losing focus, returning to the launcher, switching to fullscreen or
failure to obtain a valid rectangle releases clipping applied by this patch.
The routine calls ClipCursor(NULL) only when it owns an existing confinement.

The focus hook releases immediately on the existing audio focus-loss argument
1. Focus regain is handled by the next message-pump cycle. All registers,
flags, stack depth and Win32 last-error state are preserved. A guard avoids
recursive pump updates. Three user32 APIs are dynamically resolved and cached
in a writable `.wlpmous` section. No renderer depth or resolution is changed.

## Mapped sites

| Purpose | Base RVA | Expansion RVA |
| --- | --- | --- |
| Message-pump hook | 0x244295 | 0x272435 |
| Audio focus routine hook | 0x2735a0 | 0x2a11a0 |
| Graphics HWND | 0xa52fb0 | 0xc3f938 |
| Game-world lifetime pointer | 0xa56980 | 0xc43308 |
| Active graphics flags | 0xa39368 | 0xc25cf0 |

The world-pointer mapping was independently checked against each executable's
destructor code that clears the pointer. Windowed bit 0x80 follows the existing
graphics selector's dynamic windowed path.

## Validation and artifacts

`tools/verify_mouse_confinement.py` disassembles and executes the emitted x86
paths in a small instruction interpreter with mocked Win32 APIs. Fifteen cases
per build cover foreground clipping, background release, the launcher,
fullscreen, rectangle failure, empty rectangles, missing APIs, recursion guard,
cached APIs, a moved window on a monitor with a negative coordinate, immediate
focus-loss release and focus-regain argument handling. All cases check original
registers, flags, stack and last error are restored. These checks do not verify
Proton's real cursor API implementation.

Reproducibility, PE section bounds, relocation-free hook instructions, and
unchanged existing audio, focus, widescreen, enumeration and launcher-fix
sections were also verified. Installed files and backups were read back.

- `WLP_widescreen_mouse_fixed.EXE`:
  `1d6d4cee79733e36999c1d0efd85d13c5bbebdd340b43540150c6edef6dd10ea`
- `WLPADD1_widescreen_mouse_fixed.EXE`:
  `f92ee39ce6ff283376362944a89dedb7824d540c1d8e2b9901c6c0a4387a819e`

Previous user-confirmed executables are backed up alongside the installed files
as `WLP.EXE.pre-mouse-confinement.bak` and
`WLPADD1.EXE.pre-mouse-confinement.bak`.

Test after closing and relaunching: windowed gameplay edge scrolling at all four
edges; Alt-Tab to another application releases the mouse; returning captures it
again; launcher remains free; fullscreen and resolution switching still work.
