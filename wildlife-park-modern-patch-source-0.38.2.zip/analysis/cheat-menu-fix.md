# Function-key menus during cheat mode

The user confirmed PANTHERA TIGRIS enables cheat mode and showed that normal
F-key menus, including F2, then become inaccessible. This matches the original
dispatcher: base VA 0x519775 loads the cheat byte 0xcaf1d5, and the following
conditional branch sends active-mode input to 0x51a5bf, bypassing normal menus.
Expansion correspondence is VA 0x52bf55, flag 0xe3b49e, target 0x52ce09.

Installed patch intercepts that five-byte flag load. Exact internal key words
0x3c00 through 0x4400 and 0x5700/0x5800 (F2-F12) instead enter normal keyboard
dispatch at 0x5198e1 / 0x52c0c1. Existing modifier handling there is preserved.
All other key words reproduce the original flag load and continue at hook+5,
retaining cheat actions. The preceding separate debug-mode flag check remains
unchanged. The patch does not enable or clear cheat mode automatically.

The original Abbrechen callback at 0x508b10 / 0x51a280 writes zero to the cheat
byte before closing the panel. Making F2 reachable allows the player to use
that existing disable action. Enter/OK still use original activation semantics;
an empty or wrong code is not a disable action.

A new RX section .wlpcht contains position-independent routing. The old
absolute-address flag-load relocation is neutralized as IMAGE_REL_BASED_ABSOLUTE
because the replacement is a relative JMP. Every earlier section payload is
unchanged except the five-byte hook and that two-byte relocation entry.
The previous German panel, timestamp saves and other accepted fixes remain.

tools/verify_cheat_menus.py executes the actual injected x86 with mocked
continuations. Both builds passed all 65536 internal key words with cheat byte
0 and 1 at two image bases: 262144 routing cases per executable. It checks exact
menu selection, original AL-load behavior for non-menu keys, stack cleanup,
registers, flags, deterministic output, relocation removal and prior payloads.
Static assembly corroborates the original Cancel callback's clear operation.
This does not verify actual menu state or GUI event lifetimes in-game; those
checks remain for the user. Original input behavior was observed by the user;
patch behavior has only been verified in the controlled native harness.

Backups beside installed executables: .EXE.pre-cheat-menus.bak. Rebuild from
WLP_widescreen_keybinds_de.EXE / WLPADD1_widescreen_keybinds_de.EXE using
tools/patch_cheat_menus.py. Outputs are *_widescreen_cheat_menus.EXE.
