# Wildlife Park 2560×1440 experimental patch

## Findings

WLP.EXE and WLP_T.EXE are 32-bit x86 Windows PE executables of identical size (9,359,360 bytes). They differ in only four bytes. WLP.EXE already contains the user's resolution edit; WLP_T.EXE contains 1600×1200 in that slot.

The application width array starts at VA 0x0073AC4C; its height array starts at VA 0x0073AC5C. The fifth slot (index 4) is at VA 0x0073AC58 and 0x0073AC68, corresponding to file offsets 0x0033AC58 and 0x0033AC68. Code at 0x00409B77/0x00409B7D indexes these arrays when writing the Display/Resolution configuration value.

There is a second resolution lookup: function VA 0x005C64B0 iterates 87 mode indices and calls VA 0x0067EB00 to obtain width, height, and depth. It requires an exact match to all three values, and returns mode index zero if no match exists. Function 0x005C63A0 stores this index separately from the requested dimensions and recreates graphics state. This explains a concrete inconsistency in the original two-address patch; runtime tracing is still needed to prove the complete fullscreen failure path.

Function 0x0067EB00 constructs its own 87-entry table on the stack. Five 1600×1200 pairs occur in that table. The experimental patch replaces all five with 2560×1440, preserving their depth fields, instruction lengths, and mode indices:

| Width operand file offset | Height operand file offset |
| --- | --- |
| 0x0027ED9E | 0x0027EDA9 |
| 0x0027EEA8 | 0x0027EEB3 |
| 0x0027F088 | 0x0027F093 |
| 0x0027F192 | 0x0027F19D |
| 0x0027F307 | 0x0027F312 |

File offsets in the text section equal RVA for these builds; add image base 0x00400000 to obtain VA. Width operands become 00 0A 00 00; height operands become A0 05 00 00.

## First build (v1): reported crash

The user reported a crash when switching from windowed to fullscreen. The first build is not a working fullscreen fix. In the current workspace it has been renamed to WLP.EXE; WLP_.EXE has the original two-address windowed patch. Their identities were verified by SHA-256.

## Output and reproduction

`WLP_2560x1440.EXE` is a separate experimental executable. Originals are untouched. SHA-256: `271abbdd2373bdb243f4f27486532f65544dc2a78e803e89a13c1693648e5816`.

To reproduce with Python 3:

```
python3 tools/patch_widescreen.py WLP.EXE WLP_2560x1440.EXE
```

The patcher verifies the complete input SHA-256 against the two supplied builds, checks the engine operands, and refuses to overwrite an existing output.

## Runtime validation needed

Only executables are present in this workspace, so the complete game has not been launched. The patch is statically verified, not a confirmed fullscreen fix. Both inputs produce identical output; executable size remains unchanged; all five graphics pairs are verified; unknown inputs are rejected.

Copy the experimental executable into the full game installation and launch it from there. If the game requires its original executable name, back up the installed WLP.EXE before putting the experimental copy in its place. Select the resolution slot previously used for your windowed patch (the original 1600×1200 slot); menu text may still show the original label because resources have not been changed. Test windowed mode first, then fullscreen. Record whether fullscreen opens, the actual display resolution, any error or fallback, HUD alignment, mouse hit targets at all four corners, map scrolling, and save/load behavior.

This patch replaces the 1600×1200 slot rather than adding a menu option. A successful mode lookup does not guarantee that a legacy graphics backend or driver accepts the requested fullscreen mode. Aspect ratio, UI layout, and rendering coverage still need visual verification.


## Second build (v2): DirectDraw descriptors

Further tracing found that the first build changed the abstract mode lookup but left the DirectDraw driver descriptors at 1600×1200. These descriptors store maximum pixel coordinates, not dimensions: 1599 and 1199. The DirectDraw registration helper at VA 0x0068F530 adds one to both fields before matching them against enumerated driver modes. For example, the DDRAW32 enumerator at 0x00682580 registers mode index 0x55 using descriptor VA 0x00CA2D98 (call site 0x0068269F).

V2 additionally patches only the five DirectDraw descriptor pairs below to 2559 and 1439. Color depth and other descriptor fields remain unchanged. Other backends (VGA, VESA, accelerator, fullscreen DIB, etc.) have additional descriptor tables that this build does not modify.

| Descriptor file offset | VA | Depth |
| --- | --- | --- |
| 0x008A2D98 | 0x00CA2D98 | 32 |
| 0x008A3308 | 0x00CA3308 | 24 |
| 0x008A3850 | 0x00CA3850 | 15 |
| 0x008A3D00 | 0x00CA3D00 | 16 |
| 0x008A4248 | 0x00CA4248 | 8 |

Output: `WLP_2560x1440_v2.EXE`. SHA-256: `d3aac4a44dfa4b0232e2791ce8a898a0a675f53dad1c13910146b05a2ce16b10`.

The updated patcher accepts both original inputs and the known v1 build. All three produce identical v2 output. Verification confirmed that v2 differs from v1 only in these five dimension pairs, retains the executable size, and preserves all five depth fields.

V2 is an experimental correction for a proven table mismatch, not a proven diagnosis of the reported crash. No runtime crash address or stack trace was available when it was generated. Test direct fullscreen startup separately from windowed-to-fullscreen switching and provide the error text, faulting module/address, and Windows or Wine environment if either fails. Use the complete game installation; preserve the existing executable backup.

Reproduce v2 with:

```
python3 tools/patch_widescreen.py WLP_.EXE WLP_2560x1440_v2.EXE
```


## Configuration and enumeration limit

Supplied Config.ini requests useDirectDraw=1, useWindowed=1, Resolution=2560, 1440, ColorDepth=32, useVarColorDepth=0, useFullscreenDIB=0. WLP.ini identifies Wildlife Park.exe as the application main executable; Version.ini reports version 1.18, English. These are configuration data, not instructions.

DirectDraw enumeration function 0x0068F330 calls EnumDisplayModes via COM vtable offset 0x20 and callback 0x0068F370. The callback compares the collected count against 0x46 (70) at VA 0x0068F376. Upon reaching that limit it returns zero, cancelling enumeration. Modes use 20-byte records starting at VA 0x00E552D8. This is a possible reason a valid modern mode is absent from the game's supported-mode list, but has not been confirmed in Proton. Increasing the count without checking storage capacity would risk overwriting adjacent globals and is not a safe patch. A diagnostic trace should establish the modes received and whether the limit is reached before altering this logic.

The DirectDraw matching helper 0x0068F530 requires matching width, height and classified pixel depth; it additionally evaluates available memory and page count. Thus the unsupported-mode message does not establish that dimensions alone caused rejection.


## Proton log and v3 enumeration filter

steam-default.log reports 114 modes (38 each at 32, 16, and 8-bit). Target 2560×1440 appears at positions 38, 76 and 114. Callback 0x0068F370 cancels on callback 71, retaining 70 modes. Thus the 32-bit target reaches the table, while 16/8-bit targets are excluded. The log later sets 800×600×16 and crashes on activation loss at 0x0068EBF6 with ECX=0, called from 0x006802B7. This is a null graphics-context access; the filter does not directly repair that crash.

V3 adds an executable PE section .wlpmode with a width filter for 320,640,800,1024,1152,1280,1600,2560. It redirects seven bytes at 0x0068F376 into the filter. Irrelevant widths return continue-enumeration without consuming record capacity; accepted widths still obey the original 70-record limit. The stub uses relative jumps and no absolute addresses, changes only volatile EAX/flags, and preserves callback stack cleanup. No existing table storage is enlarged.

A replay of the supplied 114-mode enumeration retains 57 records and includes all three target depths. Static checks verify PE structure, branch destinations and bound behavior at counts 0,69,70. Runtime behavior remains unverified. This addresses a demonstrated missing-mode issue for 16-bit fullscreen, not the unexplained 32-bit rejection or the null-context crash directly.

Output WLP_2560x1440_v3.EXE SHA-256: 3942a2372e425ea0431cfed2ba0cf925618eabdbed94df16d8f455e9bbbb16ef. Reproduce using python3 tools/patch_mode_enumeration.py WLP_2560x1440_v2.EXE WLP_2560x1440_v3.EXE. Originals and installation were not modified.


## UI screenshot and asset evidence

User screenshot is 2560×1440 (displayed at 2048×1152). Bars occupy the centered 1600-pixel region, with 480-pixel margins on both sides. The grey uncovered region is reported as #c5c2c5. Installed Int/All/Pictures/GUI.alb contains apparent image records at offsets 0x100, 0x140 and 0x1B00; little-endian 16-bit fields at record+1/+3 read width/height 1600×115, 1600×50 and 1600×49. These support fixed-width artwork as the reason for the margins, though mapping individual records to live UI components still requires decoding/render tracing. No UI or weather patch has been made. The screenshot does not establish the weather rendering boundary.


## Alt-Tab freeze: captured restore loop and experimental v4

Capture supplied at attachment 41a7a738-cb52-4014-9400-7d3d88cd657b shows focus loss at timestamp 301.037, lost primary surface at 301.039, focus regain at 303.245, and repeated failed Restore calls about every 200 ms. Warning: Display mode format 0x77 does not match surface format 0x74. The surface is RGB565 (16-bit), while the restored desktop format differs. At 306.034 another thread times out waiting on critical section 0x00E51860 held by the main thread 013c. Code 0x00680090 loops over surface Restore and sleeps 200 ms on failure; no display-mode reapplication is visible in this loop. This supports a focus-recovery hang, distinct from the earlier null-context crash.

Gameplay display requests explicitly push 16-bit color at VAs 0x005039EA, 0x00504EB3, 0x005050C5, 0x005054DB, 0x00505B60, 0x00505EB1, 0x0050650C and 0x00544D69. V4 changes only these eight immediate operand bytes to 32-bit. This retains v3's enumeration filter and targets the lost-surface format mismatch by matching gameplay depth to the configured 32-bit mode. No restore error checks were disabled.

Output WLP_2560x1440_v4.EXE is experimental; runtime behavior and pixel conversion correctness are not yet verified. Static validation confirms only the eight requested operand changes, unchanged file size and eight valid PE sections. Reproduce with python3 tools/patch_color_depth.py WLP.EXE WLP_2560x1440_v4.EXE when WLP.EXE has the verified v3 SHA-256. Keep v3 as a fallback. Test menus, gameplay colors, weather, fullscreen/windowed switching, Alt-Tab and focus regain.


## V4 rejected; experimental V5 focus recovery

User confirmed V4 allows Alt-Tab but corrupts rendering (duplicated world and incorrect colors). This shows the gameplay renderer cannot be switched to 32-bit by changing display requests alone. V5 is rebuilt from verified V3, reversing all eight V4 depth edits when given V4 input.

V5 hooks the primary-surface Restore call at VA 0x006800EE in the focus-recovery loop. Before Restore it reapplies IDirectDraw2::SetDisplayMode using the existing graphics context's width/height maximum coordinates plus one and its original depth. It preserves registers/flags and then executes the original Restore call and existing HRESULT handling. Code resides in a new .wlpfoc section and computes the existing global DirectDraw2 pointer position-independently. It does not disable restore failures or fix unrelated null-context paths.

Output: WLP_2560x1440_v5.EXE; SHA256 e70fe4cc2fcf47f505ae4550c4d71b936faef8330026aef1993cca5a8f6528bb. Static checks verify reverted 16-bit operands, branch destinations, pointer arithmetic and valid section layout. Runtime behavior remains unverified; test rendering first and Alt-Tab second. Installed executable and GUI.alb were not modified.

## V6: four widescreen options and matching labels

User subsequently confirmed V5 fixes rendering, Alt-Tab, fullscreen/windowed switching speed and resolution switching. V6 uses that verified V5 binary as its baseline. It replaces the four resolution slots with 1280x720, 1280x800 (16:10, Steam Deck), 1920x1080 and 2560x1440.

The width/height arrays at VA 0x0073AC4C/0x0073AC5C and 20 DirectDraw descriptors (four choices across five depths) are updated. A .wlpwide thunk at VA 0x00E99000 hooks the indexed abstract-mode lookup at 0x0067F324, rewrites the matching stack entries using MOV instructions, executes the displaced MOV, and resumes at 0x0067F32B. No depth fields change.

Options label getter calls at 0x0054434F, 0x00544374, 0x00544399 and 0x005443BE now return position-independent ASCII strings for slots 0,2,1,3 respectively; the menu uses a two-by-two grid. This preserves localized resources while correcting resolution numbers. The bounded enumeration filter replaces allowed width 1600 with 1920. All seven complete 114-mode enumerations in the supplied trace retain 66 entries out of the 70-entry capacity, including all four requested modes at 16-bit depth. Different host mode inventories still require runtime testing.

Output WLP_widescreen_v6.EXE SHA256 6c7792ffdf3fd93a24a540bd2c73554def617201b181a1389b08e800b2a0efee. Reproduce with python3 tools/patch_resolution_choices.py WLP_2560x1440_v5.EXE WLP_widescreen_v6.EXE. Static checks verify reproducibility, all 20 descriptor/stack-table pairs, all four label thunk pointers, valid ten-section PE layout, and unchanged V5 focus recovery code. Runtime testing of V6 remains pending. Installed files, existing builds and GUI.alb remain unchanged.
