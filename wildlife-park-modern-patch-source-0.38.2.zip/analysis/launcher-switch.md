# Main-menu game switch — 0.34.0

The user clarified that “launcher” means the game's own main menu and provided a screenshot of the base game's seven-button jungle menu. Version 0.34.0 installs a native button in the lower-left corner (client x=30, y=540, width=232, height=38). Wildlife Park's button says **Wild Creatures**; the expansion's says **Wildlife Park**. The original menu rows keep their positions.

The build starts from immutable, accepted 0.33.0. That version was built directly from 0.30.1 and adds the working F2 Landschaft wechseln button. All previous sections and their headers are preserved except four declared relative call hooks per executable. A single image-relative `.wlpswap` section contains the new control, callback and storage. No developer-mode activation is added.

The callback obtains its own executable's full path, replaces the final filename with the sibling executable, resolves CreateProcessA from kernel32, and launches it with an explicit application path and inherited working directory/environment. Spaces need no shell quoting. It closes both returned process handles and uses the same menu result (6) and close operation as the native Beenden button. Failed path/API/process calls display an error and leave the current menu open; repeated successful events are ignored.

The control belongs to the main-menu root. It mirrors the original main buttons' visibility changes during the load dialog. Other native modal screens retain their normal input blocking. The new button is detached and destroyed before the main root's native destructor; its storage is separate from the original object layout. Actual visual appearance and modal interaction still need game validation.

## Evidence and ABI

Primary REA/Hopper evidence is retained in `launcher-switch-rea-evidence.json` and `launcher-switch-addon-rea-evidence.json`, bound to the archived 0.33.0 executable hashes. Base main-menu setup: `ev_f0f8009248acc42ccf63ffa80e8d70d8b86267ba6ec1d44d17193a126b04aea7`; destructor: `ev_a3b1f24c9575da25a0a0583ba49669777fe55e15e62dd2e922fe41e6ef53a01c`; dispatcher: `ev_a741a855db8931d36941626be57e0e011940d547bf95d7a4a25812bbe386441a`. Expansion setup: `ev_bd91443fc2581213517358d659122098cc795adb8b57d2f0d1093dfe8b69a614`; dispatcher: `ev_25d7c89560f8c8ab1bcf9bf740cb3f5486f6f73f7f0c2daa12675e085b976950`.

Hopper does not expose complete native function-body ranges, and its inferred signatures are unsuitable for determining the ABI here. Focused GNU objdump disassembly independently established the thiscall setup's `ret 4`, callback's `ret 8`, register record's six stack arguments, deleting-destructor callsite and visibility loops. These are static observations, not gameplay execution.

Preferred-base addresses (image base 0x400000):

| Operation | Wildlife Park | Wild Creatures |
| --- | --- | --- |
| Main setup | 0x53A870 | 0x54EF10 |
| Setup call hook | 0x504F0A | 0x5155D1 |
| Destructor call hook | 0x53A370 | 0x54E9E0 |
| Native main dispatch | 0x53C920 | 0x550FD0 |
| Native close | 0x5EC590 | 0x61A0F0 |
| Visibility hooks | 0x53C99A / 0x53CD99 | 0x55104A / 0x551457 |

Focused import and startup disassembly also found FindWindowA checks. Their names differ: Wildlife Park checks its own Wildlife Park title; the expansion checks Wild Creatures / Wildlife Creatures titles. No mutex/event singleton imports were present in the inspected import tables. This supports the cross-game launch design, but does not substitute for a live Wine handoff test.

## Verification and installation

`python3 tools/patch_launcher_switch.py --verify` reproducibly builds and executes the exact appended 32-bit code with engine/Windows API mocks at image bases 0x400000 and 0x14000000. It checks native control construction/attachment/destruction, registration arguments, bounds, owner guards, repeated events, menu recreation, visibility, Windows and forward-slash paths with spaces, all process arguments, zeroed STARTUPINFO, handle cleanup, native quit result, failure preservation, stack balance and callee-saved registers. The local sandbox blocks 32-bit harness execution (SIGSYS); the checks passed using approved execution outside it. These checks do not execute Wine or the actual game UI.

`launcher-switch-verification.json` binds the successful checks to candidate/code hashes. `install_launcher_switch.py` then verified current live 0.33.0 bytes, created backups under `archive/game-backups/0.33.0/pre-launcher-switch`, installed both verified executables atomically, refreshed current/version metadata and confirmed all other 326 installation files unchanged. Saves and configuration were unchanged. See `launcher-switch-installation.json` for installed hashes. Restart is required; menu appearance and actual game handoff await user validation.
