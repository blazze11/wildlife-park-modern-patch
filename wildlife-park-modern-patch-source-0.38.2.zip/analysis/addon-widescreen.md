# Wild Creatures widescreen port

Installed on 11 October 2026. Static verification passed; expansion runtime
validation is pending. The base-game fixes were confirmed by the user earlier.

The expansion uses the same engine, with independently mapped addresses.
`WLPADD1_widescreen.EXE` is installed as `Int/Win32/Program/VC6/WLPADD1.EXE`
under the Wildlife Park Gold installation. Original backups are
`WLPADD1_original.EXE` in the workspace and `WLPADD1.EXE.pre-widescreen.bak`
beside the installed executable.

Four choices and matching labels: 1280×720, 1280×800, 1920×1080, 2560×1440.
The patch updates the menu arrays, 20 DirectDraw descriptors and their matching
abstract engine table entries across 8/15/16/24/32-bit modes. Gameplay retains
16-bit RGB565. It also ports the bounded mode enumeration filter, display-mode
reapplication before fullscreen surface Restore, and foreground audio recovery.
The original 70-record enumeration capacity is retained.

The installed shared GUI.alb and Pictures.cont hashes match the base game's
verified wide-bar and weather assets. GUI_AddOn1.alb contains additional icons
and has no 1600-pixel backgrounds; no expansion artwork was changed.

## Mapped locations

File offsets equal RVA at all listed patch locations. Image base is 0x400000.

| Purpose | Expansion RVA/file offset |
| --- | --- |
| Width / height arrays | 0x36ddfc / 0x36de0c |
| Abstract table lookup hook | 0x2acf14 |
| Mode enumeration hook / resume | 0x2bcf96 / 0x2bcfa0 |
| Primary Restore hook / resume | 0x2adcde / 0x2adce4 |
| DirectDraw2 pointer | 0xc3f964 |
| Label calls, slots 0/2/1/3 | 0x164438 / 0x16445d / 0x164482 / 0x1644a7 |
| Original label getter | 0x216d50 |
| Audio message-pump hook | 0x272435 |
| Audio object / regain callback | 0xc2f0b8 / 0x2a11a0 |
| Main HWND | 0xc3f938 |
| GetModuleHandleA / GetProcAddress / OutputDebugStringA IAT | 0x334134 / 0x334164 / 0x33422c |

The final DirectDraw descriptors in each group are 0xa2f1e8 (32-bit, index 85),
0xa2f758 (24-bit, index 70), 0xa2fca0 (15-bit, index 40), 0xa30150 (16-bit,
index 55), and 0xa30698 (8-bit, index 25). Descriptors are 80 bytes apart.
Disassembly confirms the DDRAW32 registration uses VA 0xe2f1e8 with index 85;
other similar descriptor arrays belong to different backends and are untouched.

## Reproduction and verification

```
python3 tools/patch_addon_widescreen.py WLPADD1_original.EXE output.EXE
python3 tools/verify_addon_widescreen.py WLPADD1_original.EXE output.EXE
```

The patcher requires the complete original SHA-256 and refuses existing outputs.
Verification checks deterministic output, all 20 engine/driver mappings and
depths independently through original disassembly, menu arrays, label thunks,
hook destinations, section bounds/alignment, and absence of overlapping
relocations. The injected enumeration, focus and audio code was disassembled
and its continuation addresses and global references checked. Generalizing
the shared audio builder still reproduces the base game's final executable
byte-for-byte. Installed bytes and backup bytes were read back and verified.

Original SHA-256:
`d3506449f81cc1358a140fa53e1512c01d04d8d5f71d51f27cb5ffee683f1250`

Patched SHA-256:
`bd5208c96fe99bbbc7b3e38df491df3223869ca33863aa4d7116ef8b5cd6f938`

Test the expansion through its usual Heroic launcher: four options and actual
resolution, new/load game, fullscreen/windowed switching, Alt-Tab and audio.
No expansion gameplay or Proton launch was performed by the patching agent.
