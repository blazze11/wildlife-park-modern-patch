# Work-area toolbar repeat correction

User runtime evidence: previous patch fixed price +/- but did not fix
Arbeitsbereich vergrößern / verkleinern. The earlier attribution of the numeric
object-value handler to these toolbar buttons was incorrect.

Static trace of the separate path in the base game:
- 0x5132d0 receives toolbar events. After validating the enabled button, the
  counter at 0x513308 handles first press and repeated events (+0x4c).
- Like the previous numeric callback, this counter waits 16 events, then
  permits every second event, irrespective of actual elapsed time.
- 0x51342d calls 0x5141e0, which resolves the button to an action and calls
  dispatcher 0x45e600 at 0x5144b7.
- The dispatcher calls work-area increase 0x45e360 at 0x45e8cf and decrease
  0x45e4b0 at 0x45e8e3. These update selected-object radius at +0x92 by one.
- Expansion equivalent toolbar hook is 0x525338; its matching original
  counter, repeat marker, and continuation bytes were verified.

The new .wlptbar section replaces only 12 bytes at the counter entry. It
uses timeGetTime, permits an immediate first press, waits 400 ms for a held
repeat, then 120 ms between repetitions. Root and button identity restart
the timer. Rapid fresh presses remain immediate. Clock rollover is handled
using unsigned subtraction. Missed repeats are never replayed in a burst.

This is the shared toolbar hold handler, so its timing also applies to other
toolbar buttons that deliberately repeat. Original button validation, action
resolution, limits, press side effects, and return epilogue remain intact.
Two obsolete HIGHLOW relocations are neutralized per game. All existing PE
sections, including .wlprept (the confirmed price fix), remain byte-identical
except the new hook and those relocation entries.

tools/verify_toolbar_repeat.py executes the actual hook and injected x86
code at two image bases with mocked clock/action continuation and original
return epilogue. 196 checks per game passed: dense events, both delay
boundaries, rapid presses, direction/panel changes, long stalls, rollover,
ABI preservation, and all prior sections preserved. This verifies timing
code, not complete in-game GUI behavior; the user subsequently confirmed the work-area buttons are fixed.

Built/installed by tools/patch_toolbar_repeat.py [--install], atomically with
.EXE.pre-toolbar-repeat.bak backups containing the working price patch.
SHA256:
- WLP: fe320e05f133d507bab1f780832f8f7d6adac0f08fa58d2b3eb0c2fb6698041a
- WLPADD1: a3b7dc7b16453fc1d2af9ed28152e8ed0236f7192f3ac2b179efee4eb6c205ba

REA decompilation evidence: toolbar-repeat-evidence.json. Native callbacks
are statically derived; the successful price confirmation is user runtime
evidence, and the user subsequently confirmed work-area success.
