# Weather overlay: confirmed code and resource mapping

Analyzed WLP_widescreen_v6.EXE, SHA256 6c7792ffdf3fd93a24a540bd2c73554def617201b181a1389b08e800b2a0efee.
All addresses below are Ghidra virtual addresses at image base 0x00400000.

## Confirmed drawing path

- 0x00412681 checks the LodWettereffekte boolean at 0x0073AC6F.
- 0x004128C2 tests renderer +0x4005A (rain overlay enable).
- 0x004128CC–0x0041290C looks up animation descriptor 0x00CAF550 using 0x00419CF0, sets destination clipping to the framebuffer width/height, then draws it at (0,0).
- 0x0041290F tests renderer +0x4005B (snow overlay enable).
- 0x00412919–0x00412959 performs the same lookup/draw for descriptor 0x00CAF570. Its final call at 0x00412959 is indirect through the drawing object's vtable +8, with the image pointer and two zero coordinates. No scaling dimensions are passed.
- 0x00411760 initializes the rain descriptor: resource ID 999, entry 5, frame 0, last frame 9.
- 0x004117C0 initializes the snow descriptor: resource ID 999, entry 6, frame 0, last frame 9.
- 0x00412400 increments/wraps both frame indices over 0..9.
- 0x004EC2C0 dispatches weather state changes and updates these renderer flags. For example, 0x004EC409 enables snow and 0x004EC420 calls the frame advance routine. This controller is reached from 0x004EB064.

## Confirmed resource dimensions

Pictures.cont contains Misc.alb as directory entry 294 (zero-based). Archive header: record size 328, count 5569, directory offset 0x41C, payload offset 0x1BE364. Record name begins at record +44; file length is record +32. Sum the preceding payload lengths to locate this file.

Misc.alb starts at archive offset 0x0413F2D9 and is 0x14A31F bytes long. A copy is saved as Misc_original.alb in this directory; installation remains unchanged.

Its ALB header has version 200, ten entries, flags 0x210. Unlike GUI.alb's LZW encoding, these frames use sparse runs of RGB565 pixels. Both entry 5 (rain) and entry 6 (snow) have ten frames at 1600x1200, with logical raw size 3,840,000 bytes per frame. Decoding their first frames confirms the rain streaks and snowflakes visually. PNG previews are entry_5_frame_0.png and entry_6_frame_0.png; black in those previews represents skipped/transparent pixels, not an opaque black background.

This explains the original-width cutoff: the destination clip is already set to the full screen, but the overlay image ends after 1600 pixels. Changing a weather controller constant or widening the destination clip alone would not extend the artwork. A complete fix needs either larger versions of all twenty animation frames or tiling/scaling in the overlay drawing path. No weather patch has been installed or built in this investigation.

## Expanded weather archive

Built Misc_weather_2560.alb and Pictures_weather_2560.cont in the workspace using tools/expand_weather.py. Both precipitation entries now contain ten 2560x1440 frames. Original sparse spans are tiled at a 1600x1200 period, preserving the original RGB565 pixels and transparency, with repetitions cropped at the new right/bottom edges. Frame count, IDs, frame order, animation timing and unrelated metadata are retained. Width, height, logical byte sizes, ALB frame offsets and relative sparse-row offsets are updated.

Sparse row-table offsets are relative to the address of each corresponding four-byte table entry. Each two-byte span command stores the skip in its low byte and literal pixel count in its high byte. Skip-only commands can span long transparent gaps. Rows end with a zero command. Decoder validation consumes every byte of each expanded weather frame and confirms the original upper-left 1600x1200 pixel region is unchanged.

The complete container replaces only Misc.alb and its directory file-length field. Static verification confirms all twenty weather frames decode correctly, all 59 other Misc frames and metadata are unchanged, and all 5,568 other archive members are byte-identical. See verification_2560.json. PNG previews show transparent regions as black for viewing.

Misc_weather_2560.alb SHA256: dbf3cc6a74dfa6f5fa9494464d966ae8e99647ffe17dc8a8a6f9ff0a85293465. Complete archive size: 517,052,329 bytes. Install by backing up Int/All/Pictures.cont and copying Pictures_weather_2560.cont there as Pictures.cont. No executable changes are required. Runtime testing remains pending; test snow, rain and resolution switching including 1280x800. Installed files have not been modified.

## First container rejected; corrected V2 offsets

User reports that Pictures_weather_2560.cont stalls the loading screen. Investigation found a concrete archive-builder error: each 328-byte directory record ends with an absolute 64-bit payload offset at record +320. The first builder changed Misc.alb's length and moved subsequent payloads but failed to update these offsets. Its original verification compared the physical byte stream without using the stored index, so it missed this fault. Do not install the first container.

The game reads the stored offset in the image loader (0x0041A96A obtains map-node +0x160, corresponding to the directory record's +320; 0x0041A97A seeks there). Corrected tools/expand_weather.py validates source offsets and adds the payload-size delta to every following directory offset.

Pictures_weather_2560_v2.cont was rebuilt from the user's original Pictures_.cont backup. All 5,569 stored offsets are verified against member boundaries. All 5,568 unrelated members are read through their own indexed offsets and compared byte-for-byte with the original. Directory metadata differences are restricted to Misc.alb's length and the required shifted offsets. A regression check correctly rejects the first build at MoveAElephant0dead.alb, the member immediately after Misc.alb. Weather ALB bytes are unchanged from the expanded build. See verification_2560_v2.json for its SHA256. Runtime verification of the corrected container is pending; installed files have not been changed by this repair.
