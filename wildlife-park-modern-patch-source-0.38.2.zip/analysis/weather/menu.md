# Manual visual weather from F2 — 11 October 2026

Both games now have a native button at (10,65,270,20) in the existing 300×500 F2 panel. It cycles Automatisch → Schnee (Test) → Regen (Test) → Aus (Test). The existing Schließen button moves to y=475; the key table is retained. Cheat mode need not be enabled.

This changes the weather controller's dispatch input, not the world's stored weather, temperature or ecological model. Automatic passes the original state through. Snow uses native state 5, rain state 3 and no precipitation state 1. The existing engine controls animation timing and rain sound. Effects require weather rendering enabled and normal simulation updates; paused animation remains paused. Settings are process-local, are not written to saves/configuration, and return to automatic when the controller observes a different world object. A reused world address is not guaranteed to reset the override; Automatisch always restores native dispatch.

Base hook VA 0x4EC2E9 reads world+0x1A4; expansion VA 0x4FBCB9 reads world+0x1D8. Base jump table 0x4EC644 selects clear for states 1/2, rain for 3/4, snow for 5/6 and thunderstorm for 7. Expansion has the corresponding table at 0x4FBFF4 and renderer flags +0x4005E/+0x4005F. These are static observations, not an in-game execution trace.

The native button occupies appended root-object storage +0x1624 (0x638 bytes), plus a construction flag. The F2 allocation grows from 0x1624 to 0x1C60 without moving any existing member or virtual base. Constructor, setup, detach and complete destructor paths are extended; no global live GUI pointer is retained. A construction flag protects failed/partial construction. The original image-relative SEH handler is preserved in the destructor hook, and its replaced absolute-address relocation is disabled. All new code and data use image-relative addressing.

REA/Hopper decompilation evidence: `ev_2390cbe969288f6e58ba68a9fef824bf303a00f67a317aba437b136070f738a7`, saved in menu-evidence.json. Subject was the earlier timestamp-formatted base EXE; focused disassembly checked the same weather and GUI instructions in both current toolbar-repeat inputs. Broader cheat-window API evidence is in analysis/cheat-window.md.

Reproduction: tools/patch_weather_menu.py accepts the two exact toolbar-repeat hashes and emits WLP_widescreen_weather_menu.EXE / WLPADD1_widescreen_weather_menu.EXE. tools/verify_weather_menu.py passed actual 32-bit machine-code tests at image bases 0x400000 and 0x14000000 for both games: constructor, callback registration, bounds/caption, full cycle, automatic restoration, world replacement, detach, destructor and unconstructed-member guard. Tests use mocked engine APIs, so in-game rendering, mouse interaction and performance remain for user testing. Prior PE section bytes match the inputs except the seven declared hook sites and one disabled relocation.

Installed outputs:

- WLP.EXE SHA256 2fe9f1d75866c80096a369e9c705736677178f4f7529c54323ed0f4d24eee882.
- WLPADD1.EXE SHA256 8951a55ded77c912aad4ed2688677b5aa9fc880861373ce6b95620176e6c15a6.
- Backups: WLP.EXE.pre-weather-menu.bak and WLPADD1.EXE.pre-weather-menu.bak, beside the installed executables.

Restart the launcher and game, load a park, press F2 and click Wetter once to select Schnee. Use further clicks to test rain/no precipitation, then return to Automatisch. Test repeated F2 open/close and save/load, both games and different resolutions. The separate snow-revision.md describes the installed artwork change and its own container backup.
