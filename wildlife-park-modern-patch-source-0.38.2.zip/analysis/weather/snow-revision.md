# Revised snow animation — 2026-10-11

The approved artwork has been converted into the game's native sparse RGB565 format and installed in the shared `Int/All/Pictures.cont`, so both Wildlife Park and Wild Creatures receive the replacement after restarting the launcher and game.

Only `Misc.alb` entry 6 (ten snow frames, 2560 × 1440) changes. All 69 other ALB frames, including rain, remain byte-for-byte identical. The container verifier compared all 5,568 other indexed members and validated every adjusted absolute offset.

The artwork supplies 3,438 separate flakes. Their positions cover the full canvas without tiling the old 1,600-pixel image. Small shaded flake sprites use nearest-neighbor scaling and RGB565 conversion. Each moves down 12–20 pixels per animation frame with a small horizontal drift. Randomized phases and brief brightness changes at each particle's respawn create an exact ten-frame loop without a synchronized field reset. The animation timing remains controlled by the original engine. The GIF is an illustrative 100 ms/frame preview, not a timing measurement from the game.

The native frame-0 preview is `snow_revised_2560_preview.png`, and the animation preview is `snow_revised_animation.gif` in this directory. Each 80-pixel-wide column contains 2,813–4,560 nontransparent pixels, with no repeated old tile or empty vertical stripe. This replacement is denser than the former native snow image, reflecting the approved artwork; visual performance and motion still need in-game testing.

Artifacts:

- `tools/revise_snow.py` — deterministic conversion, loop check, sparse encoding round-trip checks, member verification and guarded atomic installation.
- `tools/expand_weather.py` — `replace_container` now accepts an optional `expected_original` byte string. Existing callers still check the original extracted Misc.alb by default.
- `Misc_snow_revised_2560.alb` — SHA256 `94360bb97065142379bf7575df13d9095232d4a94e80f878951e11135ff74168`.
- `Pictures_snow_revised.cont`, workspace `Pictures.cont`, installed `Int/All/Pictures.cont` — 519,055,969 bytes, SHA256 `fbae6e90ced025577c56762831a77294dfe82929170ae6fe899d572b5dce9e4a`.
- Installed backup `Pictures.cont.pre-snow-revision.bak` — previous SHA256 `24a838141af33ab921c9ded23605124faae790f14389befff2438cb36a5fe377`.
- `snow-revision.json` — full conversion and verification report.

To reproduce after installation, use the previous container backup as input and a new output path:

```bash
python3 tools/revise_snow.py /path/to/user/.codex/generated_images/01a12a24-a492-74f0-a25b-5081ad29d0c4/exec-e5a976b7-6b7b-4ecc-81a8-fc33a036d4ae.png --container '/path/to/Wildlife Park Gold/Int/All/Pictures.cont.pre-snow-revision.bak' --container-output /tmp/Pictures_snow_reproduced.cont
```

No executable or GUI.alb changes were made in this snow revision.
