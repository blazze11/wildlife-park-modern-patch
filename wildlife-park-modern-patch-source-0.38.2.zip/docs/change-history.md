# Wildlife Park Gold — final change summary

Updated 14 October 2026. Covers Wildlife Park and the Wild Creatures expansion.
This document describes the final installed state. Intermediate builds and
reverted experiments are recorded separately below; the previous chronological
summary is preserved in [analysis/change-history.md](</path/to/wlp-reverse-engineering/analysis/change-history.md>).

Workspace cleanup: current build copies are in `builds/current`, versioned snapshots in `builds/versions`, textures in `assets`, and game backups/logs in `archive`. Executable filenames remain WLP.EXE and WLPADD1.EXE; the current patch version is 0.38.2. All 322 retained game files were verified unchanged during the original cleanup. See README.md, builds/versions.json and analysis/workspace-cleanup.json for the folder guide and relocation records.

0.37.4 fixes the user-reported immediate scrolling crash. The lower native scrollbar has 33 virtual slots; the prior clone copied only 32 and routed native +0x80 value-change notification into an unrelated destructor. A complete 132-byte table preserves the missing notification and the existing redraw hook. Both games passed a regression executing that notification twice at two image bases. No other behavior or asset archives change. Restart and in-game validation required. See analysis/f2-scroll-crash.md.

0.37.3 corrects the foreground color field, bypasses opaque empty container surfaces through native composition, redraws shortcut rows on native scrollbar value changes, and detaches the close button’s empty caption to expose the original icon. Both games passed native ABI and lifecycle checks; visual appearance and close interaction await in-game validation. No game asset archives are edited. See analysis/f2-objective-fix.md.

0.37.1 was superseded after the user reported black text, stale scrolling, opaque black surfaces and missing close interaction. It replaced the rejected F2 texture with the original Spielziel frame at its exact 524 × 378 size and centered screen position. It uses the native picture widget for transparency, two native scrollbar areas, white text and gold text hover without button backgrounds. The lower scrollbar covers all shortcut rows; upper controls fit in their area. Native ownership, open/close cleanup, centering at four sizes, pointer enter/leave, press independence and shortcut scrolling passed at two image bases for both games. No texture archive changes. In-game appearance awaits a restart. See analysis/f2-objective.md.

0.36.0 was rejected by the user for its stretched frame, opaque green corners and cream text. It textured F2 in both games using the existing shared GUI wood-and-rope panel (entry 81) and wooden button plaque (entry 89). It retains the panel layout and controls and uses cream shortcut text for readability. Native drawing checks passed at two image bases, including failure cleanup and preservation of all other virtual callbacks. No texture archive changes. Restart required; appearance validation pending. See analysis/f2-texture.md.

0.35.2 fixes gameplay UI corruption caused by missing per-image first-frame index updates after inserting the menu glow frame. It corrects 88 shared-GUI and two expansion-GUI header words in loose and packed assets, keeping every texture payload and both executables unchanged. Native-index lookup regression confirms every non-menu frame resolves to its original payload. The user confirmed the gameplay texture correction works. See analysis/menu-frame-index-fix.md.

0.35.1 corrects the logo glow trigger from pressed-state selection to native pointer enter/leave. Textures were user-confirmed and remain unchanged. Native regression checks cover entering without mouse-down, press/release independence and leaving while pressed. See analysis/sign-hover-fix.md.

0.35.0 replaces the text switch with a small Wild Creatures sign in the base game and the existing Wildlife Park logo in the expansion. Both signs glow on hover and use the accepted click handoff. Separate PNG texture states are saved in assets/sign-switch, and the native loose/packed menu artwork is updated while preserving every other encoded frame and container member. Native hover/hitbox checks passed at two image bases; restart and in-game validation are required. See analysis/sign-switch.md.

0.34.0 adds a lower-left native button on each main menu to launch the other game, then leave through the normal Beenden path. Process-start failures show an error and retain the current menu. It preserves all accepted 0.33.0 and 0.30.1 changes. Native lifecycle, submenu visibility, path/launch arguments, failure guards and ABI checks passed at two image bases in both games. Main-menu appearance and actual Wine handoff await user validation. See analysis/launcher-switch.md and launcher-switch-installation.json.

0.33.0 is built directly from 0.30.1 and adds only Landschaft wechseln to F2, invoking the native F9 theme cycle. Developer mode and its F5/F7 rendering controls remain disabled. The 0.32 toggle is superseded. Both games passed native lifecycle, theme-transition, null-world and ABI checks at two image bases; the user confirmed the F2 theme button works. All other 326 installation files were verified unchanged. See analysis/theme-cycle.md and theme-cycle-installation.json.

0.31.0 was rejected by the user because it did not work at all. Restored both games to the exact immutable 0.30.1 executables on 2026-10-13, removing the 0.31 HUD, F2 debug controls, console and feedback relocation. Both live executables and builds/current were verified byte-for-byte; all other installation files remained unchanged. See analysis/debug-tools-rollback-installation.json. The rejected build remains archived.

0.30.1 adds a candidate calendar timing correction: higher TPS no longer adds the original eight in-game minutes on every tick. The replacement carries fractional minutes to preserve nominal 25-TPS calendar pacing. Both executables passed native hook checks; the user subsequently reported one mission worked; broader gameplay coverage remains untested. Settings, mission limits and saves were not edited. See analysis/tps-calendar-fix.md.

## Installed game files changed

| File | Changes |
| --- | --- |
| [Int/Win32/Program/VC6/WLP.EXE](</path/to/Wildlife Park Gold/Int/Win32/Program/VC6/WLP.EXE>) | Base-game widescreen modes, resolution labels, DirectDraw mode lookup/enumeration, fullscreen surface recovery, foreground audio recovery, launcher transitions, cursor capture, timestamp save names, German F2 panel, cheat toggle, temporary action feedback, price and toolbar repeat timing, manual visual weather selector. |
| [Int/Win32/Program/VC6/WLPADD1.EXE](</path/to/Wildlife Park Gold/Int/Win32/Program/VC6/WLPADD1.EXE>) | Equivalent executable fixes for Wild Creatures, mapped to its own engine addresses. |
| [Int/All/Pictures/GUI.alb](</path/to/Wildlife Park Gold/Int/All/Pictures/GUI.alb>) | Repacked three interface background images to cover screens up to 2560 pixels wide, retaining the original pixel format and transparency. Shared by both games. |
| [Int/All/Pictures.cont](</path/to/Wildlife Park Gold/Int/All/Pictures.cont>) | Replaced its embedded Misc.alb rain/snow artwork with larger frames and corrected the shifted container offsets. Shared by both games. |
| [Config.ini](</path/to/Wildlife Park Gold/Config.ini>) | Set `[Optionen] Intro=0` to skip the Deep Silver logo and other startup movies. Other settings shown in this file may have been changed by the launcher during testing; they are not all agent edits. |

The expansion-specific GUI_AddOn1.alb was inspected but not changed. The cursor
work borrows ideas from cnc-ddraw; no cnc-ddraw DLL or replacement renderer was
installed. Save files were not manually edited by these patches.

## Final behavior and verification

| Feature | Final change | Status |
| --- | --- | --- |
| Widescreen | Four correctly labeled modes: 1280×720, 1280×800, 1920×1080 and 2560×1440. Updated related engine and DirectDraw tables together, retaining bounded mode enumeration. | User confirmed both games work. Steam Deck hardware was not tested here. |
| Colors and Alt-Tab | Gameplay retains RGB565/16-bit rendering. Lost fullscreen surfaces reapply the current display mode before restoration. | User confirmed correct rendering and focus recovery. |
| Launcher transitions | Restored the launcher's 800×600 mode alongside the widescreen choices, fixing the reported “video mode not supported” transitions. | User confirmed repeated resolution, window/fullscreen and game/launcher transitions in both games. Launcher fullscreen behavior was accepted as likely original behavior. |
| Startup audio | Recover stale audio suspension when the game is the foreground window after the message pump. Existing volume/focus handling is retained. | User confirmed the startup sound fix. |
| Wide interface | Wider top bar, bottom bar and bottom overlay artwork. Controls themselves are not globally scaled. | Recorded as user-confirmed in the earlier working build. |
| Rain and snow | Twenty animation frames expanded from 1600×1200 to 2560×1440, preserving pixels, transparency and animation order. Corrected archive offsets; 5,568 unrelated members stayed byte-identical. | User confirmed weather works. |
| Startup movies | `Intro=0` skips the existing startup movie sequence. | User confirmed. |
| Windowed mouse | Focused gameplay confines the cursor; release is handled on focus loss. Cached bounds avoid redundant ClipCursor calls. Lifecycle handling covers window/layout changes and system-cursor hiding. | Confinement was confirmed during testing. Inactive hover scrolling and cursor appearance near borders remain unresolved; the last background-input filter was reverted. Scrolling performance was not conclusively confirmed. |
| Save names | Editable default `Save_YYYY_MM_DD_HH_MM_SS`, using local time, zero padding and a 24-hour clock. | User confirmed final format works. Defaults have one-second precision. |
| F2 panel | Enlarged to 300×550 with a two-column German shortcut table, native cheat/weather controls and FPS/TPS/frame-time toggle buttons. | Earlier panel user-confirmed; new debug buttons passed native checks, gameplay validation pending. Installed language assets are German. |
| Cheats | Keep F2–F12 menus accessible in cheat mode. Replace the visible cheat input with “Cheats einschalten / Cheats ausschalten”; “Schließen” closes the panel without changing mode. | User confirmed the combined cheat-toggle/feedback update works. |
| Action feedback | German success/failure messages for saving, loading and screenshots, plus cheat on/off, now at the bottom left. Clears after four seconds; a new message replaces the previous one. No fade. | Earlier feedback user-confirmed. Bottom placement passed native geometry/timer checks; gameplay validation pending. |
| Debug HUD and console | Optional green render FPS, measured/configured TPS and average frame ms at bottom right; F2 toggles and ^ console with help/status and display commands. | Native measurement, rendering-state, lifecycle, keyboard/focus and parser checks passed in both games at two image bases. In-game validation pending. |
| Price buttons | One immediate step on press, 400 ms before repeating, then 120 ms between steps using real time. | User confirmed price increase/decrease works. |
| Work-area buttons | Applied the same real-time repeat timing to the separate toolbar handler used by Arbeitsbereich vergrößern/verkleinern. Also governs other toolbar buttons that repeat while held. | User confirmed fixed. The working price patch is preserved. |

## Workspace source and verification files

Files in `tools/` were created or updated to build, inspect or verify the patches.
Some tools retain options for historical experiments; their existence does not
mean those experiments are installed.

| Work | Files |
| --- | --- |
| Base widescreen, mode tables and labels | [tools/patch_widescreen.py](</path/to/wlp-reverse-engineering/tools/patch_widescreen.py>), [tools/patch_mode_enumeration.py](</path/to/wlp-reverse-engineering/tools/patch_mode_enumeration.py>), [tools/patch_resolution_choices.py](</path/to/wlp-reverse-engineering/tools/patch_resolution_choices.py>) |
| Fullscreen surface recovery | [tools/patch_focus_recovery.py](</path/to/wlp-reverse-engineering/tools/patch_focus_recovery.py>) |
| Audio recovery and earlier audio experiment | [tools/patch_audio_foreground.py](</path/to/wlp-reverse-engineering/tools/patch_audio_foreground.py>), [tools/patch_audio_startup.py](</path/to/wlp-reverse-engineering/tools/patch_audio_startup.py>), [tools/trace_audio.py](</path/to/wlp-reverse-engineering/tools/trace_audio.py>) |
| Expansion port | [tools/patch_addon_widescreen.py](</path/to/wlp-reverse-engineering/tools/patch_addon_widescreen.py>), [tools/verify_addon_widescreen.py](</path/to/wlp-reverse-engineering/tools/verify_addon_widescreen.py>) |
| Launcher mode correction and diagnosis | [tools/patch_launcher_mode.py](</path/to/wlp-reverse-engineering/tools/patch_launcher_mode.py>), [tools/trace_video_modes.py](</path/to/wlp-reverse-engineering/tools/trace_video_modes.py>) |
| GUI extraction/repacking | [tools/extract_alb.py](</path/to/wlp-reverse-engineering/tools/extract_alb.py>), [tools/replace_alb_frame.py](</path/to/wlp-reverse-engineering/tools/replace_alb_frame.py>) |
| Expanded weather archive | [tools/expand_weather.py](</path/to/wlp-reverse-engineering/tools/expand_weather.py>) |
| Cursor capture and experiments | [tools/patch_mouse_confinement.py](</path/to/wlp-reverse-engineering/tools/patch_mouse_confinement.py>), [tools/verify_mouse_confinement.py](</path/to/wlp-reverse-engineering/tools/verify_mouse_confinement.py>), [tools/trace_mouse_runtime.py](</path/to/wlp-reverse-engineering/tools/trace_mouse_runtime.py>) |
| Default save name and timestamp variants | [tools/patch_default_save_name.py](</path/to/wlp-reverse-engineering/tools/patch_default_save_name.py>), [tools/verify_default_save_name.py](</path/to/wlp-reverse-engineering/tools/verify_default_save_name.py>) |
| F2 layout, table and German text | [tools/patch_keybind_panel.py](</path/to/wlp-reverse-engineering/tools/patch_keybind_panel.py>), [tools/verify_keybind_panel.py](</path/to/wlp-reverse-engineering/tools/verify_keybind_panel.py>) |
| Cheat-mode menu routing | [tools/patch_cheat_menus.py](</path/to/wlp-reverse-engineering/tools/patch_cheat_menus.py>), [tools/verify_cheat_menus.py](</path/to/wlp-reverse-engineering/tools/verify_cheat_menus.py>) |
| Cheat toggle and timed feedback | [tools/patch_action_feedback.py](</path/to/wlp-reverse-engineering/tools/patch_action_feedback.py>), [tools/verify_action_feedback.py](</path/to/wlp-reverse-engineering/tools/verify_action_feedback.py>) |
| Price/numeric repeat timing | [tools/patch_button_repeat.py](</path/to/wlp-reverse-engineering/tools/patch_button_repeat.py>), [tools/verify_button_repeat.py](</path/to/wlp-reverse-engineering/tools/verify_button_repeat.py>) |
| Work-area/toolbar repeat timing | [tools/patch_toolbar_repeat.py](</path/to/wlp-reverse-engineering/tools/patch_toolbar_repeat.py>), [tools/verify_toolbar_repeat.py](</path/to/wlp-reverse-engineering/tools/verify_toolbar_repeat.py>) |
| Rejected 32-bit rendering experiment | [tools/patch_color_depth.py](</path/to/wlp-reverse-engineering/tools/patch_color_depth.py>) — historical, not the final gameplay rendering mode. |

Artwork supplied/edited during the GUI work:
[bottom_bar_2560.png](</path/to/wlp-reverse-engineering/assets/previews/bottom_bar_2560.png>), [bottom_overlay_2560.png](</path/to/wlp-reverse-engineering/assets/previews/bottom_overlay_2560.png>) and
[top_bar_2560.png](</path/to/wlp-reverse-engineering/assets/previews/top_bar_2560.png>). These are packed into the current [GUI.alb](</path/to/wlp-reverse-engineering/assets/current/GUI.alb>).
The current [Pictures.cont](</path/to/wlp-reverse-engineering/assets/current/Pictures.cont>) contains the expanded
[Misc_weather_2560.alb](</path/to/wlp-reverse-engineering/assets/archive/Misc_weather_2560.alb>). Extracted source frames, previews and manifests
are retained under `analysis/gui/` and `analysis/weather/`; GUI_extracted.zip is
an extraction artifact.

## Current distributable builds

| Workspace file | Installed destination |
| --- | --- |
| [WLP.EXE](</path/to/wlp-reverse-engineering/builds/versions/0.31.0/WLP.EXE>) | WLP.EXE |
| [WLPADD1.EXE](</path/to/wlp-reverse-engineering/builds/versions/0.31.0/WLPADD1.EXE>) | WLPADD1.EXE |
| [GUI.alb](</path/to/wlp-reverse-engineering/assets/current/GUI.alb>) | Int/All/Pictures/GUI.alb |
| [Pictures.cont](</path/to/wlp-reverse-engineering/assets/current/Pictures.cont>) | Int/All/Pictures.cont |

These four installed binaries/archives were read back and their hashes matched
this final state. Config.ini is an existing user configuration: the relevant
intentional change is `Intro=0`.

```text
WLP.EXE
676951470191bd312fca07ca0f9699d8c9d78b08d390f76662e6b7842dcdfdc1

WLPADD1.EXE
b7f2a6ee1a4ac6556e8abfe08f85de864154d3269024bfd0843b8d9442fa625d

GUI.alb
7c230f52432c82312bc17617b200141729111badb9cbce0369235ba526491af7

Pictures.cont
7ced8de8ef653aa8ec2a8d14c68dea182feaf511672daffc475ac62bcece6e89
```

## Backups, intermediate builds and reverted work

Backups of successive executable states remain beside the installed EXEs with
`.bak` suffixes. The latest `.EXE.pre-weather-menu.bak` preserves the complete working toolbar fix. `.EXE.pre-toolbar-repeat.bak` preserves the working
price patch before the work-area correction. `.EXE.pre-button-repeat.bak`
preserves the prior feedback build. Config.ini.before-no-intro.bak preserves
the configuration before disabling startup movies.

The workspace contains original/reference EXEs, diagnostic builds and paired
`WLP*_widescreen_*` intermediate builds. They are historical artifacts; use the
current builds above for the final executable state. A complete inventory of
workspace root files, tools, analysis records and installed patch backups is
saved in [analysis/edited-files-inventory.json](</path/to/wlp-reverse-engineering/analysis/edited-files-inventory.json>). Original/reference files
are included as references, not asserted to have been edited.

Experiments that were superseded or reverted:

- 32-bit gameplay rendering caused wrong colors/duplicated rendering; final
  gameplay stays 16-bit.
- Initial launcher table edits omitted 800×600; the missing mode was restored.
- Early cursor patches had no effect. Runtime tracing identified an incorrect
  capture guard; subsequent capture/cache/lifecycle builds superseded them.
- The final inactive WM_MOUSEMOVE filter failed user testing and was reverted.
- Numbered default saves repeatedly offered Save(1). Timestamp naming replaced
  that file-numbering logic.
- The first timestamp syntax was replaced by the requested underscore format.
- The first weather container had incorrect shifted directory offsets and
  stalled loading. The corrected v2 container is installed.
- The original English F2 table was replaced by German text.
- The original cheat input was hidden in favor of a direct toggle.
- The first repeat patch fixed prices but missed toolbar work-area controls.
  The additional toolbar patch is now user-confirmed.

## Investigation and test records

Feature notes are retained in `analysis/widescreen.md`, `addon-widescreen.md`,
`video-mode-transition.md`, `audio-startup.md`, `mouse-confinement.md`,
`cnc-ddraw-mouse-research.md`, `default-save-name.md`, `cheat-window.md`,
`keybind-panel.md`, `cheat-menu-fix.md`, `action-feedback.md`, `button-repeat.md`,
`toolbar-repeat.md` and `weather/findings.md`. REA evidence JSON, archive
verification JSON, diagnostic traces, extracted frames and previews accompany
those records. Historical “pending” statements in chronological notes describe
that stage; the status table above incorporates subsequent user confirmations.

Native x86 verification included 312 numeric repeat checks and 196 toolbar
repeat checks per game at two image bases. Other patch-specific checks covered
menu routing, callback ABI preservation, save names, message lifetime, mouse
capture logic, PE bounds/relocations and preservation of earlier patch sections.
These harnesses test emitted code with mocked engine/API dependencies; the
in-game confirmations came from the user.

## Snow revision and manual weather testing

Replaced the snow animation with ten frames based on the approved artwork, removing the repeated 1600-pixel tile. Rain and 5,568 other archive members remain unchanged. Added a German F2 button cycling Automatisch / Schnee / Regen / Aus in both games, with native control construction and cleanup. The override affects visible weather dispatch; stored climate and temperature are retained. Native mock tests passed for both games at two image bases; in-game testing remains pending. Restart the launcher and game before testing.

Current executable outputs are WLP_widescreen_weather_menu.EXE and WLPADD1_widescreen_weather_menu.EXE. Current shared archive is Pictures_snow_revised.cont. See analysis/weather/menu.md, menu-installation.json, snow-revision.md and snow-revision.json; tools/patch_weather_menu.py, tools/verify_weather_menu.py and tools/revise_snow.py reproduce these changes. Installed .pre-weather-menu.bak and Pictures.cont.pre-snow-revision.bak backups preserve the previous working versions.

### Small bright snow correction

User reported dark outlines, oversized flakes and fast movement in the first artwork conversion. Replaced shaded RGB565 flakes with 1–3 pixel particles using only the original light snow palette; movement reduced from 12–20 to 4–8 pixels per animation frame. The native sparse format omits background pixels entirely. Distribution covers the full canvas without repeated tiles. Ten-frame loop and all sparse encode/decode round trips validated; all 69 other Misc frames and 5,568 other container members are unchanged. Installed Pictures_snow_small.cont with Pictures.cont.pre-small-snow.bak retaining the previous candidate. F2 weather controls were user-confirmed working and unchanged. See tools/refine_snow.py and analysis/weather/snow-small.json. Appearance and speed require another in-game test.

### Experimental 10-point zoom controls

**Reverted:** The user subsequently requested removing the 10% zoom changes because they were unstable and not useful. Both games now use the verified pre-zoom weather-menu executables and their original zoom behavior. Mouse confinement and all earlier fixes remain; snow, GUI assets and settings were verified unchanged. See analysis/zoom-rollback-installation.json. The following zoom entries describe historical experiments, not current installed behavior.

**Follow-up:** At the user's request, Wild Creatures' original 25% overview is disabled with a single branch-byte change; zoom-out stops at 50%. Its original 50/100/200% renderer and zoom controls are retained. This avoids reported building hover flicker at 25%; the original bug's cause is unproven. The base game is unchanged. See analysis/addon-zoom-limit.md and addon-zoom-limit-installation.json.

Installed WLP_widescreen_zoom_steps.EXE and WLPADD1_widescreen_zoom_steps.EXE. Zoom in/out and keyboard +/− step by 10 percentage points between 50% and 200%; reset is 100%. Intermediate levels use an offscreen world-render scaling pass, inverse mouse mapping and restored viewport metrics. HUD and weather overlays stay at physical resolution. Native mock tests passed for all levels at two image bases in both games; in-game visual/picking/performance tests remain pending. Backups .EXE.pre-zoom-steps.bak preserve the prior working weather-menu build. See analysis/zoom-steps.md and zoom-steps-installation.json; tools/zoom_steps.c, patch_zoom_steps.py and verify_zoom_steps.py reproduce the prototype. The small bright snow was user-confirmed and remains unchanged.

### Zoom viewport correction

User reported a garbage strip above the bottom bar and an upward shift at intermediate levels (screenshot 11_10_2026_22_13_31.bmp). Corrected virtual window/viewport heights to retain the measured difference between full-window globals and the park surface height. Previously assigning the surface height to window globals caused the HUD subtraction to happen twice. Temporary RGB565 rows now have four-byte-aligned pitch, and the scratch buffer is cleared each frame. Native regression checks now model a 124-pixel HUD margin and verify all 16 levels, complete source initialization, row alignment, sampling, mouse mapping and restoration in both games at two image bases. Corrected candidates installed with .EXE.pre-zoom-viewport-fix.bak backups; in-game confirmation remains pending. See analysis/zoom-viewport-installation.json.

### Zoom weather lifetime correction

The user confirmed the bottom-bar correction, but reported absent weather on intermediate zoom levels and two crashes. Static inspection found the previous post-render weather redraw dereferenced a delegate already freed by native finish-render cleanup (base VA 0x412A16 / expansion 0x412FC6). The redraw now executes inside finish-render before cleanup, after flushing deferred world spans and scaling the world once. Native cleanup flushes weather spans before releasing the delegate and image resources. No drawing objects are accessed after native render returns. Regression mocks now simulate both direct and delegated deferred world queues, draw weather before release, poison the delegate afterward, and ensure final resampling does not erase weather. Both games passed at two image bases, with weather enabled/disabled and all intermediate levels. Installed backups .EXE.pre-zoom-weather-lifetime.bak retain the preceding viewport build; the original .pre-zoom-steps.bak still retains the last stable pre-zoom version. Further crash/visual testing remains pending. See analysis/zoom-weather-lifetime.md and zoom-weather-lifetime-installation.json.

0.37.5 fixes F2 button palette resets, adds native close-button hover/press texture states and assigns the exact Spielziel header font. Native state and lifecycle checks passed for both games at two image bases. The user confirmed 0.37.4 scrolling and transparency. See [analysis/f2-button-style.md](analysis/f2-button-style.md).

0.37.6 corrects the close-button states after user validation: GUI99 frame 1 is hover and frame 2 is pressed. Exactly two bytes change in each 0.37.5 executable; all other bytes remain identical. See analysis/f2-close-states-verification.json and analysis/f2-close-states-installation.json.

0.38.0 uses the original 120×34 Zufallswerte/Rücksetzen textures on all three F2 controls, with native hover and pressed states. Existing callbacks, close button, scrolling and heading remain. New image entries are appended to shared loose/packed GUI assets without shifting any old frame indices; every other encoded frame and container member is verified unchanged. Both executables passed native widget lifecycle/state checks at two image bases. See [analysis/f2-weather-buttons.md](analysis/f2-weather-buttons.md).

0.38.1 shortens all F2 action captions, keeps normal/hover/pressed/focus text black, reapplies centered inset label bounds after native updates, and uses the first button’s working border variant on the weather button. Archives retain exact 0.38.0 bytes. Native state/alignment regression checks passed for both games at two image bases. See [analysis/f2-button-labels.md](analysis/f2-button-labels.md).

0.38.2 moves the three F2 captions up 3 pixels to match the supplied original-button comparison. Exact one-byte correction verified in both executables; every other byte remains unchanged. See [analysis/f2-label-height.md](analysis/f2-label-height.md).
