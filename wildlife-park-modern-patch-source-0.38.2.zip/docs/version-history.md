# Executable versions

Current patch version: **0.38.2** (F2 uses the native Spielziel frame with white text, scrollbars and text hover; retains accepted switching and previous fixes).

These versions identify our patch snapshots; they are not the publisher's game version numbers. Historical snapshots received retrospective 0.x version IDs. Executable filenames always remain WLP.EXE and WLPADD1.EXE.

| Version | Status | Changes / snapshot |
| --- | --- | --- |
| 0.0.0-original | reference | Original distribution references |
| 0.0.0-windowed-reference | reference | Earlier user-modified windowed reference |
| 0.1.0 | historical | 2560x1440 v2 |
| 0.2.0 | historical | legacy-build |
| 0.3.0 | historical | 2560x1440 v5 |
| 0.4.0 | historical | widescreen v6 |
| 0.5.0 | historical | widescreen v7 audio test |
| 0.6.0 | diagnostic | widescreen audio diagnostic |
| 0.7.0 | historical | widescreen v8 audio test |
| 0.8.0 | historical | widescreen |
| 0.9.0 | diagnostic | video diagnostic |
| 0.10.0 | historical | widescreen launcher fixed |
| 0.11.0 | historical | widescreen mouse fixed |
| 0.12.0 | historical | widescreen mouse events |
| 0.13.0 | diagnostic | mouse runtime diagnostic |
| 0.14.0 | historical | widescreen mouse capture |
| 0.15.0 | historical | widescreen mouse cached |
| 0.16.0 | historical | widescreen mouse lifecycle |
| 0.17.0 | reverted experiment | widescreen mouse background |
| 0.18.0 | historical | widescreen default save |
| 0.19.0 | historical | widescreen timestamp save |
| 0.20.0 | historical | widescreen timestamp formatted |
| 0.21.0 | historical | widescreen keybinds |
| 0.22.0 | historical | widescreen keybinds de |
| 0.23.0 | historical | widescreen cheat menus |
| 0.24.0 | historical | widescreen feedback |
| 0.25.0 | historical | widescreen button repeat |
| 0.26.0 | historical | widescreen toolbar repeat |
| 0.27.0 | historical | widescreen weather menu |
| 0.28.0 | reverted experiment | widescreen zoom steps |
| 0.29.0 | diagnostic | display transition trace |
| 0.30.0 | user-tested baseline | Original zoom restored; Wild Creatures overview capped at 50%; all other accepted fixes retained |
| 0.30.1 | historical baseline; one mission user-tested | Calendar progression normalized at higher TPS; retains all 0.30.0 fixes |
| 0.31.0 | reverted experiment; user reported it did not work at all | Bottom-left feedback, green FPS/TPS/frame timing HUD, F2 toggles and ^ console; retains 0.30.1 |
| 0.32.0 | superseded; developer mode removed at user request | F2 native developer-mode An/Aus toggle; F2 remains reachable while enabled; based directly on 0.30.1 |
| 0.33.0 | superseded; user confirmed theme button works | F2 Landschaft wechseln button for the native F9 theme cycle; based directly on 0.30.1 |
| 0.34.0 | superseded; user confirmed switching works well | Main-menu switch between base game and Wild Creatures; retains 0.33.0 |
| 0.35.0 | superseded; textures worked, glow fired on mouse-down | Top-left logo switches with separate normal/glow textures, replacing the lower-left text switch |
| 0.35.1 | superseded; hover worked, gameplay UI texture indices were wrong | Glow uses pointer enter/leave instead of mouse-down; texture assets retained from 0.35.0 |
| 0.35.2 | superseded; user confirmed gameplay texture correction works | Correct later image frame indices after the added menu frame; hover code and texture pixels retained |
| 0.36.0 | rejected; stretched texture and opaque green corners | F2 uses existing shared GUI wood-and-rope panel and wooden buttons, with cream shortcut text; controls and archives retained |
| 0.37.0 | archived draft; never installed | First Spielziel-frame draft, superseded during native ABI verification |
| 0.37.1 | superseded; user reported text, scrolling, black-buffer and close issues | Unscaled native 524 × 378 Spielziel frame and centered position, native scrollbars, white text and gold text hover; removes button backgrounds |
| 0.37.2 | archived draft; never installed | Intermediate correction, superseded by final close-caption detachment |
| 0.37.3 | superseded; user reported immediate scroll crash | Correct foreground RGB, native transparent container surfaces, scrollbar-to-label invalidation and close icon visibility |
| 0.37.4 | superseded; user confirmed scrolling and transparency | Preserve all 33 lower-scrollbar virtual slots, fixing invalid dispatch on scrolling; retains 0.37.3 layout and redraw behavior |
| 0.37.5 | superseded; user confirmed behavior except reversed close states | Persistent white/gold button palettes, original close hover/press textures and exact Spielziel header font |
| 0.37.6 | superseded; accepted F2 behavior retained | Swap close hover and pressed frames, retaining accepted 0.37.5 behavior |
| 0.38.0 | superseded; user requested label/alignment and weather border correction | Original 120×34 Freies Spiel weather buttons on all three F2 actions |
| 0.38.1 | superseded; user requested slightly higher captions | Short black centered captions, working border on weather button |
| 0.38.2 | current; exact one-byte correction verified | Move all three F2 captions 3 pixels upward |
| 0.0.0-backup.1 | historical backup | Backup-only historical snapshot; feature identity not reconstructed |
| 0.0.0-backup.2 | historical backup | Backup-only historical snapshot; feature identity not reconstructed |
| 0.0.0-backup.3 | historical backup | Backup-only historical snapshot; feature identity not reconstructed |
| 0.0.0-backup.4 | historical backup | Backup-only historical snapshot; feature identity not reconstructed |

See versions.json for exact hashes, file paths and historical filename aliases. Some historical versions contain only one game. Current contains both. The 0.31 debug tools are archived and no longer installed. See analysis/debug-tools-rollback-installation.json for restoration hashes.

See analysis/launcher-switch.md for the new main-menu control and verification limits, and analysis/theme-cycle.md for the retained F2 feature. analysis/native-developer-mode.md describes the superseded developer experiment.
