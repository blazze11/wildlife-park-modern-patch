#!/usr/bin/env python3
"""Check every key word with cheat mode off/on using actual x86 routing code."""
import argparse
import subprocess
import tempfile
from pathlib import Path
import pefile
from patch_cheat_menus import patch


def verify(source,output):
    src=source.read_bytes()
    new,m=patch(src)
    assert new==output.read_bytes()
    p=pefile.PE(data=src)
    expected=bytearray(src)
    off=p.get_offset_from_rva(m['hook'])
    expected[off:off+5]=new[off:off+5]
    for roff in m['reloc_offsets']:
        expected[roff:roff+2]=new[roff:roff+2]
    for s in p.sections:
        a,z=s.PointerToRawData,s.SizeOfRawData
        assert new[a:a+z]==expected[a:a+z]
    for block in pefile.PE(data=new).DIRECTORY_ENTRY_BASERELOC:
        for entry in block.entries:
            assert not entry.type or not m['hook']<=entry.rva<m['hook']+5
    with tempfile.TemporaryDirectory() as tmp:
        d=Path(tmp)
        (d/'code.bin').write_bytes(m['code'])
        for base in (0x400000,0x10000000):
            asm=f'''.intel_syntax noprefix
.code32
.section .main,"ax"
.global start
start:
 mov [saved_sp], esp
 xor eax,eax
 mov [key],eax
next_key:
 mov eax,[key]
 mov WORD PTR [event+0x40],ax
 mov DWORD PTR [expected_menu],0
 cmp eax,0x3c00
 je expect_menu
 cmp eax,0x3d00
 je expect_menu
 cmp eax,0x3e00
 je expect_menu
 cmp eax,0x3f00
 je expect_menu
 cmp eax,0x4000
 je expect_menu
 cmp eax,0x4100
 je expect_menu
 cmp eax,0x4200
 je expect_menu
 cmp eax,0x4300
 je expect_menu
 cmp eax,0x4400
 je expect_menu
 cmp eax,0x5700
 je expect_menu
 cmp eax,0x5800
 jne run_case
expect_menu:
 mov DWORD PTR [expected_menu],1
run_case:
 mov eax,0x123456ab
 mov ecx,0x2222
 mov edx,0x3333
 mov ebx,0x4444
 mov ebp,0x5555
 mov esi,0x6666
 mov edi,OFFSET event
 pushfd
 pop DWORD PTR [flags]
 call thunk
 pushfd
 pop DWORD PTR [after_flags]
 cmp esp,[saved_sp]
 jne fail
 cmp ecx,0x2222
 jne fail
 cmp edx,0x3333
 jne fail
 cmp ebx,0x4444
 jne fail
 cmp ebp,0x5555
 jne fail
 cmp esi,0x6666
 jne fail
 cmp edi,OFFSET event
 jne fail
 mov ecx,[flags]
 cmp ecx,[after_flags]
 jne fail
 mov ecx,[expected_menu]
 cmp ecx,[actual_menu]
 jne fail
 test ecx,ecx
 jne check_menu
 mov ecx,0x12345600
 mov cl,[cheat_flag]
 cmp eax,ecx
 jne fail
 jmp next
check_menu:
 cmp eax,0x123456ab
 jne fail
next:
 inc DWORD PTR [key]
 cmp DWORD PTR [key],0x10000
 jb next_key
 cmp BYTE PTR [cheat_flag],0
 jne done
 mov BYTE PTR [cheat_flag],1
 mov DWORD PTR [key],0
 jmp next_key
done:
 xor ebx,ebx
 jmp exit
fail:
 mov ebx,1
exit:
 mov eax,1
 int 0x80
.section .ordinary,"ax"
 mov DWORD PTR [actual_menu],0
 ret
.section .normal,"ax"
 mov DWORD PTR [actual_menu],1
 ret
.section .flag,"aw"
cheat_flag: .byte 0
.section .thunk,"ax"
thunk: .incbin "{d/'code.bin'}"
.section .data,"aw"
saved_sp: .long 0
key: .long 0
flags: .long 0
after_flags: .long 0
expected_menu: .long 0
actual_menu: .long 0
event: .space 0x50
'''
            (d/'test.s').write_text(asm)
            (d/'test.ld').write_text(f'''ENTRY(start)
SECTIONS {{
 .main {base+0x1000} : {{ *(.main) }}
 .ordinary {base+m['hook']+5} : {{ *(.ordinary) }}
 .normal {base+m['normal']} : {{ *(.normal) }}
 .flag {base+m['flag']} : {{ *(.flag) }}
 .thunk {base+m['rva']} : {{ *(.thunk) }}
 .data : {{ *(.data) }}
}}
''')
            subprocess.run(['as','--32','-o',str(d/'test.o'),str(d/'test.s')],check=True)
            subprocess.run(['ld','-m','elf_i386','-T',str(d/'test.ld'),'-o',str(d/'test'),str(d/'test.o')],check=True,capture_output=True)
            r=subprocess.run([str(d/'test')],timeout=10)
            assert r.returncode==0,(hex(base),r.returncode)
    print(output.name,'PASS: 262144 x86 key-routing cases; modes 0/1, two image bases, registers/flags/stack; prior sections intact')


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source',type=Path)
    parser.add_argument('output',type=Path)
    args=parser.parse_args()
    verify(args.source,args.output)
