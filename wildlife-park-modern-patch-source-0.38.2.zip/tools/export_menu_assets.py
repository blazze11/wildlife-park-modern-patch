#!/usr/bin/env python3
"""Export editable main-menu PNGs and shared back-button sprites, read-only."""
import hashlib,json,struct,shutil,zipfile
from pathlib import Path
from PIL import Image
from extract_alb import decompress
from workspace_paths import GAME

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'assets/menu-editing'

def decode_frame(payload,w,h,flags):
    if flags==272:
        return decompress(payload,w*h*2)
    if flags!=528:raise ValueError(f'Unsupported ALB flags {flags}')
    # Addon type-2: scanline index followed by skip/copy byte-pair packets.
    # A zero/zero packet terminates each row. Decode sequentially; indices use
    # their native encoded addressing convention rather than plain file offsets.
    pos=h*4; result=bytearray()
    for y in range(h):
        row=bytearray()
        while True:
            assert pos+2<=len(payload)
            skip,copy=payload[pos:pos+2];pos+=2
            if skip==0 and copy==0:break
            row.extend(b'\xe0\x07'*skip)
            assert pos+copy*2<=len(payload)
            row.extend(payload[pos:pos+copy*2]);pos+=copy*2
        assert len(row)==w*2,(y,len(row),w)
        result.extend(row)
    assert pos==len(payload),(pos,len(payload))
    return bytes(result)

def export(source,entries):
    data=source.read_bytes()
    version,count,flags,unused,table_start,table_size=struct.unpack_from('<HHIIII',data)
    assert version==200
    offsets=struct.unpack_from(f'<{table_size//4}I',data,table_start)
    assert offsets[-1]==len(data)
    records=[]
    for entry,folder,stem in entries:
        assert entry<count
        header=255+entry*64
        frames,w,h,size,total,identifier=struct.unpack_from('<HHHIII',data,header)
        assert size==w*h*2 and total==size*frames
        first=sum(struct.unpack_from('<H',data,255+i*64)[0] for i in range(entry))
        dest=OUT/folder;dest.mkdir(parents=True,exist_ok=True)
        record=dict(source=str(source),source_sha256=hashlib.sha256(data).hexdigest(),
                    flags=flags,entry=entry,id=identifier,width=w,height=h,
                    header_hex=data[header:header+64].hex(),frames=[])
        for frame in range(frames):
            begin,end=offsets[first+frame:first+frame+2]
            raw=decode_frame(data[begin:end],w,h,flags)
            rgb=bytearray()
            for (pixel,) in struct.iter_unpack('<H',raw):
                rgb.extend(((pixel>>11)*255//31,((pixel>>5)&63)*255//63,(pixel&31)*255//31))
            name=stem+(f'_{frame:02d}' if frames>1 else '')
            png=dest/(name+'.png');Image.frombytes('RGB',(w,h),bytes(rgb)).save(png)
            (dest/(name+'.rgb565')).write_bytes(raw)
            # PNG conversion preserves every original 16-bit pixel on import.
            restored=bytearray()
            for red,green,blue in Image.open(png).getdata():
                restored+=struct.pack('<H',(round(red*31/255)<<11)|(round(green*63/255)<<5)|round(blue*31/255))
            assert bytes(restored)==raw
            record['frames'].append(dict(png=str(png.relative_to(OUT)),
                rgb565=str((dest/(name+'.rgb565')).relative_to(OUT)),
                offset=begin,encoded_bytes=end-begin,raw_sha256=hashlib.sha256(raw).hexdigest()))
        records.append(record)
    return records

if __name__=='__main__':
    OUT.mkdir(parents=True,exist_ok=True)
    base=GAME/'Int/All/Pictures/GUI.alb'
    addon=GAME/'Int/All/Pictures/Addon1/GUI_AddOn1.alb'
    records=export(base,[(44,'wildlife-park','main-menu'),
                        (45,'shared/main-button-sprites','main-button'),
                        (54,'shared/back-button-variant','back-button'),
                        (55,'shared/back-button','back-button')])
    records+=export(addon,[(22,'wild-creatures','main-menu')])
    originals=OUT/'original-archives';originals.mkdir(exist_ok=True)
    for source in (base,addon):
        shutil.copy2(source,originals/source.name)
        assert (originals/source.name).read_bytes()==source.read_bytes()
    (OUT/'manifest.json').write_text(json.dumps(records,indent=2)+'\n')
    (OUT/'README.md').write_text('''# Editable Wildlife Park menu assets

- `wildlife-park/main-menu.png`: base game's complete 800 × 600 main-menu background (shared GUI.alb entry 44).
- `wild-creatures/main-menu.png`: expansion's complete 800 × 600 main-menu background (GUI_AddOn1.alb entry 22).
- `shared/back-button/back-button_00.png`: the 116 × 80 back-arrow sprite matching the supplied Freies Spiel screenshot. All eight source frames are included (_00 through _07).
- `shared/back-button-variant/`: the adjacent eight-frame back-arrow variant, for comparison.
- `shared/main-button-sprites/`: all 24 wooden menu-button sprite frames, 232 × 38, from shared GUI.alb entry 45.
- `original-archives/`: untouched copies of both installed ALB files.

Edit the PNGs. The `.rgb565` files retain exact original pixels; `manifest.json` records archive entries, original headers and hashes for reimporting. PNG export/import was checked to reproduce all original 16-bit pixels exactly. No installed game file was changed.

The backgrounds include the normal wooden button artwork. Text is drawn by the executable, so do not paint captions into the backgrounds. Menu hitboxes are 232 × 38, start at (300, 213), and advance by 40 pixels. Beenden is at (300, 453); a matching new row below it would be at (300, 493). Changing the image alone does not move the clickable switch: its executable position will be adjusted when the edited art is ready.

Keep the backgrounds at 800 × 600. The back sprite includes jungle/background pixels rather than inferred PNG transparency; preserve its original frame dimensions. These are exact RGB exports, with archive transparency information retained in the manifest. The back-arrow assets are in the common GUI archive used alongside both games; there is no separate 116 × 80 sprite in the expansion archive.
''')
    z=ROOT/'assets/menu-editing.zip'
    with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as archive:
        for file in sorted(OUT.rglob('*')):
            if file.is_file():archive.write(file,Path('menu-editing')/file.relative_to(OUT))
    print(f'Exported {sum(len(r["frames"]) for r in records)} PNGs to {OUT}')
    print(f'ZIP: {z}')
