#!/usr/bin/env python3
"""Run actual weather-menu machine code with native GUI/weather API mocks."""
import argparse,struct,subprocess,tempfile
from pathlib import Path
from workspace_paths import artifact
import pefile
from patch_weather_menu import patch,BUTTON,READY,SIZE

def verify(name,build_only=False):
 src=artifact(name+'_widescreen_toolbar_repeat.EXE').read_bytes();new,m=patch(src)
 assert new==artifact(name+'_widescreen_weather_menu.EXE').read_bytes()
 p=pefile.PE(data=src);np=pefile.PE(data=new);expected=bytearray(src)
 for h,n in m['changes']:
  off=p.get_offset_from_rva(h);expected[off:off+n]=new[off:off+n]
 for off in m['reloc_offsets']:expected[off:off+2]=new[off:off+2]
 for s in p.sections:
  a=s.PointerToRawData;assert new[a:a+s.SizeOfRawData]==expected[a:a+s.SizeOfRawData]
 for b in np.DIRECTORY_ENTRY_BASERELOC:
  for e in b.entries:assert not e.type or not any(h<=e.rva<h+n for h,n in m['changes'])
 sy=m['symbols'];pr=m['profile']
 for base in (0x400000,0x14000000):
  with tempfile.TemporaryDirectory() as tmp:
   d=Path(tmp);(d/'code.bin').write_bytes(m['code'])
   asm=f'''.intel_syntax noprefix
.code32
.global start
.section .main,"ax"
start:
 mov [saved_sp],esp
 mov DWORD PTR [step],1
 mov ecx,OFFSET root
 push 1
 call thunk+{sy['constructor']}
 cmp eax,OFFSET root
 jne fail
 cmp DWORD PTR [root+{READY}],1
 jne fail
 cmp DWORD PTR [constructed],1
 jne fail
 cmp esp,[saved_sp]
 jne fail
 mov DWORD PTR [step],2
 mov ecx,OFFSET root+0xbf0
 push OFFSET root
 call thunk+{sy['attach_button']}
 cmp DWORD PTR [attached],2
 jne fail
 cmp DWORD PTR [bounds_called],1
 jne fail
 cmp DWORD PTR [enabled_called],1
 jne fail
 cmp DWORD PTR [registered],1
 jne fail
 cmp esp,[saved_sp]
 jne fail
 mov DWORD PTR [step],3
 mov esi,OFFSET world
 mov DWORD PTR [world+{pr['weather_field']}],7
 mov DWORD PTR [wanted],7
 call thunk+{sy['weather']}
 cmp DWORD PTR [thunk+{sy['mode']}],0
 jne fail
 mov DWORD PTR [step],4
 mov ecx,OFFSET root
 push 0
 push 0
 call thunk+{sy['cycle']}
 cmp al,1
 jne fail
 cmp DWORD PTR [thunk+{sy['mode']}],1
 jne fail
 mov DWORD PTR [wanted],5
 mov esi,OFFSET world
 call thunk+{sy['weather']}
 mov DWORD PTR [step],5
 mov ecx,OFFSET root
 push 0
 push 0
 call thunk+{sy['cycle']}
 mov DWORD PTR [wanted],3
 mov esi,OFFSET world
 call thunk+{sy['weather']}
 mov DWORD PTR [step],6
 mov ecx,OFFSET root
 push 0
 push 0
 call thunk+{sy['cycle']}
 mov DWORD PTR [wanted],1
 mov esi,OFFSET world
 call thunk+{sy['weather']}
 mov DWORD PTR [step],7
 mov ecx,OFFSET root
 push 0
 push 0
 call thunk+{sy['cycle']}
 mov DWORD PTR [wanted],7
 mov esi,OFFSET world
 call thunk+{sy['weather']}
 cmp DWORD PTR [world+{pr['weather_field']}],7
 jne fail
 mov DWORD PTR [step],8
 mov ecx,OFFSET root
 push 0
 push 0
 call thunk+{sy['cycle']}
 mov DWORD PTR [wanted],2
 mov esi,OFFSET world2
 mov DWORD PTR [world2+{pr['weather_field']}],2
 call thunk+{sy['weather']}
 cmp DWORD PTR [thunk+{sy['mode']}],0
 jne fail
 cmp esp,[saved_sp]
 jne fail
 mov DWORD PTR [step],9
 mov ecx,OFFSET root+0x1228
 call thunk+{sy['detach_button']}
 cmp DWORD PTR [detached],1
 jne fail
 cmp DWORD PTR [input_detached],1
 jne fail
 mov DWORD PTR [step],10
 mov ecx,OFFSET root+0x1620
 call thunk+{sy['destructor']}
 cmp DWORD PTR [destroyed],1
 jne fail
 cmp DWORD PTR [root+{READY}],0
 jne fail
 cmp esp,[saved_sp]
 jne fail
 # Nonconstructed button must not be destroyed.
 call thunk+{sy['destructor']}
 cmp DWORD PTR [destroyed],1
 jne fail
 mov DWORD PTR [step],11
 mov ecx,OFFSET root+0xbf0
 push 20
 push 80
 push 65
 push 200
 call thunk+{sy['close_bounds']}
 cmp esp,[saved_sp]
 jne fail
 xor ebx,ebx
 mov eax,1
 int 0x80
fail:
 mov ebx,[step]
 mov eax,1
 int 0x80
.section .ctor,"ax"
 cmp ecx,OFFSET root
 jne fail
 cmp DWORD PTR [esp+4],1
 jne fail
 mov eax,ecx
 ret 4
.section .button_ctor,"ax"
 cmp ecx,OFFSET root+{BUTTON}
 jne fail
 cmp DWORD PTR [esp+4],1
 jne fail
 inc DWORD PTR [constructed]
 ret 4
.section .button_dtor,"ax"
 cmp ecx,OFFSET root+{BUTTON+0x630}
 jne fail
 inc DWORD PTR [destroyed]
 ret
.section .dtor_tail,"ax"
 cmp DWORD PTR [esp],{base+struct.unpack('<I',p.get_data(pr['dtor']+3,4))[0]-0x400000}
 jne fail
 cmp DWORD PTR [esp+4],-1
 jne fail
 cmp ecx,OFFSET root+0x1620
 jne fail
 add esp,8
 ret
.section .attach,"ax"
 cmp DWORD PTR [esp+4],OFFSET root
 jne fail
 inc DWORD PTR [attached]
 ret 4
.section .caption,"ax"
 cmp ecx,OFFSET root+{BUTTON}
 jne fail
 mov eax,[thunk+{sy['mode']}]
 mov edx,[thunk+{sy['captions']}+eax*4]
 add edx,OFFSET thunk
 cmp edx,[esp+4]
 jne fail
 ret 4
.section .register,"ax"
 cmp ecx,OFFSET root+{BUTTON}
 jne fail
 cmp DWORD PTR [esp+4],0x0e
 jne fail
 cmp DWORD PTR [esp+8],OFFSET root
 jne fail
 cmp DWORD PTR [esp+12],OFFSET thunk+{sy['cycle']}
 jne fail
 cmp DWORD PTR [esp+16],0
 jne fail
 cmp DWORD PTR [esp+20],0
 jne fail
 cmp DWORD PTR [esp+24],0
 jne fail
 inc DWORD PTR [registered]
 ret 24
.section .enabled,"ax"
 cmp ecx,OFFSET root+{BUTTON}
 jne fail
 cmp DWORD PTR [esp+4],1
 jne fail
 inc DWORD PTR [enabled_called]
 ret 4
.section .bounds,"ax"
 cmp DWORD PTR [step],11
 je close_case
 cmp ecx,OFFSET root+{BUTTON}
 jne fail
 cmp DWORD PTR [esp+4],10
 jne fail
 cmp DWORD PTR [esp+8],65
 jne fail
 cmp DWORD PTR [esp+12],270
 jne fail
 cmp DWORD PTR [esp+16],20
 jne fail
 inc DWORD PTR [bounds_called]
 ret 16
close_case:
 cmp DWORD PTR [esp+4],200
 jne fail
 cmp DWORD PTR [esp+8],475
 jne fail
 cmp DWORD PTR [esp+12],80
 jne fail
 cmp DWORD PTR [esp+16],20
 jne fail
 ret 16
.section .detach,"ax"
 cmp ecx,OFFSET root+{BUTTON}
 jne fail
 inc DWORD PTR [detached]
 ret
.section .input_detach,"ax"
 cmp ecx,OFFSET root+0x1228
 jne fail
 inc DWORD PTR [input_detached]
 ret
.section .weather_tail,"ax"
 cmp eax,[wanted]
 jne fail
 ret
.section .thunk,"awx"
thunk: .incbin "{d/'code.bin'}"
.section .data,"aw"
step: .long 0
saved_sp: .long 0
wanted: .long 0
constructed: .long 0
attached: .long 0
destroyed: .long 0
detached: .long 0
input_detached: .long 0
bounds_called: .long 0
enabled_called: .long 0
registered: .long 0
root: .zero {SIZE}
world: .zero 0x200
world2: .zero 0x200
'''
   sections={n:pr[n] for n in ('ctor','button_ctor','button_dtor','attach','caption','register','enabled','bounds','detach','input_detach')}
   sections.update(dtor_tail=pr['dtor']+7,weather_tail=pr['weather_hook']+6,thunk=m['rva'])
   layout='\n'.join(f'.{k} {base+v} : {{ *(.{k}) }}' for k,v in sorted(sections.items(),key=lambda x:x[1]))
   (d/'test.s').write_text(asm);(d/'test.ld').write_text(f'ENTRY(start)\nSECTIONS {{ .main {base+0x1000} : {{ *(.main) }}\n{layout}\n.data : {{ *(.data) }} }}')
   subprocess.run(['as','--32','-o',str(d/'test.o'),str(d/'test.s')],check=True)
   subprocess.run(['ld','-m','elf_i386','-T',str(d/'test.ld'),'-o',str(d/'test'),str(d/'test.o')],check=True,capture_output=True)
   if not build_only:
    r=subprocess.run([str(d/'test')],timeout=10);assert r.returncode==0,(name,hex(base),r.returncode)
 print(name,'PASS: native weather cycle, UI lifetime/layout, ABI, auto restoration; two bases; all prior sections preserved')
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('--build-only',action='store_true');args=a.parse_args()
 for name in ('WLP','WLPADD1'):verify(name,args.build_only)
