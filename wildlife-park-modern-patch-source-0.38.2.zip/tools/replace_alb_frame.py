#!/usr/bin/env python3
"""Replace a single-frame RGB565 ALB entry without touching other payloads."""
import argparse, struct, hashlib, json
from pathlib import Path
from PIL import Image
from extract_alb import decompress

def encode_literals(raw):
    # Reset every 200 literal bytes, keeping every code at nine bits.
    out=bytearray(); bits=0; count=0
    def emit(code):
        nonlocal bits,count
        bits|=code<<count;count+=9
        while count>=8:
            out.append(bits&255);bits>>=8;count-=8
    for pos in range(0,len(raw),200):
        emit(256)
        for byte in raw[pos:pos+200]:emit(byte)
    if count:out.append(bits&255)
    return bytes(out)

def replace(source,png,entry,output):
    data=source.read_bytes();version,n,flags,unused,table_start,table_bytes=struct.unpack_from('<HHIIII',data)
    if version!=200 or flags!=272:raise ValueError('Unsupported ALB format')
    if not 0<=entry<n:raise ValueError('Invalid entry')
    header=255+entry*64
    frames,w,h,old_raw,total,identifier=struct.unpack_from('<HHHIII',data,header)
    if frames!=1:raise ValueError('Only single-frame entries supported')
    image=Image.open(png).convert('RGBA')
    if any(a!=255 for *rgb,a in image.getdata()):
        print('Note: RGB565 has no alpha; importing RGB colors of partially transparent pixels')
    width,height=image.size
    if height!=h:raise ValueError('Height must remain unchanged')
    raw=bytearray()
    for red,green,blue,alpha in image.getdata():
        pixel=(round(red*31/255)<<11)|(round(green*63/255)<<5)|round(blue*31/255)
        raw+=struct.pack('<H',pixel)
    compressed=encode_literals(raw)
    assert decompress(compressed,len(raw))==raw
    frame=sum(struct.unpack_from('<H',data,255+i*64)[0] for i in range(entry))
    offsets=list(struct.unpack_from(f'<{table_bytes//4}I',data,table_start))
    begin,end=offsets[frame:frame+2];delta=len(compressed)-(end-begin)
    result=bytearray(data[:begin]+compressed+data[end:])
    struct.pack_into('<HH',result,header+2,width,height)
    struct.pack_into('<II',result,header+6,len(raw),len(raw))
    for i in range(frame+1,len(offsets)):offsets[i]+=delta
    struct.pack_into(f'<{len(offsets)}I',result,table_start,*offsets)
    assert offsets[-1]==len(result)
    with output.open('xb') as f:f.write(result)
    print(f'Created {output}; entry {entry}: {w}x{h} -> {width}x{height}; SHA256 {hashlib.sha256(result).hexdigest()}')

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('source',type=Path);p.add_argument('png',type=Path);p.add_argument('output',type=Path);p.add_argument('--entry',type=int,default=0)
    a=p.parse_args();replace(a.source,a.png,a.entry,a.output)
