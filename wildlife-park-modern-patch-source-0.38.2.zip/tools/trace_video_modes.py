#!/usr/bin/env python3
"""Log mode requests and errors without changing their behavior, in both games.

Fixed 2050-byte records: 32 DWORD header, 70 DirectDraw records (20 bytes),
87 abstract mode registrations (6 bytes). Files are appended in the game root.
The original Win32 last-error value, registers, flags and stack are preserved.
"""
import argparse
import hashlib
import struct
from pathlib import Path
import pefile
from patch_addon_widescreen import append_section, next_rva, redirect

PROFILES = {
    '864fd20600dd5f84d0655712f4475e55ef6f04c6f5c969d32f941e58a0ed8d18':
        ('base', 0, 0x1c63a0, 0x26f590),
    'bd5208c96fe99bbbc7b3e38df491df3223869ca33863aa4d7116ef8b5cd6f938':
        ('addon', 0x1ec988, 0x1f3d20, 0x29d110),
}
FIELDS = ('magic', 'event', 'caller', 'arg0', 'arg1', 'arg2',
          'mode', 'width', 'height', 'depth', 'requested_flags', 'status',
          'mode_count', 'driver', 'selected_mode', 'active_flags',
          'primary_context', 'render_context', 'actual_width', 'actual_height',
          'engine_error', 'enumerated_count', 'video_memory', 'dd_caps',
          'enumeration_pending', 'ddraw_pointer', 'last_error')


def patch(src):
    profile = PROFILES.get(hashlib.sha256(src).hexdigest())
    if profile is None:
        raise ValueError('Requires known working widescreen build')
    name, delta, request, error = profile
    p = pefile.PE(data=src)
    imports = {i.name.decode(): i.address - p.OPTIONAL_HEADER.ImageBase
               for dll in p.DIRECTORY_ENTRY_IMPORT for i in dll.imports if i.name}
    b = bytearray(src)
    rva = next_rva(b)
    code, references = bytearray(), []

    def api(name):
        code.extend(b'\xff\x93' + struct.pack('<I', imports[name]))

    def reference(op, name):
        code.extend(op)
        references.append((len(code), name))
        code.extend(bytes(4))

    def store(index):
        code.extend(bytes.fromhex('898424') + struct.pack('<I', index * 4))

    for event, hook, original in [(1, request, bytes.fromhex('83ec10535556')),
                                  (2, error, bytes.fromhex('64a100000000'))]:
        target = rva + len(code)
        code.extend(bytes.fromhex('9c608bec'))  # save flags/registers; EBP = saved frame
        code.extend(bytes.fromhex('e8000000005b'))
        anchor = rva + len(code) - 1
        code.extend(b'\x81\xeb' + struct.pack('<I', anchor))
        code.extend(b'\x81\xec' + struct.pack('<I', 2080))
        code.extend(bytes.fromhex('fc8bfc33c0b908020000f3ab'))  # zero 2080-byte scratch
        api('GetLastError')
        code.extend(bytes.fromhex('898424') + struct.pack('<I', 2076))
        store(26)
        for index, value in [(0, int.from_bytes(b'WVM1', 'little')), (1, event)]:
            code.extend(b'\xb8' + struct.pack('<I', value))
            store(index)
        for index, saved in [(2, 36), (3, 40), (4, 44), (5, 48)]:
            code.extend(bytes.fromhex('8b45') + bytes([saved]))
            store(index)
        if event == 1:
            code.extend(bytes.fromhex('8b7518'))  # PUSHAD saved ECX at +24
        else:
            code.extend(b'\x8d\xb3' + struct.pack('<I', 0xa392e8 + delta))
        for index, off in enumerate((0x20, 0x24, 0x28, 0x2c, 0x30, 0x70,
                                     0x74, 0x78, 0x7c, 0x80, 0x84, 0x88,
                                     0x90, 0x94), 6):
            code.extend(b'\x8b\x86' + struct.pack('<I', off))
            store(index)
        for index, global_rva in enumerate((0xa5879c, 0xa5449c, 0xa585dc,
                                           0xa585a4, 0x8aa970, 0xa52fdc), 20):
            # Initialized data and zero-filled globals have different shifts.
            shift = 0x18c450 if name == 'addon' and global_rva == 0x8aa970 else delta
            code.extend(b'\x8b\x83' + struct.pack('<I', global_rva + shift))
            store(index)
        for dest, source, count in [(128, 0xa552d8, 350), (1528, 0xa58c80, 130)]:
            code.extend(bytes.fromhex('8dbc24') + struct.pack('<I', dest))
            code.extend(b'\x8d\xb3' + struct.pack('<I', source + delta))
            code.extend(b'\xb9' + struct.pack('<I', count) + bytes.fromhex('f3a5'))
        # Last two registration bytes after 130 DWORDs.
        code.extend(b'\x66\x8b\x06\x66\x89\x07')
        code.extend(bytes.fromhex('6a0068800000006a046a006a036a04'))
        reference(b'\x8d\x83', 'filename')
        code.extend(b'\x50')
        api('CreateFileA')
        code.extend(bytes.fromhex('8bf883f8ff0f84'))
        skip = len(code)
        code.extend(bytes(4))
        code.extend(bytes.fromhex('8bd48d8c24') + struct.pack('<I', 2072))
        code.extend(bytes.fromhex('6a005168020800005257'))  # 2050 bytes; buffer = EDX
        api('WriteFile')
        code.extend(b'\x57')
        api('CloseHandle')
        struct.pack_into('<i', code, skip, len(code) - skip - 4)
        code.extend(bytes.fromhex('ffb424') + struct.pack('<I', 2076))
        api('SetLastError')
        code.extend(b'\x81\xc4' + struct.pack('<I', 2080))
        code.extend(bytes.fromhex('619d') + original)
        code.extend(b'\xe9' + struct.pack('<i', hook + len(original) - (rva + len(code) + 5)))
        redirect(b, hook, original, target)
    filename = rva + len(code)
    code.extend(('C:\\Program Files (x86)\\Deep Silver\\Wildlife Park Gold\\VideoModeTrace-'
                 + name + '.bin\0').encode('ascii'))
    for off, _ in references:
        struct.pack_into('<I', code, off, filename)
    append_section(b, b'.wlpvlog', code)
    return bytes(b)


def decode(path):
    data = path.read_bytes()
    if len(data) % 2050:
        raise ValueError('Incomplete trace record')
    for off in range(0, len(data), 2050):
        values = struct.unpack_from('<32I', data, off)
        assert values[0] == int.from_bytes(b'WVM1', 'little')
        row = dict(zip(FIELDS, values))
        print('Record', off // 2050, 'request' if row['event'] == 1 else 'error')
        print(' '.join(f'{k}={v:#x}' for k, v in row.items() if k not in ('magic', 'event')))
        if row['event'] == 2:
            print('Registered modes:', [(i, data[off + 1528 + i * 6],
                                        data[off + 1529 + i * 6]) for i in range(87)
                                       if data[off + 1528 + i * 6] != 255])
            count = min(row['enumerated_count'], 70)
            print('Enumerated modes:', [(struct.unpack_from('<II', data, off + 128 + i * 20),
                                        data[off + 144 + i * 20]) for i in range(count)])


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path)
    parser.add_argument('output', nargs='?', type=Path)
    args = parser.parse_args()
    if args.output is None:
        decode(args.source)
    else:
        result = patch(args.source.read_bytes())
        with args.output.open('xb') as f:
            f.write(result)
        print(hashlib.sha256(result).hexdigest())
