#!/usr/bin/env python3
"""Keep F2-F12 menus reachable in cheat mode; Cancel can then clear the mode."""
import argparse
import hashlib
import struct
import subprocess
import tempfile
from pathlib import Path
import pefile
from patch_addon_widescreen import append_section, next_rva

PROFILES = {
    '1a6895802829aa5f7b83ed5d942dd3ffc10c6658c6313aef9d3f918c274e028f':
        (0x119775, 0x1198e1, 0x8af1d5),
    '678d6e85d52667094448abda17c35257bb0c59a8fb0950b4e6dec87a73e034ff':
        (0x12bf55, 0x12c0c1, 0xa3b49e),
}


def patch(src):
    hook, normal, flag = PROFILES[hashlib.sha256(src).hexdigest()]
    rva = next_rva(src)
    asm = f'''.intel_syntax noprefix
.code32
.global _start
_start:
 pushfd
 push eax
 movzx eax, WORD PTR [edi+0x40]
 test al, al
 jne ordinary
 cmp ah, 0x57
 je menu
 cmp ah, 0x58
 je menu
 cmp ah, 0x3c
 jb ordinary
 cmp ah, 0x44
 ja ordinary
menu:
 pop eax
 popfd
 jmp _start + {normal-rva}
ordinary:
 call anchor
anchor:
 pop eax
 sub eax, {rva}+anchor-_start
 mov al, BYTE PTR [eax+{flag}]
 mov BYTE PTR [esp], al
 pop eax
 popfd
 jmp _start + {hook+5-rva}
'''
    with tempfile.TemporaryDirectory() as tmp:
        d=Path(tmp)
        (d/'thunk.s').write_text(asm)
        subprocess.run(['as','--32','-o',str(d/'thunk.o'),str(d/'thunk.s')],check=True)
        assert 'R_386' not in subprocess.check_output(['objdump','-r',str(d/'thunk.o')],text=True)
        subprocess.run(['objcopy','-O','binary','-j','.text',str(d/'thunk.o'),str(d/'thunk.bin')],check=True)
        code=(d/'thunk.bin').read_bytes()
    p=pefile.PE(data=src)
    off=p.get_offset_from_rva(hook)
    b=bytearray(src)
    assert b[off:off+5] == b'\xa0'+struct.pack('<I',0x400000+flag)
    b[off:off+5] = b'\xe9'+struct.pack('<i',rva-hook-5)
    # The replaced absolute address had a loader relocation. A relative JMP
    # must not receive that adjustment when the executable is rebased.
    reloc_offsets=[]
    for block in p.DIRECTORY_ENTRY_BASERELOC:
        for entry in block.entries:
            if entry.rva==hook+1 and entry.type==3:
                roff=entry.struct.get_file_offset()
                value=struct.unpack_from('<H',b,roff)[0]
                struct.pack_into('<H',b,roff,value & 0xfff)
                reloc_offsets.append(roff)
    assert len(reloc_offsets)==1
    append_section(b,b'.wlpcht',code)
    return bytes(b),dict(hook=hook,normal=normal,flag=flag,rva=rva,code=code,reloc_offsets=reloc_offsets)


if __name__ == '__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input',type=Path)
    parser.add_argument('output',type=Path)
    args=parser.parse_args()
    out,_=patch(args.input.read_bytes())
    with args.output.open('xb') as f:
        f.write(out)
    print(args.output,hashlib.sha256(out).hexdigest())
