#!/usr/bin/env python3
"""Bounded experimental TPS memory change via WineDbg's GDB remote protocol.

Specific to the current base WLP.EXE. Does not update cached object durations.
"""
import argparse
import json
import os
from pathlib import Path
import socket
import struct
import subprocess
import time

ROOT = Path(__file__).resolve().parents[1]
WINE = '/path/to/user/.local/share/Steam/compatibilitytools.d/GE-Proton-latest/files/bin/wine'
PREFIX = '/path/to/user/Games/Heroic/Prefixes/default/WildlifePark'

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--pid', required=True, type=lambda x: int(x, 0))
    ap.add_argument('--tps', required=True, type=int)
    args = ap.parse_args()
    if not 1 <= args.tps <= 255:
        ap.error('TPS must fit the nonzero unsigned byte used by this executable')
    env = os.environ.copy()
    env['WINEPREFIX'] = PREFIX
    log = ROOT / 'analysis/tps-remote-debugger.log'
    report_path = ROOT / 'analysis/tps-live-test.json'
    report = {'pid': hex(args.pid), 'requested_tps': args.tps, 'writes': [],
              'limitation': 'Existing object countdowns and cached duration tables are not recalculated.'}
    sock = None
    detached = False
    applied = []
    with log.open('w') as out:
        proc = subprocess.Popen([WINE, 'winedbg', '--gdb', '--no-start', '--port',
                                 '31379', hex(args.pid)], env=env, stdout=out, stderr=out)
        try:
            deadline = time.monotonic() + 15
            while time.monotonic() < deadline:
                if proc.poll() is not None:
                    raise RuntimeError('WineDbg exited: ' + log.read_text()[-2000:])
                try:
                    sock = socket.create_connection(('127.0.0.1', 31379), timeout=1)
                    break
                except ConnectionRefusedError:
                    time.sleep(0.1)
            if sock is None:
                raise RuntimeError('WineDbg remote server did not become ready')
            sock.settimeout(10)

            def packet(command):
                body = command.encode('ascii')
                sock.sendall(b'$' + body + b'#' + f'{sum(body) & 255:02x}'.encode())
                while True:
                    ch = sock.recv(1)
                    if not ch:
                        raise RuntimeError('Remote connection closed')
                    if ch == b'$':
                        break
                data = bytearray()
                while True:
                    ch = sock.recv(1)
                    if not ch:
                        raise RuntimeError('Incomplete remote reply')
                    if ch == b'#':
                        break
                    data.extend(ch)
                checksum = b''
                while len(checksum) < 2:
                    checksum += sock.recv(2 - len(checksum))
                if sum(data) & 255 != int(checksum, 16):
                    sock.sendall(b'-')
                    raise RuntimeError('Invalid remote reply checksum')
                sock.sendall(b'+')
                return data.decode('ascii')

            def read(address, size):
                reply = packet(f'm{address:x},{size:x}')
                if reply.startswith('E'):
                    raise RuntimeError('Remote read failed: ' + reply)
                result = bytes.fromhex(reply)
                if len(result) != size:
                    raise RuntimeError('Incomplete remote memory read')
                return result

            def write(address, value):
                reply = packet(f'M{address:x},{len(value):x}:{value.hex()}')
                if reply != 'OK':
                    raise RuntimeError('Remote write failed: ' + reply)
                if read(address, len(value)) != value:
                    raise RuntimeError('Memory write readback mismatch')

            report['stop_reply'] = packet('?')
            pe_bytes = (ROOT / 'builds/current/WLP.EXE').read_bytes()
            # The current binary's .text has matching RVA and raw offset.
            expected = pe_bytes[0x106ca0:0x106cb4]
            if read(0x506ca0, len(expected)) != expected:
                raise RuntimeError('Live timing function differs from the analyzed executable')
            tps = read(0x73ac89, 1)[0]
            obj = struct.unpack('<I', read(0xccc454, 4))[0]
            if not obj:
                raise RuntimeError('No live timer owner')
            base = struct.unpack('<I', read(obj + 0x5f0, 4))[0]
            active = struct.unpack('<f', read(obj + 0x5e0, 4))[0]
            phase = struct.unpack('<f', read(obj + 0x5e4, 4))[0]
            report['before'] = {'tps': tps, 'owner': hex(obj), 'base_ms': base,
                                'active_ms': active, 'phase': phase,
                                'neighbor_bytes': read(0x73ac89, 8).hex()}
            if tps != 25 or base != 40:
                raise RuntimeError('Expected the user-selected 25 TPS baseline before the test')
            new_base = 1000 // args.tps
            changes = [(0x73ac89, bytes([args.tps])),
                       (obj + 0x5f0, struct.pack('<I', new_base))]
            if active > 0:
                # Retain slow-down/speed-up relative to the base interval.
                changes += [(obj + 0x5e0, struct.pack('<f', active * new_base / base)),
                            (obj + 0x5e4, struct.pack('<f', 0.0))]
            for address, value in changes:
                old = read(address, len(value))
                applied.append((address, old))
                write(address, value)
                report['writes'].append({'address': hex(address), 'before': old.hex(),
                                         'after': value.hex()})
            report['after'] = {'tps': read(0x73ac89, 1)[0],
                               'base_ms': struct.unpack('<I', read(obj + 0x5f0, 4))[0],
                               'active_ms': struct.unpack('<f', read(obj + 0x5e0, 4))[0],
                               'neighbor_bytes': read(0x73ac89, 8).hex()}
            report['status'] = 'applied-and-readback-verified'
        except Exception as exc:
            report['status'] = 'failed'
            report['error'] = str(exc)
            if sock is not None and applied:
                try:
                    for address, old in reversed(applied):
                        write(address, old)
                    report['rollback'] = 'verified'
                except Exception as rollback_exc:
                    report['rollback_error'] = str(rollback_exc)
        finally:
            if sock is not None:
                try:
                    report['detach_reply'] = packet('D')
                    detached = report['detach_reply'] == 'OK'
                except Exception as exc:
                    report['detach_error'] = str(exc)
                if detached:
                    sock.close()
            report['detached'] = detached
            report_path.write_text(json.dumps(report, indent=2) + '\n')
            print(json.dumps(report, indent=2), flush=True)
            if detached:
                try:
                    proc.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    print('WineDbg has not exited after detach; game detach was acknowledged.')
            elif sock is None:
                print('Remote attach failed; inspect debugger log before further actions.')
            if report['status'] == 'failed' or not detached:
                raise SystemExit(1)

if __name__ == '__main__':
    main()
