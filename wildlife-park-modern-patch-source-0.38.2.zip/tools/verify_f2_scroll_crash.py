#!/usr/bin/env python3
"""Execute native value-change virtual dispatch at +80 after table repair."""
import json,subprocess,tempfile
from pathlib import Path
from fix_f2_scroll_crash import ROOT,build
from patch_debug_tools import digest

def verify(m):
 for base in (0x400000,0x14000000):
  s=m['symbols'];rv=m['rva'];table=base+rv+s['table'];oldtable=base+rv+0x20000
  asm=f'''.intel_syntax noprefix
.code32
.global start
.section .main,"ax"
start:
 mov [saved_sp],esp
 mov ecx,OFFSET root+0xbf0
 push OFFSET root
 call thunk+{s['attach']}
 cmp DWORD PTR [root+{m['scroll']}],{table}
 jne fail
 cmp DWORD PTR [previous_calls],1
 jne fail
 cmp DWORD PTR [{table}+8],{base+m['invalidate']}
 jne fail
 cmp DWORD PTR [{table}+0x80],{base+m['last']}
 jne fail
 xor edx,edx
compare:
 cmp edx,8
 je next
 mov eax,[edx+{base+m['native']}]
 cmp eax,[edx+{table}]
 jne fail
next:
 add edx,4
 cmp edx,132
 jb compare
 # Native slider paths 64078a / 640913 call the final slot with one argument.
 mov ecx,OFFSET root+{m['scroll']}
 mov eax,[ecx]
 push OFFSET packet
 call DWORD PTR [eax+0x80]
 mov ecx,OFFSET root+{m['scroll']}
 mov eax,[ecx]
 push OFFSET packet
 call DWORD PTR [eax+0x80]
 cmp DWORD PTR [notifications],2
 jne fail
 # Existing redraw hook remains the target for dirty/value changes.
 mov ecx,OFFSET root+{m['scroll']}
 mov eax,[ecx]
 push 1
 call DWORD PTR [eax+8]
 cmp DWORD PTR [redraws],1
 jne fail
 cmp esp,[saved_sp]
 jne fail
 xor ebx,ebx
 mov eax,1
 int 0x80
fail:
 mov ebx,1
 mov eax,1
 int 0x80
.section .previous,"ax"
 cmp ecx,OFFSET root+0xbf0
 jne fail
 cmp DWORD PTR [esp+4],OFFSET root
 jne fail
 mov DWORD PTR [root+{m['scroll']}],{oldtable}
 inc DWORD PTR [previous_calls]
 ret 4
.section .notification,"ax"
 cmp ecx,OFFSET root+{m['scroll']}
 jne fail
 cmp DWORD PTR [esp+4],OFFSET packet
 jne fail
 inc DWORD PTR [notifications]
 ret 4
.section .invalidate,"ax"
 cmp ecx,OFFSET root+{m['scroll']}
 jne fail
 cmp DWORD PTR [esp+4],1
 jne fail
 inc DWORD PTR [redraws]
 ret 4
.section .native,"aw"
.rept 32
.long {base+m['last']}
.endr
.long {base+m['last']}
.section .thunk,"axw"
thunk: .incbin "CODEPATH"
.section .mockdata,"aw"
saved_sp: .long 0
previous_calls: .long 0
notifications: .long 0
redraws: .long 0
packet: .zero 32
root: .zero {m['size']}
'''
  sec=dict(previous=m['previous'],notification=m['last'],invalidate=m['invalidate'],native=m['native'],thunk=rv)
  with tempfile.TemporaryDirectory() as tmp:
   d=Path(tmp);(d/'code.bin').write_bytes(m['code']);(d/'test.s').write_text(asm.replace('CODEPATH',str(d/'code.bin')))
   layout='\n'.join(f'.{k} {base+x} : {{ *(.{k}) }}' for k,x in sorted(sec.items(),key=lambda x:x[1]))
   (d/'test.ld').write_text(f'ENTRY(start)\nSECTIONS {{ .main {base+0x1000} : {{ *(.main) }}\n{layout}\n.mockdata {base+rv+0x10000} : {{ *(.mockdata) }} }}')
   subprocess.run(['as','--32','-o',str(d/'test.o'),str(d/'test.s')],check=True)
   subprocess.run(['ld','-m','elf_i386','-T',str(d/'test.ld'),'-o',str(d/'test'),str(d/'test.o')],check=True,capture_output=True)
   result=subprocess.run([str(d/'test')],timeout=10);assert result.returncode==0,(m['name'],hex(base),result.returncode)
 print('PASS '+m['name']+': all 33 slots, native +80 dispatch twice, preserved redraw hook and stack balance; two bases')
if __name__=='__main__':
 records=[]
 for name in ('WLP','WLPADD1'):
  data,m=build(name);verify(m);records.append(dict(name=name,passed=True,sha256=digest(data),code_sha256=digest(m['code']),image_bases=['0x400000','0x14000000']))
 (ROOT/'analysis/f2-scroll-crash-verification.json').write_text(json.dumps(records,indent=2)+'\n')
