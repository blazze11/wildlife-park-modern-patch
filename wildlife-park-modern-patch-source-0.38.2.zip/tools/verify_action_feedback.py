#!/usr/bin/env python3
"""Execute action feedback thunks against mocked engine methods (not a GUI test)."""
import argparse
import struct
import subprocess
import tempfile
from pathlib import Path

import pefile
from patch_action_feedback import patch
from patch_keybind_panel import asm_string


def verify(source, output, build_only=False):
    src = source.read_bytes()
    new, m = patch(src)
    assert new == output.read_bytes()
    old = pefile.PE(data=src)
    expected = bytearray(src)
    for rva, size in m['changes']:
        off = old.get_offset_from_rva(rva)
        expected[off:off + size] = new[off:off + size]
    for off in m['reloc_offsets']:
        expected[off:off + 2] = new[off:off + 2]
    for section in old.sections:
        off, size = section.PointerToRawData, section.SizeOfRawData
        assert new[off:off + size] == expected[off:off + size]
    parsed = pefile.PE(data=new)
    assert all(s.PointerToRawData + s.SizeOfRawData <= len(new) for s in parsed.sections)
    assert parsed.sections[-1].Characteristics & 0x80000000
    for block in parsed.DIRECTORY_ENTRY_BASERELOC:
        for entry in block.entries:
            assert not entry.type or not any(h <= entry.rva < h + n for h, n in m['changes'])
    p = m['profile']
    symbols = '\n'.join(f'.set {name}, thunk+{off}' for name, off in m['symbols'].items())
    expected_strings = '\n'.join(asm_string(f'oracle_{i + 1}', text)
                                 for i, text in enumerate(m['messages']))
    routines = []
    cases = []
    step = 0

    def case(code):
        nonlocal step
        step += 1
        cases.append(f'mov DWORD PTR [step], {step}\n{code}\n'
                     'cmp esp,[saved_sp]\njne fail\n')

    # Toggle is a callback with two event arguments; it keeps the panel open.
    for old_mode, message, caption in [(0, 1, 'disable_oracle'), (1, 2, 'enable_oracle')]:
        case(f'''mov BYTE PTR [cheat_flag],{old_mode}
 mov DWORD PTR [pending],0
 mov DWORD PTR [expected_caption],OFFSET {caption}
 mov DWORD PTR [caption_calls],0
 mov DWORD PTR [close_calls],0
 mov ecx,OFFSET root
 mov eax,0x12345678
 mov edx,0x3333
 mov ebx,0x4444
 mov ebp,0x5555
 mov esi,0x6666
 mov edi,0x7777
 pushfd
 pop DWORD PTR [before_flags]
 push 0xabc1
 push 0xabc2
 call toggle
 pushfd
 pop DWORD PTR [after_flags]
 cmp eax,0x12345601
 jne fail
 cmp ecx,OFFSET root
 jne fail
 cmp edx,0x3333
 jne fail
 cmp ebx,0x4444
 jne fail
 cmp ebp,0x5555
 jne fail
 cmp esi,0x6666
 jne fail
 cmp edi,0x7777
 jne fail
 mov eax,[before_flags]
 cmp eax,[after_flags]
 jne fail
 cmp BYTE PTR [cheat_flag],{1-old_mode}
 jne fail
 cmp DWORD PTR [pending],{message}
 jne fail
 cmp DWORD PTR [caption_calls],1
 jne fail
 cmp DWORD PTR [close_calls],0
 jne fail''')
    for mode in (0, 1):
        case(f'''mov BYTE PTR [cheat_flag],{mode}
 mov DWORD PTR [close_calls],0
 mov ecx,OFFSET root
 push 0
 push 0
 call close_panel
 cmp al,1
 jne fail
 cmp BYTE PTR [cheat_flag],{mode}
 jne fail
 cmp DWORD PTR [close_calls],1
 jne fail''')
    # Every action invokes its actual engine routine once and forwards arguments.
    for kind, success_id, failure_id in [('save', 3, 6), ('load', 4, 7), ('shot', 5, 8)]:
        for result in (0, 1, 0x12345600, 0x12345601):
            success = result == 1 if kind == 'shot' else bool(result & 255)
            call_args = '\n'.join(f'push {i}' for i in range(6, 0, -1)) if kind == 'shot' else 'push OFFSET filename'
            cleanup = 'add esp,24' if kind == 'shot' else ''
            case(f'''mov DWORD PTR [pending],0
 mov DWORD PTR [action_calls],0
 mov DWORD PTR [mock_result],{result}
 mov ecx,0x13572468
 mov ebx,0x4444
 mov ebp,0x5555
 mov esi,0x6666
 mov edi,0x7777
 {call_args}
 call {kind}_feedback
 pushfd
 pop DWORD PTR [after_flags]
 {cleanup}
 cmp eax,{result}
 jne fail
 cmp ecx,0x8888
 jne fail
 cmp edx,0x9999
 jne fail
 cmp ebx,0x4444
 jne fail
 cmp ebp,0x5555
 jne fail
 cmp esi,0x6666
 jne fail
 cmp edi,0x7777
 jne fail
 cmp DWORD PTR [action_calls],1
 jne fail
 cmp DWORD PTR [pending],{success_id if success else failure_id}
 jne fail
 {'mov eax,[after_flags]\nxor eax,[mock_flags]\ntest eax,0x8d5\njne fail' if kind != 'shot' else ''}''')
        compare = '\n'.join(f'cmp DWORD PTR [esp+{i*4}],{i}\njne fail' for i in range(1, 7)) if kind == 'shot' else '''cmp DWORD PTR [esp+4],OFFSET filename
 jne fail'''
        routines.append(f'''.section .{kind},"ax"
 cmp ecx,0x13572468
 jne fail
 {compare}
 inc DWORD PTR [action_calls]
 mov eax,[mock_result]
 mov ecx,0x8888
 mov edx,0x9999
 cmp edx,edx
 stc
 pushfd
 pop DWORD PTR [mock_flags]
 {'ret' if kind == 'shot' else 'ret 4'}
''')
    # Update runs in the live UI frame with ESI=root; continuation mocked as RET.
    for message in range(1, 9):
        case(f'''mov DWORD PTR [owner],OFFSET root
 mov DWORD PTR [pending],{message}
 mov DWORD PTR [tick_now],100
 mov DWORD PTR [expected_text],OFFSET oracle_{message}
 mov DWORD PTR [expected_visible],1
 mov DWORD PTR [setter_calls],0
 mov DWORD PTR [visible_calls],0
 mov esi,OFFSET root
 mov ecx,0x2222
 mov edx,0x3333
 mov ebx,0x4444
 mov ebp,0x5555
 mov edi,0x7777
 mov eax,0x12345678
 pushfd
 pop DWORD PTR [before_flags]
 call update
 pushfd
 pop DWORD PTR [after_flags]
 cmp eax,0x12345678
 jne fail
 cmp ecx,0x2222
 jne fail
 cmp edx,0x3333
 jne fail
 cmp ebx,0x4444
 jne fail
 cmp ebp,0x5555
 jne fail
 cmp edi,0x7777
 jne fail
 cmp esi,OFFSET root
 jne fail
 mov eax,[before_flags]
 cmp eax,[after_flags]
 jne fail
 cmp DWORD PTR [pending],0
 jne fail
 cmp DWORD PTR [active],{message}
 jne fail
 cmp DWORD PTR [started],100
 jne fail
 cmp DWORD PTR [setter_calls],1
 jne fail
 cmp DWORD PTR [visible_calls],1
 jne fail''')
    case('''mov DWORD PTR [tick_now],4099
 mov DWORD PTR [setter_calls],0
 mov DWORD PTR [visible_calls],0
 mov esi,OFFSET root
 call update
 cmp DWORD PTR [active],8
 jne fail
 cmp DWORD PTR [setter_calls],0
 jne fail
 cmp DWORD PTR [visible_calls],0
 jne fail''')
    case('''mov DWORD PTR [tick_now],4100
 mov DWORD PTR [expected_text],OFFSET empty_oracle
 mov DWORD PTR [expected_visible],0
 mov esi,OFFSET root
 call update
 cmp DWORD PTR [active],0
 jne fail
 cmp DWORD PTR [setter_calls],1
 jne fail
 cmp DWORD PTR [visible_calls],1
 jne fail''')
    # Unsigned elapsed subtraction spans timeGetTime's 32-bit wrap.
    for elapsed in (3999, 4000):
        case(f'''mov DWORD PTR [owner],OFFSET root
 mov DWORD PTR [active],3
 mov DWORD PTR [started],0xfffffff0
 mov DWORD PTR [tick_now],{(0xfffffff0+elapsed)&0xffffffff}
 mov DWORD PTR [setter_calls],0
 mov DWORD PTR [visible_calls],0
 mov esi,OFFSET root
 call update
 cmp DWORD PTR [active],{3 if elapsed < 4000 else 0}
 jne fail
 cmp DWORD PTR [setter_calls],{0 if elapsed < 4000 else 1}
 jne fail
 cmp DWORD PTR [visible_calls],{0 if elapsed < 4000 else 1}
 jne fail''')
    case('''mov DWORD PTR [owner],OFFSET old_root
 mov DWORD PTR [active],3
 mov DWORD PTR [pending],0
 mov DWORD PTR [setter_calls],0
 mov DWORD PTR [visible_calls],0
 mov esi,OFFSET root
 call update
 cmp DWORD PTR [owner],OFFSET root
 jne fail
 cmp DWORD PTR [active],0
 jne fail
 cmp DWORD PTR [setter_calls],1
 jne fail
 cmp DWORD PTR [visible_calls],1
 jne fail''')
    case('''mov DWORD PTR [owner],OFFSET old_root
 mov DWORD PTR [active],3
 mov DWORD PTR [pending],4
 mov DWORD PTR [tick_now],9000
 mov DWORD PTR [expected_text],OFFSET oracle_4
 mov DWORD PTR [expected_visible],1
 mov DWORD PTR [setter_calls],0
 mov DWORD PTR [visible_calls],0
 mov esi,OFFSET root
 call update
 cmp DWORD PTR [owner],OFFSET root
 jne fail
 cmp DWORD PTR [active],4
 jne fail
 cmp DWORD PTR [started],9000
 jne fail
 cmp DWORD PTR [pending],0
 jne fail''')
    with tempfile.TemporaryDirectory() as tmp:
        d = Path(tmp)
        (d / 'code.bin').write_bytes(m['code'])
        for base in (0x400000, 0x10000000):
            asm = f'''.intel_syntax noprefix
.code32
.section .main,"ax"
.global start
{symbols}
start:
 mov [saved_sp],esp
{''.join(cases)}
 xor ebx,ebx
 jmp exit
fail:
 mov ebx,[step]
exit:
 mov eax,1
 int 0x80
compare_string:
 push eax
 push ecx
compare_next:
 mov cl,[eax]
 cmp cl,[edx]
 jne fail
 test cl,cl
 je compare_done
 inc eax
 inc edx
 jmp compare_next
compare_done:
 pop ecx
 pop eax
 ret
.section .caption,"ax"
 cmp ecx,OFFSET root+0x5b8
 jne fail
 mov eax,[esp+4]
 mov edx,[expected_caption]
 call compare_string
 inc DWORD PTR [caption_calls]
 mov eax,0x9876
 mov ecx,0x8765
 mov edx,0x7654
 ret 4
.section .close,"ax"
 cmp ecx,OFFSET root
 jne fail
 inc DWORD PTR [close_calls]
 ret
.section .setter,"ax"
 cmp ecx,OFFSET root+0x620
 jne fail
 mov eax,[esp+4]
 mov edx,[expected_text]
 call compare_string
 inc DWORD PTR [setter_calls]
 mov eax,0x9876
 mov ecx,0x8765
 mov edx,0x7654
 ret 4
.section .visible,"ax"
 cmp ecx,OFFSET root+0x620
 jne fail
 mov eax,[esp+4]
 cmp eax,[expected_visible]
 jne fail
 inc DWORD PTR [visible_calls]
 ret 4
.section .continuation,"ax"
 ret
.section .tick,"aw"
 .long tick_mock
{''.join(routines)}
.section .flag,"aw"
cheat_flag: .byte 0
.section .thunk,"awx"
thunk: .incbin "{d/'code.bin'}"
.section .data,"aw"
saved_sp: .long 0
step: .long 0
before_flags: .long 0
after_flags: .long 0
mock_flags: .long 0
mock_result: .long 0
expected_caption: .long 0
caption_calls: .long 0
close_calls: .long 0
action_calls: .long 0
expected_text: .long 0
expected_visible: .long 0
setter_calls: .long 0
visible_calls: .long 0
tick_now: .long 0
filename: .asciz "Save_2026_10_11_19_58_00.sav"
{asm_string('enable_oracle','Cheats einschalten')}
{asm_string('disable_oracle','Cheats ausschalten')}
empty_oracle: .byte 0
{expected_strings}
.balign 4
root: .space 0xc00
old_root: .space 0xc00
.section .tick_mock,"ax"
tick_mock:
 mov eax,[tick_now]
 ret
'''
            sections = {'save': p['save'], 'load': p['load'], 'shot': p['shot'],
                        'continuation': p['update']+45, 'setter': p['setter'],
                        'visible': p['visible'], 'caption': p['caption'],
                        'close': p['close'], 'tick': p['tick'], 'flag': p['flag'],
                        'thunk': m['rva']}
            layout = '\n'.join(f'.{name} {base+rva} : {{ *(.{name}) }}'
                               for name, rva in sorted(sections.items(), key=lambda pair: pair[1]))
            (d/'test.s').write_text(asm)
            (d/'test.ld').write_text(f'''ENTRY(start)
SECTIONS {{
 .main {base+0x1000} : {{ *(.main) }}
 {layout}
 .data : {{ *(.data) }}
 .tick_mock : {{ *(.tick_mock) }}
}}
''')
            subprocess.run(['as','--32','-o',str(d/'test.o'),str(d/'test.s')],check=True)
            subprocess.run(['ld','-m','elf_i386','-T',str(d/'test.ld'),'-o',str(d/'test'),str(d/'test.o')],check=True,capture_output=True)
            if not build_only:
                result = subprocess.run([str(d/'test')],timeout=10)
                assert result.returncode == 0, (hex(base), 'case', result.returncode)
    print(output.name, f"PASS: {'assembled' if build_only else 'executed'} {step*2} x86 cases at two bases; toggle/close, action result forwarding, German messages, timer boundary/wrap/UI replacement; prior sections intact")


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--build-only', action='store_true')
    args = parser.parse_args()
    verify(args.source,args.output,args.build_only)
