#!/usr/bin/env python3
"""Run the exact appended machine code under 32-bit native engine/API mocks."""
import subprocess,tempfile
from pathlib import Path

def verify(m):
    sy,pr=m['symbols'],m['profile']
    for base in (0x400000,0x14000000):
        def a(n):return base+m['rva']+sy[n]
        tests=[]
        # Every failure must leave the current menu open and report an error.
        for mode in range(1,9):
            tests.append(f'''mov DWORD PTR [mode],{mode}
 mov ecx,OFFSET root
 push 0
 push 0
 call thunk+{sy['switch_game']}
 cmp al,1
 jne fail
 cmp DWORD PTR [root+0x3130],0
 jne fail
 cmp DWORD PTR [quit_calls],0
 jne fail
 cmp DWORD PTR [close_calls],0
 jne fail
 cmp DWORD PTR [messages],{mode}
 jne fail
 cmp esp,[saved_sp]
 jne fail''')
        asm=f'''.intel_syntax noprefix
.code32
.global start
.section .main,"ax"
start:
 mov [saved_sp],esp
 mov DWORD PTR [step],1
 mov ecx,OFFSET root
 push OFFSET parent
 call thunk+{sy['setup']}
 cmp eax,0x87654321
 jne fail
 cmp DWORD PTR [{a('ready')}],1
 jne fail
 cmp DWORD PTR [attached],1
 jne fail
 cmp esp,[saved_sp]
 jne fail
 mov DWORD PTR [step],2
 mov ecx,OFFSET root+0x5a0
 push 0
 call thunk+{sy['visibility']}
 cmp DWORD PTR [visible_calls],2
 jne fail
 cmp DWORD PTR [button_visible],0
 jne fail
 mov ecx,OFFSET root+0xbd4
 push 0
 call thunk+{sy['visibility']}
 cmp DWORD PTR [visible_calls],3
 jne fail
 mov ecx,OFFSET root+0x5a0
 push 1
 call thunk+{sy['visibility']}
 cmp DWORD PTR [visible_calls],5
 jne fail
 cmp DWORD PTR [button_visible],1
 jne fail
 cmp esp,[saved_sp]
 jne fail
 mov DWORD PTR [step],3
 {chr(10).join(tests)}
 mov DWORD PTR [step],4
 # A stale/non-owner event cannot launch a game.
 mov DWORD PTR [mode],0
 mov ecx,OFFSET parent
 push 0
 push 0
 call thunk+{sy['switch_game']}
 cmp DWORD PTR [quit_calls],0
 jne fail
 mov ecx,OFFSET root
 mov esi,0x12345678
 mov edi,0x23456789
 push 0
 push 0
 call thunk+{sy['switch_game']}
 cmp al,1
 jne fail
 cmp esi,0x12345678
 jne fail
 cmp edi,0x23456789
 jne fail
 cmp DWORD PTR [root+0x3130],6
 jne fail
 cmp DWORD PTR [quit_calls],1
 jne fail
 cmp DWORD PTR [close_calls],2
 jne fail
 cmp DWORD PTR [{a('pending')}],1
 jne fail
 cmp esp,[saved_sp]
 jne fail
 mov ecx,OFFSET root
 push 0
 push 0
 call thunk+{sy['switch_game']}
 cmp DWORD PTR [quit_calls],1
 jne fail
 mov DWORD PTR [step],5
 mov ecx,OFFSET parent+0x129b0
 call thunk+{sy['destructor']}
 cmp DWORD PTR [destroyed],0
 jne fail
 mov ecx,OFFSET root+0x129b0
 call thunk+{sy['destructor']}
 cmp DWORD PTR [destroyed],1
 jne fail
 cmp DWORD PTR [detached],1
 jne fail
 cmp DWORD PTR [{a('ready')}],0
 jne fail
 cmp DWORD PTR [{a('owner')}],0
 jne fail
 cmp DWORD PTR [{a('pending')}],0
 jne fail
 mov ecx,OFFSET root+0x129b0
 call thunk+{sy['destructor']}
 cmp DWORD PTR [destroyed],1
 jne fail
 cmp esp,[saved_sp]
 jne fail
 mov DWORD PTR [step],6
 # Recreating a menu and a forward-slash executable path also work.
 mov ecx,OFFSET root
 push OFFSET parent
 call thunk+{sy['setup']}
 mov DWORD PTR [mode],9
 mov ecx,OFFSET root
 push 0
 push 0
 call thunk+{sy['switch_game']}
 cmp DWORD PTR [quit_calls],2
 jne fail
 cmp DWORD PTR [close_calls],4
 jne fail
 cmp esp,[saved_sp]
 jne fail
 xor ebx,ebx
 mov eax,1
 int 0x80
fail:
 mov ebx,[step]
 mov eax,1
 int 0x80
check_button:
 cmp ecx,{a('button')}
 jne fail
 ret
.section .setup,"ax"
 cmp ecx,OFFSET root
 jne fail
 cmp DWORD PTR [esp+4],OFFSET parent
 jne fail
 mov eax,0x87654321
 ret 4
.section .button_ctor,"ax"
 call check_button
 cmp DWORD PTR [esp+4],1
 jne fail
 ret 4
.section .bounds,"ax"
 call check_button
 cmp DWORD PTR [esp+4],30
 jne fail
 cmp DWORD PTR [esp+8],540
 jne fail
 cmp DWORD PTR [esp+12],232
 jne fail
 cmp DWORD PTR [esp+16],38
 jne fail
 ret 16
.section .caption,"ax"
 call check_button
 cmp DWORD PTR [esp+4],{a('caption_text')}
 jne fail
 ret 4
.section .register,"ax"
 call check_button
 cmp DWORD PTR [esp+4],0x0e
 jne fail
 cmp DWORD PTR [esp+8],OFFSET root
 jne fail
 cmp DWORD PTR [esp+12],{a('switch_game')}
 jne fail
 cmp DWORD PTR [esp+16],0
 jne fail
 cmp DWORD PTR [esp+20],0
 jne fail
 cmp DWORD PTR [esp+24],0
 jne fail
 ret 24
.section .enabled,"ax"
 call check_button
 cmp DWORD PTR [esp+4],1
 jne fail
 ret 4
.section .attach,"ax"
 call check_button
 cmp DWORD PTR [esp+4],OFFSET root
 jne fail
 inc DWORD PTR [attached]
 ret 4
.section .visible,"ax"
 inc DWORD PTR [visible_calls]
 cmp ecx,{a('button')}
 jne visible_done
 mov eax,[esp+4]
 mov [button_visible],eax
visible_done:
 mov ecx,0x55555555
 mov edx,0x66666666
 ret 4
.section .detach,"ax"
 call check_button
 inc DWORD PTR [detached]
 ret
.section .button_dtor,"ax"
 cmp ecx,{a('button')+0x630}
 jne fail
 inc DWORD PTR [destroyed]
 ret
.section .dtor,"ax"
 inc DWORD PTR [native_dtor]
 ret
.section .end_menu,"ax"
 cmp ecx,OFFSET root
 jne fail
 cmp DWORD PTR [ecx+0x3130],6
 jne fail
 inc DWORD PTR [quit_calls]
 ret
.section .main,"ax"
filename:
 cmp DWORD PTR [esp+4],0
 jne fail
 cmp DWORD PTR [esp+8],{a('path')}
 jne fail
 cmp DWORD PTR [esp+12],1024
 jne fail
 cmp DWORD PTR [mode],1
 je filename_zero
 cmp DWORD PTR [mode],2
 je filename_truncated
 cmp DWORD PTR [mode],3
 je filename_noseparator
 cmp DWORD PTR [mode],8
 je filename_long
 mov eax,OFFSET source_path
 cmp DWORD PTR [mode],9
 jne filename_copy
 mov eax,OFFSET source_forward
filename_copy:
 push esi
 push edi
 mov esi,eax
 mov edi,[esp+16]
copy_path:
 lodsb
 stosb
 test al,al
 jne copy_path
 mov eax,edi
 sub eax,[esp+16]
 dec eax
 pop edi
 pop esi
 ret 12
filename_zero:
 xor eax,eax
 ret 12
filename_truncated:
 mov eax,1024
 ret 12
filename_noseparator:
 mov eax,OFFSET source_noseparator
 jmp filename_copy
filename_long:
 push edi
 mov edi,[esp+12]
 mov ecx,1018
 mov al,0x61
 rep stosb
 mov BYTE PTR [edi],0x5c
 mov BYTE PTR [edi+1],0x62
 mov BYTE PTR [edi+2],0
 pop edi
 mov eax,1020
 ret 12
module:
 cmp DWORD PTR [esp+4],{a('kernel_text')}
 jne fail
 mov eax,1
 cmp DWORD PTR [mode],4
 jne module_done
 xor eax,eax
module_done:
 ret 4
proc:
 cmp DWORD PTR [esp+4],1
 jne fail
 cmp DWORD PTR [esp+8],{a('create_text')}
 jne fail
 mov eax,OFFSET create_process
 cmp DWORD PTR [mode],5
 jne proc_done
 xor eax,eax
proc_done:
 ret 8
create_process:
 cmp DWORD PTR [esp+4],{a('path')}
 jne fail
 mov ecx,7
 lea edx,[esp+8]
zero_args:
 cmp DWORD PTR [edx],0
 jne fail
 add edx,4
 loop zero_args
 cmp DWORD PTR [esp+36],{a('startup')}
 jne fail
 cmp DWORD PTR [esp+40],{a('process')}
 jne fail
 cmp DWORD PTR [{a('startup')}],68
 jne fail
 mov ecx,16
 mov edx,{a('startup')+4}
zero_startup:
 cmp DWORD PTR [edx],0
 jne fail
 add edx,4
 loop zero_startup
 push esi
 push edi
 mov esi,OFFSET expected_path
 cmp DWORD PTR [mode],9
 jne compare_path
 mov esi,OFFSET expected_forward
compare_path:
 mov edi,{a('path')}
path_loop:
 lodsb
 cmp al,[edi]
 jne fail
 inc edi
 test al,al
 jne path_loop
 pop edi
 pop esi
 cmp DWORD PTR [mode],6
 je create_failed
 cmp DWORD PTR [mode],7
 je create_failed
 mov DWORD PTR [{a('process')}],0x1122
 mov DWORD PTR [{a('process')+4}],0x3344
 mov eax,1
 ret 40
create_failed:
 xor eax,eax
 ret 40
close_handle:
 mov eax,[close_calls]
 and eax,1
 mov edx,0x3344
 test eax,eax
 je close_check
 mov edx,0x1122
close_check:
 cmp edx,[esp+4]
 jne fail
 inc DWORD PTR [close_calls]
 mov eax,1
 ret 4
message:
 cmp DWORD PTR [esp+4],0
 jne fail
 cmp DWORD PTR [esp+8],{a('failure_text')}
 jne fail
 cmp DWORD PTR [esp+12],{a('caption_text')}
 jne fail
 inc DWORD PTR [messages]
 ret 16
.section .thunk,"awx"
thunk: .incbin "CODEPATH"
.section .data,"aw"
saved_sp: .long 0
step: .long 0
mode: .long 0
attached: .long 0
visible_calls: .long 0
button_visible: .long 1
quit_calls: .long 0
close_calls: .long 0
messages: .long 0
destroyed: .long 0
detached: .long 0
native_dtor: .long 0
source_path: .asciz "C:/Program Files/Game/WLP.EXE"
source_forward: .asciz "C:/Other Folder/WLP.EXE"
source_noseparator: .asciz "WLP.EXE"
expected_path: .asciz "C:/Program Files/Game/{m['target']}"
expected_forward: .asciz "C:/Other Folder/{m['target']}"
root: .zero 0x129b4
parent: .zero 0x129b4
'''
        # Exercise Windows backslashes in the primary path (assembler escaping).
        asm=asm.replace('C:/Program Files/Game/','C:\\\\Program Files\\\\Game\\\\')
        names=('setup','button_ctor','button_dtor','bounds','caption','register','enabled','attach','detach','visible','dtor','end_menu')
        sections={n:pr[n] for n in names}; sections['thunk']=m['rva']
        api_functions={'GetModuleFileNameA':'filename','GetModuleHandleA':'module','GetProcAddress':'proc','CloseHandle':'close_handle','MessageBoxA':'message'}
        for i,(name,func) in enumerate(api_functions.items()):
            asm+=f'\n.section .iat_{i},"aw"\n.long {func}\n'
            sections['iat_'+str(i)]=m['imports'][name]
        with tempfile.TemporaryDirectory() as tmp:
            d=Path(tmp); (d/'code.bin').write_bytes(m['code'])
            (d/'test.s').write_text(asm.replace('CODEPATH',str(d/'code.bin')))
            layout='\n'.join(f'.{k} {base+v} : {{ *(.{k}) }}' for k,v in sorted(sections.items(),key=lambda x:x[1]))
            (d/'test.ld').write_text(f'ENTRY(start)\nSECTIONS {{ .main {base+0x1000} : {{ *(.main) }}\n{layout}\n.data {base+m["rva"]+0x10000} : {{ *(.data) }} }}')
            subprocess.run(['as','--32','-o',str(d/'test.o'),str(d/'test.s')],check=True)
            r=subprocess.run(['ld','-m','elf_i386','-T',str(d/'test.ld'),'-o',str(d/'test'),str(d/'test.o')],capture_output=True,text=True)
            assert r.returncode==0,r.stderr
            r=subprocess.run([str(d/'test')],timeout=10)
            assert r.returncode==0,(m['target'],hex(base),r.returncode)
    print('PASS: '+m['target']+' switching lifecycle, visibility, paths, API arguments, failure guards and ABI; two image bases')
