#!/usr/bin/env python3
"""Experimental v5: retain RGB565 and reapply fullscreen mode before Restore."""
from pathlib import Path
import struct,hashlib,pefile
from patch_color_depth import SITES,V3

def patch(src):
    digest=hashlib.sha256(src).hexdigest()
    if digest=='b788e61731d351c01ef222c4b91347f734778141f161ad5cd3f84a0326f2af5b':
        src=bytearray(src)
        for o in SITES:
            assert src[o:o+2]==b'\x6a\x20';src[o+1]=16
        src=bytes(src)
    if hashlib.sha256(src).hexdigest()!=V3:raise ValueError('Requires known v3 or v4')
    p=pefile.PE(data=src);out=bytearray(src);hook=0x2800ee
    original=bytes.fromhex('8b0850ff516c');assert src[hook:hook+6]==original
    align=lambda n,a:(n+a-1)//a*a
    last=p.sections[-1];rva=align(last.VirtualAddress+max(last.Misc_VirtualSize,last.SizeOfRawData),p.OPTIONAL_HEADER.SectionAlignment)
    raw=align(len(out),p.OPTIONAL_HEADER.FileAlignment)
    code=bytearray(b'\x9c\x60') # preserve registers and flags
    code+=b'\x85\xff\x74\x00';j1=len(code)-1
    code+=b'\xe8\x00\x00\x00\x00\x5a' # position-independent global address
    anchor=rva+len(code)-1
    code+=b'\x81\xc2'+struct.pack('<i',0xa52fdc-anchor)
    code+=b'\x8b\x02\x85\xc0\x74\x00';j2=len(code)-1
    code+=b'\x6a\x00\x6a\x00' # flags, refresh
    code+=bytes.fromhex('ffb7b8010000') # depth
    code+=bytes.fromhex('8b8fb40100004151') # height + 1
    code+=bytes.fromhex('8b8fb00100004151') # width + 1
    code+=bytes.fromhex('8b1050ff5254') # IDirectDraw2::SetDisplayMode
    resume=len(code);code+=b'\x61\x9d'+original
    code+=b'\xe9'+struct.pack('<i',hook+6-(rva+len(code)+5))
    for j in [j1,j2]:code[j]=resume-(j+1)
    out[hook:hook+6]=b'\xe9'+struct.pack('<i',rva-(hook+5))+b'\x90'
    h=p.sections[0].get_file_offset()+40*p.FILE_HEADER.NumberOfSections
    assert h+40<=p.OPTIONAL_HEADER.SizeOfHeaders and not any(out[h:h+40])
    size=align(len(code),p.OPTIONAL_HEADER.FileAlignment)
    out[h:h+40]=struct.pack('<8sIIIIIIHHI',b'.wlpfoc',len(code),rva,size,raw,0,0,0,0,0x60000020)
    struct.pack_into('<H',out,p.FILE_HEADER.get_field_absolute_offset('NumberOfSections'),p.FILE_HEADER.NumberOfSections+1)
    struct.pack_into('<I',out,p.OPTIONAL_HEADER.get_field_absolute_offset('SizeOfImage'),align(rva+len(code),p.OPTIONAL_HEADER.SectionAlignment))
    struct.pack_into('<I',out,p.OPTIONAL_HEADER.get_field_absolute_offset('SizeOfCode'),p.OPTIONAL_HEADER.SizeOfCode+size)
    struct.pack_into('<I',out,p.OPTIONAL_HEADER.get_field_absolute_offset('CheckSum'),0)
    out+=bytes(raw-len(out))+code+bytes(size-len(code))
    return bytes(out)
if __name__=='__main__':
    import argparse
    a=argparse.ArgumentParser(description=__doc__);a.add_argument('input',type=Path);a.add_argument('output',type=Path);v=a.parse_args();b=patch(v.input.read_bytes())
    with v.output.open('xb') as f:f.write(b)
    print(hashlib.sha256(b).hexdigest())
