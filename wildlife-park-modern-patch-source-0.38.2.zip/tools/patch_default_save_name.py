#!/usr/bin/env python3
"""Prefill the save dialog with the first unused Save(n).sav basename."""
import argparse
import hashlib
import struct
import subprocess
import tempfile
from pathlib import Path
import pefile
from patch_addon_widescreen import append_section, next_rva, redirect

PROFILES = {
    'ddb8fedbe49a615491dd933b0d7edd3d282bceb3d113c0668dd6039ee3d4439c': (0x137cef, 0x120b50),
    'b225be3403c1b2bcdf8782bd459835190c1fccd5d04ee55ba84acbd65208e6fc': (0x14cb5f, 0x1343b0),
}


def patch(src, timestamp=False):
    hook, setter = PROFILES[hashlib.sha256(src).hexdigest()]
    p = pefile.PE(data=src)
    imports = {i.name.decode(): i.address - p.OPTIONAL_HEADER.ImageBase
               for dll in p.DIRECTORY_ENTRY_IMPORT for i in dll.imports if i.name}
    rva = next_rva(src)
    asm = f'''.intel_syntax noprefix
.code32
.global _start
_start:
    pushfd
    pushad
    call anchor
anchor:
    pop ebx
    sub ebx, {rva} + anchor - _start
    sub esp, 96
    call DWORD PTR [ebx + {imports['GetLastError']}]
    mov [esp+76], eax
    mov ebp, 1
candidate:
    mov DWORD PTR [esp], 0x65766153
    mov BYTE PTR [esp+4], 0x28
    mov eax, ebp
    mov edi, 10
    xor ecx, ecx
digits:
    xor edx, edx
    div edi
    add dl, 48
    mov [esp+ecx+16], dl
    inc ecx
    test eax, eax
    jne digits
    lea esi, [esp+5]
reverse:
    dec ecx
    mov al, [esp+ecx+16]
    mov [esi], al
    inc esi
    test ecx, ecx
    jne reverse
    mov BYTE PTR [esi], 0x29
    inc esi
    mov BYTE PTR [esi], 0
    xor ecx, ecx
copy_path:
    mov al, [esp+ecx]
    mov [esp+ecx+32], al
    test al, al
    je extension
    inc ecx
    jmp copy_path
extension:
    mov DWORD PTR [esp+ecx+32], 0x7661732e
    mov BYTE PTR [esp+ecx+36], 0
    lea eax, [esp+32]
    push eax
    call DWORD PTR [ebx + {imports['GetFileAttributesA']}]
    cmp eax, -1
    jne occupied
    call DWORD PTR [ebx + {imports['GetLastError']}]
    cmp eax, 2
    je chosen
    cmp eax, 3
    jne fallback
chosen:
    lea eax, [esp]
    mov [esp+64], eax
    mov [esp+68], esi
    lea eax, [esi+1]
    mov [esp+72], eax
    lea eax, [esp+64]
    jmp set_name
occupied:
    inc ebp
    jne candidate
fallback:
    mov eax, [esp+136]
set_name:
    mov ecx, [esp+120]
    push eax
    lea eax, [ebx+{setter}]
    call eax
    mov [esp+124], eax
    push DWORD PTR [esp+76]
    call DWORD PTR [ebx+{imports['SetLastError']}]
    add esp, 96
    popad
    popfd
    ret 4
'''
    if timestamp:
        fields = [(0, 5, 4), (2, 10, 2), (6, 13, 2), (8, 16, 2),
                  (10, 19, 2), (12, 22, 2)]
        format_fields = '\n'.join(f'''movzx eax, WORD PTR [esp+{32+offset}]
    lea esi, [esp+{start+width-1}]
    mov ecx, {width}
    call fixed_digits''' for offset, start, width in fields)
        asm = f'''.intel_syntax noprefix
.code32
.global _start
_start:
    pushfd
    pushad
    call anchor
anchor:
    pop ebx
    sub ebx, {rva} + anchor - _start
    sub esp, 96
    call DWORD PTR [ebx+{imports['GetLastError']}]
    mov [esp+76], eax
    lea eax, [esp+32]
    push eax
    call DWORD PTR [ebx+{imports['GetLocalTime']}]
    mov DWORD PTR [esp], 0x65766153
    mov BYTE PTR [esp+4], 0x5f
    mov edi, 10
    {format_fields}
    mov BYTE PTR [esp+9], 0x5f
    mov BYTE PTR [esp+12], 0x5f
    mov BYTE PTR [esp+15], 0x5f
    mov BYTE PTR [esp+18], 0x5f
    mov BYTE PTR [esp+21], 0x5f
    mov BYTE PTR [esp+24], 0
    lea eax, [esp]
    mov [esp+64], eax
    lea eax, [esp+24]
    mov [esp+68], eax
    inc eax
    mov [esp+72], eax
    lea eax, [esp+64]
    mov ecx, [esp+120]
    push eax
    lea eax, [ebx+{setter}]
    call eax
    mov [esp+124], eax
    push DWORD PTR [esp+76]
    call DWORD PTR [ebx+{imports['SetLastError']}]
    add esp, 96
    popad
    popfd
    ret 4
fixed_digits:
    xor edx, edx
    div edi
    add dl, 48
    mov [esi], dl
    dec esi
    dec ecx
    jne fixed_digits
    ret
'''
    with tempfile.TemporaryDirectory() as tmp:
        d = Path(tmp)
        (d/'patch.s').write_text(asm)
        subprocess.run(['as', '--32', '-o', str(d/'patch.o'), str(d/'patch.s')], check=True)
        subprocess.run(['objcopy', '-O', 'binary', '-j', '.text', str(d/'patch.o'), str(d/'patch.bin')], check=True)
        # All address constants are RVAs; local branches are assembly-relative.
        relocs = subprocess.check_output(['objdump', '-r', str(d/'patch.o')], text=True)
        assert 'R_386' not in relocs, relocs
        code = (d/'patch.bin').read_bytes()
    b = bytearray(src)
    expected = b'\xe8' + struct.pack('<i', setter-hook-5)
    redirect(b, hook, expected, rva)
    # redirect emits JMP, but the wrapper is a replacement callee with RET 4.
    b[p.get_offset_from_rva(hook)] = 0xe8
    append_section(b, b'.wlpsave', code)
    return bytes(b), {'rva': rva, 'hook': hook, 'setter': setter, 'imports': imports, 'code': code}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--timestamp', action='store_true')
    args = parser.parse_args()
    output, _ = patch(args.source.read_bytes(), timestamp=args.timestamp)
    with args.output.open('xb') as f:
        f.write(output)
    print(hashlib.sha256(output).hexdigest())
