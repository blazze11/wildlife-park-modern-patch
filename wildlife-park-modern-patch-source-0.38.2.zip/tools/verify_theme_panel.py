#!/usr/bin/env python3
"""Execute appended F2 controls with native 32-bit lifecycle/API mocks."""
import subprocess,tempfile
from pathlib import Path
from theme_panel import SIZE,READY,BUTTONS


def verify(m):
    sy,pr=m['symbols'],m['profile']
    for base in (0x400000,0x14000000):
        with tempfile.TemporaryDirectory() as tmp:
            d=Path(tmp);(d/'code.bin').write_bytes(m['code'])
            cycle=[]
            for previous, expected in ((0,3),(3,1),(1,0),(2,1)):
                cycle.append(f"""mov DWORD PTR [world+0x10404c],{previous}
 mov ecx,OFFSET root
 push 0
 push 0
 call thunk+{sy['toggle_0']}
 cmp al,1
 jne fail
 cmp DWORD PTR [world+0x10404c],{expected}
 jne fail
 cmp esp,[saved_sp]
 jne fail""")
            cycle='\n'.join(cycle)
            asm=f'''.intel_syntax noprefix
.code32
.global start
.section .main,"ax"
start:
 mov [saved_sp],esp
 mov DWORD PTR [step],1
 mov ecx,OFFSET root
 push 1
 call thunk+{sy['constructor']}
 cmp eax,OFFSET root
 jne fail
 cmp DWORD PTR [root+{READY}],1
 jne fail
 cmp DWORD PTR [constructed],1
 jne fail
 cmp esp,[saved_sp]
 jne fail
 mov DWORD PTR [step],2
 mov ecx,OFFSET root+0xbf0
 push OFFSET root
 call thunk+{sy['attach_buttons']}
 cmp DWORD PTR [attached],1
 jne fail
 cmp DWORD PTR [registered],1
 jne fail
 cmp DWORD PTR [bounds_called],1
 jne fail
 cmp DWORD PTR [enabled_called],1
 jne fail
 cmp DWORD PTR [caption_called],1
 jne fail
 cmp esp,[saved_sp]
 jne fail
 {cycle}
 cmp DWORD PTR [theme_calls],4
 jne fail
 mov DWORD PTR [worldptr],0
 mov ecx,OFFSET root
 push 0
 push 0
 call thunk+{sy['toggle_0']}
 cmp al,1
 jne fail
 cmp DWORD PTR [theme_calls],4
 jne fail
 cmp DWORD PTR [caption_called],6
 jne fail
 cmp DWORD PTR [flags],0xc35aa500
 jne fail
 mov DWORD PTR [step],6
 mov ecx,OFFSET root+0x1228
 call thunk+{sy['detach_buttons']}
 cmp DWORD PTR [detached],1
 jne fail
 cmp DWORD PTR [old_detached],1
 jne fail
 cmp esp,[saved_sp]
 jne fail
 mov DWORD PTR [step],7
 mov ecx,OFFSET root+0x1620
 call thunk+{sy['destructor']}
 cmp DWORD PTR [destroyed],1
 jne fail
 cmp DWORD PTR [root+{READY}],0
 jne fail
 cmp DWORD PTR [old_destroyed],1
 jne fail
 cmp esp,[saved_sp]
 jne fail
 call thunk+{sy['destructor']}
 cmp DWORD PTR [destroyed],1
 jne fail
 cmp DWORD PTR [old_destroyed],2
 jne fail
 cmp esp,[saved_sp]
 jne fail
 cmp DWORD PTR [flags],0xc35aa500
 jne fail
 xor ebx,ebx
 mov eax,1
 int 0x80
fail:
 mov ebx,[step]
 mov eax,1
 int 0x80
.section .previous_ctor,"ax"
 cmp ecx,OFFSET root
 jne fail
 cmp DWORD PTR [esp+4],1
 jne fail
 mov eax,ecx
 ret 4
.section .button_ctor,"ax"
 cmp DWORD PTR [esp+4],1
 jne fail
 mov eax,[constructed]
 imul eax,{0x638}
 add eax,OFFSET root+{BUTTONS[0]}
 cmp ecx,eax
 jne fail
 inc DWORD PTR [constructed]
 ret 4
.section .previous_attach,"ax"
 cmp ecx,OFFSET root+0xbf0
 jne fail
 cmp DWORD PTR [esp+4],OFFSET root
 jne fail
 ret 4
.section .attach,"ax"
 jmp check_attach
.section .main,"ax"
check_attach:
 cmp DWORD PTR [esp+4],OFFSET root
 jne fail
 mov eax,[attached]
 imul eax,{0x638}
 add eax,OFFSET root+{BUTTONS[0]}
 cmp ecx,eax
 jne fail
 inc DWORD PTR [attached]
 ret 4
.section .bounds,"ax"
 cmp ecx,OFFSET root+{BUTTONS[0]}
 jne fail
 cmp DWORD PTR [esp+4],10
 jne fail
 cmp DWORD PTR [esp+8],475
 jne fail
 cmp DWORD PTR [esp+12],270
 jne fail
 cmp DWORD PTR [esp+16],20
 jne fail
 inc DWORD PTR [bounds_called]
 ret 16
.section .enabled,"ax"
 cmp DWORD PTR [esp+4],1
 jne fail
 inc DWORD PTR [enabled_called]
 ret 4
.section .register,"ax"
 cmp DWORD PTR [esp+4],0x0e
 jne fail
 cmp DWORD PTR [esp+8],OFFSET root
 jne fail
 mov eax,[registered]
 mov eax,[callbacks+eax*4]
 cmp eax,[esp+12]
 jne fail
 inc DWORD PTR [registered]
 ret 24
.section .caption,"ax"
 push esi
 mov eax,ecx
 sub eax,OFFSET root+{BUTTONS[0]}
 xor edx,edx
 mov esi,{0x638}
 div esi
 cmp eax,0
 ja fail
 test edx,edx
 jne fail
 mov eax,{base+m['rva']+sy['caption_0']}
check_caption:
 cmp eax,[esp+8]
 jne fail
 inc DWORD PTR [caption_called]
 pop esi
 ret 4
.section .previous_detach,"ax"
 cmp ecx,OFFSET root+0x1228
 jne fail
 inc DWORD PTR [old_detached]
 ret
.section .detach,"ax"
 jmp check_detach
.section .main,"ax"
check_detach:
 mov eax,0
 sub eax,[detached]
 imul eax,{0x638}
 add eax,OFFSET root+{BUTTONS[0]}
 cmp ecx,eax
 jne fail
 inc DWORD PTR [detached]
 ret
.section .button_dtor,"ax"
 mov eax,0
 sub eax,[destroyed]
 imul eax,{0x638}
 add eax,OFFSET root+{BUTTONS[0]+0x630}
 cmp ecx,eax
 jne fail
 inc DWORD PTR [destroyed]
 ret
.section .previous_dtor,"ax"
 cmp ecx,OFFSET root+0x1620
 jne fail
 inc DWORD PTR [old_destroyed]
 ret
.section .set_theme,"ax"
 cmp ecx,OFFSET world
 jne fail
 mov eax,[esp+4]
 cmp eax,3
 ja fail
 cmp eax,2
 je fail
 mov [world+0x10404c],eax
 inc DWORD PTR [theme_calls]
 # Clobber volatile registers as a real engine call may.
 mov ecx,0x11223344
 mov edx,0x55667788
 ret 4
.section .worldptr,"aw"
worldptr: .long world
.section .thunk,"awx"
thunk: .incbin "{d/'code.bin'}"
.section .flags,"aw"
flags: .byte 0,0xa5,0x5a,0xc3
.section .data,"aw"
callbacks: .long {','.join(str(base+m['rva']+sy['toggle_'+str(i)]) for i in range(1))}
saved_sp: .long 0
step: .long 0
constructed: .long 0
attached: .long 0
registered: .long 0
bounds_called: .long 0
enabled_called: .long 0
caption_called: .long 0
detached: .long 0
old_detached: .long 0
destroyed: .long 0
old_destroyed: .long 0
theme_calls: .long 0
world: .zero 0x10404c
 .long 0
root: .zero {SIZE}
'''
            sections={n:pr[n] for n in ('previous_ctor','button_ctor','previous_attach','attach','bounds','caption','enabled','register','previous_detach','detach','button_dtor','previous_dtor')}
            sections.update(thunk=m['rva'],flags=(0xa3b47c if pr['set_theme']==0x1d50 else 0x8af1b4),worldptr=m['world_rva'],set_theme=pr['set_theme'])
            # Keep mock/data independent from code; flags can precede patch section.
            layout='\n'.join(f'.{k} {base+v} : {{ *(.{k}) }}' for k,v in sorted(sections.items(),key=lambda x:x[1]))
            (d/'test.s').write_text(asm)
            (d/'test.ld').write_text(f'ENTRY(start)\nSECTIONS {{ .main {base+0x1000} : {{ *(.main) }}\n{layout}\n.data {base+m["rva"]+0x10000} : {{ *(.data) }} }}')
            subprocess.run(['as','--32','-o',str(d/'test.o'),str(d/'test.s')],check=True)
            r=subprocess.run(['ld','-m','elf_i386','-T',str(d/'test.ld'),'-o',str(d/'test'),str(d/'test.o')],capture_output=True,text=True)
            assert r.returncode==0,r.stderr
            r=subprocess.run([str(d/'test')],timeout=10)
            assert r.returncode==0,(hex(base),r.returncode)
    print('PASS: theme panel lifecycle, native transitions, null-world guard, unchanged developer flag and ABI; two image bases')

