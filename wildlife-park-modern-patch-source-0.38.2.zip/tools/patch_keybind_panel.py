#!/usr/bin/env python3
"""Enlarge F2 to 300x500 and draw a two-column shortcut table below its controls.

Uses the existing label and text renderer: no new GUI objects or ownership.
Shortcuts are from handbuch.pdf p42; numbered bookmarks are from game code.
"""
import argparse
import hashlib
import struct
import subprocess
import tempfile
from pathlib import Path
import pefile
from patch_addon_widescreen import append_section, next_rva

PROFILES = {
    '45c4b1861c5ede62bcf4a8b9c466d48e33d75de7774e18823ff67bbbeab848f8':
        (0x10868c, 0x1086fd, 0x108709, 0x1f2d67, 0x1f5fc0, 0x1f2c40, 0x23e430),
    '66694a6a20d1e5d298de65d2efcdcd9a5c016c2bd25c94920f1496d98bb8a566':
        (0x119dfc, 0x119e6d, 0x119e79, 0x220e97, 0x2241c0, 0x220d80, 0x26e300),
}
ENGLISH_ROWS = [
    ('KEY', 'ACTION'),
    ('Space', 'Pause / resume'),
    ('F2', 'Cheat / keybind panel'),
    ('F3 / Ctrl+L', 'Load park'),
    ('F4 / Ctrl+S', 'Save park'),
    ('F5', 'Objectives'),
    ('F6', 'Finance / statistics'),
    ('F7', 'Screenshot'),
    ('F8', 'Undo construction'),
    ('F9', 'Toggle entrance'),
    ('F10', 'Toggle visitor facilities'),
    ('F11', 'Toggle staff facilities'),
    ('F12', 'Toggle animal facilities'),
    ('+ / -', 'Zoom in / out'),
    ('Home / End', 'Original / reversed view'),
    ('PgUp / PgDn', 'Rotate view left / right'),
    ('Num 3/1/7/9', 'Object orientation'),
    ('Num 4 / 6', 'Rotate object left / right'),
    ('C / O', 'Close / open selected'),
    ('Shift+C / O', 'Close / open same type'),
    ('Shift + / -', 'Work area / price +/-'),
    ('S / Del', 'Sell selected object'),
    ('Shift+S / Del', 'Sell all of same type'),
    ('Shift', 'Rectangular fences'),
    ('N', 'Next object of same type'),
    ('F', 'Follow selected object'),
    ('H', 'Animal / staff home'),
    ('0 - 9', 'Recall object bookmark'),
    ('Ctrl+0 - 9', 'Store object bookmark'),
    ('Esc', 'Options menu'),
    ('Alt+F4', 'Quit game'),
]
ROWS = [
    ('TASTE', 'AKTION'),
    ('Leertaste', 'Pause / weiter'),
    ('F2', 'Cheats / Tastenbelegung'),
    ('F3 / Strg+L', 'Park laden'),
    ('F4 / Strg+S', 'Park speichern'),
    ('F5', 'Spielziele'),
    ('F6', 'Finanzen / Statistik'),
    ('F7', 'Bildschirmfoto'),
    ('F8', 'Bau rückgängig machen'),
    ('F9', 'Eingang öffnen / schließen'),
    ('F10', 'Besuchereinrichtungen an/aus'),
    ('F11', 'Personaleinrichtungen an/aus'),
    ('F12', 'Tiereinrichtungen an/aus'),
    ('+ / -', 'Ansicht vergrößern / verkleinern'),
    ('Pos1 / Ende', 'Ansicht normal / umgekehrt'),
    ('Bild auf/ab', 'Ansicht links / rechts drehen'),
    ('Num 3/1/7/9', 'Objekt ausrichten'),
    ('Num 4 / 6', 'Objekt links / rechts drehen'),
    ('C / O', 'Auswahl schließen / öffnen'),
    ('Umsch+C / O', 'Gleichen Typ schließen / öffnen'),
    ('Umsch + / -', 'Arbeitsbereich / Preis +/-'),
    ('S / Entf', 'Auswahl verkaufen'),
    ('Umsch+S / Entf', 'Alle vom gleichen Typ verkaufen'),
    ('Umsch', 'Rechteckigen Zaun ziehen'),
    ('N', 'Nächstes Objekt gleichen Typs'),
    ('F', 'Auswahl verfolgen'),
    ('H', 'Tier- / Personalgebäude'),
    ('0 - 9', 'Objektmarkierung aufrufen'),
    ('Strg+0 - 9', 'Objektmarkierung speichern'),
    ('Esc', 'Optionsmenü'),
    ('Alt+F4', 'Spiel beenden'),
]
MARKER = 'WLP_KEY_TABLE_V1'


def asm_string(label, text):
    # The original renderer accepts single-byte Western Windows text.
    return f'{label}: .byte ' + ', '.join(str(b) for b in text.encode('cp1252')+b'\0')


def patch(src, language='de'):
    profile = PROFILES[hashlib.sha256(src).hexdigest()]
    root_hook, label_hook, text_hook, draw_hook, bounds, setter, draw = profile
    rva = next_rva(src)
    rows = ROWS if language == 'de' else ENGLISH_ROWS
    assert language in ('de', 'en')
    descriptors = [(0, 0, 270, 20, 'Cheat-Code:' if language == 'de' else 'CheatCode:')]
    for row, (key, action) in enumerate(rows):
        descriptors.extend([(0, 85 + row*12, 99, 12, key),
                            (103, 85 + row*12, 167, 12, action)])
    assert max(y+h for x,y,w,h,s in descriptors) <= 475
    records = '\n'.join(f'.long {x}, {y}, {w}, {h}, string_{i}-_start'
                        for i,(x,y,w,h,s) in enumerate(descriptors))
    strings = '\n'.join(asm_string(f'string_{i}', s)
                        for i,(*_,s) in enumerate(descriptors))
    asm = f'''.intel_syntax noprefix
.code32
.global _start, root_bounds, label_bounds, label_text, label_draw
_start:
root_bounds:
 mov DWORD PTR [esp+16], 500
 jmp _start + {bounds-rva}
label_bounds:
 mov DWORD PTR [esp+16], 475
 jmp _start + {bounds-rva}
label_text:
 pushfd
 push eax
 call text_anchor
text_anchor:
 pop eax
 add eax, marker-text_anchor
 mov [esp+12], eax
 pop eax
 popfd
 jmp _start + {setter-rva}
label_draw:
 pushfd
 pushad
 sub esp, 32
 call anchor
anchor:
 pop ebx
 sub ebx, {rva} + anchor-_start
 mov esi, [esp+76]
 test esi, esi
 je ordinary
 lea edi, [ebx+{rva}+marker-_start]
match:
 cmp BYTE PTR [edi], 0
 je end_marker
 mov al, [esi]
 cmp al, [edi]
 jne ordinary
 inc esi
 inc edi
 jmp match
end_marker:
 # The engine's word-wrap path may append a final CR/LF to label text.
 cmp BYTE PTR [esi], 13
 jne end_lf
 inc esi
end_lf:
 cmp BYTE PTR [esi], 10
 jne end_zero
 inc esi
end_zero:
 cmp BYTE PTR [esi], 0
 jne ordinary
 mov esi, [esp+56]
 mov ebp, [esp+72]
 lea edi, [ebx+{rva}+records-_start]
next_row:
 mov eax, [edi]
 add eax, [ebp]
 mov [esp], eax
 add eax, [edi+8]
 mov [esp+8], eax
 mov eax, [edi+4]
 add eax, [ebp+4]
 mov [esp+4], eax
 add eax, [edi+12]
 mov [esp+12], eax
 mov eax, [edi+16]
 add eax, ebx
 add eax, {rva}
 mov edx, esp
 push eax
 push edx
 mov ecx, esi
 lea eax, [ebx+{draw}]
 call eax
 add edi, 20
 lea eax, [ebx+{rva}+records_end-_start]
 cmp edi, eax
 jne next_row
 mov [esp+60], eax
 add esp, 32
 popad
 popfd
 ret 8
ordinary:
 add esp, 32
 popad
 popfd
 jmp _start + {draw-rva}
marker: .asciz "{MARKER}"
.balign 4
records:
{records}
records_end:
{strings}
'''
    with tempfile.TemporaryDirectory() as tmp:
        d = Path(tmp)
        (d/'panel.s').write_text(asm)
        subprocess.run(['as','--32','-o',str(d/'panel.o'),str(d/'panel.s')],check=True)
        relocs = subprocess.check_output(['objdump','-r',str(d/'panel.o')],text=True)
        assert 'R_386' not in relocs, relocs
        subprocess.run(['objcopy','-O','binary','-j','.text',str(d/'panel.o'),str(d/'panel.bin')],check=True)
        code = (d/'panel.bin').read_bytes()
        symbols = {parts[2]: int(parts[0],16) for line in
                   subprocess.check_output(['nm',str(d/'panel.o')],text=True).splitlines()
                   if len(parts:=line.split()) == 3}
    p = pefile.PE(data=src)
    b = bytearray(src)
    changes = []
    for hook, target, name in [(root_hook,bounds,'root_bounds'),
                                (label_hook,bounds,'label_bounds'),
                                (text_hook,setter,'label_text'),
                                (draw_hook,draw,'label_draw')]:
        off = p.get_offset_from_rva(hook)
        expected = b'\xe8'+struct.pack('<i',target-hook-5)
        assert b[off:off+5] == expected, hex(hook)
        b[off:off+5] = b'\xe8'+struct.pack('<i',rva+symbols[name]-hook-5)
        changes.append((hook, name))
    append_section(b,b'.wlpkeys',code)
    return bytes(b), dict(rva=rva,code=code,symbols=symbols,profile=profile,
                         changes=changes,descriptors=descriptors)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input',type=Path)
    parser.add_argument('output',type=Path)
    parser.add_argument('--language', choices=('de','en'), default='de')
    args = parser.parse_args()
    out, meta = patch(args.input.read_bytes(), language=args.language)
    with args.output.open('xb') as f:
        f.write(out)
    print(f'Created {args.output}: {hashlib.sha256(out).hexdigest()} ({len(ROWS)} rows)')
