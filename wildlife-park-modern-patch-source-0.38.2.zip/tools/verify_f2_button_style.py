#!/usr/bin/env python3
"""Exercise the added native hooks with ABI-accurate widget dependencies."""
import json,subprocess,tempfile
from pathlib import Path
from f2_button_style import ROOT,build
from patch_debug_tools import digest

def verify(m):
 for base in (0x400000,0x14000000):
  pr=m['profile'];s=m['symbols'];rv=m['rva'];pic=m['picture'];ready=m['ready'];title=m['title']
  sections={};bodies={}
  def mock(key,body):
   sections[key]=pr[key];bodies[key]=body
  mock('previous_ctor','mov eax,ecx\nret 4')
  mock('picture_ctor',f'''cmp ecx,OFFSET root+{pic}
 jne fail
 mov DWORD PTR [ecx+4],OFFSET virtualbase
 mov DWORD PTR [ecx+8],OFFSET destructor_table
 mov eax,ecx
 ret 4''')
  mock('generic_attach',f'cmp ecx,OFFSET root+{pic}\njne fail\ninc DWORD PTR [attachments]\nret 4')
  mock('previous_attach','mov DWORD PTR [root+0x5b8],OFFSET button_table\nmov DWORD PTR [root+0xbf0],OFFSET button_table\nmov DWORD PTR [root+0x1624],OFFSET button_table\nmov DWORD PTR [root+0x1c60],OFFSET button_table\nret 4')
  mock('bounds',f'''cmp ecx,OFFSET root+{pic}
 jne fail
 cmp DWORD PTR [esp+4],464
 jne fail
 cmp DWORD PTR [esp+8],9
 jne fail
 cmp DWORD PTR [esp+12],40
 jne fail
 cmp DWORD PTR [esp+16],40
 jne fail
 ret 16''')
  mock('enabled','ret 4')
  mock('font_set',f'''cmp ecx,OFFSET root+{title}
 jne fail
 cmp DWORD PTR [esp+4],{base+pr['font']+0x30}
 jne fail
 inc DWORD PTR [fonts]
 ret 4''')
  mock('state_update','''lea edx,[ecx+0x5d0]
 test BYTE PTR [ecx+0x29c],2
 jz palette
 lea edx,[ecx+0x5f0]
 test BYTE PTR [ecx+0x29c],1
 jz palette
 lea edx,[ecx+0x600]
palette:
 mov ax,[edx]
 mov [ecx+0x52c],ax
 mov al,[edx+2]
 mov [ecx+0x52e],al
 ret''')
  mock('frame_set',f'''cmp ecx,OFFSET root+{pic}
 jne fail
 mov eax,[esp+4]
 mov [ecx+0x29c],eax
 ret 4''')
  mock('generic_detach',f'cmp ecx,OFFSET root+{pic}\njne fail\ninc DWORD PTR [detached]\nret')
  mock('previous_detach','inc DWORD PTR [old_detached]\nret')
  mock('previous_dtor','inc DWORD PTR [old_destroyed]\nret')
  sections['font']=pr['font'];bodies['font']='.long OFFSET font_vtable\n.zero 64'
  sections['bank']=pr['bank'];bodies['bank']='.long OFFSET bank_vtable'
  checks=[]
  for off in (0x5b8,0x1624,0x1c60):
   for bits,rgb in ((0,0xffffff),(2,0xffd740),(3,0xffffff),(2,0xffd740),(0,0xffffff),(0,0xffffff)):
    checks.append(f'''mov ecx,OFFSET root+{off}
 mov BYTE PTR [ecx+0x29c],{bits}
 mov eax,[ecx]
 call DWORD PTR [eax]
 cmp WORD PTR [root+{off}+0x52c],{rgb&65535}
 jne fail
 cmp BYTE PTR [root+{off}+0x52e],{rgb>>16}
 jne fail''')
  for bits,frame in ((0,0),(2,2),(3,1),(2,2),(0,0)):
   checks.append(f'''mov ecx,OFFSET root+0xbf0
 mov BYTE PTR [ecx+0x29c],{bits}
 mov eax,[ecx]
 call DWORD PTR [eax]
 cmp DWORD PTR [root+{pic}+0x29c],{frame}
 jne fail''')
  asm=f'''.intel_syntax noprefix
.code32
.global start
.section .main,"ax"
start:
 mov [saved_sp],esp
 mov ecx,OFFSET root
 push 1
 call thunk+{s['constructor']}
 cmp eax,OFFSET root
 jne fail
 cmp DWORD PTR [root+{ready}],1
 jne fail
 mov ecx,OFFSET root+0xbf0
 push OFFSET root
 call thunk+{s['attach']}
 cmp DWORD PTR [fonts],1
 jne fail
 cmp DWORD PTR [attachments],1
 jne fail
 cmp DWORD PTR [root+{pic}+0x298],{base+pr['bank']+0x80}
 jne fail
 cmp DWORD PTR [root+{pic}+0x2a0],99
 jne fail
 cmp DWORD PTR [button_table+0x20],{base+pr['button_update']}
 jne fail
 cmp DWORD PTR [button_table+0x60],{base+pr['button_enter']}
 jne fail
 cmp DWORD PTR [button_table+0x64],{base+pr['button_leave']}
 jne fail
 {chr(10).join(checks)}
 mov ecx,OFFSET root+0x1228
 call thunk+{s['detach']}
 cmp DWORD PTR [detached],1
 jne fail
 cmp DWORD PTR [old_detached],1
 jne fail
 mov ecx,OFFSET root+0x1620
 call thunk+{s['destructor']}
 mov ecx,OFFSET root+0x1620
 call thunk+{s['destructor']}
 cmp DWORD PTR [disposed],1
 jne fail
 cmp DWORD PTR [old_destroyed],2
 jne fail
 cmp esp,[saved_sp]
 jne fail
 xor ebx,ebx
 mov eax,1
 int 0x80
fail:
 mov ebx,1
 mov eax,1
 int 0x80
invalidate:
 ret 4
dispose:
 cmp ecx,OFFSET root+{pic}+8
 jne fail
 cmp DWORD PTR [esp+4],0
 jne fail
 inc DWORD PTR [disposed]
 ret 4
.section .thunk,"axw"
thunk: .incbin "CODEPATH"
.section .mockdata,"aw"
saved_sp: .long 0
attachments: .long 0
fonts: .long 0
detached: .long 0
old_detached: .long 0
disposed: .long 0
old_destroyed: .long 0
virtualbase: .long 0,4
font_vtable: .zero 20
.long 0x30
bank_vtable: .zero 12
.long 0x80
destructor_table: .long dispose
button_table: .long 0,0,invalidate
.zero 116
root: .zero {m['size']}
'''
  for k,body in bodies.items():asm+=f'\n.section .{k},"axw"\n{body}\n'
  with tempfile.TemporaryDirectory() as tmp:
   d=Path(tmp);(d/'code.bin').write_bytes(m['code']);(d/'test.s').write_text(asm.replace('CODEPATH',str(d/'code.bin')))
   sections['thunk']=rv
   layout='\n'.join(f'.{k} {base+x} : {{ *(.{k}) }}' for k,x in sorted(sections.items(),key=lambda x:x[1]))
   (d/'test.ld').write_text(f'ENTRY(start)\nSECTIONS {{ .main {base+0x1000} : {{ *(.main) }}\n{layout}\n.mockdata {base+rv+0x10000} : {{ *(.mockdata) }} }}')
   subprocess.run(['as','--32','-o',str(d/'test.o'),str(d/'test.s')],check=True)
   subprocess.run(['ld','-m','elf_i386','-T',str(d/'test.ld'),'-o',str(d/'test'),str(d/'test.o')],check=True,capture_output=True)
   r=subprocess.run([str(d/'test')],timeout=10);assert r.returncode==0,(m['name'],hex(base),r.returncode)
 print('PASS '+m['name']+': initial/repeated palettes, close frames, native font, constructor/detach/destructor and stack; two bases')
if __name__=='__main__':
 records=[]
 for name in ('WLP','WLPADD1'):
  data,m=build(name);verify(m);records.append(dict(name=name,passed=True,sha256=digest(data),code_sha256=digest(m['code']),image_bases=['0x400000','0x14000000']))
 (ROOT/'analysis/f2-button-style-verification.json').write_text(json.dumps(records,indent=2)+'\n')
