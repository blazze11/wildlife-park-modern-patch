#!/usr/bin/env python3
"""Patch known Wildlife Park builds for experimental DirectDraw widescreen; preserve input."""
import argparse
import hashlib
import struct
from pathlib import Path

KNOWN = {
    "3063d48ae82b580f02dbdee8da9d9913c9539eb3a28dd2266400f89d5e8f6ec5",
    "915d9cf9fc76ae7f6c9187b8bd26aa4b5e58978a8677ae9d7212cdfa616f0545",
    "271abbdd2373bdb243f4f27486532f65544dc2a78e803e89a13c1693648e5816",
}
ENGINE_PAIRS = [(0x27ed9e, 0x27eda9), (0x27eea8, 0x27eeb3),
                (0x27f088, 0x27f093), (0x27f192, 0x27f19d),
                (0x27f307, 0x27f312)]
DIRECTDRAW_MODES = [(0x8a2d98, 32), (0x8a3308, 24), (0x8a3850, 15),
                   (0x8a3d00, 16), (0x8a4248, 8)]

def patch(source):
    if hashlib.sha256(source).hexdigest() not in KNOWN:
        raise ValueError("Unsupported input SHA-256; refusing to patch unknown build")
    result = bytearray(source)
    for width, height in ENGINE_PAIRS:
        dimensions = (struct.unpack_from("<I", source, width)[0],
                      struct.unpack_from("<I", source, height)[0])
        if dimensions not in {(1600, 1200), (2560, 1440)}:
            raise ValueError("Engine instruction operands do not match")
        struct.pack_into("<I", result, width, 2560)
        struct.pack_into("<I", result, height, 1440)
    for offset, depth in DIRECTDRAW_MODES:
        if struct.unpack_from("<III", source, offset) != (1599, 1199, depth):
            raise ValueError("DirectDraw mode descriptor does not match")
        struct.pack_into("<II", result, offset, 2559, 1439)
    struct.pack_into("<I", result, 0x33ac58, 2560)
    struct.pack_into("<I", result, 0x33ac68, 1440)
    return bytes(result)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    result = patch(args.input.read_bytes())
    with args.output.open("xb") as output:
        output.write(result)
    print(f"Created {args.output}: {hashlib.sha256(result).hexdigest()}")
