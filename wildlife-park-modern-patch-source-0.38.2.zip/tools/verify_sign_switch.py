#!/usr/bin/env python3
"""Execute the actual logo setup and hover hooks at two image bases."""
import subprocess,tempfile,json
from pathlib import Path
from sign_switch import patch,ROOT
from patch_debug_tools import digest
def verify(m):
    for base in (0x400000,0x14000000):
        sy=m['symbols'];pr=m['profile'];bt=base+m['button'];rd=base+m['ready'];ow=base+m['owner']
        vt=base+m['rva']+sy['vtable'];x,y,w,h=m['bounds']
        asm=f'''.intel_syntax noprefix
.code32
.global start
.section .main,"ax"
start:
 mov [saved_sp],esp
 mov ecx,OFFSET root
 push 0x55667788
 call thunk+{sy['setup']}
 cmp eax,0x12345678
 jne fail
 cmp esp,[saved_sp]
 jne fail
 cmp DWORD PTR [{bt}],{vt}
 jne fail
 cmp DWORD PTR [{vt}+0x3c],{base+m['rva']+sy['hover']}
 jne fail
 cmp DWORD PTR [bounds_calls],1
 jne fail
 cmp DWORD PTR [caption_calls],1
 jne fail
 # Every inherited slot except hover is copied unchanged.
 xor edi,edi
vtable_loop:
 cmp edi,0x3c
 je next_slot
 mov eax,DWORD PTR [native_table+edi]
 cmp eax,DWORD PTR [{vt}+edi]
 jne fail
next_slot:
 add edi,4
 cmp edi,128
 jb vtable_loop
 mov ecx,{bt}
 push 1
 call thunk+{sy['hover']}
 cmp DWORD PTR [root+0x2f0+0x29c],1
 jne fail
 mov ecx,{bt}
 push 0
 call thunk+{sy['hover']}
 cmp DWORD PTR [root+0x2f0+0x29c],0
 jne fail
 # The actual native normalization must control the frame, not raw input.
 and DWORD PTR [{bt}+0x244],0xffffffef
 mov ecx,{bt}
 push 1
 call thunk+{sy['hover']}
 cmp DWORD PTR [root+0x2f0+0x29c],0
 jne fail
 cmp DWORD PTR [frame_calls],3
 jne fail
 mov DWORD PTR [{rd}],0
 mov ecx,{bt}
 push 1
 call thunk+{sy['hover']}
 cmp DWORD PTR [frame_calls],3
 jne fail
 mov DWORD PTR [{rd}],1
 mov DWORD PTR [{ow}],0
 mov ecx,{bt}
 push 1
 call thunk+{sy['hover']}
 cmp DWORD PTR [frame_calls],3
 jne fail
 cmp esp,[saved_sp]
 jne fail
 xor ebx,ebx
 mov eax,1
 int 0x80
fail:
 mov ebx,1
 mov eax,1
 int 0x80
.section .previous,"ax"
 cmp ecx,OFFSET root
 jne fail
 cmp DWORD PTR [esp+4],0x55667788
 jne fail
 mov eax,0x12345678
 ret 4
.section .bounds,"ax"
 cmp ecx,{bt}
 jne fail
 cmp DWORD PTR [esp+4],{x}
 jne fail
 cmp DWORD PTR [esp+8],{y}
 jne fail
 cmp DWORD PTR [esp+12],{w}
 jne fail
 cmp DWORD PTR [esp+16],{h}
 jne fail
 inc DWORD PTR [bounds_calls]
 ret 16
.section .caption,"ax"
 cmp ecx,{bt}
 jne fail
 mov eax,[esp+4]
 cmp BYTE PTR [eax],0
 jne fail
 inc DWORD PTR [caption_calls]
 ret 4
.section .native_hover,"ax"
 cmp ecx,{bt}
 jne fail
 xor eax,eax
 cmp DWORD PTR [esp+4],0
 je native_leave
 test DWORD PTR [ecx+0x244],0x10
 setne al
native_leave:
 mov DWORD PTR [ecx+0x240],eax
 mov ecx,0x99887766
 mov edx,0x11223344
 ret 4
.section .frame,"ax"
 cmp ecx,OFFSET root+0x2f0
 jne fail
 mov eax,[esp+4]
 cmp eax,1
 ja fail
 mov [ecx+0x29c],eax
 inc DWORD PTR [frame_calls]
 ret 4
.section .nativevtable,"aw"
native_table: .long {','.join(str(base+m['native_hover']) if i==15 else str(0x11110000+i) for i in range(32))}
.section .ready,"aw"
 .long 1
.section .owner,"aw"
 .long root
.section .button,"aw"
 .zero 0x638
.section .thunk,"awx"
thunk: .incbin "CODEPATH"
.section .data,"aw"
saved_sp: .long 0
bounds_calls: .long 0
caption_calls: .long 0
frame_calls: .long 0
root: .zero 0x129b4
'''
        sections=dict(previous=m['previous'],bounds=pr['bounds'],caption=pr['caption'],native_hover=m['native_hover'],
                      frame=m['frame_setter'],nativevtable=m['native_vtable'],ready=m['ready'],owner=m['owner'],button=m['button'],thunk=m['rva'])
        with tempfile.TemporaryDirectory() as tmp:
            d=Path(tmp);(d/'code.bin').write_bytes(m['code']);(d/'test.s').write_text(asm.replace('CODEPATH',str(d/'code.bin')))
            layout='\n'.join(f'.{k} {base+v} : {{ *(.{k}) }}' for k,v in sorted(sections.items(),key=lambda x:x[1]))
            (d/'test.ld').write_text(f'ENTRY(start)\nSECTIONS {{ .main {base+0x1000} : {{ *(.main) }}\n{layout}\n.data {base+m["rva"]+0x10000} : {{ *(.data) }} }}')
            subprocess.run(['as','--32','-o',str(d/'test.o'),str(d/'test.s')],check=True)
            r=subprocess.run(['ld','-m','elf_i386','-T',str(d/'test.ld'),'-o',str(d/'test'),str(d/'test.o')],capture_output=True,text=True)
            assert r.returncode==0,r.stderr
            r=subprocess.run([str(d/'test')],timeout=10);assert r.returncode==0,(m['name'],hex(base),r.returncode)
    print('PASS: '+m['name']+' logo bounds, inherited vtable, enter/leave normalization, lifetime guards and ABI; two image bases')
if __name__=='__main__':
    checks=[]
    for name in ('WLP','WLPADD1'):
        result,m=patch((ROOT/'builds/versions/0.34.0'/f'{name}.EXE').read_bytes(),name)
        assert result==(ROOT/'builds/versions/0.35.0'/f'{name}.EXE').read_bytes()
        verify(m)
        checks.append(dict(name=name,passed=True,sha256=digest(result),code_sha256=digest(m['code']),image_bases=['0x400000','0x14000000']))
    (ROOT/'analysis/sign-switch-verification.json').write_text(json.dumps(checks,indent=2)+'\n')
