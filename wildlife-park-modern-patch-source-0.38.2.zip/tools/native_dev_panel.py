#!/usr/bin/env python3
"""Add one F2 toggle for the native developer flag, based strictly on 0.30.1."""
import struct, subprocess, tempfile
from pathlib import Path
import pefile
from patch_addon_widescreen import append_section, next_rva
from patch_keybind_panel import asm_string
from patch_weather_menu import PROFILES as WEATHER_PROFILES, SIZE as WEATHER_SIZE

BUTTON_SIZE = 0x638
BUTTONS = tuple(WEATHER_SIZE + i * BUTTON_SIZE for i in range(1))
READY = WEATHER_SIZE + BUTTON_SIZE
SIZE = READY + 4
CAPTIONS = ('Entwicklermodus',)


def patch(data, tag):
    addon = tag in ('addon', 'WLPADD1', 'WLPADD1.EXE')
    if tag not in ('base', 'WLP', 'WLP.EXE', 'addon', 'WLPADD1', 'WLPADD1.EXE'):
        raise ValueError(tag)
    pr = dict(list(WEATHER_PROFILES.values())[int(addon)])
    pr['root_hook'] = 0x119dfc if addon else 0x10868c
    flags = 0xa3b47c if addon else 0x8af1b4
    input_hook = 0x12bf48 if addon else 0x119768
    normal = 0x12c0c1 if addon else 0x1198e1
    p = pefile.PE(data=data)
    rva = next_rva(data)
    def current_call(h):
        raw = p.get_data(h, 5)
        assert raw[0] == 0xe8, (hex(h), raw.hex())
        return h + 5 + struct.unpack('<i', raw[1:])[0]
    pr['previous_ctor'] = current_call(pr['ctor_call'])
    pr['previous_attach'] = current_call(pr['attach_hook'])
    pr['previous_detach'] = current_call(pr['detach_hook'])
    old_dtor = p.get_data(pr['dtor'], 5)
    assert old_dtor[0] == 0xe9
    pr['previous_dtor'] = pr['dtor'] + 5 + struct.unpack('<i', old_dtor[1:])[0]
    root_bounds = current_call(pr['root_hook'])
    close_bounds = current_call(pr['bounds_hook'])
    assert p.get_data(root_bounds, 8) == bytes.fromhex('c7442410f4010000')
    assert p.get_data(close_bounds, 8) == bytes.fromhex('c7442408db010000')
    def call(n):
        return f'.byte 0xe8\n.long {pr[n]}-({rva}+.-_start+4)'
    ctor = '\n'.join(f'lea ecx,[esi+{b}]\npush 1\n{call("button_ctor")}' for b in BUTTONS)
    destroy = '\n'.join(f'lea ecx,[esi+{b+0x630}]\n{call("button_dtor")}' for b in reversed(BUTTONS))
    attach = []
    for i,b in enumerate(BUTTONS):
        x,y,w = (10,475,270)
        attach.append(f'''lea edi,[esi+{b}]
 push 20
 push {w}
 push {y}
 push {x}
 mov ecx,edi
 {call('bounds')}
 mov ecx,edi
 call refresh_{i}
 push 0
 push 0
 push 0
 lea eax,[ebx+{rva}+toggle_{i}-_start]
 push eax
 push esi
 push 0x0e
 mov ecx,edi
 {call('register')}
 push 1
 mov ecx,edi
 {call('enabled')}
 push esi
 mov ecx,edi
 {call('attach')}''')
    detach = '\n'.join(f'lea ecx,[esi+{b}]\n{call("detach")}' for b in reversed(BUTTONS))
    toggles = []
    for i,b in enumerate(BUTTONS):
        toggles.append(f'''toggle_{i}:
 pushfd
 pushad
 call get_base
 cmp BYTE PTR [ebx+{flags}],0
 sete al
 mov BYTE PTR [ebx+{flags}],al
 mov ecx,[esp+24]
 add ecx,{b}
 call refresh_{i}
 popad
 popfd
 mov al,1
 ret 8
refresh_{i}:
 lea eax,[ebx+{rva}+caption_off_{i}-_start]
 cmp BYTE PTR [ebx+{flags}],0
 je caption_{i}
 lea eax,[ebx+{rva}+caption_on_{i}-_start]
caption_{i}:
 push eax
 {call('caption')}
 ret
{asm_string('caption_off_'+str(i), CAPTIONS[i]+': Aus')}
{asm_string('caption_on_'+str(i), CAPTIONS[i]+': An')}
''')
    asm=f'''.intel_syntax noprefix
.code32
.global _start
_start:
get_base:
 call anchor
anchor:
 pop ebx
 sub ebx,{rva}+anchor-_start
 ret
constructor:
 push esi
 push DWORD PTR [esp+8]
 {call('previous_ctor')}
 mov esi,eax
 mov DWORD PTR [esi+{READY}],0
 {ctor}
 mov DWORD PTR [esi+{READY}],1
 mov eax,esi
 pop esi
 ret 4
destructor:
 pushfd
 pushad
 lea esi,[ecx-0x1620]
 cmp DWORD PTR [esi+{READY}],1
 jne dtor_done
 mov DWORD PTR [esi+{READY}],0
 {destroy}
dtor_done:
 popad
 popfd
 jmp _start+{pr['previous_dtor']-rva}
attach_buttons:
 push ebx
 push esi
 push edi
 mov esi,[esp+16]
 push esi
 {call('previous_attach')}
 call get_base
 {chr(10).join(attach)}
 pop edi
 pop esi
 pop ebx
 ret 4
detach_buttons:
 push esi
 lea esi,[ecx-0x1228]
 {call('previous_detach')}
 {detach}
 pop esi
 ret
{chr(10).join(toggles)}
# Preserve the native developer dispatch except for F2, which must stay reachable.
f2_gate:
 pushfd
 push eax
 cmp WORD PTR [edi+0x40],0x3c00
 je f2_menu
 push ebx
 call get_base
 mov al,BYTE PTR [ebx+{flags}]
 pop ebx
 mov BYTE PTR [esp],al
 pop eax
 popfd
 jmp _start+{input_hook+5-rva}
f2_menu:
 pop eax
 popfd
 jmp _start+{normal-rva}
'''
    with tempfile.TemporaryDirectory() as tmp:
        d=Path(tmp);(d/'panel.s').write_text(asm)
        subprocess.run(['as','--32','-o',str(d/'panel.o'),str(d/'panel.s')],check=True)
        assert 'R_386' not in subprocess.check_output(['objdump','-r',str(d/'panel.o')],text=True)
        subprocess.run(['objcopy','-O','binary','-j','.text',str(d/'panel.o'),str(d/'panel.bin')],check=True)
        code=(d/'panel.bin').read_bytes()
        symbols={a[2]:int(a[0],16) for line in subprocess.check_output(['nm',str(d/'panel.o')],text=True).splitlines() if len(a:=line.split())==3}
    b=bytearray(data);changes=[]
    def replace(h, old, new):
        assert len(old)==len(new)
        off=p.get_offset_from_rva(h)
        assert b[off:off+len(old)]==old,(hex(h),bytes(b[off:off+len(old)]).hex())
        b[off:off+len(old)]=new;changes.append((h,len(old)))
    replace(pr['alloc'], b'\x68'+struct.pack('<I',WEATHER_SIZE), b'\x68'+struct.pack('<I',SIZE))
    for field,symbol in [('ctor_call','constructor'),('attach_hook','attach_buttons'),('detach_hook','detach_buttons')]:
        h=pr[field];replace(h,p.get_data(h,5),b'\xe8'+struct.pack('<i',rva+symbols[symbol]-h-5))
    h=pr['dtor'];replace(h,old_dtor,b'\xe9'+struct.pack('<i',rva+symbols['destructor']-h-5))
    replace(root_bounds+4,struct.pack('<I',500),struct.pack('<I',530))
    replace(close_bounds+4,struct.pack('<I',475),struct.pack('<I',505))
    replace(input_hook,b'\xa0'+struct.pack('<I',0x400000+flags),
            b'\xe9'+struct.pack('<i',rva+symbols['f2_gate']-input_hook-5))
    reloc_offsets=[]
    for block in p.DIRECTORY_ENTRY_BASERELOC:
        for e in block.entries:
            if e.type and e.rva==input_hook+1:
                assert e.type==3
                off=e.struct.get_file_offset()
                struct.pack_into('<H',b,off,struct.unpack_from('<H',b,off)[0]&0xfff)
                reloc_offsets.append(off)
    assert len(reloc_offsets)==1
    for block in p.DIRECTORY_ENTRY_BASERELOC:
        for e in block.entries:
            assert not e.type or e.rva==input_hook+1 or not any(h<=e.rva<h+n for h,n in changes)
    append_section(b,b'.wlpdev',code)
    np=pefile.PE(data=b)
    struct.pack_into('<I',b,np.sections[-1].get_file_offset()+36,0xe0000020)
    return bytes(b),dict(profile=pr,rva=rva,code=code,symbols=symbols,changes=changes,
                         reloc_offsets=reloc_offsets,input_hook=input_hook,normal=normal,flags_rva=flags,button_offsets=BUTTONS,ready=READY,size=SIZE,
                         callbacks=[rva+symbols['toggle_'+str(i)] for i in range(1)])
