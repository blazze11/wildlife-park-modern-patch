#!/usr/bin/env python3
"""Tile the original sparse RGB565 weather animations to a larger canvas."""
import argparse
import hashlib
import struct
from pathlib import Path


def rows(payload, width, height):
    """Decode sparse spans; offsets are relative to each row's table word."""
    result = []
    end = height * 4
    for y in range(height):
        pos = struct.unpack_from('<I', payload, y * 4)[0] + y * 4
        assert pos == end
        x = 0
        spans = []
        while x < width:
            command = struct.unpack_from('<H', payload, pos)[0]
            pos += 2
            skip, count = command & 255, command >> 8
            assert skip or count
            x += skip
            assert x + count <= width
            pixels = payload[pos:pos + count * 2]
            assert len(pixels) == count * 2
            if count:
                spans.append((x, pixels))
            pos += count * 2
            x += count
        assert payload[pos:pos + 2] == b'\0\0'
        end = pos + 2
        result.append(spans)
    assert end == len(payload)
    return result


def tiled_rows(original, old_width, width, height):
    result = []
    for y in range(height):
        spans = []
        for base in range(0, width, old_width):
            for x, pixels in original[y % len(original)]:
                dest = base + x
                if dest < width:
                    spans.append((dest, pixels[:(width - dest) * 2]))
        result.append(spans)
    return result


def encode(spans_by_row, width):
    height = len(spans_by_row)
    out = bytearray(height * 4)
    for y, spans in enumerate(spans_by_row):
        struct.pack_into('<I', out, y * 4, len(out) - y * 4)
        cursor = 0
        for x, pixels in spans:
            gap = x - cursor
            assert gap >= 0 and len(pixels) % 2 == 0
            while gap > 255:
                out += struct.pack('<H', 255)
                gap -= 255
            for pos in range(0, len(pixels), 510):
                part = pixels[pos:pos + 510]
                out += struct.pack('<H', (len(part) // 2 << 8) | gap) + part
                gap = 0
            cursor = x + len(pixels) // 2
        gap = width - cursor
        while gap:
            chunk = min(gap, 255)
            out += struct.pack('<H', chunk)
            gap -= chunk
        out += b'\0\0'
    return bytes(out)


def expand(src, width=2560, height=1440):
    version, count, flags, unused, table, size = struct.unpack_from('<HHIIII', src)
    assert (version, count, flags) == (200, 10, 0x210)
    offsets = struct.unpack_from(f'<{size // 4}I', src, table)
    assert offsets[-1] == len(src)
    result = bytearray(src[:offsets[0]])
    new_offsets = [len(result)]
    frame = 0
    changed = 0
    for entry in range(count):
        header = 255 + entry * 64
        nf, ow, oh, raw, total, ident = struct.unpack_from('<HHHIII', src, header)
        assert raw == ow * oh * 2 and total == raw * nf
        if entry in (5, 6):
            assert (nf, ow, oh) == (10, 1600, 1200)
            struct.pack_into('<HHII', result, header + 2, width, height,
                             width * height * 2, width * height * 2 * nf)
        for _ in range(nf):
            original = src[offsets[frame]:offsets[frame + 1]]
            payload = original
            if entry in (5, 6):
                decoded = rows(original, ow, oh)
                tiled = tiled_rows(decoded, ow, width, height)
                payload = encode(tiled, width)
                assert rows(payload, width, height) == tiled
                changed += 1
            result += payload
            new_offsets.append(len(result))
            frame += 1
    assert len(new_offsets) == len(offsets) and changed == 20
    struct.pack_into(f'<{len(new_offsets)}I', result, table, *new_offsets)
    return bytes(result)


def replace_container(source, replacement, output, expected_original=None):
    with source.open('rb') as f:
        header = f.read(28)
        assert header[:4] == b'cont'
        stride, count, directory, payload = struct.unpack_from('<4I', header, 12)
        assert stride == 328
        f.seek(0)
        metadata = bytearray(f.read(payload))
        lengths = [struct.unpack_from('<I', metadata, directory + i * stride + 32)[0]
                   for i in range(count)]
        assert payload + sum(lengths) == source.stat().st_size
        cursor = payload
        for i, length in enumerate(lengths):
            # Eight bytes after WIN32_FIND_DATA hold an absolute file offset.
            stored = struct.unpack_from('<Q', metadata, directory + i * stride + 320)[0]
            assert stored == cursor, f'Unexpected source member offset {i}'
            cursor += length
        matches = [i for i in range(count)
                   if metadata[directory + i * stride + 44:].split(b'\0', 1)[0] == b'Misc.alb']
        assert len(matches) == 1
        index = matches[0]
        begin = payload + sum(lengths[:index])
        f.seek(begin)
        original = f.read(lengths[index])
        if expected_original is None:
            expected_original = Path('analysis/weather/Misc_original.alb').read_bytes()
        assert original == expected_original, 'Unexpected source Misc.alb'
        struct.pack_into('<I', metadata, directory + index * stride + 32, len(replacement))
        delta = len(replacement) - lengths[index]
        for i in range(index + 1, count):
            field = directory + i * stride + 320
            stored = struct.unpack_from('<Q', metadata, field)[0]
            struct.pack_into('<Q', metadata, field, stored + delta)
        with output.open('xb') as out:
            out.write(metadata)
            f.seek(payload)
            remaining = begin - payload
            while remaining:
                chunk = f.read(min(remaining, 1024 * 1024))
                assert chunk
                out.write(chunk)
                remaining -= len(chunk)
            out.write(replacement)
            f.seek(begin + lengths[index])
            while chunk := f.read(1024 * 1024):
                out.write(chunk)
    return begin, lengths[index]


def verify_container(source, output, replacement):
    """Read every member through its stored index, as the game does."""
    with source.open('rb') as original, output.open('rb') as changed:
        header = original.read(28)
        stride, count, directory, payload = struct.unpack_from('<4I', header, 12)
        original.seek(0)
        old_meta = original.read(payload)
        new_meta = changed.read(payload)
        assert old_meta[:directory] == new_meta[:directory]
        cursor = payload
        verified = 0
        for i in range(count):
            record = directory + i * stride
            old_record = old_meta[record:record + stride]
            new_record = new_meta[record:record + stride]
            name = old_record[44:304].split(b'\0', 1)[0]
            old_length = struct.unpack_from('<I', old_record, 32)[0]
            new_length = struct.unpack_from('<I', new_record, 32)[0]
            old_offset = struct.unpack_from('<Q', old_record, 320)[0]
            new_offset = struct.unpack_from('<Q', new_record, 320)[0]
            assert new_offset == cursor, f'Wrong indexed offset for {name!r}'
            expected_record = bytearray(old_record)
            struct.pack_into('<Q', expected_record, 320, new_offset)
            original.seek(old_offset)
            changed.seek(new_offset)
            if name == b'Misc.alb':
                struct.pack_into('<I', expected_record, 32, len(replacement))
                assert new_length == len(replacement)
                assert changed.read(new_length) == replacement
            else:
                assert old_length == new_length
                remaining = old_length
                while remaining:
                    size = min(remaining, 1024 * 1024)
                    assert original.read(size) == changed.read(size), f'Changed member {name!r}'
                    remaining -= size
                verified += 1
            assert new_record == expected_record
            cursor += new_length
        assert cursor == output.stat().st_size
        assert verified == count - 1
    return verified


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--container', type=Path)
    parser.add_argument('--container-output', type=Path)
    args = parser.parse_args()
    result = expand(args.input.read_bytes())
    with args.output.open('xb') as f:
        f.write(result)
    print(f'Created {args.output}: 20 frames expanded; SHA256 {hashlib.sha256(result).hexdigest()}')
    if args.container:
        if args.container_output is None:
            parser.error('--container-output required with --container')
        replace_container(args.container, result, args.container_output)
        verified = verify_container(args.container, args.container_output, result)
        print(f'Created {args.container_output}; verified all indexed offsets and {verified} unchanged members')
