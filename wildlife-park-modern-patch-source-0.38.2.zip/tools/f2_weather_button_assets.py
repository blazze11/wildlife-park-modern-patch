#!/usr/bin/env python3
"""Append exact expansion button pixels to shared GUI without shifting old IDs."""
import json,struct,hashlib
from pathlib import Path
from export_menu_assets import decode_frame
from replace_alb_frame import encode_literals
from workspace_paths import ROOT,GAME
VERSION='0.38.0'
def sha(d):return hashlib.sha256(d).hexdigest()
def append_buttons(data):
 v,n,flags,u,table,size=struct.unpack_from('<HHIIII',data)
 assert (v,n,flags,table)==(200,133,272,255+133*64)
 offsets=struct.unpack_from(f'<{size//4}I',data,table);assert offsets[-1]==len(data)
 source=(GAME/'Int/All/Pictures/Addon1/GUI_AddOn1.alb').read_bytes()
 headers=[];payloads=[];pixels=[];first=len(offsets)-1
 for j,folder in enumerate(('random','reset')):
  header=bytearray(source[255+(j+1)*64:255+(j+2)*64]);assert struct.unpack_from('<HHH',header)==(4,120,34)
  struct.pack_into('<I',header,15,first+j*4);headers.append(header)
  for state in range(4):
   raw=(ROOT/'assets/weather-menu-buttons'/folder/f'button_{state:02d}.rgb565').read_bytes();encoded=encode_literals(raw)
   assert decode_frame(encoded,120,34,272)==raw
   pixels.append(sha(raw));payloads.append(encoded)
 newtable=table+128;newsize=size+32
 result=bytearray(data[:table]+b''.join(headers)+bytes(newsize));struct.pack_into('<H',result,2,n+2);struct.pack_into('<II',result,12,newtable,newsize)
 newoffsets=[len(result)]
 for i in range(len(offsets)-1):result.extend(data[offsets[i]:offsets[i+1]]);newoffsets.append(len(result))
 for payload in payloads:result.extend(payload);newoffsets.append(len(result))
 struct.pack_into(f'<{len(newoffsets)}I',result,newtable,*newoffsets)
 assert result[255:table]==data[255:table]
 for i in range(len(offsets)-1):assert result[newoffsets[i]:newoffsets[i+1]]==data[offsets[i]:offsets[i+1]]
 return bytes(result),dict(old_entries=n,new_entries=n+2,preserved_frames=len(offsets)-1,raw_button_sha256=pixels)
def container(source,target):
 with source.open('rb') as f:
  header=f.read(28);stride,count,directory,start=struct.unpack_from('<4I',header,12);assert stride==328
  f.seek(0);meta=bytearray(f.read(start));cursor=start;entries=[]
  for i in range(count):
   r=directory+i*stride;ln=struct.unpack_from('<I',meta,r+32)[0];off=struct.unpack_from('<Q',meta,r+320)[0];assert off==cursor
   entries.append((off,ln));cursor+=ln
   if meta[r+44:r+304].split(b'\0')[0]==b'GUI.alb':selected=i
  assert cursor==source.stat().st_size
  begin,length=entries[selected];f.seek(begin);raw=f.read(length);replacement,info=append_buttons(raw)
  delta=len(replacement)-length;struct.pack_into('<I',meta,directory+selected*stride+32,len(replacement))
  for i in range(selected+1,count):struct.pack_into('<Q',meta,directory+i*stride+320,entries[i][0]+delta)
  with target.open('wb') as out:
   out.write(meta);f.seek(start)
   for i,(off,ln) in enumerate(entries):
    if i==selected:out.write(replacement);f.seek(off+ln)
    else:
     remaining=ln
     while remaining:
      part=f.read(min(1024*1024,remaining));assert part;out.write(part);remaining-=len(part)
 with source.open('rb') as a,target.open('rb') as b:
  for i,(off,ln) in enumerate(entries):
   a.seek(off);b.seek(struct.unpack_from('<Q',meta,directory+i*stride+320)[0])
   if i==selected:assert b.read(len(replacement))==replacement
   else:
    remaining=ln
    while remaining:
     size=min(1024*1024,remaining);assert a.read(size)==b.read(size);remaining-=size
 info['preserved_container_members']=count-1;return info
if __name__=='__main__':
 out=ROOT/'assets/versions'/VERSION;out.mkdir(exist_ok=True);records=[]
 for rel in ('Int/All/Pictures/GUI.alb','Int/All/Pictures.cont'):
  source=GAME/rel;target=out/source.name
  if source.suffix=='.alb':data,info=append_buttons(source.read_bytes());target.write_bytes(data)
  else:info=container(source,target)
  records.append(dict(path=rel,candidate=str(target),source_sha256=sha(source.read_bytes()),sha256=sha(target.read_bytes()),verification=info))
 (ROOT/'analysis/f2-weather-button-assets.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(records,indent=2))
