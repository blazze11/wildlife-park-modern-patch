#!/usr/bin/env python3
"""Preserve the scrollbar's 33rd virtual slot; retain all 0.37.3 behavior."""
import json,struct,subprocess,tempfile
from pathlib import Path
import pefile
from patch_debug_tools import ROOT,digest,public,check_preservation
from patch_addon_widescreen import append_section,next_rva
VERSION='0.37.4'
def patch(data,name):
 old=next(x['patch'] for x in json.loads((ROOT/'analysis/f2-objective-fix-candidate-0.37.3.json').read_text()) if x['name']==name)
 assert old['profile']['scroll_vtable'] and old['scrolls'][1]
 p=pefile.PE(data=data);h=old['profile']['attach_hook'];raw=p.get_data(h,5);assert raw[0]==0xe8
 previous=h+5+struct.unpack('<i',raw[1:])[0];rva=next_rva(data)
 native=old['profile']['scroll_vtable'];invalidate=old['rva']+old['symbols']['scroll_invalidate']
 last=struct.unpack('<I',p.get_data(native+0x80,4))[0]-p.OPTIONAL_HEADER.ImageBase
 assert p.get_data(last,3)==b'\xc2\x04\x00','Expected native value-change notification stub'
 asm=f'''.intel_syntax noprefix
.code32
.global _start
_start:
attach:
 push esi
 mov esi,[esp+8]
 push esi
 .byte 0xe8
 .long {previous}-({rva}+.-_start+4)
 pushfd
 pushad
 cld
 call anchor
anchor:
 pop ebx
 sub ebx,{rva}+anchor-_start
 push esi
 lea esi,[ebx+{native}]
 lea edi,[ebx+{rva}+table-_start]
 mov ecx,33
 rep movsd
 pop esi
 lea eax,[ebx+{invalidate}]
 mov [ebx+{rva}+table-_start+8],eax
 lea eax,[ebx+{rva}+table-_start]
 mov [esi+{old['scrolls'][1]}],eax
 popad
 popfd
 pop esi
 ret 4
.balign 4
table: .zero 132
'''
 with tempfile.TemporaryDirectory() as tmp:
  d=Path(tmp);(d/'fix.s').write_text(asm)
  subprocess.run(['as','--32','-o',str(d/'fix.o'),str(d/'fix.s')],check=True)
  assert 'R_386' not in subprocess.check_output(['objdump','-r',str(d/'fix.o')],text=True)
  subprocess.run(['objcopy','-O','binary','-j','.text',str(d/'fix.o'),str(d/'fix.bin')],check=True)
  code=(d/'fix.bin').read_bytes();sy={a[2]:int(a[0],16) for line in subprocess.check_output(['nm',str(d/'fix.o')],text=True).splitlines() if len(a:=line.split())==3}
 b=bytearray(data);off=p.get_offset_from_rva(h);b[off:off+5]=b'\xe8'+struct.pack('<i',rva+sy['attach']-h-5)
 append_section(b,b'.wlpscrf',code);q=pefile.PE(data=b);struct.pack_into('<I',b,q.sections[-1].get_file_offset()+36,0xe0000020)
 m=dict(name=name,rva=rva,code=code,symbols=sy,previous=previous,native=native,invalidate=invalidate,last=last,scroll=old['scrolls'][1],size=old['size'],changes=[(h,5)],reloc_offsets=[])
 check_preservation(data,b,m);return bytes(b),m
def build(name):
 f=ROOT/'builds/versions/0.37.3'/f'{name}.EXE'
 expected=next(x['sha256'] for e in json.loads((ROOT/'builds/versions.json').read_text())['versions'] if e['version']=='0.37.3' for x in e['files'] if x['path'].endswith('/'+f.name))
 data=f.read_bytes();assert digest(data)==expected;return patch(data,name)
if __name__=='__main__':
 out=ROOT/'builds/versions'/VERSION;out.mkdir(exist_ok=True);records=[]
 for name in ('WLP','WLPADD1'):
  data,m=build(name);target=out/f'{name}.EXE'
  if target.exists():assert target.read_bytes()==data
  else:target.write_bytes(data)
  records.append(dict(name=name,sha256=digest(data),bytes=len(data),patch=public(m)))
 (ROOT/'analysis/f2-scroll-crash-candidate.json').write_text(json.dumps(records,indent=2)+'\n')
 print(json.dumps([dict(name=x['name'],sha256=x['sha256']) for x in records],indent=2))
