#!/usr/bin/env python3
"""0.35.1: use native pointer enter/leave rather than pressed-state selection."""
import json,struct,subprocess,tempfile
from pathlib import Path
import pefile
from sign_switch import ROOT
from patch_addon_widescreen import next_rva,append_section
from patch_debug_tools import check_preservation,public,digest
VERSION='0.35.1'
def patch(data,name):
    old=next(e['patch'] for e in json.loads((ROOT/'analysis/sign-switch-candidate.json').read_text()) if e['name']==name)
    p=pefile.PE(data=data);rva=next_rva(data);pr=old['profile']
    hook=pr['setup_hook'];raw=p.get_data(hook,5)
    assert raw[0]==0xe8
    previous=hook+5+struct.unpack('<i',raw[1:])[0]
    assert previous==old['rva']+old['symbols']['setup']
    vt=old['rva']+old['symbols']['vtable']
    native=old['native_vtable']
    targets={key:struct.unpack('<I',p.get_data(native+slot,4))[0]-p.OPTIONAL_HEADER.ImageBase
             for key,slot in [('pressed',0x3c),('enter',0x60),('leave',0x64)]}
    def call(dest):return f'.byte 0xe8\n.long {dest}-({rva}+.-_start+4)'
    handlers=[]
    for key,frame in [('enter',1),('leave',0)]:
        handlers.append(f'''{key}:
 push DWORD PTR [esp+4]
 {call(targets[key])}
 pushfd
 pushad
 call get_base
 cmp DWORD PTR [ebx+{old['ready']}],1
 jne {key}_done
 mov ecx,DWORD PTR [ebx+{old['owner']}]
 test ecx,ecx
 je {key}_done
 add ecx,0x2f0
 push {frame}
 {call(old['frame_setter'])}
{key}_done:
 popad
 popfd
 ret 4''')
    asm=f'''.intel_syntax noprefix
.code32
.global _start
_start:
get_base:
 call anchor
anchor:
 pop ebx
 sub ebx,{rva}+anchor-_start
 ret
setup:
 push DWORD PTR [esp+4]
 {call(previous)}
 pushfd
 pushad
 call get_base
 cmp DWORD PTR [ebx+{old['ready']}],1
 jne setup_done
 # Restore native press/selection handling; only enter/leave changes texture.
 lea eax,[ebx+{targets['pressed']}]
 mov DWORD PTR [ebx+{vt}+0x3c],eax
 lea eax,[ebx+{rva}+enter-_start]
 mov DWORD PTR [ebx+{vt}+0x60],eax
 lea eax,[ebx+{rva}+leave-_start]
 mov DWORD PTR [ebx+{vt}+0x64],eax
setup_done:
 popad
 popfd
 ret 4
{chr(10).join(handlers)}
'''
    with tempfile.TemporaryDirectory() as tmp:
        d=Path(tmp);(d/'fix.s').write_text(asm)
        subprocess.run(['as','--32','-o',str(d/'fix.o'),str(d/'fix.s')],check=True)
        assert 'R_386' not in subprocess.check_output(['objdump','-r',str(d/'fix.o')],text=True)
        subprocess.run(['objcopy','-O','binary','-j','.text',str(d/'fix.o'),str(d/'fix.bin')],check=True)
        code=(d/'fix.bin').read_bytes()
        symbols={a[2]:int(a[0],16) for line in subprocess.check_output(['nm',str(d/'fix.o')],text=True).splitlines() if len(a:=line.split())==3}
    b=bytearray(data);off=p.get_offset_from_rva(hook)
    b[off:off+5]=b'\xe8'+struct.pack('<i',rva+symbols['setup']-hook-5)
    append_section(b,b'.wlphov',code)
    m=dict(name=name,rva=rva,code=code,symbols=symbols,changes=[(hook,5)],reloc_offsets=[],
           previous=previous,targets=targets,vtable=vt,ready=old['ready'],owner=old['owner'],button=old['button'],frame_setter=old['frame_setter'])
    check_preservation(data,b,m)
    return bytes(b),m
def build(name):
    source=(ROOT/'builds/versions/0.35.0'/f'{name}.EXE').read_bytes()
    expected=next(f['sha256'] for e in json.loads((ROOT/'builds/versions.json').read_text())['versions'] if e['version']=='0.35.0' for f in e['files'] if f['path'].endswith('/'+name+'.EXE'))
    assert digest(source)==expected
    return patch(source,name)
if __name__=='__main__':
    out=ROOT/'builds/versions'/VERSION;out.mkdir(exist_ok=True);records=[]
    for name in ('WLP','WLPADD1'):
        data,m=build(name);target=out/f'{name}.EXE'
        if target.exists():assert target.read_bytes()==data
        else:target.write_bytes(data)
        records.append(dict(name=name,sha256=digest(data),bytes=len(data),patch=public(m)))
    (ROOT/'analysis/sign-hover-fix-candidate.json').write_text(json.dumps(records,indent=2)+'\n')
    print(json.dumps([dict(name=r['name'],sha256=r['sha256']) for r in records],indent=2))
