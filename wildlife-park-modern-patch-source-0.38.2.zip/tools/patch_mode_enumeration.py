#!/usr/bin/env python3
"""Add a bounded DirectDraw enumeration filter to the verified v2 build."""
import hashlib, struct, argparse
from pathlib import Path
import pefile

V2 = 'd3aac4a44dfa4b0232e2791ce8a898a0a675f53dad1c13910146b05a2ce16b10'
WIDTHS = (320, 640, 800, 1024, 1152, 1280, 1600, 2560)
def align(n,a): return (n+a-1)//a*a

def patch(src):
    if hashlib.sha256(src).hexdigest()!=V2: raise ValueError('Requires verified v2 executable')
    p=pefile.PE(data=src); b=bytearray(src)
    hook=0x28f376
    assert b[hook:hook+7]==bytes.fromhex('83fa467c0533c0')
    last=p.sections[-1]
    rva=align(last.VirtualAddress+max(last.Misc_VirtualSize,last.SizeOfRawData),p.OPTIONAL_HEADER.SectionAlignment)
    raw=align(len(b),p.OPTIONAL_HEADER.FileAlignment)
    section_header=p.sections[0].get_file_offset()+40*p.FILE_HEADER.NumberOfSections
    assert section_header+40<=p.OPTIONAL_HEADER.SizeOfHeaders
    assert not any(b[section_header:section_header+40])
    code=bytearray(bytes.fromhex('8b442404')) # eax = surface descriptor; no registers need preservation
    branches=[]
    for width in WIDTHS:
        code+=bytes.fromhex('81780c')+struct.pack('<I',width) # compare descriptor width
        branches.append(len(code)); code+=b'\x74\x00'
    code+=bytes.fromhex('b801000000c20800') # skip irrelevant mode, continue enumeration
    accepted=len(code)
    code+=bytes.fromhex('83fa46') # original 70-record bound
    code+=b'\x0f\x8c'+struct.pack('<i',0x28f380-(rva+len(code)+6))
    code+=bytes.fromhex('33c0c20800') # full: cancel enumeration
    for branch in branches:
        displacement=accepted-(branch+2)
        assert 0<=displacement<128
        code[branch+1]=displacement
    b[hook:hook+7]=b'\xe9'+struct.pack('<i',rva-(hook+5))+b'\x90\x90'
    size=align(len(code),p.OPTIONAL_HEADER.FileAlignment)
    header=struct.pack('<8sIIIIIIHHI',b'.wlpmode',len(code),rva,size,raw,0,0,0,0,0x60000020)
    b[section_header:section_header+40]=header
    struct.pack_into('<H',b,p.FILE_HEADER.get_field_absolute_offset('NumberOfSections'),p.FILE_HEADER.NumberOfSections+1)
    struct.pack_into('<I',b,p.OPTIONAL_HEADER.get_field_absolute_offset('SizeOfImage'),align(rva+len(code),p.OPTIONAL_HEADER.SectionAlignment))
    struct.pack_into('<I',b,p.OPTIONAL_HEADER.get_field_absolute_offset('SizeOfCode'),p.OPTIONAL_HEADER.SizeOfCode+size)
    struct.pack_into('<I',b,p.OPTIONAL_HEADER.get_field_absolute_offset('CheckSum'),0)
    b+=bytes(raw-len(b))+code+bytes(size-len(code))
    return bytes(b)

if __name__=='__main__':
    a=argparse.ArgumentParser(description=__doc__);a.add_argument('input',type=Path);a.add_argument('output',type=Path);args=a.parse_args()
    result=patch(args.input.read_bytes())
    with args.output.open('xb') as f:f.write(result)
    print(hashlib.sha256(result).hexdigest())
