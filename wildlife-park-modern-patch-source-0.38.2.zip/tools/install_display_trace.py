#!/usr/bin/env python3
"""Install validated temporary display-transition diagnostics atomically."""
import hashlib, json, os
from pathlib import Path
from workspace_paths import artifact, backup_path
from trace_display_transition import PROFILES

root=Path('/path/to/Wildlife Park Gold')
program=root/'Int/Win32/Program/VC6'
pending=[]
for name in ('WLP','WLPADD1'):
 target=program/(name+'.EXE');old=target.read_bytes()
 assert hashlib.sha256(old).hexdigest() in PROFILES
 assert old==artifact(name+'_widescreen_zoom_steps.EXE').read_bytes()
 new=artifact(name+'_display_transition_trace.EXE').read_bytes()
 backup=backup_path(target.with_name(target.name+'.pre-display-transition-trace.bak'))
 if backup.exists():assert backup.read_bytes()==old
 pending.append((target,old,new,backup))
records=[]
for target,old,new,backup in pending:
 if not backup.exists():
  with backup.open('xb') as f:f.write(old)
 staged=target.with_name(target.name+'.display-trace.tmp')
 with staged.open('xb') as f:f.write(new)
 staged.chmod(target.stat().st_mode)
 assert target.read_bytes()==old
 os.replace(staged,target)
 assert target.read_bytes()==new
 records.append(dict(path=str(target),backup=str(backup),previous_sha256=hashlib.sha256(old).hexdigest(),sha256=hashlib.sha256(new).hexdigest(),size=len(new)))
Path('analysis/display-transition-installation.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps(records,indent=2))
