#!/usr/bin/env python3
"""Build the native developer-mode F2 toggle from immutable 0.30.1."""
import argparse
import json
from patch_debug_tools import ROOT, BASELINE, digest, public, check_preservation
from native_dev_panel import patch

VERSION = '0.32.0'

def build(name):
    source = (ROOT/'builds/versions/0.30.1'/f'{name}.EXE').read_bytes()
    assert digest(source) == BASELINE[name]
    result, metadata = patch(source, name)
    check_preservation(source, result, metadata)
    return result, metadata

if __name__ == '__main__':
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--verify', action='store_true', help='Run native 32-bit engine mocks at two image bases')
    args = ap.parse_args()
    out = ROOT/'builds/versions'/VERSION
    out.mkdir(exist_ok=True)
    records = []
    checks = []
    for name in BASELINE:
        result, metadata = build(name)
        if args.verify:
            from verify_native_dev_panel import verify
            verify(metadata)
            for base in (0x400000, 0x14000000):
                checks.append(dict(name=name, image_base=hex(base), passed=True,
                    sha256=digest(result), emittedcode_sha256=digest(metadata['code']),
                    scope='Native engine mocks: control lifecycle, caption refresh, byte isolation, F2 gate and ABI'))
        target = out/f'{name}.EXE'
        if target.exists():
            assert target.read_bytes() == result, 'Immutable snapshot differs'
        else:
            target.write_bytes(result)
        records.append(dict(name=name, source_sha256=BASELINE[name], sha256=digest(result),
                            bytes=len(result), panel=public(metadata)))
    (ROOT/'analysis/native-developer-candidate.json').write_text(json.dumps(records, indent=2)+'\n')
    if args.verify:
        (ROOT/'analysis/native-developer-verification.json').write_text(json.dumps(checks, indent=2)+'\n')
    print(json.dumps([dict(name=r['name'], sha256=r['sha256'], bytes=r['bytes']) for r in records], indent=2))
