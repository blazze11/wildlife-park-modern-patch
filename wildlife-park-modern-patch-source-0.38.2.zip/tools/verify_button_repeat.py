#!/usr/bin/env python3
"""Execute actual numeric repeat thunks at two bases with mocked clock/actions."""
import argparse
import struct
import subprocess
import tempfile
from pathlib import Path
from workspace_paths import artifact
import pefile
from patch_button_repeat import patch

def verify(name, build_only=False):
    src=artifact(f'{name}_widescreen_feedback.EXE').read_bytes()
    new,m=patch(src)
    assert new==artifact(f'{name}_widescreen_button_repeat.EXE').read_bytes()
    p=pefile.PE(data=src)
    expected=bytearray(src)
    for h,l in m['changes']:
        off=p.get_offset_from_rva(h)
        expected[off:off+l]=new[off:off+l]
    for off in m['reloc_offsets']:
        expected[off:off+2]=new[off:off+2]
    for s in p.sections:
        a=s.PointerToRawData
        assert new[a:a+s.SizeOfRawData]==expected[a:a+s.SizeOfRawData]
    np=pefile.PE(data=new)
    for block in np.DIRECTORY_ENTRY_BASERELOC:
        for e in block.entries:
            assert not e.type or not any(h<=e.rva<h+l for h,l in m['changes'])
    for base in (0x400000,0x14000000):
        with tempfile.TemporaryDirectory() as tmp:
            d=Path(tmp)
            (d/'code.bin').write_bytes(m['code'])
            cases=[]
            count=0
            for n,(_,_,saved_esi) in enumerate(m['sites']):
                expected_count=0
                def case(t, repeat, increment, reset=False, delta=1, owner='root'):
                    nonlocal count,expected_count
                    count+=1
                    expected_count+=increment
                    cases.append(f'''mov DWORD PTR [step],{count}
 mov DWORD PTR [now],{t & 0xffffffff}
 mov DWORD PTR [event+0x4c],{repeat}
 mov DWORD PTR [event+0x34],{delta}
 {'mov BYTE PTR ['+owner+'+0x1d5c],0' if reset else ''}
 mov ecx,OFFSET {owner}
 mov ebx,0x11223344
 mov esi,0x55667788
 mov edi,0x99aabbcc
 mov ebp,0x12345678
 push OFFSET event
 push 0
 call thunk+{m['symbols'][f'gate{n}']}
 cmp al,1
 jne fail
 cmp ecx,OFFSET {owner}
 jne fail
 cmp ebx,0x11223344
 jne fail
 cmp esi,0x55667788
 jne fail
 cmp edi,0x99aabbcc
 jne fail
 cmp ebp,0x12345678
 jne fail
 cmp esp,[saved_sp]
 jne fail
 cmp DWORD PTR [calls{n}],{expected_count}
 jne fail
''')
                case(1000,0,1,reset=True)
                # Dense updates: a short click and 399 ms of hold only count once.
                for t in range(1001,1400,7):
                    case(t,1,0)
                case(1400,1,1)
                case(1519,1,0)
                case(1520,1,1)
                case(1520,1,0)
                case(10000,1,1)  # No burst of missed repeats after a stall.
                case(10001,1,0)
                case(10002,0,1,reset=True) # Rapid release/repress stays immediate.
                case(10003,0,1,reset=True)
                case(10004,1,1,reset=True) # Existing release flag resets delay.
                case(10005,1,0)
                case(10006,1,1,delta=-1) # Opposite button gets a fresh delay.
                case(10007,1,0,delta=-1)
                case(10008,1,1,owner='other')
                case(10009,1,0,owner='other')
                case(10009,0,0,owner='other') # Custom events may clear repeat flag.
                case(0xffffff00,0,1,reset=True)
                case(0x8f,1,0)
                case(0x90,1,1)
                case(0x107,1,0)
                case(0x108,1,1)
            bodies=''
            for n,(_,body,saved_esi) in enumerate(m['sites']):
                bodies+=f'''.section .body{n},"ax"
 {'cmp esi,ecx' if saved_esi else 'cmp ecx,OFFSET root'}
 {'jne fail' if saved_esi else ''}
 inc DWORD PTR [calls{n}]
 {'pop esi' if saved_esi else ''}
 mov al,1
 ret 8
'''
            asm=f'''.intel_syntax noprefix
.code32
.global start
.section .main,"ax"
start:
 mov [saved_sp],esp
 {''.join(cases)}
 xor ebx,ebx
 mov eax,1
 int 0x80
fail:
 mov ebx,[step]
 mov eax,1
 int 0x80
{bodies}
.section .tick,"aw"
 .long mock_tick
.section .thunk,"awx"
thunk: .incbin "{d/'code.bin'}"
.section .data,"aw"
saved_sp: .long 0
step: .long 0
now: .long 0
calls0: .long 0
calls1: .long 0
event: .zero 0x88
root: .zero 0x1d60
other: .zero 0x1d60
.section .mock,"ax"
mock_tick:
 mov eax,[now]
 mov ecx,0xfeed
 mov edx,0xbeef
 ret
'''
            sections={'tick':m['tick'],'thunk':m['rva']}
            sections.update({f'body{n}':s[1] for n,s in enumerate(m['sites'])})
            layout='\n'.join(f'.{k} {base+v} : {{ *(.{k}) }}' for k,v in sorted(sections.items(),key=lambda x:x[1]))
            (d/'test.s').write_text(asm)
            (d/'test.ld').write_text(f'ENTRY(start)\nSECTIONS {{ .main {base+0x1000} : {{ *(.main) }}\n{layout}\n.data : {{ *(.data) }}\n.mock : {{ *(.mock) }} }}')
            subprocess.run(['as','--32','-o',str(d/'test.o'),str(d/'test.s')],check=True)
            subprocess.run(['ld','-m','elf_i386','-T',str(d/'test.ld'),'-o',str(d/'test'),str(d/'test.o')],check=True,capture_output=True)
            if not build_only:
                r=subprocess.run([str(d/'test')],timeout=10)
                assert r.returncode==0,(name,hex(base),r.returncode)
    print(name,'PASS',count*2,'native timing/ABI cases at two bases; existing sections preserved')

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build-only',action='store_true')
    args=parser.parse_args()
    for name in ('WLP','WLPADD1'):
        verify(name,args.build_only)
