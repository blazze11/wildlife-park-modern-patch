#!/usr/bin/env python3
"""Restore native F2 state palettes, objective font, and close image states."""
import json,struct,subprocess,tempfile
from pathlib import Path
import pefile
from patch_debug_tools import ROOT,digest,public,check_preservation
from patch_addon_widescreen import append_section,next_rva
VERSION='0.37.5'
def patch(data,name):
 old=next(x['patch'] for x in json.loads((ROOT/'analysis/f2-objective-fix-candidate-0.37.3.json').read_text()) if x['name']==name)
 pr=dict(old['profile']);p=pefile.PE(data=data);addon=name=='WLPADD1'
 for k,h,op in [('previous_ctor','ctor_call',0xe8),('previous_attach','attach_hook',0xe8),('previous_detach','detach_hook',0xe8),('previous_dtor','dtor',0xe9)]:
  raw=p.get_data(pr[h],5);assert raw[0]==op;pr[k]=pr[h]+5+struct.unpack('<i',raw[1:])[0]
 pr.update(state_update=(0x2677a0,0x295980)[addon],font=(0x8cfd18,0xa5f440)[addon],font_set=(0x1ea670,0x2181a0)[addon],frame_set=(0x15e8c0,0x188580)[addon])
 rv=next_rva(data);pic=old['size'];ready=pic+0x2ac;size=ready+4
 def call(k):return f'.byte 0xe8\n.long {pr[k]}-({rv}+.-_start+4)'
 def ptr(k):return f'[ebx+{rv}+{k}-_start]'
 fixes=[]
 for off in old['buttons']:
  fixes.append(f'lea edi,[esi+{off}]')
  for c in (0x5cc,0x5dc,0x5ec,0x5fc,0x60c,0x61c):
   rgb=0xffd740 if c==0x5ec else 0xffffff
   fixes.append(f'mov WORD PTR [edi+{c+4}],{rgb&65535}\nmov BYTE PTR [edi+{c+6}],{rgb>>16}')
  fixes.append('push 1\nmov ecx,edi\nmov eax,[ecx]\ncall DWORD PTR [eax+8]\nmov ecx,edi\ncall update')
 asm=f'''.intel_syntax noprefix
.code32
.global _start
_start:
get_base:
 call anchor
anchor:
 pop ebx
 sub ebx,{rv}+anchor-_start
 ret
constructor:
 push esi
 push DWORD PTR [esp+8]
 {call('previous_ctor')}
 mov esi,eax
 mov DWORD PTR [esi+{ready}],0
 push 1
 lea ecx,[esi+{pic}]
 {call('picture_ctor')}
 push esi
 lea ecx,[esi+{pic}]
 {call('generic_attach')}
 mov DWORD PTR [esi+{ready}],1
 mov eax,esi
 pop esi
 ret 4
attach:
 push esi
 mov esi,[esp+8]
 push esi
 {call('previous_attach')}
 pushfd
 pushad
 call get_base
 mov {ptr('owner')},esi
 # Replace only the four erroneous overrides and wrap the real state update.
 mov edi,[esi+0x5b8]
 lea eax,{ptr('update')}
 mov [edi],eax
 lea eax,[ebx+{pr['button_update']}]
 mov [edi+0x20],eax
 lea eax,{ptr('noop')}
 mov [edi+0x24],eax
 lea eax,[ebx+{pr['button_enter']}]
 mov [edi+0x60],eax
 lea eax,[ebx+{pr['button_leave']}]
 mov [edi+0x64],eax
 lea edi,[esi+{pic}]
 push 40
 push 40
 push 9
 push 464
 mov ecx,edi
 {call('bounds')}
 mov eax,[ebx+{pr['bank']}]
 mov eax,[eax+0xc]
 lea edx,[ebx+{pr['bank']}]
 add eax,edx
 mov [edi+0x298],eax
 mov DWORD PTR [edi+0x2a0],99
 mov DWORD PTR [edi+0x29c],0
 push 1
 mov ecx,edi
 {call('enabled')}
 mov ecx,[ebx+{pr['font']}]
 mov eax,[ecx+0x14]
 lea edx,[ebx+{pr['font']}]
 add eax,edx
 push eax
 lea ecx,[esi+{old['title']}]
 {call('font_set')}
 mov DWORD PTR [esi+{old['title']}+0x2cc],1
 {chr(10).join(fixes)}
 popad
 popfd
 pop esi
 ret 4
update:
 push ecx
 {call('state_update')}
 pop ecx
 pushfd
 pushad
 call get_base
 mov esi,{ptr('owner')}
 test esi,esi
 jz updated
 cmp DWORD PTR [esi+{ready}],1
 jne updated
 lea eax,[esi+0xbf0]
 cmp ecx,eax
 jne updated
 xor eax,eax
 test BYTE PTR [ecx+0x29c],2
 jz frame_ready
 mov eax,2
 test BYTE PTR [ecx+0x29c],1
 jz frame_ready
 mov eax,1
frame_ready:
 push eax
 lea ecx,[esi+{pic}]
 {call('frame_set')}
updated:
 popad
 popfd
 ret
noop:
 ret
detach:
 pushfd
 pushad
 lea esi,[ecx-0x1228]
 lea ecx,[esi+{pic}]
 {call('generic_detach')}
 popad
 popfd
 jmp _start+{pr['previous_detach']-rv}
destructor:
 pushfd
 pushad
 lea esi,[ecx-0x1620]
 cmp DWORD PTR [esi+{ready}],1
 jne destroyed
 mov DWORD PTR [esi+{ready}],0
 call get_base
 mov DWORD PTR {ptr('owner')},0
 lea ecx,[esi+{pic}]
 mov eax,[ecx+4]
 mov eax,[eax+4]
 lea ecx,[ecx+eax+4]
 mov eax,[ecx]
 push 0
 call DWORD PTR [eax]
destroyed:
 popad
 popfd
 jmp _start+{pr['previous_dtor']-rv}
.balign 4
owner: .long 0
'''
 with tempfile.TemporaryDirectory() as tmp:
  d=Path(tmp);(d/'fix.s').write_text(asm);subprocess.run(['as','--32','-o',str(d/'fix.o'),str(d/'fix.s')],check=True)
  assert 'R_386' not in subprocess.check_output(['objdump','-r',str(d/'fix.o')],text=True)
  subprocess.run(['objcopy','-O','binary','-j','.text',str(d/'fix.o'),str(d/'fix.bin')],check=True)
  code=(d/'fix.bin').read_bytes();sy={a[2]:int(a[0],16) for line in subprocess.check_output(['nm',str(d/'fix.o')],text=True).splitlines() if len(a:=line.split())==3}
 b=bytearray(data);changes=[]
 for key,label,op in [('ctor_call','constructor',0xe8),('attach_hook','attach',0xe8),('detach_hook','detach',0xe8),('dtor','destructor',0xe9)]:
  h=pr[key];off=p.get_offset_from_rva(h);b[off:off+5]=bytes([op])+struct.pack('<i',rv+sy[label]-h-5);changes.append((h,5))
 assert struct.unpack('<I',p.get_data(pr['alloc']+1,4))[0]==old['size']
 struct.pack_into('<I',b,p.get_offset_from_rva(pr['alloc']+1),size);changes.append((pr['alloc']+1,4))
 append_section(b,b'.wlpf2st',code);q=pefile.PE(data=b);struct.pack_into('<I',b,q.sections[-1].get_file_offset()+36,0xe0000020)
 m=dict(name=name,profile=pr,rva=rv,code=code,symbols=sy,picture=pic,ready=ready,size=size,title=old['title'],buttons=old['buttons'],changes=changes,reloc_offsets=[])
 check_preservation(data,b,m);return bytes(b),m
def build(name):
 f=ROOT/'builds/versions/0.37.4'/f'{name}.EXE';index=json.loads((ROOT/'builds/versions.json').read_text())
 expected=next(x['sha256'] for e in index['versions'] if e['version']=='0.37.4' for x in e['files'] if x['path'].endswith('/'+f.name))
 data=f.read_bytes();assert digest(data)==expected;return patch(data,name)
if __name__=='__main__':
 out=ROOT/'builds/versions'/VERSION;out.mkdir(exist_ok=True);records=[]
 for name in ('WLP','WLPADD1'):
  data,m=build(name);f=out/f'{name}.EXE'
  if f.exists():assert f.read_bytes()==data
  else:f.write_bytes(data)
  records.append(dict(name=name,sha256=digest(data),bytes=len(data),patch=public(m)))
 (ROOT/'analysis/f2-button-style-candidate.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps([{k:x[k] for k in ('name','sha256')} for x in records],indent=2))
