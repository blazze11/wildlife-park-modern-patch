#!/usr/bin/env python3
"""Execute the actual injected x86 code in a Linux ELF with mocked Win32 APIs.

This verifies assembly and ABI behavior, not the game's UI or Proton runtime.
"""
import argparse
import subprocess
import tempfile
from pathlib import Path
import pefile
from patch_default_save_name import patch


def verify(source, output, timestamp=False):
    original = source.read_bytes()
    rebuilt, meta = patch(original, timestamp=timestamp)
    assert rebuilt == output.read_bytes()
    p = pefile.PE(data=rebuilt)
    old = pefile.PE(data=original)
    off = old.get_offset_from_rva(meta['hook'])
    expected = bytearray(original)
    expected[off:off+5] = rebuilt[off:off+5]
    # New PE headers differ; every original section's payload stays intact
    # except the one replacement CALL in .text.
    for s in old.sections:
        start, size = s.PointerToRawData, s.SizeOfRawData
        assert rebuilt[start:start+size] == expected[start:start+size]
    for block in old.DIRECTORY_ENTRY_BASERELOC:
        for entry in block.entries:
            assert not entry.type or not meta['hook'] <= entry.rva < meta['hook']+5
    assert all(s.PointerToRawData+s.SizeOfRawData <= len(rebuilt) for s in p.sections)
    with tempfile.TemporaryDirectory() as tmp:
        d = Path(tmp)
        (d/'thunk.bin').write_bytes(meta['code'])
        cases = ((0, 2), (1, 2), (9, 2), (99, 2), (999, 2), (0, 5))
        if timestamp:
            cases = ((2026,10,0,11,14,35,8,123), (2027,1,0,1,0,0,0,0),
                     (2026,12,0,31,23,59,59,999), (2026,10,0,11,14,35,9,124))
        for base in (0x400000, 0x10000000):
            for case in cases:
                occupied, error = (0, 2) if timestamp else case
                if timestamp:
                    year, month, _, day, hour, minute, second, millisecond = case
                    name = f'Save_{year:04}_{month:02}_{day:02}_{hour:02}_{minute:02}_{second:02}'
                else:
                    name = 'Remembered' if error == 5 else f'Save({occupied+1})'
                api_keys = ('GetLastError','SetLastError','GetLocalTime' if timestamp else 'GetFileAttributesA')
                iat_start = min(meta['imports'][k] for k in api_keys) & ~0xfff
                iats = '\n'.join(f'.org {meta["imports"][k]-iat_start}\n.long {label}'
                                  for k, label in sorted((('GetLastError','get_error'),('SetLastError','set_error'),
                                                         (api_keys[2], 'local_time' if timestamp else 'attributes')),
                                                        key=lambda pair: meta['imports'][pair[0]]))
                time_mock = 'local_time:\n'
                if timestamp:
                    time_mock += ' mov eax, [esp+4]\n'
                    time_mock += '\n'.join(f' mov WORD PTR [eax+{i*2}], {value}' for i,value in enumerate(case))
                time_mock += '\n ret 4\n'
                asm = f'''.intel_syntax noprefix
.code32
.section .main,"ax"
.global start
start:
 mov DWORD PTR [saved_sp], esp
 mov ecx, 0x1234
 mov edx, 0x2222
 mov ebx, 0x3333
 mov ebp, 0x4444
 mov esi, 0x5555
 mov edi, 0x6666
 pushfd
 pop DWORD PTR [saved_flags]
 push OFFSET source_string
 call thunk
 pushfd
 pop DWORD PTR [result_flags]
 cmp eax, 0x5678
 jne fail
 cmp ecx, 0x1234
 jne fail
 cmp edx, 0x2222
 jne fail
 cmp ebx, 0x3333
 jne fail
 cmp ebp, 0x4444
 jne fail
 cmp esi, 0x5555
 jne fail
 cmp edi, 0x6666
 jne fail
 cmp esp, [saved_sp]
 jne fail
 mov eax, [result_flags]
 cmp eax, [saved_flags]
 jne fail
 cmp DWORD PTR [last_error], 1234
 jne fail
 cmp DWORD PTR [calls], {0 if timestamp else occupied+1}
 jne fail
 xor ebx, ebx
 jmp exit
fail:
 mov ebx, 1
exit:
 mov eax, 1
 int 0x80
get_error:
 mov eax, [last_error]
 ret
set_error:
 mov eax, [esp+4]
 mov [last_error], eax
 ret 4
attributes:
 inc DWORD PTR [calls]
 cmp DWORD PTR [calls], {occupied}
 jbe exists
 push esi
 push edi
 mov esi, [esp+12]
 mov edi, OFFSET expected_path
compare_path:
 mov al, [esi]
 cmp al, [edi]
 jne fail
 inc esi
 inc edi
 test al, al
 jne compare_path
 pop edi
 pop esi
 mov DWORD PTR [last_error], {error}
 mov eax, -1
 ret 4
exists:
 mov eax, 0x20
 ret 4
{time_mock}
.section .setter,"ax"
setter:
 cmp ecx, 0x1234
 jne fail
 push esi
 push edi
 mov eax, [esp+12]
 mov esi, [eax]
 mov edi, OFFSET expected_name
compare_name:
 mov dl, [esi]
 cmp dl, [edi]
 jne fail
 test dl, dl
 je end_name
 inc esi
 inc edi
 jmp compare_name
end_name:
 cmp esi, [eax+4]
 jne fail
 cmp esi, [eax+8]
 jae fail
 pop edi
 pop esi
 mov DWORD PTR [last_error], 5678
 mov edx, 0xbeef
 mov eax, 0x5678
 ret 4
.section .thunk,"ax"
thunk:
 .incbin "{d/'thunk.bin'}"
.section .iat,"aw"
{iats}
.section .data,"aw"
saved_sp: .long 0
saved_flags: .long 0
result_flags: .long 0
last_error: .long 1234
calls: .long 0
source_string: .long remembered, remembered_end, remembered_end+1
remembered: .ascii "Remembered"
remembered_end: .byte 0
expected_name: .asciz "{name}"
expected_path: .asciz "Save({occupied+1}).sav"
'''
                (d/'test.s').write_text(asm)
                (d/'test.ld').write_text(f'''ENTRY(start)
SECTIONS {{
 .main {base+0x1000} : {{ *(.main) }}
 .setter {base+meta['setter']} : {{ *(.setter) }}
 .iat {base+iat_start} : {{ *(.iat) }}
 .thunk {base+meta['rva']} : {{ *(.thunk) }}
 .data : {{ *(.data) }}
}}
''')
                subprocess.run(['as','--32','-o',str(d/'test.o'),str(d/'test.s')],check=True)
                subprocess.run(['ld','-m','elf_i386','-T',str(d/'test.ld'),'-o',str(d/'test'),str(d/'test.o')],
                               check=True, capture_output=True)
                result = subprocess.run([str(d/'test')], timeout=5)
                assert result.returncode == 0, (base, occupied, error, result.returncode)
    print(output.name, f'PASS: {len(cases)*2} actual x86 executions; formatting/ABI/relocated base; prior sections intact')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--timestamp', action='store_true')
    args = parser.parse_args()
    verify(args.source, args.output, timestamp=args.timestamp)
