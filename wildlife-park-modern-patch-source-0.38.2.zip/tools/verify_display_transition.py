#!/usr/bin/env python3
"""Run the emitted timing logger with native 32-bit Win32 API mocks."""
import json, subprocess, tempfile
from pathlib import Path
from workspace_paths import artifact
import pefile
from trace_display_transition import patch

for name in ('WLP','WLPADD1'):
 src=artifact(name+'_widescreen_zoom_steps.EXE').read_bytes();data,m=patch(src)
 assert data==artifact(name+'_display_transition_trace.EXE').read_bytes()
 p=pefile.PE(data=src)
 imports={i.name.decode():i.address-p.OPTIONAL_HEADER.ImageBase for d in p.DIRECTORY_ENTRY_IMPORT for i in d.imports if i.name}
 for base in (0x400000,0x14000000):
  with tempfile.TemporaryDirectory() as td:
   d=Path(td);(d/'blob').write_bytes(bytes.fromhex(m['code']))
   apis=['GetLastError','SetLastError','timeGetTime','GetCurrentThreadId','CreateFileA','WriteFile','CloseHandle']
   assignments='\n'.join(f'*(U *){base+imports[x]}u=(U)mock_{x};' for x in apis)
   c=f'''
typedef unsigned int U;
#define API __attribute__((stdcall))
static U last=77,fail,writes,closes,record[8];
U saved[9];
void quit(U code){{__asm__ volatile("int $0x80"::"a"(1),"b"(code));__builtin_unreachable();}}
#define CHECK(x) do{{if(!(x))quit(__LINE__);}}while(0)
U API mock_GetLastError(void){{return last;}}
void API mock_SetLastError(U x){{last=x;}}
U API mock_timeGetTime(void){{last=888;return 123456;}}
U API mock_GetCurrentThreadId(void){{return 0x1234;}}
U API mock_CreateFileA(char *f,U access,U sharing,U security,U disposition,U attrs,U template){{
 CHECK(access==4&&sharing==4&&!security&&disposition==4&&attrs==128&&!template);
 CHECK(f==(char *){base+m['symbols']['filename']}u);CHECK(f[0]=='C');return fail?0xffffffff:42;
}}
U API mock_WriteFile(U handle,U *buf,U size,U *written,U overlapped){{
 CHECK(handle==42&&size==32&&!overlapped);for(U i=0;i<8;i++)record[i]=buf[i];*written=32;writes++;return 1;
}}
U API mock_CloseHandle(U handle){{CHECK(handle==42);closes++;return 1;}}
extern void exercise(void);
void run(void){{
 {assignments}
 for(fail=0;fail<2;fail++){{exercise();CHECK(last==77);
  CHECK(saved[0]==0x11111111&&saved[1]==0x22222222&&saved[2]==0x33333333&&saved[3]==0x44444444);
  CHECK(saved[4]==0x55555555&&saved[5]==0x66666666&&saved[6]==0x77777777);
  CHECK(saved[7]==saved[8]);
 }}
 CHECK(writes==1&&closes==1);CHECK(record[0]==0x31544457&&record[1]==42&&record[2]==123456&&record[3]==0x1234);
 CHECK(record[4]==0x11111111&&record[5]==0x22222222&&record[6]==0x77777777&&record[7]==77);quit(0);
}}
'''
   a=f'''
.section .blob,"ax"
.incbin "{d/'blob'}"
.section .iat,"aw",@nobits
.space 0x5000
.text
.global _start
_start: call run
.global exercise
exercise:
pushfl
pushal
movl $0x11111111,%eax
movl $0x22222222,%ecx
movl $0x33333333,%edx
movl $0x44444444,%ebx
movl $0x55555555,%ebp
movl $0x66666666,%esi
movl $0x77777777,%edi
cld
stc
pushfl
popl saved+32
pushl $42
call logger_target
pushfl
popl saved+28
movl %eax,saved
movl %ecx,saved+4
movl %edx,saved+8
movl %ebx,saved+12
movl %ebp,saved+16
movl %esi,saved+20
movl %edi,saved+24
popal
popfl
ret
.set logger_target,{base+m['symbols']['logger']}
.section .note.GNU-stack,"",@progbits
'''
   (d/'test.c').write_text(c);(d/'test.s').write_text(a)
   subprocess.run(['gcc','-m32','-O2','-ffreestanding','-fno-pie','-fno-stack-protector','-c',str(d/'test.c'),'-o',str(d/'c.o')],check=True)
   subprocess.run(['as','--32',str(d/'test.s'),'-o',str(d/'a.o')],check=True)
   iat=min(imports[x] for x in apis)&~0xfff
   subprocess.run(['ld','-m','elf_i386','-e','_start','-Ttext=0x2000000',f'--section-start=.blob=0x{base+m["rva"]:x}',f'--section-start=.iat=0x{base+iat:x}',str(d/'a.o'),str(d/'c.o'),'-o',str(d/'test')],check=True)
   result=subprocess.run([str(d/'test')]);assert result.returncode==0,(name,hex(base),result.returncode)
   print(name,hex(base),'logger preserves registers, flags, stack and last error; success/failure paths passed')
