#!/usr/bin/env python3
"""Bottom-corner notification/debug HUD, retaining the existing feedback queue."""
import struct
import subprocess
import tempfile
from pathlib import Path
import pefile
from patch_addon_widescreen import append_section, next_rva
from patch_action_feedback import PROFILES as FEEDBACK_PROFILES, MESSAGES

PROFILES = {
    'WLP': dict(update=0x112834, draw_hook=0x1f2d67, draw=0x23e430,
                setter=0x1f2c40, visible=0x1ea340, bounds=0x1f5fc0,
                mode=0x33ac48, widths=0x33ac4c, heights=0x33ac5c, tps=0x33ac89,
                frame_hook=0x86eb, frame=0xe510, tick_hook=0x8143,
                text_guard=0x1f2ced, empty_string=0xcaf1e4, compare=0x5c5490),
    'WLPADD1': dict(update=0x124844, draw_hook=0x220e97, draw=0x26e300,
                    setter=0x220d80, visible=0x217e80, bounds=0x2241c0,
                    mode=0x36ddf8, widths=0x36ddfc, heights=0x36de0c, tps=0x36de35,
                    frame_hook=0x8583, frame=0xe190, tick_hook=0x7fe3,
                    text_guard=0x220e1d, empty_string=0xe3b4c4, compare=0x5f2e40),
}


def recover_feedback(pe):
    """Locate the old queue from its validated eight-message pointer table."""
    section = next(s for s in pe.sections if s.Name.rstrip(b'\0') == b'.wlpui')
    payload = pe.get_data(section.VirtualAddress, section.Misc_VirtualSize)
    offsets = [payload.index(s.encode('cp1252') + b'\0') for s in MESSAGES]
    table = b''.join(struct.pack('<I', n) for n in offsets)
    start = payload.index(table)
    assert start >= 16 and payload.count(table) == 1
    return dict(section_rva=section.VirtualAddress, messages=section.VirtualAddress + start,
                pending=section.VirtualAddress + start-16,
                active=section.VirtualAddress + start-12,
                started=section.VirtualAddress + start-8,
                owner=section.VirtualAddress + start-4)


def patch(src, tag):
    pe = pefile.PE(data=src)
    pr = dict(PROFILES[tag])
    assert struct.unpack('<4I', pe.get_data(pr['widths'],16)) == (1280,1280,1920,2560)
    assert struct.unpack('<4I', pe.get_data(pr['heights'],16)) == (720,800,1080,1440)
    # The native label bypasses the shared draw call for an empty string.
    # A space keeps that path active while the notification itself is blank.
    guard = bytes.fromhex('8dae1803000068') + struct.pack('<I',pr['empty_string']) + b'\x55\xe8'
    guard += struct.pack('<i',pr['compare']-(0x400000+pr['text_guard']+17))
    guard += bytes.fromhex('83c40885c00f848e000000')
    assert pe.get_data(pr['text_guard'],len(guard)) == guard
    old = recover_feedback(pe)
    pr['time'] = next(i.address-pe.OPTIONAL_HEADER.ImageBase
                      for d in pe.DIRECTORY_ENTRY_IMPORT for i in d.imports
                      if i.name == b'timeGetTime')
    rva = next_rva(src)
    draw_bytes = pe.get_data(pr['draw_hook'], 5)
    assert draw_bytes[0] == 0xe8
    draw_chain = pr['draw_hook'] + 5 + struct.unpack('<i', draw_bytes[1:])[0]
    assert any(s.Name.rstrip(b'\0') == b'.wlpkeys' and
               s.VirtualAddress <= draw_chain < s.VirtualAddress+s.Misc_VirtualSize
               for s in pe.sections)
    assert pe.get_data(pr['frame_hook'], 5) == b'\xe8'+struct.pack('<i',pr['frame']-pr['frame_hook']-5)
    assert pe.get_data(pr['tick_hook'], 6) == bytes.fromhex('8b46408b4e68')
    update_bytes = pe.get_data(pr['update'], 5)
    assert update_bytes[0] == 0xe9
    prior_update = pr['update']+5+struct.unpack('<i',update_bytes[1:])[0]
    assert old['section_rva'] <= prior_update < old['pending']

    def a(name): return f'[ebx+{rva}+{name}-entry]'
    def ext(name): return f'[ebx+{old[name]}]'
    def call(addr): return f'.byte 0xe8\n.long {addr}-({rva}+.-entry+4)'
    def jump(addr): return f'.byte 0xe9\n.long {addr}-({rva}+.-entry+4)'
    asm = f'''.intel_syntax noprefix
.code32
.global entry
entry:
get_base:
 call anchor
anchor:
 pop ebx
 sub ebx,{rva}+anchor-entry
 ret
tick_hook:
 pushfd
 pushad
 call get_base
 inc DWORD PTR {a('ticks')}
 call sample
 popad
 popfd
 mov eax,[esi+0x40]
 mov ecx,[esi+0x68]
 {jump(pr['tick_hook']+6)}
frame_hook:
 push DWORD PTR [esp+8]
 push DWORD PTR [esp+8]
 {call(pr['frame'])}
 pushfd
 pushad
 call get_base
 inc DWORD PTR {a('frames')}
 call sample
 popad
 popfd
 ret 8
sample:
 call DWORD PTR [ebx+{pr['time']}]
 cmp DWORD PTR {a('sample_ready')},0
 jne sample_existing
 mov DWORD PTR {a('sample_ready')},1
 mov DWORD PTR {a('sample_start')},eax
 mov DWORD PTR {a('frames')},0
 mov DWORD PTR {a('ticks')},0
 ret
sample_existing:
 mov ecx,eax
 sub eax,DWORD PTR {a('sample_start')}
 cmp eax,500
 jb sample_done
 mov DWORD PTR {a('sample_start')},ecx
 mov edi,eax
 mov ecx,DWORD PTR {a('frames')}
 test ecx,ecx
 je no_frame_time
 xor edx,edx
 div ecx
 mov DWORD PTR {a('frame_ms')},eax
 jmp frame_time_done
no_frame_time:
 mov DWORD PTR {a('frame_ms')},0
frame_time_done:
 imul eax,DWORD PTR {a('frames')},1000
 xor edx,edx
 div edi
 mov DWORD PTR {a('fps')},eax
 imul eax,DWORD PTR {a('ticks')},1000
 xor edx,edx
 div edi
 mov DWORD PTR {a('measured_tps')},eax
 mov DWORD PTR {a('frames')},0
 mov DWORD PTR {a('ticks')},0
sample_done:
 ret
update:
 pushfd
 pushad
 call get_base
 cmp DWORD PTR {ext('owner')},esi
 je owner_same
 mov DWORD PTR {ext('owner')},esi
 mov DWORD PTR {ext('active')},0
 mov DWORD PTR {a('last_width')},0
owner_same:
 lea ebp,[esi+0x620]
 mov ecx,[ebx+{pr['mode']}]
 cmp ecx,3
 jbe valid_mode
 xor ecx,ecx
valid_mode:
 mov eax,[ebx+{pr['widths']}+ecx*4]
 mov edx,[ebx+{pr['heights']}+ecx*4]
 mov DWORD PTR {a('screen_width')},eax
 mov DWORD PTR {a('screen_height')},edx
 mov ecx,100
 cmp DWORD PTR {a('console_visible')},0
 je chosen_height
 mov ecx,160
chosen_height:
 cmp DWORD PTR {a('last_width')},eax
 jne new_bounds
 cmp DWORD PTR {a('last_height')},edx
 jne new_bounds
 cmp DWORD PTR {a('last_strip')},ecx
 je bounds_done
new_bounds:
 mov DWORD PTR {a('last_width')},eax
 mov DWORD PTR {a('last_height')},edx
 mov DWORD PTR {a('last_strip')},ecx
 sub edx,ecx
 sub eax,20
 push ecx
 push eax
 push edx
 push 10
 mov ecx,ebp
 {call(pr['bounds'])}
bounds_done:
 mov eax,DWORD PTR {ext('pending')}
 test eax,eax
 je existing_message
 cmp eax,8
 ja clear_pending
 mov DWORD PTR {ext('pending')},0
 mov DWORD PTR {ext('active')},eax
 push eax
 call DWORD PTR [ebx+{pr['time']}]
 mov DWORD PTR {ext('started')},eax
 pop eax
 dec eax
 lea edx,{ext('messages')}
 mov eax,[edx+eax*4]
 add eax,ebx
 add eax,{old['section_rva']}
 push eax
 mov ecx,ebp
 {call(pr['setter'])}
 jmp visibility
clear_pending:
 mov DWORD PTR {ext('pending')},0
existing_message:
 cmp DWORD PTR {ext('active')},0
 je clear_text
 call DWORD PTR [ebx+{pr['time']}]
 sub eax,DWORD PTR {ext('started')}
 cmp eax,4000
 jb visibility
 mov DWORD PTR {ext('active')},0
clear_text:
 lea eax,{a('empty')}
 push eax
 mov ecx,ebp
 {call(pr['setter'])}
visibility:
 mov eax,DWORD PTR {ext('active')}
 or eax,DWORD PTR {a('flags')}
 or eax,DWORD PTR {a('console_visible')}
 setne al
 movzx eax,al
 push eax
 mov ecx,ebp
 {call(pr['visible'])}
 popad
 popfd
 {jump(pr['update']+45)}
draw_hook:
 pushfd
 pushad
 sub esp,64
 call get_base
 mov esi,[esp+88]
 mov eax,DWORD PTR {ext('owner')}
 test eax,eax
 je ordinary
 add eax,0x620
 cmp esi,eax
 jne ordinary
 # Preserve the shared label's style. Drawing uses a full bottom-strip clip.
 mov eax,[esi+0x28c]
 mov [esp+16],eax
 mov eax,[esi+0x2c8]
 mov [esp+20],eax
 mov eax,[esi+0x2cc]
 mov [esp+24],eax
 mov eax,[esi+0x2d0]
 mov [esp+28],eax
 mov DWORD PTR [esi+0x2c8],3
 mov DWORD PTR [esi+0x2cc],2
 mov eax,[esp+108]
 mov edi,24
 mov ebp,10
 call draw_line
 mov DWORD PTR [esi+0x28c],0x0000ff00
 and DWORD PTR [esi+0x2d0],0xffffffdf
 mov DWORD PTR [esi+0x2c8],2
 test DWORD PTR {a('flags')},1
 je skip_fps
 lea edi,{a('fps_buffer')}+5
 mov eax,DWORD PTR {a('fps')}
 call uint_text
 lea eax,{a('fps_buffer')}
 mov edi,72
 mov ebp,DWORD PTR {a('screen_width')}
 sub ebp,340
 call draw_line
skip_fps:
 test DWORD PTR {a('flags')},2
 je skip_tps
 lea edi,{a('tps_buffer')}+5
 mov eax,DWORD PTR {a('measured_tps')}
 call uint_text
 mov BYTE PTR [edi],' '
 mov BYTE PTR [edi+1],'/'
 mov BYTE PTR [edi+2],' '
 add edi,3
 movzx eax,BYTE PTR [ebx+{pr['tps']}]
 call uint_text
 lea eax,{a('tps_buffer')}
 mov edi,56
 mov ebp,DWORD PTR {a('screen_width')}
 sub ebp,340
 call draw_line
skip_tps:
 test DWORD PTR {a('flags')},4
 je skip_timing
 lea edi,{a('timing_buffer')}+7
 mov eax,DWORD PTR {a('frame_ms')}
 call uint_text
 mov DWORD PTR [edi],0x00736d20
 lea eax,{a('timing_buffer')}
 mov edi,40
 mov ebp,DWORD PTR {a('screen_width')}
 sub ebp,340
 call draw_line
skip_timing:
 cmp DWORD PTR {a('console_visible')},0
 je restore_style
 mov DWORD PTR [esi+0x2c8],3
 lea eax,{a('console_output')}
 mov edi,144
 mov ebp,10
 call draw_line
 lea eax,{a('prompt')}
 mov edi,112
 mov ebp,10
 call draw_line
 lea eax,{a('console_input')}
 mov edi,112
 mov ebp,26
 call draw_line
restore_style:
 mov eax,[esp+16]
 mov [esi+0x28c],eax
 mov eax,[esp+20]
 mov [esi+0x2c8],eax
 mov eax,[esp+24]
 mov [esi+0x2cc],eax
 mov eax,[esp+28]
 mov [esi+0x2d0],eax
 add esp,64
 popad
 popfd
 ret 8
ordinary:
 add esp,64
 popad
 popfd
 {jump(draw_chain)}
draw_line:
 # EAX text, EDI distance from bottom, EBP left. Private RECT keeps return safe.
 sub esp,16
 mov [esp],ebp
 mov edx,DWORD PTR {a('screen_height')}
 sub edx,edi
 mov [esp+12],edx
 sub edx,16
 mov [esp+4],edx
 mov ecx,DWORD PTR {a('screen_width')}
 sub ecx,10
 mov [esp+8],ecx
 mov edx,esp
 push eax
 push edx
 mov ecx,esi
 {call(pr['draw'])}
 add esp,16
 ret
uint_text:
 # Append decimal EAX to EDI, retaining EDI at terminating NUL.
 push ebp
 mov ebp,esp
 mov ecx,10
 xor edx,edx
uint_digit:
 xor edx,edx
 div ecx
 add edx,48
 push edx
 test eax,eax
 jne uint_digit
uint_copy:
 pop eax
 stosb
 cmp esp,ebp
 jne uint_copy
 mov BYTE PTR [edi],0
 pop ebp
 ret
.balign 4
flags: .long 0
console_visible: .long 0
sample_ready: .long 0
sample_start: .long 0
frames: .long 0
ticks: .long 0
fps: .long 0
measured_tps: .long 0
frame_ms: .long 0
last_width: .long 0
last_height: .long 0
last_strip: .long 0
screen_width: .long 1280
screen_height: .long 720
fps_buffer: .ascii "FPS: "
.zero 32
tps_buffer: .ascii "TPS: "
.zero 32
timing_buffer: .ascii "Frame: "
.zero 32
prompt: .asciz "> "
empty: .asciz " "
.balign 4
console_input: .zero 128
console_output: .zero 256
'''
    # lea requires a memory expression without adding outside its brackets.
    asm = asm.replace(a('fps_buffer')+'+5',f'[ebx+{rva}+fps_buffer-entry+5]')
    asm = asm.replace(a('tps_buffer')+'+5',f'[ebx+{rva}+tps_buffer-entry+5]')
    asm = asm.replace(a('timing_buffer')+'+7',f'[ebx+{rva}+timing_buffer-entry+7]')
    with tempfile.TemporaryDirectory() as tmp:
        d = Path(tmp)
        (d/'hud.s').write_text(asm)
        subprocess.run(['as','--32','-o',str(d/'hud.o'),str(d/'hud.s')],check=True)
        relocs = subprocess.check_output(['objdump','-r',str(d/'hud.o')],text=True)
        assert 'R_386' not in relocs,relocs
        subprocess.run(['objcopy','-O','binary','-j','.text',str(d/'hud.o'),str(d/'hud.bin')],check=True)
        code = (d/'hud.bin').read_bytes()
        symbols = {p[2]:int(p[0],16) for line in subprocess.check_output(['nm',str(d/'hud.o')],text=True).splitlines()
                   if len(p:=line.split())==3}
    result = bytearray(src)
    changes = []
    for hook, name, n, opcode in [(pr['update'],'update',5,0xe9),
                                  (pr['tick_hook'],'tick_hook',6,0xe9),
                                  (pr['frame_hook'],'frame_hook',5,0xe8),
                                  (pr['draw_hook'],'draw_hook',5,0xe8)]:
        off = pe.get_offset_from_rva(hook)
        result[off:off+n] = bytes([opcode])+struct.pack('<i',rva+symbols[name]-hook-5)+b'\x90'*(n-5)
        changes.append((hook,n))
    append_section(result,b'.wlphud',code)
    newpe = pefile.PE(data=result)
    struct.pack_into('<I',result,newpe.sections[-1].get_file_offset()+36,0xe0000020)
    metadata = dict(rva=rva,code=code,symbols=symbols,profile=pr,feedback=old,
                    changes=changes,reloc_offsets=[],draw_chain=draw_chain)
    for label in ['flags','console_visible','console_input','console_output']:
        metadata[label+'_rva'] = rva+symbols[label]
    metadata['console_line_rva'] = metadata['console_input_rva']
    return bytes(result),metadata
