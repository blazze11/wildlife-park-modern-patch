#!/usr/bin/env python3
"""Short black captions, persistent centered text, consistent button border."""
import json,struct,subprocess,tempfile
from pathlib import Path
import pefile
from patch_debug_tools import ROOT,digest,public,check_preservation
from patch_addon_widescreen import append_section,next_rva
VERSION='0.38.1'
LABELS={'Cheats einschalten':'Cheats: Aus','Cheats ausschalten':'Cheats: An','Wetter: Automatisch':'Wetter: Auto','Wetter: Schnee (Test)':'Wetter: Schnee','Wetter: Regen (Test)':'Wetter: Regen','Wetter: Aus (Test)':'Wetter: Aus','Landschaft wechseln':'Landschaft'}
def patch(data,name):
 old=next(x['patch'] for x in json.loads((ROOT/'analysis/f2-weather-buttons-candidate.json').read_text()) if x['name']==name)
 pr=dict(old['profile']);p=pefile.PE(data=data);h=pr['attach_hook'];raw=p.get_data(h,5);assert raw[0]==0xe8
 pr['previous_attach']=h+5+struct.unpack('<i',raw[1:])[0];pr['previous_update']=old['rva']+old['symbols']['update']
 rv=next_rva(data);buttons=old['buttons']
 def call(k):return f'.byte 0xe8\n.long {pr[k]}-({rv}+.-_start+4)'
 def ptr(k):return f'[ebx+{rv}+{k}-_start]'
 lookup='\n'.join(f'lea eax,[esi+{b}]\ncmp ecx,eax\nje found' for b in buttons)
 black='\n'.join(f'mov WORD PTR [ecx+{c+4}],0\nmov BYTE PTR [ecx+{c+6}],0' for c in (0x5cc,0x5dc,0x5ec,0x5fc,0x60c,0x61c))
 setup='\n'.join(f'lea ecx,[esi+{b}]\npush 1\nmov eax,[ecx]\ncall DWORD PTR [eax+8]\nlea ecx,[esi+{b}]\ncall update' for b in buttons)
 asm=f'''.intel_syntax noprefix
.code32
.global _start
_start:
get_base:
 call anchor
anchor:
 pop ebx
 sub ebx,{rv}+anchor-_start
 ret
attach:
 push esi
 mov esi,[esp+8]
 push esi
 {call('previous_attach')}
 pushfd
 pushad
 call get_base
 mov {ptr('owner')},esi
 mov edi,[esi+0x5b8]
 lea eax,{ptr('update')}
 mov [edi],eax
 {setup}
 popad
 popfd
 pop esi
 ret 4
find_button:
 mov esi,{ptr('owner')}
 test esi,esi
 jz missing
 {lookup}
missing:
 xor eax,eax
 ret
found:
 mov eax,1
 ret
update:
 push ecx
 pushfd
 pushad
 call get_base
 call find_button
 test eax,eax
 jz palette_done
 {black}
palette_done:
 popad
 popfd
 {call('previous_update')}
 pop ecx
 pushfd
 pushad
 call get_base
 call find_button
 test eax,eax
 jz centered
 # Reassert label geometry after native caption refresh/layout.
 lea edi,[ecx+0x2a0]
 push 28
 push 112
 push 0
 push 4
 mov ecx,edi
 {call('bounds')}
 mov DWORD PTR [edi+0x2c8],1
 mov DWORD PTR [edi+0x2cc],1
 mov WORD PTR [edi+0x28c],0
 mov BYTE PTR [edi+0x28e],0
 push 1
 mov ecx,edi
 mov eax,[ecx]
 call DWORD PTR [eax+8]
centered:
 popad
 popfd
 ret
.balign 4
owner: .long 0
'''
 with tempfile.TemporaryDirectory() as tmp:
  d=Path(tmp);(d/'fix.s').write_text(asm);subprocess.run(['as','--32','-o',str(d/'fix.o'),str(d/'fix.s')],check=True)
  assert 'R_386' not in subprocess.check_output(['objdump','-r',str(d/'fix.o')],text=True)
  subprocess.run(['objcopy','-O','binary','-j','.text',str(d/'fix.o'),str(d/'fix.bin')],check=True)
  code=(d/'fix.bin').read_bytes();sy={a[2]:int(a[0],16) for line in subprocess.check_output(['nm',str(d/'fix.o')],text=True).splitlines() if len(a:=line.split())==3}
 b=bytearray(data);changes=[]
 off=p.get_offset_from_rva(h);b[off:off+5]=b'\xe8'+struct.pack('<i',rv+sy['attach']-h-5);changes.append((h,5))
 label_records=[]
 for before,after in LABELS.items():
  raw=before.encode()+b'\0';assert data.count(raw)==1
  off=data.index(raw);encoded=after.encode()+b'\0';assert len(encoded)<=len(raw)
  b[off:off+len(raw)]=encoded.ljust(len(raw),b'\0');changes.append((p.get_rva_from_offset(off),len(raw)));label_records.append(dict(before=before,after=after,rva=p.get_rva_from_offset(off)))
 # Reuse the first button's working border on the weather picture. No assets edited.
 start=old['rva']+old['symbols']['attach'];end=old['rva']+old['symbols']['update']
 block=p.get_data(start,end-start);pic=old['pictures'][1]
 needle=b'\xc7\x86'+struct.pack('<I',pic+0x2a0)+struct.pack('<I',134)
 assert block.count(needle)==1
 at=start+block.index(needle)+6;struct.pack_into('<I',b,p.get_offset_from_rva(at),133);changes.append((at,4))
 append_section(b,b'.wlplabl',code);q=pefile.PE(data=b);struct.pack_into('<I',b,q.sections[-1].get_file_offset()+36,0xe0000020)
 m=dict(name=name,profile=pr,rva=rv,code=code,symbols=sy,buttons=buttons,pictures=old['pictures'],size=old['size'],changes=changes,reloc_offsets=[],labels=label_records)
 check_preservation(data,b,m);return bytes(b),m
def build(name):
 f=ROOT/'builds/versions/0.38.0'/f'{name}.EXE';index=json.loads((ROOT/'builds/versions.json').read_text())
 expected=next(x['sha256'] for e in index['versions'] if e['version']=='0.38.0' for x in e['files'] if x['path'].endswith('/'+f.name))
 data=f.read_bytes();assert digest(data)==expected;return patch(data,name)
if __name__=='__main__':
 out=ROOT/'builds/versions'/VERSION;out.mkdir(exist_ok=True);records=[]
 for name in ('WLP','WLPADD1'):
  data,m=build(name);f=out/f'{name}.EXE'
  if f.exists():assert f.read_bytes()==data
  else:f.write_bytes(data)
  records.append(dict(name=name,sha256=digest(data),bytes=len(data),patch=public(m)))
 (ROOT/'analysis/f2-button-labels-candidate.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps([{k:x[k] for k in ('name','sha256')} for x in records],indent=2))
