#!/usr/bin/env python3
"""Execute panel thunks with mocked engine methods; this is not a GUI test."""
import argparse
import struct
import subprocess
import tempfile
from pathlib import Path
import pefile
from patch_keybind_panel import patch, MARKER, asm_string


def verify(source, output):
    original = source.read_bytes()
    rebuilt, meta = patch(original)
    assert rebuilt == output.read_bytes()
    old = pefile.PE(data=original)
    expected = bytearray(original)
    for hook, name in meta['changes']:
        off = old.get_offset_from_rva(hook)
        expected[off:off+5] = rebuilt[off:off+5]
    for s in old.sections:
        start, size = s.PointerToRawData, s.SizeOfRawData
        assert rebuilt[start:start+size] == expected[start:start+size]
    for block in old.DIRECTORY_ENTRY_BASERELOC:
        for entry in block.entries:
            assert not entry.type or not any(h <= entry.rva < h+5 for h,_ in meta['changes'])
    p = pefile.PE(data=rebuilt)
    assert all(s.PointerToRawData+s.SizeOfRawData <= len(rebuilt) for s in p.sections)
    _,_,_,_,bounds,setter,draw = meta['profile']
    expected_rows = '\n'.join(f'.long {74+x}, {42+y}, {74+x+w}, {42+y+h}, text_{i}'
                              for i,(x,y,w,h,t) in enumerate(meta['descriptors']))
    text_rows = '\n'.join(asm_string(f'text_{i}', t)
                          for i,(*_,t) in enumerate(meta['descriptors']))
    with tempfile.TemporaryDirectory() as tmp:
        d = Path(tmp)
        (d/'thunk.bin').write_bytes(meta['code'])
        for base in (0x400000,0x10000000):
            syms = '\n'.join(f'.set {name}, thunk+{offset}' for name,offset in meta['symbols'].items()
                             if name in ('root_bounds','label_bounds','label_text','label_draw'))
            ordinary = '\n'.join(f'''mov DWORD PTR [normal], 1
 mov DWORD PTR [calls], 0
 mov ecx, 0x12345678
 push {text}
 push OFFSET rectangle
 call label_draw
 cmp DWORD PTR [calls], 1
 jne fail
 cmp esp, [saved_sp]
 jne fail''' for text in ('OFFSET other','0','OFFSET near_marker','OFFSET short_text','OFFSET empty'))
            wrapped = '\n'.join(f'''mov DWORD PTR [calls], 0
 mov ecx, 0x12345678
 push OFFSET {text}
 push OFFSET rectangle
 call label_draw
 cmp DWORD PTR [calls], {len(meta['descriptors'])}
 jne fail
 cmp esp, [saved_sp]
 jne fail''' for text in ('marker_crlf','marker_lf'))
            asm = f'''.intel_syntax noprefix
.code32
.section .main,"ax"
.global start
{syms}
start:
 mov [saved_sp], esp
 mov ecx, 0x12345678
 mov DWORD PTR [height], 500
 push 100
 push 300
 push 0
 push 0
 call root_bounds
 mov ecx, 0x12345678
 mov DWORD PTR [height], 475
 push 20
 push 270
 push 15
 push 10
 call label_bounds
 mov ecx, 0x12345678
 push OFFSET other
 call label_text
 mov ecx, 0x12345678
 mov ebx, 0x2222
 mov ebp, 0x3333
 mov esi, 0x4444
 mov edi, 0x5555
 mov edx, 0x6666
 pushfd
 pop DWORD PTR [flags]
 push OFFSET marker_copy
 push OFFSET rectangle
 call label_draw
 pushfd
 pop eax
 cmp eax, [flags]
 jne fail
 cmp ecx, 0x12345678
 jne fail
 cmp ebx, 0x2222
 jne fail
 cmp ebp, 0x3333
 jne fail
 cmp esi, 0x4444
 jne fail
 cmp edi, 0x5555
 jne fail
 cmp edx, 0x6666
 jne fail
 cmp DWORD PTR [calls], {len(meta['descriptors'])}
 jne fail
 cmp esp, [saved_sp]
 jne fail
{wrapped}
{ordinary}
 xor ebx, ebx
 jmp exit
fail:
 mov ebx, 1
exit:
 mov eax, 1
 int 0x80
.section .bounds,"ax"
 cmp ecx, 0x12345678
 jne fail
 mov eax, [esp+16]
 cmp eax, [height]
 jne fail
 ret 16
.section .setter,"ax"
 cmp ecx, 0x12345678
 jne fail
 mov eax, [esp+4]
 push esi
 push edi
 mov esi, eax
 mov edi, OFFSET marker_copy
setter_compare:
 mov al, [esi]
 cmp al, [edi]
 jne fail
 inc esi
 inc edi
 test al, al
 jne setter_compare
 pop edi
 pop esi
 ret 4
.section .draw,"ax"
 cmp ecx, 0x12345678
 jne fail
 inc DWORD PTR [calls]
 cmp DWORD PTR [normal], 1
 je normal_return
 push esi
 push edi
 mov eax, [calls]
 dec eax
 imul eax, eax, 20
 lea edi, [expected_rows+eax]
 mov esi, [esp+12]
 mov eax, [esi]
 cmp eax, [edi]
 jne fail
 mov eax, [esi+4]
 cmp eax, [edi+4]
 jne fail
 mov eax, [esi+8]
 cmp eax, [edi+8]
 jne fail
 mov eax, [esi+12]
 cmp eax, [edi+12]
 jne fail
 mov esi, [esp+16]
 mov edi, [edi+16]
compare_text:
 mov al, [esi]
 cmp al, [edi]
 jne fail
 inc esi
 inc edi
 test al, al
 jne compare_text
 pop edi
 pop esi
normal_return:
 mov eax, 0x9999
 mov edx, 0x8888
 mov ecx, 0x7777
 ret 8
.section .thunk,"ax"
thunk: .incbin "{d/'thunk.bin'}"
.section .data,"aw"
saved_sp: .long 0
height: .long 0
flags: .long 0
calls: .long 0
normal: .long 0
rectangle: .long 74,42,344,517
marker_copy: .asciz "{MARKER}"
marker_crlf: .asciz "{MARKER}\\r\\n"
marker_lf: .asciz "{MARKER}\\n"
near_marker: .asciz "WLP_KEY_TABLE_V2"
other: .asciz "Other game label"
short_text: .asciz "W"
empty: .byte 0
.balign 4
expected_rows:
{expected_rows}
{text_rows}
'''
            (d/'test.s').write_text(asm)
            (d/'test.ld').write_text(f'''ENTRY(start)
SECTIONS {{
 .main {base+0x1000} : {{ *(.main) }}
 .setter {base+setter} : {{ *(.setter) }}
 .bounds {base+bounds} : {{ *(.bounds) }}
 .draw {base+draw} : {{ *(.draw) }}
 .thunk {base+meta['rva']} : {{ *(.thunk) }}
 .data : {{ *(.data) }}
}}
''')
            subprocess.run(['as','--32','-o',str(d/'test.o'),str(d/'test.s')],check=True)
            subprocess.run(['ld','-m','elf_i386','-T',str(d/'test.ld'),'-o',str(d/'test'),str(d/'test.o')],check=True,capture_output=True)
            result = subprocess.run([str(d/'test')],timeout=5)
            assert result.returncode == 0, (hex(base),result.returncode)
    print(output.name,'PASS: actual x86 at two bases; 63 text draws, wrapped marker variants, five ordinary-label cases; bounds, stack, registers, flags, prior sections')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source',type=Path)
    parser.add_argument('output',type=Path)
    args = parser.parse_args()
    verify(args.source,args.output)
