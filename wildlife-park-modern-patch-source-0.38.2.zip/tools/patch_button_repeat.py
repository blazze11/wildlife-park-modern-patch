#!/usr/bin/env python3
"""Replace numeric control event counters with monotonic millisecond repeat timing."""
import argparse
import hashlib
import os
import shutil
import struct
import subprocess
import tempfile
from pathlib import Path
from workspace_paths import artifact, backup_path
import pefile
from patch_addon_widescreen import append_section, next_rva

PROFILES = {
 '2c3856a3e4e1495624fa09e82a2b6d380a8dd09ca0dfe6a0f72f042cbfcadd30':
     [(0x131f00, 0x131f58, True), (0x1490c0, 0x14910d, False)],
 '1f68512ba27af93ce23df69ab10bb8aede9a11b60a8e102671e23638b2673d39':
     [(0x146c60, 0x146cb0, True), (0x1706f0, 0x17073d, False)],
}

def patch(src):
    sites = PROFILES[hashlib.sha256(src).hexdigest()]
    p = pefile.PE(data=src)
    tick = next(i.address-0x400000 for d in p.DIRECTORY_ENTRY_IMPORT
                for i in d.imports if i.name == b'timeGetTime')
    rva = next_rva(src)
    asm = '.intel_syntax noprefix\n.code32\n.global _start\n_start:\n'
    for n, (hook, body, saved_esi) in enumerate(sites):
        state = f'[ebx+{rva}+state{n}-_start]'
        asm += f'''gate{n}:
 pushfd
 pushad
 call base
 lea ebp,{state}
 mov esi,[esp+24]
 mov edi,[esp+44]
 test edi,edi
 jz skip{n}
 call DWORD PTR [ebx+{tick}]
 mov edx,[edi+0x34]
 cmp BYTE PTR [esi+0x1d5c],0
 je first{n}
 cmp [ebp],esi
 jne first{n}
 cmp [ebp+4],edx
 jne first{n}
 mov ecx,eax
 sub ecx,[ebp+8]
 cmp ecx,[ebp+12]
 jb skip{n}
 mov DWORD PTR [ebp+12],120
 jmp allow{n}
first{n}:
 mov [ebp],esi
 mov [ebp+4],edx
 mov DWORD PTR [ebp+12],400
 mov BYTE PTR [esi+0x1d5d],0
allow{n}:
 mov [ebp+8],eax
 mov BYTE PTR [esi+0x1d5c],1
 popad
 popfd
 {'push esi' if saved_esi else ''}
 {'mov esi,ecx' if saved_esi else ''}
 jmp _start+{body-rva}
skip{n}:
 popad
 popfd
 mov al,1
 ret 8
'''
    asm += f'''base:
 call anchor
anchor:
 pop ebx
 sub ebx,{rva}+anchor-_start
 ret
 .balign 4
state0: .zero 16
state1: .zero 16
'''
    with tempfile.TemporaryDirectory() as tmp:
        d=Path(tmp)
        (d/'repeat.s').write_text(asm)
        subprocess.run(['as','--32','-o',str(d/'repeat.o'),str(d/'repeat.s')],check=True)
        assert 'R_386' not in subprocess.check_output(['objdump','-r',str(d/'repeat.o')],text=True)
        subprocess.run(['objcopy','-O','binary','-j','.text',str(d/'repeat.o'),str(d/'repeat.bin')],check=True)
        code=(d/'repeat.bin').read_bytes()
        symbols={a[2]:int(a[0],16) for line in subprocess.check_output(['nm',str(d/'repeat.o')],text=True).splitlines()
                 if len(a:=line.split())==3}
    b=bytearray(src)
    changes=[]
    for n,(hook,body,saved_esi) in enumerate(sites):
        original=p.get_data(hook,body-hook)
        assert original.startswith(b'\x8a\x15' if saved_esi else b'\xa0')
        assert b'\x5c\x1d\0\0' in original and b'\x5d\x1d\0\0' in original
        assert b'\xa8\x01' in original
        off=p.get_offset_from_rva(hook)
        b[off:off+len(original)] = b'\xe9'+struct.pack('<i',rva+symbols[f'gate{n}']-hook-5)+b'\x90'*(len(original)-5)
        changes.append((hook,len(original)))
    reloc_offsets=[]
    for block in p.DIRECTORY_ENTRY_BASERELOC:
        for entry in block.entries:
            if entry.type and any(h<=entry.rva<h+l for h,l in changes):
                off=entry.struct.get_file_offset()
                struct.pack_into('<H',b,off,struct.unpack_from('<H',b,off)[0]&0xfff)
                reloc_offsets.append(off)
    append_section(b,b'.wlprept',code)
    np=pefile.PE(data=b)
    struct.pack_into('<I',b,np.sections[-1].get_file_offset()+36,0xe0000020)
    return bytes(b),dict(rva=rva,code=code,symbols=symbols,sites=sites,tick=tick,
                         changes=changes,reloc_offsets=reloc_offsets)

if __name__ == '__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--install',action='store_true')
    args=parser.parse_args()
    for name in ('WLP','WLPADD1'):
        src=artifact(f'{name}_widescreen_feedback.EXE').read_bytes()
        out,m=patch(src)
        path=artifact(f'{name}_widescreen_button_repeat.EXE')
        path.write_bytes(out)
        print(path,hashlib.sha256(out).hexdigest(),len(m['reloc_offsets']))
        if args.install:
            root=Path('/path/to/Wildlife Park Gold/Int/Win32/Program/VC6')
            target=root/f'{name}.EXE'
            assert target.read_bytes()==src, f'{target} has unexpected changes'
            backup=backup_path(target.with_name(target.name+'.pre-button-repeat.bak'))
            if backup.exists():
                assert backup.read_bytes()==src
            else:
                shutil.copy2(target,backup)
            staged=target.with_name(target.name+'.button-repeat.tmp')
            staged.write_bytes(out)
            staged.chmod(target.stat().st_mode)
            os.replace(staged,target)
            assert target.read_bytes()==out
            print('Installed',target,'backup',backup.name)
