#!/usr/bin/env python3
"""Build version 0.34.0 on the accepted theme-only 0.33.0 binaries."""
import argparse,json
from patch_debug_tools import ROOT,digest,public,check_preservation
from launcher_switch import patch
VERSION='0.34.0'
BASELINE={
 'WLP':'16e4c15fd38b57f2e5e301d430360fb02f4c94c0f1a4c61a214e9835c83cad17',
 'WLPADD1':'6807805d97586eec2fb204aa14b09513fa015e4c7c0fc6c0baddfc915f4e7181',
}
def build(name):
    source=(ROOT/'builds/versions/0.33.0'/f'{name}.EXE').read_bytes()
    assert digest(source)==BASELINE[name]
    result,metadata=patch(source,name)
    check_preservation(source,result,metadata)
    return result,metadata
if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--verify',action='store_true')
    args=ap.parse_args(); out=ROOT/'builds/versions'/VERSION
    out.mkdir(exist_ok=True);records=[];checks=[]
    for name in BASELINE:
        result,m=build(name)
        if args.verify:
            from verify_launcher_switch import verify
            verify(m)
            for base in (0x400000,0x14000000):
                checks.append(dict(name=name,image_base=hex(base),passed=True,
                    sha256=digest(result),emittedcode_sha256=digest(m['code']),
                    scope='Native mocks: button lifecycle, submenu visibility, path construction, process API arguments, failure guards, native quit, ABI'))
        target=out/f'{name}.EXE'
        if target.exists(): assert target.read_bytes()==result,'Immutable snapshot differs'
        else: target.write_bytes(result)
        records.append(dict(name=name,source_sha256=BASELINE[name],sha256=digest(result),bytes=len(result),patch=public(m)))
    (ROOT/'analysis/launcher-switch-candidate.json').write_text(json.dumps(records,indent=2)+'\n')
    if args.verify: (ROOT/'analysis/launcher-switch-verification.json').write_text(json.dumps(checks,indent=2)+'\n')
    print(json.dumps([dict(name=r['name'],sha256=r['sha256'],bytes=r['bytes']) for r in records],indent=2))
