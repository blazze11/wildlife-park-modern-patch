#!/usr/bin/env python3
"""Run label correction hooks after simulated native refresh and state changes."""
import json,subprocess,tempfile
from pathlib import Path
from f2_button_labels import ROOT,build
from patch_debug_tools import digest

def verify(m):
 for base in (0x400000,0x14000000):
  pr=m['profile'];s=m['symbols'];rv=m['rva'];checks=[];seed=[]
  for b in m['buttons']:
   seed.append(f'mov DWORD PTR [root+{b}],OFFSET table\nmov DWORD PTR [root+{b}+0x2a0],OFFSET label_table')
   for c in (0x5cc,0x5dc,0x5ec,0x5fc,0x60c,0x61c):seed.append(f'mov DWORD PTR [root+{b+c+4}],0xffffff')
   for bits in (0,2,3,2,0,0):
    checks.append(f'mov ecx,OFFSET root+{b}\nmov BYTE PTR [ecx+0x29c],{bits}\nmov eax,[ecx]\ncall DWORD PTR [eax]')
    for c in (0x5cc,0x5dc,0x5ec,0x5fc,0x60c,0x61c):checks.append(f'cmp WORD PTR [root+{b+c+4}],0\njne fail\ncmp BYTE PTR [root+{b+c+6}],0\njne fail')
    for field,value in ((0x40,4),(0x44,0),(0x48,112),(0x4c,28),(0x2c8,1),(0x2cc,1)):
     checks.append(f'cmp DWORD PTR [root+{b+0x2a0+field}],{value}\njne fail')
    checks.append(f'cmp WORD PTR [root+{b}+0x52c],0\njne fail\ncmp BYTE PTR [root+{b}+0x52e],0\njne fail')
  asm=f'''.intel_syntax noprefix
.code32
.global start
.section .main,"ax"
start:
 mov [saved_sp],esp
 mov ecx,OFFSET root+0xbf0
 push OFFSET root
 call thunk+{s['attach']}
 {chr(10).join(checks)}
 # Non-action state refresh stays chained but untouched by label corrections.
 mov ecx,OFFSET root+0xbf0
 call thunk+{s['update']}
 cmp DWORD PTR [close_calls],1
 jne fail
 cmp DWORD PTR [updates],22
 jne fail
 cmp esp,[saved_sp]
 jne fail
 xor ebx,ebx
 mov eax,1
 int 0x80
fail:
 mov ebx,1
 mov eax,1
 int 0x80
invalidate:
 ret 4
.section .previous_attach,"ax"
 {chr(10).join(seed)}
 mov DWORD PTR [root+0xbf0],OFFSET table
 ret 4
.section .previous_update,"ax"
 inc DWORD PTR [updates]
 cmp ecx,OFFSET root+0xbf0
 jne action
 inc DWORD PTR [close_calls]
 ret
action:
 lea edx,[ecx+0x5d0]
 test BYTE PTR [ecx+0x29c],2
 jz palette
 lea edx,[ecx+0x5f0]
 test BYTE PTR [ecx+0x29c],1
 jz palette
 lea edx,[ecx+0x600]
palette:
 mov ax,[edx]
 mov [ecx+0x52c],ax
 mov al,[edx+2]
 mov [ecx+0x52e],al
 # Native caption refresh may reset geometry; wrapper must repair it afterwards.
 mov DWORD PTR [ecx+0x2a0+0x44],10
 mov DWORD PTR [ecx+0x2a0+0x4c],34
 ret
.section .bounds,"ax"
 mov eax,[esp+4]
 mov [ecx+0x40],eax
 mov eax,[esp+8]
 mov [ecx+0x44],eax
 mov eax,[esp+12]
 mov [ecx+0x48],eax
 mov eax,[esp+16]
 mov [ecx+0x4c],eax
 ret 16
.section .thunk,"axw"
thunk: .incbin "CODEPATH"
.section .mockdata,"aw"
saved_sp: .long 0
updates: .long 0
close_calls: .long 0
table: .long 0,0,invalidate
.zero 116
label_table: .long 0,0,invalidate
root: .zero {m['size']}
'''
  sec=dict(previous_attach=pr['previous_attach'],previous_update=pr['previous_update'],bounds=pr['bounds'],thunk=rv)
  with tempfile.TemporaryDirectory() as tmp:
   d=Path(tmp);(d/'code.bin').write_bytes(m['code']);(d/'test.s').write_text(asm.replace('CODEPATH',str(d/'code.bin')))
   layout='\n'.join(f'.{k} {base+x} : {{ *(.{k}) }}' for k,x in sorted(sec.items(),key=lambda x:x[1]))
   (d/'test.ld').write_text(f'ENTRY(start)\nSECTIONS {{ .main {base+0x1000} : {{ *(.main) }}\n{layout}\n.mockdata {base+rv+0x10000} : {{ *(.mockdata) }} }}')
   subprocess.run(['as','--32','-o',str(d/'test.o'),str(d/'test.s')],check=True)
   subprocess.run(['ld','-m','elf_i386','-T',str(d/'test.ld'),'-o',str(d/'test'),str(d/'test.o')],check=True,capture_output=True)
   r=subprocess.run([str(d/'test')],timeout=10);assert r.returncode==0,(m['name'],hex(base),r.returncode)
 print('PASS '+m['name']+': repeated black palette/foreground, centered inset after layout resets, preserved close chain and stack; two bases')
if __name__=='__main__':
 records=[]
 for name in ('WLP','WLPADD1'):
  data,m=build(name);verify(m);records.append(dict(name=name,passed=True,sha256=digest(data),code_sha256=digest(m['code']),image_bases=['0x400000','0x14000000']))
 (ROOT/'analysis/f2-button-labels-verification.json').write_text(json.dumps(records,indent=2)+'\n')
