#!/usr/bin/env python3
"""Convert approved snow artwork into a looping native RGB565 ALB animation."""
import argparse
import hashlib
import json
import os
import shutil
import struct
from pathlib import Path
from workspace_paths import artifact, backup_path

import numpy as np
from PIL import Image
from scipy.ndimage import find_objects, label

from expand_weather import encode, rows, replace_container, verify_container

EXPECTED = '24a838141af33ab921c9ded23605124faae790f14389befff2438cb36a5fe377'
WIDTH, HEIGHT, FRAMES = 2560, 1440, 10
SEED = 20261011


def digest(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def particles(artwork):
    # Discard faint generator background noise while retaining shaded flake edges.
    source = np.asarray(Image.open(artwork).convert('L'))
    labels, _ = label(source >= 24, np.ones((3, 3)))
    rng = np.random.default_rng(SEED)
    result = []
    for ident, bounds in enumerate(find_objects(labels), 1):
        mask = labels[bounds] == ident
        if mask.sum() < 2 or source[bounds][mask].max() < 72:
            continue
        sprite = np.where(mask, source[bounds], 0).astype('uint8')
        sh = max(1, round(sprite.shape[0] * HEIGHT / source.shape[0]))
        sw = max(1, round(sprite.shape[1] * WIDTH / source.shape[1]))
        sprite = np.asarray(Image.fromarray(sprite).resize((sw, sh), Image.Resampling.NEAREST))
        phase = int(rng.integers(FRAMES))
        velocity = int(rng.integers(12, 21))
        drift = int(rng.integers(-2, 3))
        x = round(bounds[1].start * WIDTH / source.shape[1]) - phase * drift
        y = round(bounds[0].start * HEIGHT / source.shape[0]) - phase * velocity
        sy, sx = np.nonzero(sprite)
        result.append((x, y, phase, velocity, drift, sx, sy, sprite[sy, sx]))
    return result


def render(particles, frame):
    # Staggered ten-frame lifetimes avoid a whole-field jump at the loop seam.
    # Each particle fades before respawning on its short downward trajectory.
    fade = [0, .5, 1, 1, 1, 1, 1, 1, 1, .5]
    canvas = np.zeros((HEIGHT, WIDTH), dtype='uint8')
    for x, y, phase, velocity, drift, sx, sy, values in particles:
        age = (frame + phase) % FRAMES
        brightness = np.rint(values * fade[age]).astype('uint8')
        xx = (x + age * drift + sx) % WIDTH
        yy = (y + age * velocity + sy) % HEIGHT
        np.maximum.at(canvas, (yy, xx), brightness)
    value = canvas.astype('uint16')
    return ((value >> 3) << 11) | ((value >> 2) << 5) | (value >> 3)


def sparse(pixels):
    result = []
    for row in pixels:
        occupied = row != 0
        edges = np.diff(np.r_[False, occupied, False].astype('int8'))
        starts = np.flatnonzero(edges == 1)
        ends = np.flatnonzero(edges == -1)
        result.append([(int(a), row[a:b].astype('<u2').tobytes()) for a, b in zip(starts, ends)])
    payload = encode(result, WIDTH)
    assert rows(payload, WIDTH, HEIGHT) == result
    return payload


def preview(pixels):
    rgb = np.stack((((pixels >> 11) & 31) * 255 // 31,
                    ((pixels >> 5) & 63) * 255 // 63,
                    (pixels & 31) * 255 // 31), axis=2).astype('uint8')
    return Image.fromarray(rgb)


def build(source, animation):
    _, count, _, _, table, size = struct.unpack_from('<HHIIII', source)
    offsets = struct.unpack_from(f'<{size // 4}I', source, table)
    output = bytearray(source[:offsets[0]])
    new_offsets = [len(output)]
    frame = 0
    unchanged = 0
    for entry in range(count):
        nf, w, h = struct.unpack_from('<HHH', source, 255 + entry * 64)
        if entry == 6:
            assert (nf, w, h) == (FRAMES, WIDTH, HEIGHT)
        for local in range(nf):
            old = source[offsets[frame]:offsets[frame + 1]]
            payload = animation[local] if entry == 6 else old
            output.extend(payload)
            new_offsets.append(len(output))
            if entry != 6:
                assert payload == old
                unchanged += 1
            frame += 1
    assert frame == len(offsets) - 1
    struct.pack_into(f'<{len(new_offsets)}I', output, table, *new_offsets)
    return bytes(output), unchanged


def atomic_copy(source, destination):
    staged = destination.with_name(destination.name + '.snow-revision.tmp')
    assert not staged.exists()
    shutil.copyfile(source, staged)
    os.chmod(staged, destination.stat().st_mode & 0o777)
    with staged.open('rb') as f:
        os.fsync(f.fileno())
    os.replace(staged, destination)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('artwork', type=Path)
    parser.add_argument('--container', type=Path, default=artifact('Pictures.cont'), help='Previous container, SHA256 checked')
    parser.add_argument('--container-output', type=Path, default=artifact('Pictures_snow_revised.cont'))
    parser.add_argument('--install', type=Path, help='Installed Pictures.cont to back up and atomically replace')
    args = parser.parse_args()
    directory = Path('analysis/weather')
    original_alb = artifact('Misc_weather_2560.alb').read_bytes()
    flakes = particles(args.artwork)
    images = [render(flakes, i) for i in range(FRAMES)]
    assert np.array_equal(render(flakes, FRAMES), images[0]), 'Animation must loop exactly'
    payloads = [sparse(frame) for frame in images]
    revised, unchanged = build(original_alb, payloads)
    alb_path = artifact('Misc_snow_revised_2560.alb')
    alb_path.write_bytes(revised)
    preview_path = directory / 'snow_revised_2560_preview.png'
    preview(images[0]).save(preview_path)
    gif_path = directory / 'snow_revised_animation.gif'
    previews = [preview(frame).resize((1280, 720), Image.Resampling.NEAREST) for frame in images]
    previews[0].save(gif_path, save_all=True, append_images=previews[1:], duration=100, loop=0)
    original_cont = args.container
    assert digest(original_cont) == EXPECTED
    candidate = args.container_output
    replace_container(original_cont, revised, candidate, expected_original=original_alb)
    verified = verify_container(original_cont, candidate, revised)
    report = dict(artwork=str(args.artwork.resolve()), artwork_sha256=digest(args.artwork),
                  particles=len(flakes), seed=SEED, width=WIDTH, height=HEIGHT, frames=FRAMES,
                  unchanged_alb_frames=unchanged, unchanged_container_members=verified,
                  previous_container_sha256=EXPECTED, container_sha256=digest(candidate),
                  alb_sha256=digest(alb_path), container_bytes=candidate.stat().st_size,
                  frame_pixels=[int(np.count_nonzero(frame)) for frame in images],
                  frame0_pixels_per_80px_column=[int(np.count_nonzero(images[0][:, x:x+80])) for x in range(0, WIDTH, 80)],
                  preview=str(preview_path.resolve()), animation_preview=str(gif_path.resolve()))
    if args.install:
        assert digest(args.install) == EXPECTED
        backup = backup_path(args.install.with_name(args.install.name + '.pre-snow-revision.bak'))
        assert not backup.exists()
        with backup.open('xb') as out, args.install.open('rb') as src:
            shutil.copyfileobj(src, out, 1024 * 1024)
        assert digest(backup) == EXPECTED
        assert digest(args.install) == EXPECTED
        atomic_copy(candidate, args.install)
        assert digest(args.install) == report['container_sha256']
        workspace_cont = artifact('Pictures.cont')
        assert digest(workspace_cont) == EXPECTED
        atomic_copy(candidate, workspace_cont)
        report.update(installed=str(args.install.resolve()), backup=str(backup.resolve()))
    (directory / 'snow-revision.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
