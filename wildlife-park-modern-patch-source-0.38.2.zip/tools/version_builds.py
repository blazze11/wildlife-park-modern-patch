#!/usr/bin/env python3
"""Organize existing snapshots by workspace version; preserve executable names."""
import hashlib,json,shutil
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
index=ROOT/'builds/versions.json'
assert not index.exists(),'Version index already exists'
def digest(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
versions=[];moves=[];aliases={};hash_versions={}
def move(src,dst,version):
 dst.parent.mkdir(parents=True,exist_ok=True);assert not dst.exists()
 sha=digest(src);size=src.stat().st_size;shutil.move(str(src),str(dst));assert digest(dst)==sha
 aliases[str(src)]=str(dst)
 moves.append(dict(source=str(src),destination=str(dst),sha256=sha,bytes=size,version=version))
 return dict(path=str(dst.relative_to(ROOT)),sha256=sha,bytes=size)

for version,title,names in [('0.0.0-original','Original distribution references',['WLP_T.EXE','WLPADD1_original.EXE']),('0.0.0-windowed-reference','Earlier user-modified windowed reference',['WLP_.EXE'])]:
 entries=[]
 for name in names:
  src=ROOT/'builds/originals'/name;canonical='WLPADD1.EXE' if name.startswith('WLPADD1') else 'WLP.EXE'
  entry=move(src,ROOT/'builds/versions'/version/canonical,version);entries.append(entry);hash_versions.setdefault(entry['sha256'],version)
 versions.append(dict(version=version,description=title,status='reference',files=entries))

groups={}
for src in (ROOT/'builds/archive').glob('*.EXE'):
 name=src.name
 stage=name.split('_',1)[1][:-4] if '_' in name else 'legacy-build'
 groups.setdefault(stage,[]).append(src)
ordered=sorted(groups,key=lambda stage:(min(p.stat().st_mtime for p in groups[stage]),stage))
for minor,stage in enumerate(ordered,1):
 version=f'0.{minor}.0';entries=[]
 for src in sorted(groups[stage]):
  canonical='WLPADD1.EXE' if src.name.startswith('WLPADD1') else 'WLP.EXE'
  sidecar=Path(str(src)+'.json')
  entries.append(move(src,ROOT/'builds/versions'/version/canonical,version))
  hash_versions.setdefault(entries[-1]['sha256'],version)
  if sidecar.exists():move(sidecar,ROOT/'builds/versions'/version/(canonical+'.json'),version)
 status='historical'
 if 'diagnostic' in stage or 'trace' in stage:status='diagnostic'
 elif 'zoom_steps' in stage or 'mouse_background' in stage:status='reverted experiment'
 versions.append(dict(version=version,description=stage.replace('_',' '),status=status,files=entries))

# The final release pairs the unchanged base game with the latest expansion.
current_version=next(v['version'] for v in versions if v['description']=='widescreen zoom limit')
current=next(v for v in versions if v['version']==current_version);current['status']='current'
current['description']='Original zoom restored; Wild Creatures overview capped at 50%; all other accepted fixes retained'
for src in (ROOT/'builds/current').glob('*.EXE'):
 dst=ROOT/'builds/versions'/current_version/src.name
 if dst.exists():assert src.read_bytes()==dst.read_bytes()
 else:
  shutil.copy2(src,dst);current['files'].append(dict(path=str(dst.relative_to(ROOT)),sha256=digest(dst),bytes=dst.stat().st_size))
(ROOT/'builds/current/VERSION').write_text(current_version+'\n')

unknown=0
for src in sorted((ROOT/'archive/game-backups').rglob('*.EXE*.bak')):
 sha=digest(src);version=hash_versions.get(sha)
 if version is None:
  unknown+=1;version=f'0.0.0-backup.{unknown}';hash_versions[sha]=version
  versions.append(dict(version=version,description='Backup-only historical snapshot; feature identity not reconstructed',status='historical backup',files=[]))
 rel=src.relative_to(ROOT/'archive/game-backups')
 canonical,tag=src.name.split('.EXE',1);canonical+='.EXE'
 tag=tag.removesuffix('.bak').lstrip('.')
 dst=ROOT/'archive/game-backups'/version/tag/rel.parent/canonical
 entry=move(src,dst,version)
 # Keep every duplicate backup and its provenance; no deduplication/deletion.
 aliases[str(Path('/path/to/Wildlife Park Gold')/rel)]=str(dst)

cleanup=ROOT/'analysis/workspace-cleanup.json';report=json.loads(cleanup.read_text())
for r in report['moves']:
 if r['destination'] in aliases:aliases[r['source']]=aliases[r['destination']]
index.write_text(json.dumps(dict(scheme='Semantic versions for our patch snapshots, not publisher game versions. Historical IDs assigned retrospectively; 0.x indicates this evolving patch project.',current=current_version,versions=versions,aliases=aliases,moves=moves),indent=2)+'\n')

for p in [ROOT/'CHANGE_SUMMARY.md',*(ROOT/'analysis').glob('*.md')]:
 text=p.read_text()
 for old,new in sorted(aliases.items(),key=lambda x:len(x[0]),reverse=True):text=text.replace(old,new)
 p.write_text(text)
inv=ROOT/'analysis/edited-files-inventory.json';doc=json.loads(inv.read_text())
def remap(value):
 if isinstance(value,str):return aliases.get(value,value)
 if isinstance(value,list):return [remap(x) for x in value]
 if isinstance(value,dict):return {k:remap(v) for k,v in value.items()}
 return value
doc=remap(doc);doc['version_index']=str(index);inv.write_text(json.dumps(doc,indent=2)+'\n')
lines=['# Executable versions','',f'Current patch version: **{current_version}**.','',
       'These versions identify our patch snapshots; they are not the publisher\'s game version numbers. Historical snapshots received retrospective 0.x version IDs. Executable filenames always remain WLP.EXE and WLPADD1.EXE.','',
       '| Version | Status | Changes / snapshot |','| --- | --- | --- |']
for v in versions:lines.append(f'| {v["version"]} | {v["status"]} | {v["description"]} |')
lines+=['','See versions.json for exact hashes, file paths and historical filename aliases. Some historical versions contain only one game. Current contains both; the base executable is unchanged from the weather-menu build.']
(ROOT/'builds/README.md').write_text('\n'.join(lines)+'\n')
print(json.dumps(dict(current=current_version,versions=len(versions),moved_files=len(moves)),indent=2))
