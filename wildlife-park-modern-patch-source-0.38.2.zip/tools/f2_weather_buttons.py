#!/usr/bin/env python3
"""Add three unscaled native weather-menu picture skins to existing F2 actions."""
import json,struct,subprocess,tempfile
from pathlib import Path
import pefile
from patch_debug_tools import ROOT,digest,public,check_preservation
from patch_addon_widescreen import append_section,next_rva
VERSION='0.38.0'
def patch(data,name):
 old=next(x['patch'] for x in json.loads((ROOT/'analysis/f2-button-style-candidate.json').read_text()) if x['name']==name)
 pr=dict(old['profile']);p=pefile.PE(data=data)
 for k,h,op in [('previous_ctor','ctor_call',0xe8),('previous_attach','attach_hook',0xe8),('previous_detach','detach_hook',0xe8),('previous_dtor','dtor',0xe9)]:
  raw=p.get_data(pr[h],5);assert raw[0]==op;pr[k]=pr[h]+5+struct.unpack('<i',raw[1:])[0]
 pr['previous_update']=old['rva']+old['symbols']['update']
 oldsize=struct.unpack('<I',p.get_data(pr['alloc']+1,4))[0];assert oldsize==old['size']
 pics=[oldsize+i*0x2ac for i in range(3)];ready=oldsize+3*0x2ac;size=ready+4;rv=next_rva(data);buttons=[0x5b8,0x1624,0x1c60]
 def call(k):return f'.byte 0xe8\n.long {pr[k]}-({rv}+.-_start+4)'
 def ptr(k):return f'[ebx+{rv}+{k}-_start]'
 ctor='\n'.join(f'push 1\nlea ecx,[esi+{pic}]\n{call("picture_ctor")}\npush esi\nlea ecx,[esi+{pic}]\n{call("generic_attach")}' for pic in pics)
 detach='\n'.join(f'lea ecx,[esi+{pic}]\n{call("generic_detach")}' for pic in pics)
 dispose='\n'.join(f'lea ecx,[esi+{pic}]\ncall dispose' for pic in reversed(pics))
 setup=[];lookup=[]
 for i,(b,pic) in enumerate(zip(buttons,pics)):
  y=52+42*i;entry=134 if i==1 else 133
  for off in (pic,b):setup.append(f'push 34\npush 120\npush {y}\npush 183\nlea ecx,[esi+{off}]\n{call("bounds")}')
  setup.append(f'''mov eax,[ebx+{pr['bank']}]
 mov eax,[eax+0xc]
 lea edx,[ebx+{pr['bank']}]
 add eax,edx
 mov [esi+{pic}+0x298],eax
 mov DWORD PTR [esi+{pic}+0x2a0],{entry}
 mov DWORD PTR [esi+{pic}+0x29c],0
 push 1
 lea ecx,[esi+{pic}]
 {call('enabled')}
 push 34
 push 120
 push 0
 push 0
 lea ecx,[esi+{b}+0x2a0]
 {call('bounds')}
 mov DWORD PTR [esi+{b}+0x2a0+0x2c8],1
 mov DWORD PTR [esi+{b}+0x2a0+0x2cc],1
 lea ecx,[esi+{b}]
 call update''')
  lookup.append(f'lea eax,[esi+{b}]\ncmp ecx,eax\nje state_{i}')
 states='\n'.join(f'state_{i}:\nlea edi,[esi+{pic}]\njmp set_state' for i,pic in enumerate(pics))
 asm=f'''.intel_syntax noprefix
.code32
.global _start
_start:
get_base:
 call anchor
anchor:
 pop ebx
 sub ebx,{rv}+anchor-_start
 ret
constructor:
 push esi
 push DWORD PTR [esp+8]
 {call('previous_ctor')}
 mov esi,eax
 mov DWORD PTR [esi+{ready}],0
 {ctor}
 mov DWORD PTR [esi+{ready}],1
 mov eax,esi
 pop esi
 ret 4
attach:
 push esi
 mov esi,[esp+8]
 push esi
 {call('previous_attach')}
 pushfd
 pushad
 call get_base
 mov {ptr('owner')},esi
 mov edi,[esi+0x5b8]
 lea eax,{ptr('update')}
 mov [edi],eax
 {chr(10).join(setup)}
 popad
 popfd
 pop esi
 ret 4
update:
 push ecx
 {call('previous_update')}
 pop ecx
 pushfd
 pushad
 call get_base
 mov esi,{ptr('owner')}
 test esi,esi
 jz updated
 cmp DWORD PTR [esi+{ready}],1
 jne updated
 {chr(10).join(lookup)}
 jmp updated
 {states}
set_state:
 xor eax,eax
 test BYTE PTR [ecx+0x29c],2
 jz frame_ready
 mov eax,2
 test BYTE PTR [ecx+0x29c],1
 jz frame_ready
 mov eax,1
frame_ready:
 push eax
 mov ecx,edi
 {call('frame_set')}
updated:
 popad
 popfd
 ret
detach:
 pushfd
 pushad
 lea esi,[ecx-0x1228]
 {detach}
 popad
 popfd
 jmp _start+{pr['previous_detach']-rv}
destructor:
 pushfd
 pushad
 lea esi,[ecx-0x1620]
 cmp DWORD PTR [esi+{ready}],1
 jne destroyed
 mov DWORD PTR [esi+{ready}],0
 call get_base
 mov DWORD PTR {ptr('owner')},0
 {dispose}
destroyed:
 popad
 popfd
 jmp _start+{pr['previous_dtor']-rv}
dispose:
 mov eax,[ecx+4]
 mov eax,[eax+4]
 lea ecx,[ecx+eax+4]
 mov eax,[ecx]
 push 0
 call DWORD PTR [eax]
 ret
.balign 4
owner: .long 0
'''
 with tempfile.TemporaryDirectory() as tmp:
  d=Path(tmp);(d/'skin.s').write_text(asm);subprocess.run(['as','--32','-o',str(d/'skin.o'),str(d/'skin.s')],check=True)
  assert 'R_386' not in subprocess.check_output(['objdump','-r',str(d/'skin.o')],text=True)
  subprocess.run(['objcopy','-O','binary','-j','.text',str(d/'skin.o'),str(d/'skin.bin')],check=True)
  code=(d/'skin.bin').read_bytes();sy={a[2]:int(a[0],16) for line in subprocess.check_output(['nm',str(d/'skin.o')],text=True).splitlines() if len(a:=line.split())==3}
 b=bytearray(data);changes=[]
 for key,label,op in [('ctor_call','constructor',0xe8),('attach_hook','attach',0xe8),('detach_hook','detach',0xe8),('dtor','destructor',0xe9)]:
  h=pr[key];off=p.get_offset_from_rva(h);b[off:off+5]=bytes([op])+struct.pack('<i',rv+sy[label]-h-5);changes.append((h,5))
 struct.pack_into('<I',b,p.get_offset_from_rva(pr['alloc']+1),size);changes.append((pr['alloc']+1,4))
 append_section(b,b'.wlpwbtn',code);q=pefile.PE(data=b);struct.pack_into('<I',b,q.sections[-1].get_file_offset()+36,0xe0000020)
 m=dict(name=name,profile=pr,rva=rv,code=code,symbols=sy,pictures=pics,ready=ready,size=size,buttons=buttons,changes=changes,reloc_offsets=[])
 check_preservation(data,b,m);return bytes(b),m
def build(name):
 f=ROOT/'builds/versions/0.37.6'/f'{name}.EXE';index=json.loads((ROOT/'builds/versions.json').read_text())
 expected=next(x['sha256'] for e in index['versions'] if e['version']=='0.37.6' for x in e['files'] if x['path'].endswith('/'+f.name))
 data=f.read_bytes();assert digest(data)==expected;return patch(data,name)
if __name__=='__main__':
 out=ROOT/'builds/versions'/VERSION;out.mkdir(exist_ok=True);records=[]
 for name in ('WLP','WLPADD1'):
  data,m=build(name);f=out/f'{name}.EXE'
  if f.exists():assert f.read_bytes()==data
  else:f.write_bytes(data)
  records.append(dict(name=name,sha256=digest(data),bytes=len(data),patch=public(m)))
 (ROOT/'analysis/f2-weather-buttons-candidate.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps([{k:x[k] for k in ('name','sha256')} for x in records],indent=2))
