#!/usr/bin/env python3
"""Build v6 from verified v5: four widescreen choices and matching menu labels."""
import argparse
import hashlib
import struct
from pathlib import Path
import pefile

V5 = 'e70fe4cc2fcf47f505ae4550c4d71b936faef8330026aef1993cca5a8f6528bb'
MODES = ((1280, 720), (1280, 800), (1920, 1080), (2560, 1440))
OLD = ((800, 600), (1024, 768), (1280, 1024), (2560, 1440))
GROUPS = ((32, 0x8a2d98, 85), (24, 0x8a3308, 70),
          (15, 0x8a3850, 40), (16, 0x8a3d00, 55), (8, 0x8a4248, 25))
LABEL_CALLS = ((0x14434f, 0), (0x144374, 2), (0x144399, 1), (0x1443be, 3))

def align(n, a):
    return (n + a - 1) // a * a

def patch(src):
    if hashlib.sha256(src).hexdigest() != V5:
        raise ValueError('Requires verified WLP_2560x1440_v5.EXE')
    p = pefile.PE(data=src)
    b = bytearray(src)
    assert struct.unpack_from('<4I', b, 0x33ac4c) == tuple(w for w, h in OLD)
    assert struct.unpack_from('<4I', b, 0x33ac5c) == tuple(h for w, h in OLD)
    struct.pack_into('<4I', b, 0x33ac4c, *(w for w, h in MODES))
    struct.pack_into('<4I', b, 0x33ac5c, *(h for w, h in MODES))

    # Every depth has fixed descriptors whose indices refer to the abstract table.
    slots = {}
    for depth, last, last_index in GROUPS:
        found = set()
        for off in range(last - 14 * 80, last + 1, 80):
            w, h, d = struct.unpack_from('<III', b, off)
            if (w + 1, h + 1) not in OLD:
                continue
            assert d == depth
            choice = OLD.index((w + 1, h + 1))
            found.add(choice)
            nw, nh = MODES[choice]
            struct.pack_into('<II', b, off, nw - 1, nh - 1)
            slots[last_index - (last - off) // 80] = (nw, nh)
        assert found == set(range(4))
    assert len(slots) == 20

    last = p.sections[-1]
    rva = align(last.VirtualAddress + max(last.Misc_VirtualSize, last.SizeOfRawData),
                p.OPTIONAL_HEADER.SectionAlignment)
    raw = align(len(b), p.OPTIONAL_HEADER.FileAlignment)
    code = bytearray()
    # Rewrite the stack table immediately before its indexed lookup. MOV does
    # not affect flags, registers, or stack depth; preserve the displaced MOV.
    hook = 0x27f324
    original = bytes.fromhex('8b942420040000')
    assert b[hook:hook + 7] == original
    for index, (w, h) in sorted(slots.items()):
        for delta, value in ((0, w), (4, h)):
            code += bytes.fromhex('c78424') + struct.pack('<II', 0x10 + index * 12 + delta, value)
    code += original
    code += b'\xe9' + struct.pack('<i', hook + 7 - (rva + len(code) + 5))
    b[hook:hook + 7] = b'\xe9' + struct.pack('<i', rva - (hook + 5)) + b'\x90\x90'

    # Return ASCII labels through position-independent, register-safe thunks.
    for call, choice in LABEL_CALLS:
        assert b[call] == 0xe8
        assert call + 5 + struct.unpack_from('<i', b, call + 1)[0] == 0x1e91f0
        target = rva + len(code)
        code += bytes.fromhex('e8000000005883c005c3')
        # The CALL pushes target+5; string starts at target+10, so add five.
        w, h = MODES[choice]
        code += f'{w}x{h}'.encode('ascii') + b'\0'
        b[call:call + 5] = b'\xe8' + struct.pack('<i', target - (call + 5))

    # Include 1920-wide modes in the bounded DirectDraw enumeration filter.
    mode_section = next(s for s in p.sections if s.Name.rstrip(b'\0') == b'.wlpmode')
    filt = mode_section.PointerToRawData + 4 + 6 * 9 + 3
    assert struct.unpack_from('<I', b, filt)[0] == 1600
    struct.pack_into('<I', b, filt, 1920)

    header = p.sections[0].get_file_offset() + 40 * p.FILE_HEADER.NumberOfSections
    assert header + 40 <= p.OPTIONAL_HEADER.SizeOfHeaders and not any(b[header:header + 40])
    size = align(len(code), p.OPTIONAL_HEADER.FileAlignment)
    b[header:header + 40] = struct.pack('<8sIIIIIIHHI', b'.wlpwide', len(code), rva, size, raw, 0, 0, 0, 0, 0x60000020)
    struct.pack_into('<H', b, p.FILE_HEADER.get_field_absolute_offset('NumberOfSections'), p.FILE_HEADER.NumberOfSections + 1)
    struct.pack_into('<I', b, p.OPTIONAL_HEADER.get_field_absolute_offset('SizeOfImage'), align(rva + len(code), p.OPTIONAL_HEADER.SectionAlignment))
    struct.pack_into('<I', b, p.OPTIONAL_HEADER.get_field_absolute_offset('SizeOfCode'), p.OPTIONAL_HEADER.SizeOfCode + size)
    struct.pack_into('<I', b, p.OPTIONAL_HEADER.get_field_absolute_offset('CheckSum'), 0)
    b += bytes(raw - len(b)) + code + bytes(size - len(code))
    return bytes(b)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    result = patch(args.input.read_bytes())
    with args.output.open('xb') as f:
        f.write(result)
    print(hashlib.sha256(result).hexdigest())
