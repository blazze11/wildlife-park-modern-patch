#!/usr/bin/env python3
"""Replace cheat entry with a toggle and show timed German action feedback."""
import argparse
import hashlib
import struct
import subprocess
import tempfile
from pathlib import Path
import pefile
from patch_addon_widescreen import append_section, next_rva
from patch_keybind_panel import asm_string

PROFILES = {
 'd49d3b8f8fdb2fd3c05a4bb3ebb8aedceb093b7c65971ac539eadf94562c88e0': dict(
  flag=0x8af1d5, update=0x112834, setter=0x1f2c40, visible=0x1ea340,
  caption=0x267de0, bounds=0x1f5fc0, close=0x1ea980,
  toggle=0x108910, cancel=0x108b10, input_attach=0x10875b,
  focus_event=0x108873, button_bounds=0x108770, button_caption=0x108791,
  close_caption=0x1087fc, status_bounds=0x110bb7,
  save_hook=0x8fe5, save=0x6530, load_hook=0x8ad9, load=0x66a0,
  shot_hook=0x11bcd7, shot=0x27d450),
 '9e1d68e5c61915f0b012d9ce16cc24b2db43e45067f88ff60409a3282a452691': dict(
  flag=0xa3b49e, update=0x124844, setter=0x220d80, visible=0x217e80,
  caption=0x295fc0, bounds=0x2241c0, close=0x2184b0,
  toggle=0x11a080, cancel=0x11a280, input_attach=0x119ecb,
  focus_event=0x119fe3, button_bounds=0x119ee0, button_caption=0x119f01,
  close_caption=0x119f6c, status_bounds=0x1229f3,
  save_hook=0x8c63, save=0x6430, load_hook=0x8869, load=0x6580,
  shot_hook=0x12e6a7, shot=0x2ab040),
}
MESSAGES = ['Cheats eingeschaltet', 'Cheats ausgeschaltet',
            'Park gespeichert', 'Park geladen', 'Bildschirmfoto gespeichert',
            'Speichern fehlgeschlagen', 'Laden fehlgeschlagen',
            'Bildschirmfoto fehlgeschlagen']


def patch(src):
    profile = dict(PROFILES[hashlib.sha256(src).hexdigest()])
    p = pefile.PE(data=src)
    profile['tick'] = next(i.address-0x400000 for d in p.DIRECTORY_ENTRY_IMPORT
                           for i in d.imports if i.name == b'timeGetTime')
    rva=next_rva(src)
    def call(name):
        return f'.byte 0xe8\n .long {profile[name]}-({rva}+.-_start+4)'
    def address(name):
        return f'[ebx+{rva}+{name}-_start]'
    # A callable helper, rather than an inline call/pop, preserves caller flow.
    base=f'''get_base:
 call base_anchor
base_anchor:
 pop ebx
 sub ebx, {rva}+base_anchor-_start
 ret
'''
    wrappers=[]
    for kind,success,failure in [('save',3,6),('load',4,7),('shot',5,8)]:
        copy = ('push DWORD PTR [esp+24]\n'*6 if kind=='shot'
                else 'push DWORD PTR [esp+4]\n')
        cleanup = 'lea esp,[esp+24]\n' if kind=='shot' else ''
        result = ('cmp DWORD PTR [esp+28],1' if kind=='shot'
                  else 'cmp BYTE PTR [esp+28],0')
        branch = 'jne' if kind=='shot' else 'je'
        wrappers.append(f'''{kind}_feedback:
 {copy}
 {call(kind)}
 {cleanup}
 pushfd
 pushad
 call get_base
 mov edx,{success}
 {result}
 {branch} {kind}_failed
 jmp {kind}_queue
{kind}_failed:
 mov edx,{failure}
{kind}_queue:
 mov DWORD PTR {address('pending')},edx
 popad
 popfd
 {'ret' if kind=='shot' else 'ret 4'}
''')
    asm=f'''.intel_syntax noprefix
.code32
.global _start
_start:
{base}
toggle:
 pushfd
 pushad
 call get_base
 cmp BYTE PTR [ebx+{profile['flag']}],0
 sete al
 mov BYTE PTR [ebx+{profile['flag']}],al
 mov edx,2
 test al,al
 je toggle_queue
 mov edx,1
toggle_queue:
 mov DWORD PTR {address('pending')},edx
 mov ecx,[esp+24]
 add ecx,0x5b8
 call refresh_caption
 popad
 popfd
 mov al,1
 ret 8
close_panel:
 {call('close')}
 mov al,1
 ret 8
button_caption:
 pushfd
 pushad
 call get_base
 mov ecx,[esp+24]
 call refresh_caption
 popad
 popfd
 ret 4
refresh_caption:
 lea eax,{address('enable_text')}
 cmp BYTE PTR [ebx+{profile['flag']}],0
 je caption_ready
 lea eax,{address('disable_text')}
caption_ready:
 push eax
 {call('caption')}
 ret
close_caption:
 pushfd
 push eax
 call close_anchor
close_anchor:
 pop eax
 add eax,close_text-close_anchor
 mov [esp+12],eax
 pop eax
 popfd
 jmp _start+{profile['caption']-rva}
button_bounds:
 mov DWORD PTR [esp+8],35
 mov DWORD PTR [esp+12],270
 jmp _start+{profile['bounds']-rva}
status_bounds:
 mov DWORD PTR [esp+12],400
 mov DWORD PTR [esp+16],20
 jmp _start+{profile['bounds']-rva}
update:
 pushfd
 pushad
 call get_base
 # ESI is the live gameplay GUI root; never save it across file operations.
 cmp DWORD PTR {address('owner')},esi
 je same_owner
 mov DWORD PTR {address('owner')},esi
 mov DWORD PTR {address('active')},0
same_owner:
 lea edi,[esi+0x620]
 mov eax,DWORD PTR {address('pending')}
 test eax,eax
 je existing
 mov DWORD PTR {address('pending')},0
 mov DWORD PTR {address('active')},eax
 push eax
 call DWORD PTR [ebx+{profile['tick']}]
 mov DWORD PTR {address('started')},eax
 pop eax
 dec eax
 lea edx,{address('messages')}
 mov eax,[edx+eax*4]
 add eax,ebx
 add eax,{rva}
 push eax
 mov ecx,edi
 {call('setter')}
 push 1
 mov ecx,edi
 {call('visible')}
 jmp update_done
existing:
 cmp DWORD PTR {address('active')},0
 je clear_label
 call DWORD PTR [ebx+{profile['tick']}]
 sub eax,DWORD PTR {address('started')}
 cmp eax,4000
 jb update_done
 mov DWORD PTR {address('active')},0
clear_label:
 lea eax,{address('empty_text')}
 push eax
 mov ecx,edi
 {call('setter')}
 push 0
 mov ecx,edi
 {call('visible')}
update_done:
 popad
 popfd
 jmp _start+{profile['update']+45-rva}
{''.join(wrappers)}
.balign 4
pending: .long 0
active: .long 0
started: .long 0
owner: .long 0
messages:
{chr(10).join(f'.long message_{i}-_start' for i in range(len(MESSAGES)))}
{chr(10).join(asm_string(f'message_{i}',text) for i,text in enumerate(MESSAGES))}
{asm_string('enable_text','Cheats einschalten')}
{asm_string('disable_text','Cheats ausschalten')}
{asm_string('close_text','Schließen')}
empty_text: .byte 0
'''
    with tempfile.TemporaryDirectory() as tmp:
        d=Path(tmp)
        (d/'feedback.s').write_text(asm)
        subprocess.run(['as','--32','-o',str(d/'feedback.o'),str(d/'feedback.s')],check=True)
        relocs=subprocess.check_output(['objdump','-r',str(d/'feedback.o')],text=True)
        assert 'R_386' not in relocs,relocs
        subprocess.run(['objcopy','-O','binary','-j','.text',str(d/'feedback.o'),str(d/'feedback.bin')],check=True)
        code=(d/'feedback.bin').read_bytes()
        symbols={a[2]:int(a[0],16) for line in subprocess.check_output(['nm',str(d/'feedback.o')],text=True).splitlines()
                 if len(a:=line.split())==3}
    b=bytearray(src)
    changes=[]
    def replace(hook,expected,replacement):
        off=p.get_offset_from_rva(hook)
        assert b[off:off+len(expected)]==expected,hex(hook)
        assert len(expected)==len(replacement)
        b[off:off+len(expected)]=replacement
        changes.append((hook,len(expected)))
    def redirect(hook,name,expected):
        replace(hook,expected,b'\xe9'+struct.pack('<i',rva+symbols[name]-hook-5)+b'\x90'*(len(expected)-5))
    def redirect_call(hook,name,target):
        replace(hook,b'\xe8'+struct.pack('<i',target-hook-5),
                b'\xe8'+struct.pack('<i',rva+symbols[name]-hook-5))
    redirect(profile['toggle'],'toggle',p.get_data(profile['toggle'],7))
    assert p.get_data(profile['toggle'],3)==bytes.fromhex('6aff68')
    redirect(profile['cancel'],'close_panel',b'\xc6\x05'+struct.pack('<I',0x400000+profile['flag'])+b'\0')
    original_update=p.get_data(profile['update'],45)
    assert original_update[:5]==b'\xa0'+struct.pack('<I',0x400000+profile['flag'])
    redirect(profile['update'],'update',original_update)
    for field,symbol,target in [('button_bounds','button_bounds','bounds'),
                               ('status_bounds','status_bounds','bounds'),
                               ('button_caption','button_caption','caption'),
                               ('close_caption','close_caption','caption'),
                               ('save_hook','save_feedback','save'),
                               ('load_hook','load_feedback','load'),
                               ('shot_hook','shot_feedback','shot')]:
        redirect_call(profile[field],symbol,profile[target])
    for name in ('input_attach','focus_event'):
        hook=profile[name]
        original=p.get_data(hook,5)
        assert original[0]==0xe8
        replace(hook,original,bytes.fromhex('83c4049090'))
    # The existing table heading has fixed room: change only its string bytes.
    section=next(s for s in p.sections if s.Name.rstrip(b'\0')==b'.wlpkeys')
    raw=section.PointerToRawData
    heading=src.find(b'Cheat-Code:\0',raw,raw+section.SizeOfRawData)
    assert heading!=-1
    hook=p.get_rva_from_offset(heading)
    replace(hook,b'Cheat-Code:\0',b'Cheats\0'+b'\0'*5)
    reloc_offsets=[]
    for block in p.DIRECTORY_ENTRY_BASERELOC:
        for entry in block.entries:
            if entry.type and any(h<=entry.rva<h+n for h,n in changes):
                off=entry.struct.get_file_offset()
                value=struct.unpack_from('<H',b,off)[0]
                struct.pack_into('<H',b,off,value&0xfff)
                reloc_offsets.append(off)
    assert len(reloc_offsets)==5,reloc_offsets
    append_section(b,b'.wlpui',code)
    newp=pefile.PE(data=b)
    struct.pack_into('<I',b,newp.sections[-1].get_file_offset()+36,0xe0000020)
    return bytes(b),dict(rva=rva,code=code,symbols=symbols,profile=profile,
                        changes=changes,reloc_offsets=reloc_offsets,messages=MESSAGES)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input',type=Path)
    parser.add_argument('output',type=Path)
    args=parser.parse_args()
    out,_=patch(args.input.read_bytes())
    with args.output.open('xb') as f:
        f.write(out)
    print(args.output,hashlib.sha256(out).hexdigest())
