#!/usr/bin/env python3
"""Install the verified calendar candidate, with exact baseline backups."""
import hashlib
import json
import os
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parents[1]
GAME = Path('/path/to/Wildlife Park Gold/Int/Win32/Program/VC6')
VERSION = '0.30.1'

def digest(data):
    return hashlib.sha256(data).hexdigest()

if __name__ == '__main__':
    records = json.loads((ROOT/'analysis/tps-calendar-candidate.json').read_text())
    checks = json.loads((ROOT/'analysis/tps-calendar-verification.json').read_text())
    assert {(x['name'],x['image_base']) for x in checks} == {
        (name,base) for name in ('WLP','WLPADD1') for base in ('0x400000','0x14000000')}
    plan = []
    for record in records:
        name = record['name']+'.EXE'
        source = (ROOT/'builds/versions/0.30.0'/name).read_bytes()
        candidate = (ROOT/'builds/versions'/VERSION/name).read_bytes()
        target = GAME/name
        assert digest(source) == record['source_sha256']
        assert digest(candidate) == record['sha256']
        assert target.read_bytes() == source, 'Installed game differs from verified baseline'
        assert (ROOT/'builds/current'/name).read_bytes() == source
        backup = ROOT/'archive/game-backups/0.30.0/pre-tps-calendar'/name
        if backup.exists():
            assert backup.read_bytes() == source
        plan.append((target,backup,source,candidate))
    installed = []
    try:
        for target,backup,source,candidate in plan:
            backup.parent.mkdir(parents=True,exist_ok=True)
            if not backup.exists():
                backup.write_bytes(source)
            stage = target.with_name(target.name+'.tps-calendar.tmp')
            stage.write_bytes(candidate)
            stage.chmod(target.stat().st_mode)
            assert target.read_bytes() == source
            os.replace(stage,target)
            installed.append((target,source))
            assert target.read_bytes() == candidate
    except Exception:
        for target,source in reversed(installed):
            stage = target.with_name(target.name+'.tps-calendar-rollback.tmp')
            stage.write_bytes(source)
            stage.chmod(target.stat().st_mode)
            os.replace(stage,target)
        raise
    for target,backup,source,candidate in plan:
        shutil.copy2(target,ROOT/'builds/current'/target.name)
    (ROOT/'builds/current/VERSION').write_text(VERSION+'\n')
    index_path = ROOT/'builds/versions.json'
    index = json.loads(index_path.read_text())
    for entry in index['versions']:
        if entry['version'] == index['current']:
            entry['status'] = 'historical; user-tested baseline'
    assert not any(entry['version'] == VERSION for entry in index['versions'])
    index['current'] = VERSION
    index['versions'].append(dict(version=VERSION,
        description='Normalize calendar progression at higher TPS; retains all 0.30.0 fixes',
        status='current; native checks passed, gameplay validation pending',
        files=[dict(path=f'builds/versions/{VERSION}/{r["name"]}.EXE',sha256=r['sha256'],bytes=r['bytes']) for r in records]))
    index_path.write_text(json.dumps(index,indent=2)+'\n')
    installation = dict(version=VERSION, status='installed; restart required; gameplay validation pending',
        files=[dict(path=str(target),backup=str(backup),before_sha256=digest(source),sha256=digest(candidate))
               for target,backup,source,candidate in plan],
        config_changed=False, saves_changed=False)
    (ROOT/'analysis/tps-calendar-installation.json').write_text(json.dumps(installation,indent=2)+'\n')
    inv_path = ROOT/'analysis/edited-files-inventory.json'
    inv = json.loads(inv_path.read_text())
    for target,backup,source,candidate in plan:
        for entry in inv.get('installed_changed_files',[]):
            if entry.get('path') == str(target):
                entry.update(sha256=digest(candidate),bytes=len(candidate))
        if str(backup) not in inv['installed_patch_backups']:
            inv['installed_patch_backups'].append(str(backup))
    inv_path.write_text(json.dumps(inv,indent=2)+'\n')
    print(json.dumps(installation,indent=2))
