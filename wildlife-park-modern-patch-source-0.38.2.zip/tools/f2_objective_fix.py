#!/usr/bin/env python3
"""F2 uses the unscaled native objectives frame, scrollbars and text hover."""
import struct,subprocess,tempfile,json
from pathlib import Path
import pefile
from patch_addon_widescreen import append_section,next_rva
from patch_debug_tools import ROOT,digest,public,check_preservation
from patch_weather_menu import PROFILES as WEATHER
from patch_keybind_panel import ROWS,asm_string
from theme_panel import BUTTONS,SIZE as OLD_SIZE
VERSION='0.37.3'
PICT=OLD_SIZE;TITLE=PICT+0x2ac
SCROLLS=(TITLE+0x330,TITLE+0x330+0x6ac)
READY=SCROLLS[1]+0x6ac;SIZE=READY+4
OBJECTS=[(PICT,'picture_ctor'),(TITLE,'label_ctor')]
for b in SCROLLS:
 OBJECTS.extend([(b,'scroll_ctor')]+[(b+0x394+i*0x108,'state_ctor') for i in range(3)])
BUTTON_OFFSETS=(0x5b8,0xbf0,0x1624,BUTTONS[0])
def patch(data,name):
 addon=name=='WLPADD1';p=pefile.PE(data=data);pr=dict(list(WEATHER.values())[int(addon)])
 native=dict(picture_ctor=(0x55e6e0,0x5883c0),picture_draw=(0x55e9b0,0x5886b0),label_ctor=(0x5f2b80,0x620cc0),scroll_ctor=(0x5f3110,0x621240),state_ctor=(0x5f3cd0,0x621e00),state_normal=(0x5f40f0,0x622220),state_pressed=(0x5f41f0,0x622350),state_hover=(0x5f43f0,0x622550),state_disabled=(0x5f42f0,0x622450),state_tile=(0x5f3e50,0x621f80),generic_attach=(0x5ea150,0x617cb0),generic_detach=(0x5ea1a0,0x617d00),label_set=(0x5f2c40,0x620d80),text_draw=(0x63e430,0x66e300))
 pr.update({k:v[int(addon)]-0x400000 for k,v in native.items()})
 pr.update(bank=0xa64954 if addon else 0x8d329c,root_vtable=0x339d0c if addon else 0x3095e4,button_vtable=0x339d94 if addon else 0x3096f4,root_hook=0x119dfc if addon else 0x10868c,draw_hook=0x220e97 if addon else 0x1f2d67,mode=0x36ddf8 if addon else 0x33ac48,widths=0x36ddfc if addon else 0x33ac4c,heights=0x36de0c if addon else 0x33ac5c)
 def oldtarget(h,op=0xe8):
  raw=p.get_data(h,5);assert raw[0]==op,(hex(h),raw.hex());return h+5+struct.unpack('<i',raw[1:])[0]
 for k,h in [('previous_ctor','ctor_call'),('previous_attach','attach_hook'),('previous_detach','detach_hook'),('previous_draw','draw_hook')]:pr[k]=oldtarget(pr[h])
 pr['previous_dtor']=oldtarget(pr['dtor'],0xe9)
 rva=next_rva(data)
 def call(n):return f'.byte 0xe8\n.long {pr[n]}-({rva}+.-_start+4)'
 def ptr(n):return f'[ebx+{rva}+{n}-_start]'
 ctor='\n'.join(f'lea ecx,[esi+{b}]\npush 1\n{call(k)}' for b,k in OBJECTS)
 destroy='\n'.join(f'lea ecx,[esi+{b}]\ncall dispose' for b,k in reversed(OBJECTS))
 detach='\n'.join(f'lea ecx,[esi+{b}]\n{call("generic_detach")}' for b in (*SCROLLS,TITLE,PICT))
 def bounds(b,x,y,w,h):return f'lea edi,[esi+{b}]\npush {h}\npush {w}\npush {y}\npush {x}\nmov ecx,edi\n{call("bounds")}'
 def white(b):return f'mov WORD PTR [esi+{b}+0x28c],0xffff\nmov BYTE PTR [esi+{b}+0x28e],255'
 setup=[f'mov DWORD PTR [esi+0xf8],1',bounds(PICT,0,0,524,378),f'''mov eax,[ebx+{pr['bank']}]
 mov eax,[eax+0xc]
 lea edx,[ebx+{pr['bank']}]
 add eax,edx
 mov [esi+{PICT}+0x298],eax
 mov DWORD PTR [esi+{PICT}+0x2a0],39
 mov DWORD PTR [esi+{PICT}+0x29c],0
 lea edi,[esi+{PICT}]
 push 1
 mov ecx,edi
 {call('enabled')}
''',bounds(TITLE,30,17,426,21),white(TITLE),f'''lea eax,{ptr('title_text')}
 push eax
 mov ecx,edi
 {call('label_set')}
 push esi
 mov ecx,edi
 {call('generic_attach')}''',bounds(0x288,30,230,426,108),white(0x288),f'''lea eax,{ptr('marker')}
 push eax
 mov ecx,edi
 {call('label_set')}''']
 for b,y in ((0x5b8,56),(0x1624,86),(BUTTONS[0],116)):
  setup.append(bounds(b,30,y,426,20))
  setup.append(f'lea eax,{ptr("button_vtable")}\nmov [edi],eax\nmov DWORD PTR [edi+0xf8],1\n'+white(b+0x2a0))
  for color in (0x5dc,0x5ec,0x5fc,0x60c,0x61c):
   setup.append(f'mov WORD PTR [esi+{b+color}+4],0xffff\nmov BYTE PTR [esi+{b+color}+6],255')
 setup.append(bounds(0xbf0,464,9,40,40))
 setup.append(f'mov DWORD PTR [edi+0xf8],1\nlea ecx,[edi+0x2a0]\n{call("generic_detach")}')
 setup.append(f'lea eax,{ptr("empty")}\npush eax\nmov ecx,edi\n{call("caption")}\nlea eax,{ptr("button_vtable")}\nmov [edi],eax')
 for index,b in enumerate(SCROLLS):
  setup.append(bounds(b,480,50 if index==0 else 220,28,137 if index==0 else 115))
  for state,frames in ((0,(4,5,6,7) if index==0 else (12,13,14,15)),(1,(0,1,2,3) if index==0 else (8,9,10,11)),(2,(0,0,0,0))):
   for func,frame in zip(('state_normal','state_pressed','state_hover','state_disabled'),frames):
    setup.append(f'''mov eax,[ebx+{pr['bank']}]
 mov eax,[eax+0xc]
 lea edx,[ebx+{pr['bank']}]
 add eax,edx
 push {42 if state==2 else 41}
 push {frame}
 push eax
 lea ecx,[esi+{b+0x394+state*0x108}]
 {call(func)}''')
  setup.append(f'''push 1
 lea ecx,[esi+{b+0x394+2*0x108}]
 {call('state_tile')}
 # Set native scrollbar image-state pointers and range before attachment.
 lea eax,[esi+{b+0x394}]
 mov [esi+{b}+0x2f0],eax
 lea eax,[esi+{b+0x394+0x108}]
 mov [esi+{b}+0x2f4],eax
 lea eax,[esi+{b+0x394+2*0x108}]
 mov [esi+{b}+0x2f8],eax
 mov DWORD PTR [esi+{b}+0x288],0
 mov DWORD PTR [esi+{b}+0x28c],0
 mov DWORD PTR [esi+{b}+0x290],{0 if index==0 else len(ROWS)-1-8}
 mov DWORD PTR [esi+{b}+0x294],1
 push 0
 push 0
 push 0
 lea eax,{ptr('scrolled')}
 push eax
 push esi
 push 0x18
 lea ecx,[esi+{b}]
 {call('register')}
 push 1
 lea ecx,[esi+{b}]
 {call('enabled')}
 push esi
 lea ecx,[esi+{b}]
 {call('generic_attach')}''')
 clone=[]
 # Native picture's primary table is recovered from its constructor.
 raw=p.get_data(pr['picture_ctor'],0x180);pos=raw.index(b'\xc7\x06');pr['picture_vtable']=struct.unpack('<I',raw[pos+2:pos+6])[0]-0x400000
 raw=p.get_data(pr['scroll_ctor'],0x180);pos=raw.index(b'\xc7\x06');pr['scroll_vtable']=struct.unpack('<I',raw[pos+2:pos+6])[0]-0x400000
 pr['scroll_invalidate']=struct.unpack('<I',p.get_data(pr['scroll_vtable']+8,4))[0]-0x400000
 pr['button_update']=struct.unpack('<I',p.get_data(pr['button_vtable']+0x20,4))[0]-0x400000
 for k in ('root','button'):
  clone.append(f'push esi\nlea esi,[ebx+{pr[k+"_vtable"]}]\nlea edi,{ptr(k+"_vtable")}\nmov ecx,32\nrep movsd\npop esi\nlea eax,{ptr(k+"_draw")}\nmov {ptr(k+"_vtable")}+0x24,eax')
 # Syntax for indexed destination must put displacement inside brackets.
 clone=[x.replace(']+0x24', '+0x24]') for x in clone]
 for k in ('enter','leave'):
  pr['button_'+k]=struct.unpack('<I',p.get_data(pr['button_vtable']+(0x60 if k=='enter' else 0x64),4))[0]-0x400000
  clone.append(f'lea eax,{ptr("button_"+k)}\nmov {ptr("button_vtable")[:-1]}+{0x60 if k=="enter" else 0x64}],eax')
 clone.append(f'push esi\nlea esi,[ebx+{pr["scroll_vtable"]}]\nlea edi,{ptr("scroll_vtable")}\nmov ecx,32\nrep movsd\npop esi\nlea eax,{ptr("scroll_invalidate")}\nmov {ptr("scroll_vtable")[:-1]}+8],eax')
 clone.append(f'lea eax,{ptr("button_update")}\nmov {ptr("button_vtable")[:-1]}+0x20],eax')
 setup.append(f'lea eax,{ptr("scroll_vtable")}\nmov [esi+{SCROLLS[1]}],eax')
 hover_lookup='\n'.join(f'lea edx,[esi+{b}]\ncmp ecx,edx\nje hover_{i}' for i,b in enumerate(BUTTON_OFFSETS))
 hover_labels='\n'.join(f'hover_{i}:\nmov edx,{1<<i}\njmp hover_found' for i,b in enumerate(BUTTON_OFFSETS))
 asm=f'''.intel_syntax noprefix
.code32
.global _start
_start:
get_base:
 call anchor
anchor:
 pop ebx
 sub ebx,{rva}+anchor-_start
 ret
constructor:
 push esi
 push DWORD PTR [esp+8]
 {call('previous_ctor')}
 mov esi,eax
 mov DWORD PTR [esi+{READY}],0
 {ctor}
 push esi
 lea ecx,[esi+{PICT}]
 {call('generic_attach')}
 mov DWORD PTR [esi+{READY}],1
 mov eax,esi
 pop esi
 ret 4
destructor:
 pushfd
 pushad
 lea esi,[ecx-0x1620]
 cmp DWORD PTR [esi+{READY}],1
 jne destroy_done
 mov DWORD PTR [esi+{READY}],0
 call get_base
 mov DWORD PTR {ptr('owner')},0
 {destroy}
destroy_done:
 popad
 popfd
 jmp _start+{pr['previous_dtor']-rva}
dispose:
 mov eax,[ecx+4]
 mov eax,[eax+4]
 lea ecx,[ecx+eax+4]
 mov eax,[ecx]
 push 0
 call DWORD PTR [eax]
 ret
root_bounds:
 push ebx
 call get_base
 mov eax,[ebx+{pr['mode']}]
 mov edx,[ebx+{pr['widths']}+eax*4]
 sub edx,524
 sar edx,1
 mov [esp+8],edx
 mov edx,[ebx+{pr['heights']}+eax*4]
 sub edx,378
 sar edx,1
 mov [esp+12],edx
 mov DWORD PTR [esp+16],524
 mov DWORD PTR [esp+20],378
 pop ebx
 jmp _start+{pr['bounds']-rva}
attach:
 push esi
 mov esi,[esp+8]
 push esi
 {call('previous_attach')}
 pushfd
 pushad
 cld
 call get_base
 mov {ptr('owner')},esi
 mov DWORD PTR {ptr('hover')},0
 mov DWORD PTR {ptr('last_scroll')},0
 {chr(10).join(clone)}
 lea eax,{ptr('root_vtable')}
 mov [esi],eax
 {chr(10).join(setup)}
 popad
 popfd
 pop esi
 ret 4
detach:
 pushfd
 pushad
 lea esi,[ecx-0x1228]
 {detach}
 popad
 popfd
 jmp _start+{pr['previous_detach']-rva}
root_draw:
 ret
picture_draw:
 ret
button_update:
 push esi
 mov esi,ecx
 {call('button_update')}
 pushfd
 pushad
 mov ecx,esi
 call button_draw
 popad
 popfd
 pop esi
 ret
button_draw:
 pushfd
 pushad
 call get_base
 call hover_index
 mov eax,0xffffff
 test edx,DWORD PTR {ptr('hover')}
 jz white_button
 mov eax,0x40ffff
white_button:
 cmp [ecx+0x2a0+0x28c],ax
 jne button_color_changed
 mov edx,eax
 shr edx,16
 cmp [ecx+0x2a0+0x28e],dl
 je button_color_done
button_color_changed:
 mov [ecx+0x2a0+0x28c],ax
 shr eax,16
 mov [ecx+0x2a0+0x28e],al
 add ecx,0x2a0
 mov edx,[ecx]
 push 1
 call DWORD PTR [edx+8]
button_color_done:
 popad
 popfd
 ret
hover_index:
 mov esi,{ptr('owner')}
 xor edx,edx
 test esi,esi
 jz hover_done
 {hover_lookup}
 ret
 {hover_labels}
hover_found:
hover_done:
 ret
button_enter:
 push ecx
 push DWORD PTR [esp+8]
 {call('button_enter')}
 pop ecx
 pushfd
 pushad
 call get_base
 call hover_index
 or {ptr('hover')},edx
 call button_draw
 popad
 popfd
 ret 4
button_leave:
 push ecx
 push DWORD PTR [esp+8]
 {call('button_leave')}
 pop ecx
 pushfd
 pushad
 call get_base
 call hover_index
 not edx
 and {ptr('hover')},edx
 call button_draw
 popad
 popfd
 ret 4
scroll_invalidate:
 push ecx
 push DWORD PTR [esp+8]
 {call('scroll_invalidate')}
 pop ecx
 pushfd
 pushad
 call get_base
 mov esi,{ptr('owner')}
 test esi,esi
 jz scroll_done
 mov eax,[ecx+0x288]
 cmp eax,DWORD PTR {ptr('last_scroll')}
 je scroll_done
 mov {ptr('last_scroll')},eax
 call invalidate_table
scroll_done:
 popad
 popfd
 ret 4
invalidate_table:
 lea ecx,[esi+0x288]
 mov edx,[ecx]
 push 1
 call DWORD PTR [edx+8]
 mov ecx,esi
 mov edx,[ecx]
 push 1
 call DWORD PTR [edx+8]
 ret
scrolled:
 pushfd
 pushad
 mov esi,ecx
 call invalidate_table
 popad
 popfd
 mov al,1
 ret 8
table_draw:
 pushfd
 pushad
 sub esp,32
 call get_base
 mov esi,[esp+76]
 test esi,esi
 je ordinary
 lea edi,{ptr('marker')}
match:
 mov al,[edi]
 test al,al
 je marker_end
 cmp al,[esi]
 jne ordinary
 inc edi
 inc esi
 jmp match
marker_end:
 cmp BYTE PTR [esi],13
 jne marker_lf
 inc esi
marker_lf:
 cmp BYTE PTR [esi],10
 jne marker_zero
 inc esi
marker_zero:
 cmp BYTE PTR [esi],0
 jne ordinary
 mov eax,{ptr('owner')}
 test eax,eax
 je ordinary
 mov eax,[eax+{SCROLLS[1]}+0x288]
 test eax,eax
 jns scroll_positive
 xor eax,eax
scroll_positive:
 cmp eax,{len(ROWS)-1-8}
 jbe scroll_bounded
 mov eax,{len(ROWS)-1-8}
scroll_bounded:
 inc eax
 mov [esp+20],eax
 mov DWORD PTR [esp+16],0
 mov esi,[esp+56]
 mov ebp,[esp+72]
row_loop:
 mov eax,[esp+16]
 test eax,eax
 jnz action_row
 xor eax,eax
 jmp row_selected
action_row:
 add eax,[esp+20]
 dec eax
row_selected:
 lea edi,{ptr('strings')}
 lea edi,[edi+eax*8]
 mov eax,[ebp]
 mov [esp],eax
 add eax,135
 mov [esp+8],eax
 mov eax,[esp+16]
 imul eax,12
 add eax,[ebp+4]
 mov [esp+4],eax
 add eax,12
 mov [esp+12],eax
 mov eax,[edi]
 add eax,ebx
 add eax,{rva}
 mov edx,esp
 push eax
 push edx
 mov ecx,esi
 {call('text_draw')}
 mov eax,[ebp]
 add eax,139
 mov [esp],eax
 add eax,287
 mov [esp+8],eax
 mov eax,[edi+4]
 add eax,ebx
 add eax,{rva}
 mov edx,esp
 push eax
 push edx
 mov ecx,esi
 {call('text_draw')}
 inc DWORD PTR [esp+16]
 cmp DWORD PTR [esp+16],9
 jb row_loop
 add esp,32
 popad
 popfd
 ret 8
ordinary:
 add esp,32
 popad
 popfd
 jmp _start+{pr['previous_draw']-rva}
marker: .asciz "WLP_F2_SCROLL_V1"
empty: .asciz ""
{asm_string('title_text','Cheats und Tastenbelegung')}
.balign 4
owner: .long 0
hover: .long 0
last_scroll: .long 0
scroll_vtable: .zero 128
root_vtable: .zero 128
button_vtable: .zero 128
picture_vtable: .zero 128
strings:
{chr(10).join(f'.long key_{i}-_start,action_{i}-_start' for i in range(len(ROWS)))}
{chr(10).join(asm_string(f'key_{i}',k)+chr(10)+asm_string(f'action_{i}',a) for i,(k,a) in enumerate(ROWS))}
'''
 with tempfile.TemporaryDirectory() as tmp:
  d=Path(tmp);(d/'patch.s').write_text(asm)
  subprocess.run(['as','--32','-o',str(d/'patch.o'),str(d/'patch.s')],check=True)
  assert 'R_386' not in subprocess.check_output(['objdump','-r',str(d/'patch.o')],text=True)
  subprocess.run(['objcopy','-O','binary','-j','.text',str(d/'patch.o'),str(d/'patch.bin')],check=True)
  code=(d/'patch.bin').read_bytes();sy={a[2]:int(a[0],16) for line in subprocess.check_output(['nm',str(d/'patch.o')],text=True).splitlines() if len(a:=line.split())==3}
 b=bytearray(data);changes=[]
 for hook,label,op in (('ctor_call','constructor',0xe8),('attach_hook','attach',0xe8),('detach_hook','detach',0xe8),('dtor','destructor',0xe9),('root_hook','root_bounds',0xe8),('draw_hook','table_draw',0xe8)):
  h=pr[hook];off=p.get_offset_from_rva(h);b[off:off+5]=bytes([op])+struct.pack('<i',rva+sy[label]-h-5);changes.append((h,5))
 off=p.get_offset_from_rva(pr['alloc']+1);assert struct.unpack('<I',b[off:off+4])[0]==OLD_SIZE
 b[off:off+4]=struct.pack('<I',SIZE);changes.append((pr['alloc']+1,4))
 append_section(b,b'.wlpf2ob',code);q=pefile.PE(data=b);struct.pack_into('<I',b,q.sections[-1].get_file_offset()+36,0xe0000020)
 m=dict(name=name,profile=pr,rva=rva,code=code,symbols=sy,changes=changes,reloc_offsets=[],objects=OBJECTS,size=SIZE,picture=PICT,title=TITLE,scrolls=SCROLLS,ready=READY,buttons=BUTTON_OFFSETS)
 check_preservation(data,b,m);return bytes(b),m
def build(name):
 source=ROOT/'builds/versions/0.35.2'/f'{name}.EXE'
 expected=next(f['sha256'] for e in json.loads((ROOT/'builds/versions.json').read_text())['versions'] if e['version']=='0.35.2' for f in e['files'] if f['path'].endswith('/'+source.name))
 data=source.read_bytes();assert digest(data)==expected
 return patch(data,name)
if __name__=='__main__':
 out=ROOT/'builds/versions'/VERSION;out.mkdir(exist_ok=True);records=[]
 for name in ('WLP','WLPADD1'):
  data,m=build(name);target=out/f'{name}.EXE'
  if target.exists():assert target.read_bytes()==data
  else:target.write_bytes(data)
  records.append(dict(name=name,sha256=digest(data),bytes=len(data),patch=public(m)))
 (ROOT/'analysis/f2-objective-fix-candidate.json').write_text(json.dumps(records,indent=2)+'\n')
 print(json.dumps([dict(name=r['name'],sha256=r['sha256']) for r in records],indent=2))
