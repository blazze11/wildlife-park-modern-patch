#!/usr/bin/env python3
"""Execute the generated x86 calendar hook, including its native hour branch."""
import json
import subprocess
import tempfile
from pathlib import Path
import pefile
from patch_tps_calendar import ROOT, patch

def verify(name, base):
    src = (ROOT/f'builds/versions/0.30.0/{name}.EXE').read_bytes()
    result, meta = patch(src)
    assert result == (ROOT/f'builds/versions/0.30.1/{name}.EXE').read_bytes()
    pe = pefile.PE(data=src)
    h = meta['profile']['hook']
    tests = []
    # These include fractional increments, zero-minute ticks, and a changed TPS.
    for rate in (25, 50, 60, 120, 255, 25):
        tests.append(f'''mov BYTE PTR [tps],{rate}
 mov DWORD PTR [left],{rate*120}
 mov DWORD PTR [minutes],0
 mov BYTE PTR [calendar+0x1d],0
loop_{len(tests)}:
 call run_tick
 dec DWORD PTR [left]
 jnz loop_{len(tests)}
 cmp DWORD PTR [minutes],24000
 jne fail
 cmp BYTE PTR [calendar+0x1d],0
 jne fail
''')
    with tempfile.TemporaryDirectory() as temp:
        d = Path(temp)
        (d/'hook.bin').write_bytes(result[pe.get_offset_from_rva(h):pe.get_offset_from_rva(h)+11])
        # Preserve and execute the original cmp AL,60 and JB <skip-hour>.
        (d/'branch.bin').write_bytes(pe.get_data(h+11, 8))
        (d/'code.bin').write_bytes(meta['code'])
        asm = f'''.intel_syntax noprefix
.code32
.global start
.section .main,"ax"
start:
 {''.join(tests)}
 xor ebx,ebx
 mov eax,1
 int 0x80
fail:
 mov ebx,1
 mov eax,1
 int 0x80
run_tick:
 mov [saved_sp],esp
 movzx eax,BYTE PTR [calendar+0x1d]
 mov [old_minute],eax
 mov eax,0x11223344
 mov ebx,0x55667788
 mov ecx,0x99aabbcc
 mov edx,0xaabbccdd
 mov edi,0x22334455
 mov ebp,0x66778899
 mov esi,OFFSET calendar
 jmp hook
after_tick:
 # The original hour branch's destination was selected by its original CMP.
 cmp ebx,0x55667788
 jne fail
 cmp ecx,0x99aabbcc
 jne fail
 cmp edi,0x22334455
 jne fail
 cmp ebp,0x66778899
 jne fail
 cmp esi,OFFSET calendar
 jne fail
 cmp esp,[saved_sp]
 jne fail
 cmp al,dl
 jne fail
 and eax,0xffffff00
 cmp eax,0x11223300
 jne fail
 and edx,0xffffff00
 cmp edx,0xaabbcc00
 jne fail
 # Hour rollover is mocked after exercising the original branch: carry the
 # same byte minute field modulo 60; no changes to calendar date logic.
 movzx eax,BYTE PTR [calendar+0x1d]
 sub eax,[old_minute]
 add [minutes],eax
 movzx eax,BYTE PTR [calendar+0x1d]
 cmp eax,60
 jb no_rollover
 sub eax,60
 mov BYTE PTR [calendar+0x1d],al
no_rollover:
 ret
.section .hook,"ax"
hook: .incbin "{d/'hook.bin'}"
.incbin "{d/'branch.bin'}"
 # Native branch fell through: minute must be at least 60.
 cmp BYTE PTR [calendar+0x1d],60
 jb fail
 jmp after_tick
.section .skip,"ax"
 cmp BYTE PTR [calendar+0x1d],60
 jae fail
 jmp after_tick
.section .thunk,"awx"
.incbin "{d/'code.bin'}"
.section .tps,"aw"
tps: .byte 25
.section .data,"aw"
calendar: .zero 64
saved_sp: .long 0
old_minute: .long 0
minutes: .long 0
left: .long 0
'''
        layout = {'hook': h, 'skip': h+0xce, 'thunk': meta['rva'], 'tps': meta['profile']['tps']}
        sections = '\n'.join(f'.{key} {base+offset} : {{ *(.{key}) }}'
                             for key, offset in sorted(layout.items(), key=lambda x: x[1]))
        (d/'test.s').write_text(asm)
        (d/'test.ld').write_text(f'ENTRY(start)\nSECTIONS {{ .main {base+0x1000} : {{ *(.main) }}\n{sections}\n.data : {{ *(.data) }} }}')
        subprocess.run(['as', '--32', '-o', str(d/'test.o'), str(d/'test.s')], check=True)
        subprocess.run(['ld', '-m', 'elf_i386', '-T', str(d/'test.ld'), '-o', str(d/'test'), str(d/'test.o')], check=True, capture_output=True)
        proc = subprocess.run([str(d/'test')], timeout=20)
        assert proc.returncode == 0, (name, hex(base), proc.returncode)
    return dict(name=name, image_base=hex(base), ticks=64200,
                checks='actual hook/branch execution; fractional rate, TPS change, hour rollover, registers and stack; original sections preserved')

if __name__ == '__main__':
    records = [verify(name, base) for name in ('WLP','WLPADD1')
               for base in (0x400000,0x14000000)]
    (ROOT/'analysis/tps-calendar-verification.json').write_text(json.dumps(records,indent=2)+'\n')
    print(json.dumps(records,indent=2))
