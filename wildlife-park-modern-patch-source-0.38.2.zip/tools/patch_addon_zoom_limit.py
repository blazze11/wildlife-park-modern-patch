#!/usr/bin/env python3
"""Disable Wild Creatures' native 50% -> 25% overview transition."""
import hashlib,json,os,struct
from pathlib import Path
from workspace_paths import artifact, backup_path
import pefile

SOURCE='8951a55ded77c912aad4ed2688677b5aa9fc880861373ce6b95620176e6c15a6'
def patch(src):
 assert hashlib.sha256(src).hexdigest()==SOURCE
 p=pefile.PE(data=src);off=p.get_offset_from_rva(0x124be8)
 assert src[off:off+2]==bytes.fromhex('7565')
 # Mode 0/1 already branch to the original 50%/100% transitions.
 # Mode 2 now takes the existing no-change return instead of entering
 # overview UI setup and selecting mode 3 (25%). Keyboard '-' already stops.
 b=bytearray(src);b[off]=0xeb
 assert 0x124be8+2+struct.unpack('<b',b[off+1:off+2])[0]==0x124c4f
 assert [i for i,(a,c) in enumerate(zip(src,b)) if a!=c]==[off]
 return bytes(b)

if __name__=='__main__':
 src=artifact('WLPADD1_widescreen_weather_menu.EXE').read_bytes();new=patch(src)
 candidate=artifact('WLPADD1_widescreen_zoom_limit.EXE');candidate.write_bytes(new)
 root=Path('/path/to/Wildlife Park Gold/Int/Win32/Program/VC6')
 target=root/'WLPADD1.EXE';assert target.read_bytes()==src
 base=root/'WLP.EXE';base_data=base.read_bytes()
 backup=backup_path(root/'WLPADD1.EXE.pre-disable-overview.bak')
 if backup.exists():assert backup.read_bytes()==src
 else:
  with backup.open('xb') as f:f.write(src)
 staged=root/'WLPADD1.EXE.zoom-limit.tmp'
 with staged.open('xb') as f:f.write(new)
 staged.chmod(target.stat().st_mode)
 assert target.read_bytes()==src
 os.replace(staged,target)
 assert target.read_bytes()==new and base.read_bytes()==base_data
 digest=hashlib.sha256(new).hexdigest()
 record=dict(path=str(target),backup=str(backup),sha256=digest,bytes=len(new),changed_rva='0x124be8',original='75',replacement='eb')
 Path('analysis/addon-zoom-limit-installation.json').write_text(json.dumps(record,indent=2)+'\n')
 inv=Path('analysis/edited-files-inventory.json');doc=json.loads(inv.read_text())
 entry=next(x for x in doc['installed_changed_files'] if x['path']==str(target));entry.update(sha256=digest,bytes=len(new))
 if str(backup) not in doc['installed_patch_backups']:doc['installed_patch_backups'].append(str(backup))
 inv.write_text(json.dumps(doc,indent=2)+'\n')
 print(json.dumps(record,indent=2))
