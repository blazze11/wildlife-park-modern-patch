"""Resolve historical artifact names after workspace organization."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
GAME = Path('/path/to/Wildlife Park Gold')

def backup_path(path):
    """Keep game backups outside the live installation, preserving subpaths."""
    value = Path(path).absolute()
    index = ROOT / 'builds/versions.json'
    if index.exists():
        versions = json.loads(index.read_text())
        existing = versions['aliases'].get(str(value))
        if existing:
            return Path(existing)
        relative = value.relative_to(GAME)
        if '.EXE' in value.name:
            stem, suffix = value.name.split('.EXE', 1)
            label = suffix.removesuffix('.bak').lstrip('.') or 'snapshot'
            destination = ROOT / 'archive/game-backups' / versions['current'] / label / relative.parent / (stem + '.EXE')
        else:
            destination = ROOT / 'archive/game-backups' / versions['current'] / relative
    else:
        destination = ROOT / 'archive/game-backups' / value.relative_to(GAME)
    destination.parent.mkdir(parents=True, exist_ok=True)
    return destination

def artifact(name):
    value = Path(name)
    source = str(value if value.is_absolute() else ROOT / value)
    index = ROOT / 'builds/versions.json'
    aliases = json.loads(index.read_text())['aliases'] if index.exists() else {}
    if source in aliases:
        return Path(aliases[source])
    manifest = ROOT / 'analysis/workspace-cleanup.json'
    if manifest.exists():
        records = json.loads(manifest.read_text())['moves']
        for record in records:
            if record['source'] == source:
                return Path(aliases.get(record['destination'], record['destination']))
    return value if value.is_absolute() else ROOT / value
