#!/usr/bin/env python3
"""Build the independent HUD, F2 toggles and console from immutable 0.30.1."""
import hashlib
import json
from pathlib import Path
import pefile

ROOT = Path(__file__).resolve().parents[1]
VERSION = '0.31.1'
BASELINE = {
    'WLP': 'bd97135f81460321edacbaf91949c7d2ed313a510adf4d8e6fbfd385872be0de',
    'WLPADD1': '141f6fdefb06fb1a4ff5c9aae9df560b994965f1a560ccfce85bc195665bd19e',
}

def digest(data):
    return hashlib.sha256(data).hexdigest()

def public(value):
    if isinstance(value, bytes):
        return {'bytes': len(value), 'sha256': digest(value)}
    if isinstance(value, dict):
        return {k: public(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)):
        return [public(v) for v in value]
    return value

def check_preservation(before, after, metadata):
    p = pefile.PE(data=before)
    q = pefile.PE(data=after)
    expected = bytearray(before)
    for rva, length in metadata['changes']:
        offset = p.get_offset_from_rva(rva)
        expected[offset:offset+length] = after[offset:offset+length]
    for offset in metadata.get('reloc_offsets', []):
        expected[offset:offset+2] = after[offset:offset+2]
    for section in p.sections:
        offset = section.PointerToRawData
        assert after[offset:offset+section.SizeOfRawData] == expected[offset:offset+section.SizeOfRawData], section.Name
        header = section.get_file_offset()
        assert after[header:header+40] == before[header:header+40], section.Name
    assert q.FILE_HEADER.NumberOfSections == p.FILE_HEADER.NumberOfSections + 1
    assert q.OPTIONAL_HEADER.ImageBase == p.OPTIONAL_HEADER.ImageBase
    for block in q.DIRECTORY_ENTRY_BASERELOC:
        for entry in block.entries:
            assert not entry.type or not any(r <= entry.rva < r+n for r, n in metadata['changes']), hex(entry.rva)

def build(name):
    from debug_hud import patch as hud_patch
    from debug_panel import patch as panel_patch
    from debug_console import patch as console_patch
    source = (ROOT/'builds/versions/0.30.1'/f'{name}.EXE').read_bytes()
    assert digest(source) == BASELINE[name]
    hud, hm = hud_patch(source, name)
    check_preservation(source, hud, hm)
    panel, pm = panel_patch(hud, name, hm)
    check_preservation(hud, panel, pm)
    result, cm = console_patch(panel, name, hm)
    check_preservation(panel, result, cm)
    return result, dict(name=name, source_sha256=digest(source), sha256=digest(result),
                        bytes=len(result), hud=hm, panel=pm, console=cm)

if __name__ == '__main__':
    out = ROOT/'builds/versions'/VERSION
    out.mkdir(exist_ok=True)
    records = []
    for name in BASELINE:
        result, metadata = build(name)
        target = out/f'{name}.EXE'
        if target.exists():
            assert target.read_bytes() == result, 'Immutable snapshot differs; do not overwrite'
        else:
            target.write_bytes(result)
        records.append(public(metadata))
    (ROOT/'analysis/debug-tools-candidate.json').write_text(json.dumps(records, indent=2)+'\n')
    print(json.dumps([dict(name=r['name'], sha256=r['sha256'], bytes=r['bytes']) for r in records], indent=2))
