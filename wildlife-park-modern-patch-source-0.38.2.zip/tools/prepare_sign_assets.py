#!/usr/bin/env python3
"""Pack normal/glow sign patches into two native main-menu background frames."""
import struct,json,hashlib
from pathlib import Path
from PIL import Image
from replace_alb_frame import encode_literals
from export_menu_assets import decode_frame
from expand_weather import encode,rows
from workspace_paths import GAME

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'assets/versions/0.35.0'
def digest(d):return hashlib.sha256(d).hexdigest()
def rgb565(im):
    return b''.join(struct.pack('<H',(round(r*31/255)<<11)|(round(g*63/255)<<5)|round(b*31/255)) for r,g,b in im.convert('RGB').getdata())
def patch_alb(data,entry,frames):
    version,count,flags,unused,table,size=struct.unpack_from('<HHIIII',data)
    assert version==200 and flags in (272,528)
    offsets=struct.unpack_from(f'<{size//4}I',data,table)
    assert offsets[-1]==len(data)
    header=255+entry*64;nf,w,h,raw,total,identifier=struct.unpack_from('<HHHIII',data,header)
    assert (nf,w,h)==(1,800,600)
    index=sum(struct.unpack_from('<H',data,255+i*64)[0] for i in range(entry))
    raw_frames=[];new_payloads=[]
    original_raw=decode_frame(data[offsets[index]:offsets[index+1]],w,h,flags)
    for im in frames:
        assert im.size==(w,h)
        raw=rgb565(im);raw_frames.append(raw)
        if flags==272:
            payload=encode_literals(raw)
        else:
            payload=encode([[(0,raw[y*w*2:(y+1)*w*2])] for y in range(h)],w)
        assert decode_frame(payload,w,h,flags)==raw
        new_payloads.append(payload)
    prefix=bytearray(data[:table])
    struct.pack_into('<II',prefix,12,table,size+4)
    struct.pack_into('<H',prefix,header,2)
    struct.pack_into('<I',prefix,header+10,w*h*2*2)
    # Record byte 15 stores the first global frame index (byte 14 is separate).
    # Inserting one menu frame shifts every later record's frame lookup.
    first=0
    for i in range(count):
        r=255+i*64
        assert struct.unpack_from('<I',data,r+15)[0]==first
        struct.pack_into('<I',prefix,r+15,first+(i>entry))
        first+=struct.unpack_from('<H',data,r)[0]
    result=prefix+bytearray(size+4);new_offsets=[len(result)]
    preserved=0
    for i in range(len(offsets)-1):
        chunks=new_payloads if i==index else [data[offsets[i]:offsets[i+1]]]
        for chunk in chunks:result.extend(chunk);new_offsets.append(len(result))
        if i!=index:preserved+=1
    struct.pack_into(f'<{len(new_offsets)}I',result,table,*new_offsets)
    assert len(new_offsets)*4==size+4
    first=0
    for i in range(count):
        r=255+i*64
        assert struct.unpack_from('<I',result,r+15)[0]==first
        first+=struct.unpack_from('<H',result,r)[0]
    assert first==len(new_offsets)-1
    # Every unaffected encoded frame must remain exact.
    for i in range(len(offsets)-1):
        if i!=index:
            j=i+(i>index)
            assert result[new_offsets[j]:new_offsets[j+1]]==data[offsets[i]:offsets[i+1]]
    return bytes(result),dict(source_sha256=digest(data),sha256=digest(result),entry=entry,
        preserved_frames=preserved,normal_raw_sha256=digest(raw_frames[0]),glow_raw_sha256=digest(raw_frames[1]),
        original_raw_sha256=digest(original_raw),flags=flags)
def texture_frames(game):
    base=ROOT/'assets/menu-editing'/game/'main-menu.png'
    bg=Image.open(base).convert('RGB')
    names=('wild-creatures',8,10) if game=='wildlife-park' else ('wildlife-park',35,0)
    states=[]
    for state in ('normal','glow'):
        im=bg.copy();patch=Image.open(ROOT/'assets/sign-switch'/f'{names[0]}-{state}.png').convert('RGBA')
        im.paste(patch,names[1:],patch.getchannel('A'));states.append(im)
    return states
def patch_container(source,target,member,entry,frames):
    with source.open('rb') as f:
        h=f.read(28);stride,count,directory,start=struct.unpack_from('<4I',h,12)
        assert h[:4]==b'cont' and stride==328
        f.seek(0);meta=bytearray(f.read(start));matches=[];lengths=[];cursor=start
        for i in range(count):
            r=directory+i*stride;length=struct.unpack_from('<I',meta,r+32)[0];lengths.append(length)
            assert struct.unpack_from('<Q',meta,r+320)[0]==cursor
            if meta[r+44:r+304].split(b'\0')[0]==member.encode():matches.append((i,cursor,length))
            cursor+=length
        assert cursor==source.stat().st_size and len(matches)==1
        i,begin,length=matches[0];f.seek(begin);original=f.read(length)
        replacement,info=patch_alb(original,entry,frames)
        struct.pack_into('<I',meta,directory+i*stride+32,len(replacement))
        delta=len(replacement)-length
        for j in range(i+1,count):
            field=directory+j*stride+320;struct.pack_into('<Q',meta,field,struct.unpack_from('<Q',meta,field)[0]+delta)
        with target.open('wb') as out:
            out.write(meta);f.seek(start);remaining=begin-start
            while remaining:
                chunk=f.read(min(1024*1024,remaining));assert chunk;out.write(chunk);remaining-=len(chunk)
            out.write(replacement);f.seek(begin+length)
            while chunk:=f.read(1024*1024):out.write(chunk)
    # Verify every unchanged member through stored directory offsets.
    with source.open('rb') as a,target.open('rb') as b:
        for j,ln in enumerate(lengths):
            old_pos=start+sum(lengths[:j]);new_pos=struct.unpack_from('<Q',meta,directory+j*stride+320)[0]
            new_ln=struct.unpack_from('<I',meta,directory+j*stride+32)[0]
            a.seek(old_pos);b.seek(new_pos)
            if j==i:assert b.read(new_ln)==replacement
            else:
                assert ln==new_ln
                remaining=ln
                while remaining:
                    n=min(1024*1024,remaining);assert a.read(n)==b.read(n);remaining-=n
    info.update(container_member=member,preserved_container_members=count-1)
    return info
if __name__=='__main__':
    OUT.mkdir(parents=True,exist_ok=True);reports=[]
    for game,entry,rel,container in [('wildlife-park',44,'Int/All/Pictures/GUI.alb','Pictures.cont'),
                                   ('wild-creatures',22,'Int/All/Pictures/Addon1/GUI_AddOn1.alb','Pictures_Addon1.cont')]:
        frames=texture_frames(game);source=GAME/rel;result,info=patch_alb(source.read_bytes(),entry,frames)
        target=OUT/source.name;target.write_bytes(result);info.update(path=rel,candidate=str(target));reports.append(info)
        ct=OUT/container;ci=patch_container(GAME/'Int/All'/container,ct,source.name,entry,frames)
        ci.update(path='Int/All/'+container,candidate=str(ct),source_sha256=digest((GAME/'Int/All'/container).read_bytes()),sha256=digest(ct.read_bytes()))
        reports.append(ci)
        for state,im in zip(('normal','glow'),frames):im.save(ROOT/'assets/sign-switch'/f'{game}-menu-{state}.png')
    (ROOT/'analysis/sign-assets-candidate.json').write_text(json.dumps(reports,indent=2)+'\n')
    print(json.dumps(reports,indent=2))
