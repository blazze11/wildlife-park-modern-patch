#!/usr/bin/env python3
"""Add an owned native F2 button cycling visual weather, leaving climate intact."""
import hashlib, struct, subprocess, tempfile, argparse
from pathlib import Path
import pefile
from patch_addon_widescreen import append_section, next_rva
from patch_keybind_panel import asm_string
PROFILES={
'fe320e05f133d507bab1f780832f8f7d6adac0f08fa58d2b3eb0c2fb6698041a':dict(alloc=0x119adb,ctor_call=0x119afc,ctor=0x107d70,button_ctor=0x267700,dtor=0x108240,button_dtor=0x108050,attach_hook=0x108837,attach=0x268270,detach_hook=0x1088da,input_detach=0x265c00,detach=0x268290,bounds_hook=0x1087db,bounds=0x1f5fc0,caption=0x267de0,register=0x244490,enabled=0x1ed600,weather_hook=0xec2e9,weather_field=0x1a4),
'a3b7dc7b16453fc1d2af9ed28152e8ed0236f7192f3ac2b179efee4eb6c205ba':dict(alloc=0x12c2bb,ctor_call=0x12c2dc,ctor=0x119a70,button_ctor=0x2958e0,dtor=0x119b80,button_dtor=0x11a320,attach_hook=0x119fa7,attach=0x296450,detach_hook=0x11a04a,input_detach=0x293dd0,detach=0x296470,bounds_hook=0x119f4b,bounds=0x2241c0,caption=0x295fc0,register=0x272630,enabled=0x21b070,weather_hook=0xfbcb9,weather_field=0x1d8)}
BUTTON=0x1624
READY=BUTTON+0x638
SIZE=READY+4
CAPTIONS=['Wetter: Automatisch','Wetter: Schnee (Test)','Wetter: Regen (Test)','Wetter: Aus (Test)']
def patch(src):
 p=pefile.PE(data=src);profile=PROFILES[hashlib.sha256(src).hexdigest()];rva=next_rva(src)
 def call(n):return f'.byte 0xe8\n.long {profile[n]}-({rva}+.-_start+4)'
 def addr(n):return f'[ebx+{rva}+{n}-_start]'
 asm=f'''.intel_syntax noprefix
.code32
.global _start
_start:
get_base:
 call anchor
anchor:
 pop ebx
 sub ebx,{rva}+anchor-_start
 ret
constructor:
 push esi
 push DWORD PTR [esp+8]
 {call('ctor')}
 mov esi,eax
 mov DWORD PTR [esi+{READY}],0
 lea ecx,[esi+{BUTTON}]
 push 1
 {call('button_ctor')}
 mov DWORD PTR [esi+{READY}],1
 mov eax,esi
 pop esi
 ret 4
destructor:
 pushfd
 pushad
 cmp DWORD PTR [ecx+{READY-0x1620}],1
 jne no_button
 mov DWORD PTR [ecx+{READY-0x1620}],0
 add ecx,{BUTTON+0x630-0x1620}
 {call('button_dtor')}
no_button:
 popad
 popfd
 push -1
 # original handler absolute VA recovered as image-relative at runtime
 push ebx
 call get_base
 lea ebx,[ebx+{struct.unpack('<I',p.get_data(profile['dtor']+3,4))[0]-0x400000}]
 xchg ebx,[esp]
 jmp _start+{profile['dtor']+7-rva}
close_bounds:
 mov DWORD PTR [esp+8],475
 jmp _start+{profile['bounds']-rva}
attach_button:
 push ebx
 push esi
 push edi
 mov esi,[esp+16]
 push esi
 {call('attach')}
 call get_base
 lea edi,[esi+{BUTTON}]
 push 20
 push 270
 push 65
 push 10
 mov ecx,edi
 {call('bounds')}
 mov ecx,edi
 call refresh_caption
 # callback record: selector, receiver, callback, adjust, flags, auxiliary
 push 0
 push 0
 push 0
 lea eax,{addr('cycle')}
 push eax
 push esi
 push 0x0e
 mov ecx,edi
 {call('register')}
 push 1
 mov ecx,edi
 {call('enabled')}
 push esi
 mov ecx,edi
 {call('attach')}
 pop edi
 pop esi
 pop ebx
 ret 4
detach_button:
 push esi
 mov esi,ecx
 {call('input_detach')}
 lea ecx,[esi+{BUTTON}-0x1228]
 {call('detach')}
 pop esi
 ret
cycle:
 pushfd
 pushad
 call get_base
 mov eax,DWORD PTR {addr('mode')}
 inc eax
 and eax,3
 mov DWORD PTR {addr('mode')},eax
 mov ecx,[esp+24]
 add ecx,{BUTTON}
 call refresh_caption
 popad
 popfd
 mov al,1
 ret 8
refresh_caption:
 mov eax,DWORD PTR {addr('mode')}
 mov eax,[ebx+{rva}+captions-_start+eax*4]
 lea eax,[ebx+{rva}+eax]
 push eax
 {call('caption')}
 ret
weather:
 pushfd
 push ebx
 call get_base
 cmp esi,DWORD PTR {addr('owner')}
 je same_world
 mov DWORD PTR {addr('owner')},esi
 mov DWORD PTR {addr('mode')},0
same_world:
 mov eax,DWORD PTR {addr('mode')}
 test eax,eax
 je automatic
 mov eax,[ebx+{rva}+states-_start+eax*4]
 jmp weather_done
automatic:
 mov eax,[esi+{profile['weather_field']}]
weather_done:
 pop ebx
 popfd
 jmp _start+{profile['weather_hook']+6-rva}
.balign 4
mode: .long 0
owner: .long 0
states: .long 0,5,3,1
captions: .long caption0-_start,caption1-_start,caption2-_start,caption3-_start
{chr(10).join(asm_string('caption'+str(i),s) for i,s in enumerate(CAPTIONS))}
'''
 with tempfile.TemporaryDirectory() as tmp:
  d=Path(tmp);(d/'weather.s').write_text(asm)
  subprocess.run(['as','--32','-o',str(d/'weather.o'),str(d/'weather.s')],check=True)
  assert 'R_386' not in subprocess.check_output(['objdump','-r',str(d/'weather.o')],text=True)
  subprocess.run(['objcopy','-O','binary','-j','.text',str(d/'weather.o'),str(d/'weather.bin')],check=True)
  code=(d/'weather.bin').read_bytes()
  symbols={a[2]:int(a[0],16) for line in subprocess.check_output(['nm',str(d/'weather.o')],text=True).splitlines() if len(a:=line.split())==3}
 b=bytearray(src);changes=[]
 def replace(h,old,new):
  assert len(old)==len(new);off=p.get_offset_from_rva(h);assert b[off:off+len(old)]==old,hex(h)
  b[off:off+len(old)]=new;changes.append((h,len(old)))
 def hook(field,symbol,target):
  h=profile[field];replace(h,b'\xe8'+struct.pack('<i',profile[target]-h-5),b'\xe8'+struct.pack('<i',rva+symbols[symbol]-h-5))
 replace(profile['alloc'],b'\x68'+struct.pack('<I',0x1624),b'\x68'+struct.pack('<I',SIZE))
 hook('ctor_call','constructor','ctor');hook('attach_hook','attach_button','attach');hook('detach_hook','detach_button','input_detach');hook('bounds_hook','close_bounds','bounds')
 h=profile['dtor'];old=p.get_data(h,7);assert old[:3]==bytes.fromhex('6aff68');replace(h,old,b'\xe9'+struct.pack('<i',rva+symbols['destructor']-h-5)+b'\x90\x90')
 h=profile['weather_hook'];replace(h,b'\x8b\x86'+struct.pack('<I',profile['weather_field']),b'\xe9'+struct.pack('<i',rva+symbols['weather']-h-5)+b'\x90')
 reloc_offsets=[]
 for block in p.DIRECTORY_ENTRY_BASERELOC:
  for e in block.entries:
   if e.type and any(h<=e.rva<h+n for h,n in changes):
    off=e.struct.get_file_offset();struct.pack_into('<H',b,off,struct.unpack_from('<H',b,off)[0]&0xfff);reloc_offsets.append(off)
 assert len(reloc_offsets)==1
 append_section(b,b'.wlpwthr',code)
 np=pefile.PE(data=b);struct.pack_into('<I',b,np.sections[-1].get_file_offset()+36,0xe0000020)
 return bytes(b),dict(profile=profile,rva=rva,code=code,symbols=symbols,changes=changes,reloc_offsets=reloc_offsets)
if __name__=='__main__':
 a=argparse.ArgumentParser(description=__doc__);a.add_argument('input',type=Path);a.add_argument('output',type=Path);args=a.parse_args();b,m=patch(args.input.read_bytes());args.output.open('xb').write(b);print(args.output,hashlib.sha256(b).hexdigest())
