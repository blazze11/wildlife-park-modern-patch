#!/usr/bin/env python3
"""Temporary, state-preserving timing hooks for the two current zoom builds."""
import hashlib, json, struct, subprocess, tempfile
from pathlib import Path
import pefile
from patch_addon_widescreen import append_section, next_rva, redirect

PROFILES = {
 '676951470191bd312fca07ca0f9699d8c9d78b08d390f76662e6b7842dcdfdc1': ('base',0x1c63a0,0x280090),
 'b7f2a6ee1a4ac6556e8abfe08f85de864154d3269024bfd0843b8d9442fa625d': ('addon',0x1f3d20,0x2adc80),
}
EVENTS = {1:'mode begin',2:'mode end',3:'teardown begin',4:'teardown end',
 5:'recreate begin',6:'recreate end',7:'recovery pump begin',8:'recovery pump end',
 9:'recovery retry (200ms)',10:'SetDisplayMode begin',11:'SetDisplayMode end',
 12:'primary Restore begin',13:'primary Restore end',14:'secondary Restore begin',15:'secondary Restore end',
 16:'recovery finalization begin',17:'recovery finalization end'}

def patch(src):
 name,mode,recovery=PROFILES[hashlib.sha256(src).hexdigest()]
 p=pefile.PE(data=src); b=bytearray(src); rva=next_rva(b)
 imports={i.name.decode():i.address-p.OPTIONAL_HEADER.ImageBase
          for dll in p.DIRECTORY_ENTRY_IMPORT for i in dll.imports if i.name}
 focus=next(s for s in p.sections if s.Name.rstrip(b'\0')==b'.wlpfoc').VirtualAddress
 # All replaced instructions are free of image-base relocations. COM calls
 # retain their original argument layout and stdcall stack cleanup.
 sites=[(mode,bytes.fromhex('83ec10535556'),1,None),
        (mode+0xcc,bytes.fromhex('5f5e5d5b83c410'),2,None),
        (mode+0x55,None,3,4),(mode+0x63,None,5,6),
        (recovery+0xcb-0x90,None,7,8),
        (recovery+0x136-0x90,bytes.fromhex('68c8000000'),9,None),
        (focus+0x32,bytes.fromhex('8b1050ff5254'),10,11),
        (focus+0x3a,bytes.fromhex('8b0850ff516c'),12,13),
        (recovery+0x105-0x90,bytes.fromhex('8b1050ff526c'),14,15),
        (recovery+0x1ee-0x90,None,16,17)]
 asm=['.section .text','logger:', 'pushfl','pushal','movl %esp,%ebp',
      'subl $48,%esp','call 1f','1: popl %ebx','subl $1b,%ebx',
      f'call *{imports["GetLastError"]}(%ebx)','movl %eax,28(%esp)',
      'movl $0x31544457,0(%esp)','movl 40(%ebp),%eax','movl %eax,4(%esp)',
      f'call *{imports["timeGetTime"]}(%ebx)','movl %eax,8(%esp)',
      f'call *{imports["GetCurrentThreadId"]}(%ebx)','movl %eax,12(%esp)',
      'movl 28(%ebp),%eax','movl %eax,16(%esp)',
      'movl 24(%ebp),%eax','movl %eax,20(%esp)',
      'movl 0(%ebp),%eax','movl %eax,24(%esp)',
      'pushl $0','pushl $128','pushl $4','pushl $0','pushl $4','pushl $4',
      'leal filename(%ebx),%eax','pushl %eax',f'call *{imports["CreateFileA"]}(%ebx)',
      'movl %eax,%edi','cmpl $-1,%eax','je 2f','movl %esp,%edx',
      'leal 32(%esp),%eax','pushl $0','pushl %eax','pushl $32','pushl %edx','pushl %edi',
      f'call *{imports["WriteFile"]}(%ebx)','pushl %edi',f'call *{imports["CloseHandle"]}(%ebx)',
      '2: pushl 28(%esp)',f'call *{imports["SetLastError"]}(%ebx)',
      'movl %ebp,%esp','popal','popfl','ret $4']
 changes=[]
 for i,(site,original,before,after) in enumerate(sites):
  off=p.get_offset_from_rva(site)
  if original is None:
   original=src[off:off+5]; assert original[0]==0xe8
   destination=site+5+struct.unpack_from('<i',original,1)[0]
   replay=f'call {destination}'
  else: replay='.byte '+','.join(str(x) for x in original)
  assert src[off:off+len(original)]==original
  asm += [f'hook{i}:',f'pushl ${before}','call logger',replay]
  if after: asm += [f'pushl ${after}','call logger']
  asm += ['.byte 0xe9',f'.long {site+len(original)} - . - 4']
  changes.append((site,original,i))
 filename='C:\\Program Files (x86)\\Deep Silver\\Wildlife Park Gold\\DisplayTransition-'+name+'.bin'
 asm += ['filename:', '.byte '+','.join(str(x) for x in filename.encode()+b'\0')]
 with tempfile.TemporaryDirectory() as td:
  d=Path(td);(d/'trace.s').write_text('\n'.join(asm)+'\n')
  subprocess.run(['as','--32',str(d/'trace.s'),'-o',str(d/'trace.o')],check=True)
  subprocess.run(['ld','-m','elf_i386',f'-Ttext=0x{rva:x}',str(d/'trace.o'),'-o',str(d/'trace.elf')],check=True,capture_output=True)
  nm=subprocess.check_output(['nm',str(d/'trace.elf')],text=True)
  symbols={parts[2]:int(parts[0],16) for line in nm.splitlines() if len(parts:=line.split())==3}
  subprocess.run(['objcopy','-O','binary','-j','.text',str(d/'trace.elf'),str(d/'blob')],check=True)
  code=(d/'blob').read_bytes()
 for site,original,i in changes:
  # Existing append helpers assume original sections are RVA==file offset;
  # the focus section is appended, so map every patch explicitly here.
  off=p.get_offset_from_rva(site)
  b[off:off+len(original)]=b'\xe9'+struct.pack('<i',symbols[f'hook{i}']-site-5)+b'\x90'*(len(original)-5)
 append_section(b,b'.wlpdtim',code)
 np=pefile.PE(data=b)
 for block in np.DIRECTORY_ENTRY_BASERELOC:
  for e in block.entries:
   assert not e.type or not any(site<=e.rva<site+len(original) for site,original,_ in changes)
 expected=bytearray(src)
 for site,original,_ in changes:
  off=p.get_offset_from_rva(site);expected[off:off+len(original)]=b[off:off+len(original)]
 for s in p.sections:
  off=s.PointerToRawData;assert b[off:off+s.SizeOfRawData]==expected[off:off+s.SizeOfRawData]
 return bytes(b),dict(name=name,rva=rva,changes=[(s,len(o)) for s,o,_ in changes],symbols=symbols,code=code.hex(),filename=filename)

def decode(path):
 data=path.read_bytes();assert len(data)%32==0
 first=None
 for off in range(0,len(data),32):
  magic,event,tick,tid,eax,ecx,edi,error=struct.unpack_from('<8I',data,off);assert magic==0x31544457
  if first is None:first=tick
  print(f'{(tick-first)&0xffffffff:8} ms tid={tid:x} {EVENTS[event]:30} eax={eax:08x} ecx={ecx:08x} edi={edi:08x} error={error}')

if __name__=='__main__':
 import argparse
 a=argparse.ArgumentParser();a.add_argument('input',type=Path);a.add_argument('output',type=Path,nargs='?');v=a.parse_args()
 if v.output is None:decode(v.input)
 else:
  data,m=patch(v.input.read_bytes());v.output.write_bytes(data)
  Path(str(v.output)+'.json').write_text(json.dumps(m,indent=2)+'\n')
  print(hashlib.sha256(data).hexdigest())
