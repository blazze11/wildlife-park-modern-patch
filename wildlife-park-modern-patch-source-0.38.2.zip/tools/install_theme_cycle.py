#!/usr/bin/env python3
"""Install the verified theme-only build based on 0.30.1, replacing 0.32.0."""
import json
import os
import shutil
from patch_theme_cycle import ROOT, BASELINE, VERSION, build, digest
from workspace_paths import GAME

if __name__ == '__main__':
    index_path = ROOT/'builds/versions.json'
    index = json.loads(index_path.read_text())
    assert index['current'] == '0.32.0'
    assert not any(e['version'] == VERSION for e in index['versions'])
    checks = json.loads((ROOT/'analysis/theme-cycle-verification.json').read_text())
    assert {(r['name'], r['image_base']) for r in checks} == {
        (name, hex(base)) for name in BASELINE for base in (0x400000, 0x14000000)}
    plan = []
    for name in BASELINE:
        source = (ROOT/'builds/versions/0.32.0'/f'{name}.EXE').read_bytes()
        previous = next(e for e in index['versions'] if e['version']=='0.32.0')
        expected = next(f['sha256'] for f in previous['files'] if f['path'].endswith('/'+name+'.EXE'))
        assert digest(source) == expected
        candidate, metadata = build(name)
        assert (ROOT/'builds/versions'/VERSION/f'{name}.EXE').read_bytes() == candidate
        assert all(r['passed'] and r['sha256'] == digest(candidate) and
                   r['emittedcode_sha256'] == digest(metadata['code'])
                   for r in checks if r['name'] == name)
        target = GAME/'Int/Win32/Program/VC6'/f'{name}.EXE'
        assert target.read_bytes() == source
        assert (ROOT/'builds/current'/target.name).read_bytes() == source
        backup = ROOT/'archive/game-backups/0.32.0/pre-theme-cycle'/target.name
        if backup.exists():
            assert backup.read_bytes() == source
        plan.append((target, backup, source, candidate))
    targets = {t for t, _, _, _ in plan}
    def inventory():
        return {str(p.relative_to(GAME)): digest(p.read_bytes()) for p in GAME.rglob('*')
                if p.is_file() and p not in targets and
                not any(part.startswith('.') for part in p.relative_to(GAME).parts)}
    before = inventory()
    installed = []
    try:
        for target, backup, source, candidate in plan:
            backup.parent.mkdir(parents=True, exist_ok=True)
            if not backup.exists():
                backup.write_bytes(source)
            stage = target.with_name(target.name+'.theme-cycle.tmp')
            stage.write_bytes(candidate)
            stage.chmod(target.stat().st_mode)
            assert target.read_bytes() == source
            os.replace(stage, target)
            installed.append((target, source))
            assert target.read_bytes() == candidate
        assert inventory() == before, 'Other installation files changed during verification'
    except Exception:
        for target, source in reversed(installed):
            stage = target.with_name(target.name+'.theme-cycle-rollback.tmp')
            stage.write_bytes(source)
            stage.chmod(target.stat().st_mode)
            os.replace(stage, target)
        raise
    for target, backup, source, candidate in plan:
        shutil.copy2(target, ROOT/'builds/current'/target.name)
        assert (ROOT/'builds/current'/target.name).read_bytes() == candidate
    (ROOT/'builds/current/VERSION').write_text(VERSION+'\n')
    for entry in index['versions']:
        if entry['version'] == '0.32.0':
            entry['status'] = 'superseded; developer mode removed at user request'
    index['current'] = VERSION
    index['versions'].append(dict(version=VERSION, based_on='0.30.1',
        description='F2 Landschaft wechseln button calling native F9 theme cycle; built directly from 0.30.1 with developer mode disabled',
        status='current; native checks passed, gameplay validation pending',
        files=[dict(path=f'builds/versions/{VERSION}/{t.name}', sha256=digest(c), bytes=len(c))
               for t, b, s, c in plan]))
    index_path.write_text(json.dumps(index, indent=2)+'\n')
    report = dict(date='2026-10-13', version=VERSION, based_on='0.30.1',
        status='installed; restart required; gameplay validation pending', replaced_version='0.32.0',
        files=[dict(path=str(t), backup=str(b), before_sha256=digest(s), sha256=digest(c), bytes=len(c))
               for t, b, s, c in plan],
        other_installation_files_verified_unchanged=len(before), config_changed=False, saves_changed=False)
    report_path = ROOT/'analysis/theme-cycle-installation.json'
    report_path.write_text(json.dumps(report, indent=2)+'\n')
    inventory_path = ROOT/'analysis/edited-files-inventory.json'
    inv = json.loads(inventory_path.read_text())
    for t, b, s, c in plan:
        for entry in inv.get('installed_changed_files', []):
            if entry.get('path') == str(t):
                entry.update(sha256=digest(c), bytes=len(c))
        if str(b) not in inv['installed_patch_backups']:
            inv['installed_patch_backups'].append(str(b))
    for filename in ('theme_panel.py', 'verify_theme_panel.py',
                     'patch_theme_cycle.py', 'install_theme_cycle.py'):
        path = str(ROOT/'tools'/filename)
        if path not in inv['tools']:
            inv['tools'].append(path)
    for filename in ('native-developer-mode.md', 'native-developer-rea-evidence.json',
                     'native-developer-candidate.json', 'theme-cycle-verification.json',
                     'theme-cycle-installation.json'):
        path = str(ROOT/'analysis'/filename)
        if path not in inv['analysis_files']:
            inv['analysis_files'].append(path)
    inv['date'] = '2026-10-13'
    inventory_path.write_text(json.dumps(inv, indent=2)+'\n')
    print(json.dumps(report, indent=2))
