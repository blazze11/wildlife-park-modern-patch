#!/usr/bin/env python3
"""Execute added widget hooks at two image bases with native ABI mocks."""
import json,subprocess,tempfile
from pathlib import Path
from f2_weather_buttons import ROOT,build
from patch_debug_tools import digest

def verify(m):
 for base in (0x400000,0x14000000):
  pr=m['profile'];s=m['symbols'];rv=m['rva'];pics=m['pictures'];ready=m['ready'];sections={};bodies={}
  def mock(key,body):sections[key]=pr[key];bodies[key]=body
  mock('previous_ctor','mov eax,ecx\nret 4')
  mock('picture_ctor','mov DWORD PTR [ecx+4],OFFSET virtualbase\nmov DWORD PTR [ecx+8],OFFSET destructor_table\nmov eax,ecx\ninc DWORD PTR [constructs]\nret 4')
  mock('generic_attach','inc DWORD PTR [attachments]\nret 4')
  mock('previous_attach','mov DWORD PTR [root+0x5b8],OFFSET button_table\nmov DWORD PTR [root+0xbf0],OFFSET button_table\nmov DWORD PTR [root+0x1624],OFFSET button_table\nmov DWORD PTR [root+0x1c60],OFFSET button_table\ninc DWORD PTR [old_attached]\nret 4')
  mock('bounds','''mov eax,[esp+4]
 mov [ecx+0x40],eax
 mov eax,[esp+8]
 mov [ecx+0x44],eax
 mov eax,[esp+12]
 mov [ecx+0x48],eax
 mov eax,[esp+16]
 mov [ecx+0x4c],eax
 ret 16''')
  mock('enabled','ret 4')
  mock('previous_update','inc DWORD PTR [updates]\nret')
  mock('frame_set','mov eax,[esp+4]\nmov [ecx+0x29c],eax\nret 4')
  mock('generic_detach','inc DWORD PTR [detached]\nret')
  mock('previous_detach','inc DWORD PTR [old_detached]\nret')
  mock('previous_dtor','inc DWORD PTR [old_destroyed]\nret')
  sections['bank']=pr['bank'];bodies['bank']='.long OFFSET bank_vtable'
  checks=[]
  for i,(off,pic) in enumerate(zip(m['buttons'],pics)):
   for obj in (off,pic):
    for field,val in ((0x40,183),(0x44,52+42*i),(0x48,120),(0x4c,34)):
     checks.append(f'cmp DWORD PTR [root+{obj+field}],{val}\njne fail')
   checks.append(f'cmp DWORD PTR [root+{pic}+0x298],{base+pr["bank"]+0x80}\njne fail\ncmp DWORD PTR [root+{pic}+0x2a0],{134 if i==1 else 133}\njne fail')
   for bits,frame in ((0,0),(2,2),(3,1),(2,2),(0,0),(0,0)):
    checks.append(f'''mov ecx,OFFSET root+{off}
 mov BYTE PTR [ecx+0x29c],{bits}
 mov eax,[ecx]
 call DWORD PTR [eax]
 cmp DWORD PTR [root+{pic}+0x29c],{frame}
 jne fail''')
  asm=f'''.intel_syntax noprefix
.code32
.global start
.section .main,"ax"
start:
 mov [saved_sp],esp
 mov ecx,OFFSET root
 push 1
 call thunk+{s['constructor']}
 cmp eax,OFFSET root
 jne fail
 cmp DWORD PTR [root+{ready}],1
 jne fail
 mov ecx,OFFSET root+0xbf0
 push OFFSET root
 call thunk+{s['attach']}
 cmp DWORD PTR [constructs],3
 jne fail
 cmp DWORD PTR [attachments],3
 jne fail
 cmp DWORD PTR [old_attached],1
 jne fail
 {chr(10).join(checks)}
 # A close-widget refresh still chains the previously corrected implementation.
 mov ecx,OFFSET root+0xbf0
 mov eax,[ecx]
 call DWORD PTR [eax]
 cmp DWORD PTR [updates],22
 jne fail
 mov ecx,OFFSET root+0x1228
 call thunk+{s['detach']}
 cmp DWORD PTR [detached],3
 jne fail
 cmp DWORD PTR [old_detached],1
 jne fail
 mov ecx,OFFSET root+0x1620
 call thunk+{s['destructor']}
 mov ecx,OFFSET root+0x1620
 call thunk+{s['destructor']}
 cmp DWORD PTR [disposed],3
 jne fail
 cmp DWORD PTR [old_destroyed],2
 jne fail
 cmp esp,[saved_sp]
 jne fail
 xor ebx,ebx
 mov eax,1
 int 0x80
fail:
 mov ebx,1
 mov eax,1
 int 0x80
dispose:
 cmp DWORD PTR [esp+4],0
 jne fail
 inc DWORD PTR [disposed]
 ret 4
.section .thunk,"axw"
thunk: .incbin "CODEPATH"
.section .mockdata,"aw"
saved_sp: .long 0
constructs: .long 0
attachments: .long 0
updates: .long 0
old_attached: .long 0
detached: .long 0
old_detached: .long 0
disposed: .long 0
old_destroyed: .long 0
virtualbase: .long 0,4
bank_vtable: .zero 12
.long 0x80
destructor_table: .long dispose
button_table: .zero 128
root: .zero {m['size']}
'''
  for k,body in bodies.items():asm+=f'\n.section .{k},"axw"\n{body}\n'
  with tempfile.TemporaryDirectory() as tmp:
   d=Path(tmp);(d/'code.bin').write_bytes(m['code']);(d/'test.s').write_text(asm.replace('CODEPATH',str(d/'code.bin')));sections['thunk']=rv
   layout='\n'.join(f'.{k} {base+x} : {{ *(.{k}) }}' for k,x in sorted(sections.items(),key=lambda x:x[1]))
   (d/'test.ld').write_text(f'ENTRY(start)\nSECTIONS {{ .main {base+0x1000} : {{ *(.main) }}\n{layout}\n.mockdata {base+rv+0x10000} : {{ *(.mockdata) }} }}')
   subprocess.run(['as','--32','-o',str(d/'test.o'),str(d/'test.s')],check=True)
   subprocess.run(['ld','-m','elf_i386','-T',str(d/'test.ld'),'-o',str(d/'test'),str(d/'test.o')],check=True,capture_output=True)
   r=subprocess.run([str(d/'test')],timeout=10);assert r.returncode==0,(m['name'],hex(base),r.returncode)
 print('PASS '+m['name']+': three 120x34 pictures, repeated states, previous close update, guarded ownership and stack; two bases')
if __name__=='__main__':
 records=[]
 for name in ('WLP','WLPADD1'):
  data,m=build(name);verify(m);records.append(dict(name=name,passed=True,sha256=digest(data),code_sha256=digest(m['code']),image_bases=['0x400000','0x14000000']))
 (ROOT/'analysis/f2-weather-buttons-verification.json').write_text(json.dumps(records,indent=2)+'\n')
