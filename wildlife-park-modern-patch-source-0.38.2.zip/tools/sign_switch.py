#!/usr/bin/env python3
"""Restyle the accepted 0.34 switch with native logo hitboxes and hover frames."""
import json,struct,subprocess,tempfile
from pathlib import Path
import pefile
from patch_addon_widescreen import next_rva,append_section

ROOT=Path(__file__).resolve().parents[1]
BOUNDS={'WLP':(8,10,182,135),'WLPADD1':(35,0,255,145)}
def patch(data,name):
    old=next(e['patch'] for e in json.loads((ROOT/'analysis/launcher-switch-candidate.json').read_text()) if e['name']==name)
    p=pefile.PE(data=data);rva=next_rva(data);pr=old['profile'];sy=old['symbols'];oldr=old['rva']
    button=oldr+sy['button'];ready=oldr+sy['ready'];owner=oldr+sy['owner']
    raw=p.get_data(pr['setup_hook'],5);assert raw[0]==0xe8
    previous=pr['setup_hook']+5+struct.unpack('<i',raw[1:])[0]
    assert previous==oldr+sy['setup']
    ctor=p.get_data(pr['button_ctor'],200);i=ctor.index(b'\xc7\x06')
    native_vtable=struct.unpack_from('<I',ctor,i+2)[0]-p.OPTIONAL_HEADER.ImageBase
    native_hover=struct.unpack('<I',p.get_data(native_vtable+0x3c,4))[0]-p.OPTIONAL_HEADER.ImageBase
    frame_setter=0x15e8c0 if name=='WLP' else 0x188580
    x,y,w,h=BOUNDS[name]
    def call(dest):return f'.byte 0xe8\n.long {dest}-({rva}+.-_start+4)'
    asm=f'''.intel_syntax noprefix
.code32
.global _start
_start:
get_base:
 call anchor
anchor:
 pop ebx
 sub ebx,{rva}+anchor-_start
 ret
setup:
 push DWORD PTR [esp+4]
 {call(previous)}
 pushfd
 pushad
 cld
 call get_base
 cmp DWORD PTR [ebx+{ready}],1
 jne setup_done
 lea esi,[ebx+{native_vtable}]
 lea edi,[ebx+{rva}+vtable-_start]
 mov ecx,32
 rep movsd
 lea eax,[ebx+{rva}+hover-_start]
 mov DWORD PTR [ebx+{rva}+vtable-_start+0x3c],eax
 lea eax,[ebx+{rva}+vtable-_start]
 mov DWORD PTR [ebx+{button}],eax
 or DWORD PTR [ebx+{button}+0x244],0x10
 push {h}
 push {w}
 push {y}
 push {x}
 lea ecx,[ebx+{button}]
 {call(pr['bounds'])}
 lea eax,[ebx+{rva}+empty-_start]
 push eax
 lea ecx,[ebx+{button}]
 {call(pr['caption'])}
setup_done:
 popad
 popfd
 ret 4
hover:
 push esi
 mov esi,ecx
 push DWORD PTR [esp+8]
 {call(native_hover)}
 pushfd
 pushad
 call get_base
 cmp DWORD PTR [ebx+{ready}],1
 jne hover_done
 mov ecx,DWORD PTR [ebx+{owner}]
 test ecx,ecx
 je hover_done
 add ecx,0x2f0
 # Read the native result after its hover-enabled/leave checks.
 xor eax,eax
 cmp DWORD PTR [esi+0x240],0
 setne al
 push eax
 {call(frame_setter)}
hover_done:
 popad
 popfd
 pop esi
 ret 4
empty: .byte 0
.balign 4
vtable: .zero 128
'''
    with tempfile.TemporaryDirectory() as tmp:
        d=Path(tmp);(d/'sign.s').write_text(asm)
        subprocess.run(['as','--32','-o',str(d/'sign.o'),str(d/'sign.s')],check=True)
        assert 'R_386' not in subprocess.check_output(['objdump','-r',str(d/'sign.o')],text=True)
        subprocess.run(['objcopy','-O','binary','-j','.text',str(d/'sign.o'),str(d/'sign.bin')],check=True)
        code=(d/'sign.bin').read_bytes()
        symbols={a[2]:int(a[0],16) for line in subprocess.check_output(['nm',str(d/'sign.o')],text=True).splitlines() if len(a:=line.split())==3}
    b=bytearray(data);off=p.get_offset_from_rva(pr['setup_hook'])
    b[off:off+5]=b'\xe8'+struct.pack('<i',rva+symbols['setup']-pr['setup_hook']-5)
    append_section(b,b'.wlpsign',code)
    q=pefile.PE(data=b);struct.pack_into('<I',b,q.sections[-1].get_file_offset()+36,0xe0000020)
    return bytes(b),dict(name=name,rva=rva,code=code,symbols=symbols,
        changes=[(pr['setup_hook'],5)],reloc_offsets=[],button=button,ready=ready,owner=owner,
        previous=previous,native_vtable=native_vtable,native_hover=native_hover,
        frame_setter=frame_setter,bounds=BOUNDS[name],profile=pr)
