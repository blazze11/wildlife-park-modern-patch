#!/usr/bin/env python3
"""10 percentage-point zoom; native endpoints and scaled intermediate world view."""
import argparse,hashlib,struct,subprocess,tempfile
from pathlib import Path
import pefile
from patch_addon_widescreen import append_section,next_rva
PROFILES={
'2fe9f1d75866c80096a369e9c705736677178f4f7529c54323ed0f4d24eee882':dict(selector=0x9050,frame_hook=0x86eb,render=0xe510,calc=0xdee0,alloc=0x19abbe,release=0x19aaca,mode=0x33ac48,widths=0x33ac4c,heights=0x33ac5c,screenw=0x33abb8,screenh=0x33abbc,hud_hook=0xdf13,hud=0x304824,plus=0x119ef9,minus=0x119f2b,key_end=0x11a7e9,control=0xc564,addon=False,weatherflags=0x4005a,weatherenabled=0x33ac6f,lookup=0x19cf0,manager=0xa56984,raindesc=0x8af550,snowdesc=0x8af570,bind=0x13020,finish=0x1295c,queue=0x38),
'8951a55ded77c912aad4ed2688677b5aa9fc880861373ce6b95620176e6c15a6':dict(selector=0x8cc0,frame_hook=0x8583,render=0xe190,calc=0xdd00,alloc=0x1c715e,release=0x1c706a,mode=0x36ddf8,widths=0x36ddfc,heights=0x36de0c,screenw=0x36dd68,screenh=0x36dd6c,hud_hook=0xdd33,hud=0x334824,plus=0x12c710,minus=0x12c742,key_end=0x12d033,control=0xc5ac,addon=True,weatherflags=0x4005e,weatherenabled=0x36de1e,lookup=0x1b7d0,manager=0xc43304,raindesc=0xa3b8b0,snowdesc=0xa3b8d0,bind=0x13cd0,finish=0x12f0c,queue=0x3c),
}
def patch(src):
 p=pefile.PE(data=src);pr=PROFILES[hashlib.sha256(src).hexdigest()];rva=next_rva(src)
 def call(target):return f'.byte 0xe8\n.long {target}-({rva}+.-entry+4)'
 asm=f'''.intel_syntax noprefix
.code32
.global entry,select_hook,frame_hook,hud_hook,key_plus,key_minus,context
entry:
get_context:
 call anchor
anchor:
 pop eax
 add eax,context-anchor
 mov edx,eax
 sub edx,{rva}+context-entry
 mov [eax],edx
 ret
select_hook:
 pushfd
 pushad
 call get_context
 push DWORD PTR [esp+40]
 push DWORD PTR [esp+28]
 push eax
 call zoom_step
 add esp,12
 popad
 popfd
 ret 4
frame_hook:
 pushfd
 pushad
 call get_context
 push DWORD PTR [esp+44]
 push DWORD PTR [esp+44]
 push DWORD PTR [esp+32]
 push eax
 call zoom_frame
 add esp,16
 popad
 popfd
 ret 8
hud_hook:
 pushfd
 push eax
 push edx
 call get_context
 fsub DWORD PTR [eax+40]
 pop edx
 pop eax
 popfd
 ret
finish_call:
 pushfd
 pushad
 call get_context
 push DWORD PTR [esp+24]
 push eax
 call zoom_finish
 add esp,8
 popad
 popfd
 ret
finish_hook:
 push ecx
 mov ecx,ebx
 call finish_call
 pop ecx
 mov ebp,[ebx+{pr['queue']}]
 mov ecx,[ebp+0x34]
 jmp entry+{pr['finish']+6-rva}
key_plus:
 mov ecx,[ebp+{pr['control']}]
 push 1
 {call(pr['selector'])}
 jmp entry+{pr['key_end']-rva}
key_minus:
 mov ecx,[ebp+{pr['control']}]
 push 2
 {call(pr['selector'])}
 jmp entry+{pr['key_end']-rva}
'''
 if pr['addon']:
  for name,mode in [('addon_in',1),('addon_out',2)]:
   asm+=f'''{name}:
 push esi
 mov esi,ecx
 mov ecx,[esi+{pr['control']}]
 push {mode}
 {call(pr['selector'])}
 mov ecx,[esi+{pr['control']}]
 mov eax,[ecx+0x64]
 mov BYTE PTR [eax+0xe0],0xff
 mov BYTE PTR [ecx+0x5b],0
 push 1
 lea ecx,[esi+0x96a0]
 {call(0x119820)}
 pop esi
 mov al,1
 ret 8
'''
 asm+='\n.section .data\n.balign 4\ncontext:\n.long 0,'+','.join(str(pr[k]) for k in ['render','calc','alloc','release','mode','widths','heights','screenw','screenh'])+'\n.long 0x42f80000,0,0,0\n.zero 20+5120*4\n.long '+','.join(str(pr[k]) for k in ['weatherflags','weatherenabled','lookup','manager','raindesc','snowdesc','bind'])+'\n.zero 20\n.long '+str(pr['queue'])+'\n'
 with tempfile.TemporaryDirectory() as tmp:
  d=Path(tmp);(d/'hooks.s').write_text(asm)
  subprocess.run(['as','--32','-o',str(d/'hooks.o'),str(d/'hooks.s')],check=True)
  subprocess.run(['gcc','-m32','-O2','-fPIC','-fvisibility=hidden','-ffreestanding','-fno-stack-protector','-fno-asynchronous-unwind-tables','-c',str(Path(__file__).with_name('zoom_steps.c')),'-o',str(d/'core.o')],check=True)
  (d/'link.ld').write_text('ENTRY(entry)\nSECTIONS { .text 0 : { *(.text*) *(.rodata*) *(.got*) *(.data*) *(.bss*) } /DISCARD/ : { *(.comment) *(.note*) *(.eh_frame*) } }')
  subprocess.run(['ld','-m','elf_i386','-T',str(d/'link.ld'),'-o',str(d/'linked'),str(d/'hooks.o'),str(d/'core.o')],check=True,capture_output=True)
  assert not subprocess.check_output(['nm','-u',str(d/'linked')],text=True).strip()
  assert 'R_386' not in subprocess.check_output(['objdump','-r',str(d/'linked')],text=True)
  subprocess.run(['objcopy','-O','binary','-j','.text',str(d/'linked'),str(d/'code')],check=True);code=(d/'code').read_bytes()
  sy={a[2]:int(a[0],16) for line in subprocess.check_output(['nm',str(d/'linked')],text=True).splitlines() if len(a:=line.split())==3}
 b=bytearray(src);changes=[]
 def replace(h,old,new):
  assert len(old)==len(new);off=p.get_offset_from_rva(h);assert b[off:off+len(old)]==old,hex(h)
  b[off:off+len(old)]=new;changes.append((h,len(old)))
 def jump(h,old,label):replace(h,old,b'\xe9'+struct.pack('<i',rva+sy[label]-h-5)+b'\x90'*(len(old)-5))
 jump(pr['selector'],bytes.fromhex('8b442404568bf1'),'select_hook')
 h=pr['frame_hook'];replace(h,b'\xe8'+struct.pack('<i',pr['render']-h-5),b'\xe8'+struct.pack('<i',rva+sy['frame_hook']-h-5))
 h=pr['hud_hook'];replace(h,b'\xd8\x25'+struct.pack('<I',0x400000+pr['hud']),b'\xe8'+struct.pack('<i',rva+sy['hud_hook']-h-5)+b'\x90')
 jump(pr['finish'],b'\x8b\x6b'+bytes([pr['queue']])+b'\x8b\x4d\x34','finish_hook')
 for name in ['plus','minus']:jump(pr[name],b'\x8b\x8d'+struct.pack('<I',pr['control']),'key_'+name)
 if pr['addon']:
  jump(0x124b70,bytes.fromhex('568bf16a01'),'addon_in')
  jump(0x124bd0,bytes.fromhex('568bf18b8e')+struct.pack('<I',pr['control']),'addon_out')
 rel=[]
 for block in p.DIRECTORY_ENTRY_BASERELOC:
  for e in block.entries:
   if e.type and any(h<=e.rva<h+n for h,n in changes):
    off=e.struct.get_file_offset();struct.pack_into('<H',b,off,struct.unpack_from('<H',b,off)[0]&0xfff);rel.append(off)
 assert len(rel)==1
 append_section(b,b'.wlpzoom',code);np=pefile.PE(data=b);struct.pack_into('<I',b,np.sections[-1].get_file_offset()+36,0xe0000020)
 return bytes(b),dict(rva=rva,code=code,symbols=sy,profile=pr,changes=changes,reloc_offsets=rel)
if __name__=='__main__':
 a=argparse.ArgumentParser(description=__doc__);a.add_argument('input',type=Path);a.add_argument('output',type=Path);args=a.parse_args();b,m=patch(args.input.read_bytes());args.output.open('xb').write(b);print(args.output,hashlib.sha256(b).hexdigest())
