#!/usr/bin/env python3
"""Install 0.35.2 native texture-index correction; keep accepted executables unchanged."""
import json,os,shutil,hashlib
from pathlib import Path
from workspace_paths import ROOT
from patch_debug_tools import check_preservation
from workspace_paths import GAME

VERSION='0.35.2'
def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        while b:=f.read(1024*1024):h.update(b)
    return h.hexdigest()
if __name__=='__main__':
    ip=ROOT/'builds/versions.json';index=json.loads(ip.read_text())
    assert index['current']=='0.35.1' and not any(e['version']==VERSION for e in index['versions'])
    records=json.loads((ROOT/'analysis/menu-frame-index-candidate.json').read_text())
    plan=[];retained=[]
    for r in records:
        target=GAME/r['path'];candidate=Path(r['candidate'])
        assert r['native_lookup_frames_verified']>0
        assert r['payload_and_offset_table_unchanged']
        assert sha(target)==r['source_sha256'] and sha(candidate)==r['sha256']
        plan.append(dict(target=target,candidate=candidate,before=r['source_sha256'],after=r['sha256']))
    out=ROOT/'builds/versions'/VERSION;out.mkdir(exist_ok=True)
    previous=next(e for e in index['versions'] if e['version']=='0.35.1')
    for name in ('WLP','WLPADD1'):
        source=ROOT/'builds/versions/0.35.1'/f'{name}.EXE'
        expected=next(f['sha256'] for f in previous['files'] if f['path'].endswith('/'+name+'.EXE'))
        assert sha(source)==expected==sha(GAME/'Int/Win32/Program/VC6'/source.name)==sha(ROOT/'builds/current'/source.name)
        candidate=out/source.name
        if candidate.exists():assert sha(candidate)==expected
        else:shutil.copy2(source,candidate)
        retained.append(dict(path=str(candidate.relative_to(ROOT)),sha256=expected,bytes=candidate.stat().st_size))
    targets={p['target'] for p in plan}
    def inventory():
        return {str(p.relative_to(GAME)):sha(p) for p in GAME.rglob('*') if p.is_file() and p not in targets and not any(s.startswith('.') for s in p.relative_to(GAME).parts)}
    before=inventory();installed=[]
    for p in plan:
        p['backup']=ROOT/'archive/game-backups/0.35.1/pre-frame-index-fix'/p['target'].relative_to(GAME)
        p['backup'].parent.mkdir(parents=True,exist_ok=True)
        if not p['backup'].exists():shutil.copy2(p['target'],p['backup'])
        assert sha(p['backup'])==p['before']
    try:
        for p in plan:
            stage=p['target'].with_name(p['target'].name+'.sign-switch.tmp')
            shutil.copy2(p['candidate'],stage)
            assert sha(stage)==p['after'] and sha(p['target'])==p['before']
            os.replace(stage,p['target']);installed.append(p)
            assert sha(p['target'])==p['after']
        assert inventory()==before,'Other game files changed during installation'
    except Exception:
        for p in reversed(installed):
            stage=p['target'].with_name(p['target'].name+'.sign-rollback.tmp')
            shutil.copy2(p['backup'],stage);os.replace(stage,p['target'])
        raise
    for p in plan:
        if p['target'].suffix=='.EXE':shutil.copy2(p['target'],ROOT/'builds/current'/p['target'].name)
        else:shutil.copy2(p['target'],ROOT/'assets/current'/p['target'].name)
    (ROOT/'builds/current/VERSION').write_text(VERSION+'\n')
    for e in index['versions']:
        if e['version']=='0.35.1':e['status']='superseded; menu hover user-confirmed; native image frame indices corrupted gameplay UI'
    files=retained+[dict(path=str(p['candidate'].relative_to(ROOT)),sha256=p['after'],bytes=p['candidate'].stat().st_size) for p in plan]
    index['current']=VERSION
    index['versions'].append(dict(version=VERSION,based_on='0.35.1',description='Correct first-frame indices after the extra menu texture frame; restore gameplay GUI lookups; executable hover and switching unchanged',status='current; native-index lookup regression passed; gameplay validation pending',asset_version='0.35.2',files=files))
    ip.write_text(json.dumps(index,indent=2)+'\n')
    report=dict(version=VERSION,based_on='0.35.1',status='installed; restart required; in-game validation pending',date='2026-10-13',
        files=[dict(path=str(p['target']),backup=str(p['backup']),before_sha256=p['before'],sha256=p['after']) for p in plan],
        other_game_files_verified_unchanged=len(before),config_changed=False,saves_changed=False)
    (ROOT/'analysis/menu-frame-index-installation.json').write_text(json.dumps(report,indent=2)+'\n')
    invp=ROOT/'analysis/edited-files-inventory.json';inv=json.loads(invp.read_text())
    for p in plan:
        entries=inv['installed_changed_files'];entry=next((e for e in entries if e.get('path')==str(p['target'])),None)
        if entry is None:entry=dict(path=str(p['target']));entries.append(entry)
        entry.update(sha256=p['after'],bytes=p['target'].stat().st_size)
        if str(p['backup']) not in inv['installed_patch_backups']:inv['installed_patch_backups'].append(str(p['backup']))
    for key,folder,names in [('tools','tools',['fix_menu_frame_indices.py','install_menu_frame_index_fix.py','prepare_sign_assets.py']),
                             ('analysis_files','analysis',['menu-frame-index-fix.md','menu-frame-index-candidate.json','menu-frame-index-installation.json'])]:
        for name in names:
            value=str(ROOT/folder/name)
            if value not in inv[key]:inv[key].append(value)
    invp.write_text(json.dumps(inv,indent=2)+'\n')
    print(json.dumps(report,indent=2))
