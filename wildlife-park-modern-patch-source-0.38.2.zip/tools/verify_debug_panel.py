#!/usr/bin/env python3
"""Execute appended F2 controls with native 32-bit lifecycle/API mocks."""
import subprocess,tempfile
from pathlib import Path
from debug_panel import SIZE,READY,BUTTONS


def verify(m):
    sy,pr=m['symbols'],m['profile']
    for base in (0x400000,0x14000000):
        with tempfile.TemporaryDirectory() as tmp:
            d=Path(tmp);(d/'code.bin').write_bytes(m['code'])
            cycle='\n'.join(f'''mov DWORD PTR [step],{3+i}
 mov ecx,OFFSET root
 push 0
 push 0
 call thunk+{sy['toggle_'+str(i)]}
 cmp al,1
 jne fail
 cmp DWORD PTR [flags],{(1<<(i+1))-1}
 jne fail
 cmp esp,[saved_sp]
 jne fail''' for i in range(3))
            cycle_off='\n'.join(f'''mov ecx,OFFSET root
 push 0
 push 0
 call thunk+{sy['toggle_'+str(i)]}
 cmp DWORD PTR [flags],{7 & ~((1<<(i+1))-1)}
 jne fail''' for i in range(3))
            asm=f'''.intel_syntax noprefix
.code32
.global start
.section .main,"ax"
start:
 mov [saved_sp],esp
 mov DWORD PTR [step],1
 mov ecx,OFFSET root
 push 1
 call thunk+{sy['constructor']}
 cmp eax,OFFSET root
 jne fail
 cmp DWORD PTR [root+{READY}],1
 jne fail
 cmp DWORD PTR [constructed],3
 jne fail
 cmp esp,[saved_sp]
 jne fail
 mov DWORD PTR [step],2
 mov ecx,OFFSET root+0xbf0
 push OFFSET root
 call thunk+{sy['attach_buttons']}
 cmp DWORD PTR [attached],3
 jne fail
 cmp DWORD PTR [registered],3
 jne fail
 cmp DWORD PTR [bounds_called],3
 jne fail
 cmp DWORD PTR [enabled_called],3
 jne fail
 cmp DWORD PTR [caption_called],3
 jne fail
 cmp esp,[saved_sp]
 jne fail
 {cycle}
 {cycle_off}
 cmp DWORD PTR [caption_called],9
 jne fail
 mov DWORD PTR [step],6
 mov ecx,OFFSET root+0x1228
 call thunk+{sy['detach_buttons']}
 cmp DWORD PTR [detached],3
 jne fail
 cmp DWORD PTR [old_detached],1
 jne fail
 cmp esp,[saved_sp]
 jne fail
 mov DWORD PTR [step],7
 mov ecx,OFFSET root+0x1620
 call thunk+{sy['destructor']}
 cmp DWORD PTR [destroyed],3
 jne fail
 cmp DWORD PTR [root+{READY}],0
 jne fail
 cmp DWORD PTR [old_destroyed],1
 jne fail
 cmp esp,[saved_sp]
 jne fail
 call thunk+{sy['destructor']}
 cmp DWORD PTR [destroyed],3
 jne fail
 cmp DWORD PTR [old_destroyed],2
 jne fail
 cmp esp,[saved_sp]
 jne fail
 xor ebx,ebx
 mov eax,1
 int 0x80
fail:
 mov ebx,[step]
 mov eax,1
 int 0x80
.section .previous_ctor,"ax"
 cmp ecx,OFFSET root
 jne fail
 cmp DWORD PTR [esp+4],1
 jne fail
 mov eax,ecx
 ret 4
.section .button_ctor,"ax"
 cmp DWORD PTR [esp+4],1
 jne fail
 mov eax,[constructed]
 imul eax,{0x638}
 add eax,OFFSET root+{BUTTONS[0]}
 cmp ecx,eax
 jne fail
 inc DWORD PTR [constructed]
 ret 4
.section .previous_attach,"ax"
 cmp ecx,OFFSET root+0xbf0
 jne fail
 cmp DWORD PTR [esp+4],OFFSET root
 jne fail
 ret 4
.section .attach,"ax"
 jmp check_attach
.section .main,"ax"
check_attach:
 cmp DWORD PTR [esp+4],OFFSET root
 jne fail
 mov eax,[attached]
 imul eax,{0x638}
 add eax,OFFSET root+{BUTTONS[0]}
 cmp ecx,eax
 jne fail
 inc DWORD PTR [attached]
 ret 4
.section .bounds,"ax"
 mov eax,[bounds_called]
 cmp eax,2
 je third_bounds
 cmp DWORD PTR [esp+4],10
 jne first_x
 jmp good_x
first_x:
 cmp DWORD PTR [esp+4],150
 jne fail
good_x:
 cmp DWORD PTR [esp+8],465
 jne fail
 cmp DWORD PTR [esp+12],130
 jne fail
 jmp height
third_bounds:
 cmp DWORD PTR [esp+4],10
 jne fail
 cmp DWORD PTR [esp+8],489
 jne fail
 cmp DWORD PTR [esp+12],270
 jne fail
height:
 cmp DWORD PTR [esp+16],20
 jne fail
 inc DWORD PTR [bounds_called]
 ret 16
.section .enabled,"ax"
 cmp DWORD PTR [esp+4],1
 jne fail
 inc DWORD PTR [enabled_called]
 ret 4
.section .register,"ax"
 cmp DWORD PTR [esp+4],0x0e
 jne fail
 cmp DWORD PTR [esp+8],OFFSET root
 jne fail
 mov eax,[registered]
 mov eax,[callbacks+eax*4]
 cmp eax,[esp+12]
 jne fail
 inc DWORD PTR [registered]
 ret 24
.section .caption,"ax"
 push esi
 mov eax,ecx
 sub eax,OFFSET root+{BUTTONS[0]}
 xor edx,edx
 mov esi,{0x638}
 div esi
 cmp eax,2
 ja fail
 test edx,edx
 jne fail
 bt DWORD PTR [flags],eax
 jc on_caption
 mov eax,[off_captions+eax*4]
 jmp check_caption
on_caption:
 mov eax,[on_captions+eax*4]
check_caption:
 cmp eax,[esp+8]
 jne fail
 inc DWORD PTR [caption_called]
 pop esi
 ret 4
.section .previous_detach,"ax"
 cmp ecx,OFFSET root+0x1228
 jne fail
 inc DWORD PTR [old_detached]
 ret
.section .detach,"ax"
 jmp check_detach
.section .main,"ax"
check_detach:
 mov eax,2
 sub eax,[detached]
 imul eax,{0x638}
 add eax,OFFSET root+{BUTTONS[0]}
 cmp ecx,eax
 jne fail
 inc DWORD PTR [detached]
 ret
.section .button_dtor,"ax"
 mov eax,2
 sub eax,[destroyed]
 imul eax,{0x638}
 add eax,OFFSET root+{BUTTONS[0]+0x630}
 cmp ecx,eax
 jne fail
 inc DWORD PTR [destroyed]
 ret
.section .previous_dtor,"ax"
 cmp ecx,OFFSET root+0x1620
 jne fail
 inc DWORD PTR [old_destroyed]
 ret
.section .thunk,"awx"
thunk: .incbin "{d/'code.bin'}"
.section .flags,"aw"
flags: .long 0
.section .data,"aw"
callbacks: .long {','.join(str(base+m['rva']+sy['toggle_'+str(i)]) for i in range(3))}
off_captions: .long {','.join(str(base+m['rva']+sy['caption_off_'+str(i)]) for i in range(3))}
on_captions: .long {','.join(str(base+m['rva']+sy['caption_on_'+str(i)]) for i in range(3))}
saved_sp: .long 0
step: .long 0
constructed: .long 0
attached: .long 0
registered: .long 0
bounds_called: .long 0
enabled_called: .long 0
caption_called: .long 0
detached: .long 0
old_detached: .long 0
destroyed: .long 0
old_destroyed: .long 0
root: .zero {SIZE}
'''
            sections={n:pr[n] for n in ('previous_ctor','button_ctor','previous_attach','attach','bounds','caption','enabled','register','previous_detach','detach','button_dtor','previous_dtor')}
            sections.update(thunk=m['rva'], flags=m['flags_rva'])
            # Keep mock/data independent from code; flags can precede patch section.
            layout='\n'.join(f'.{k} {base+v} : {{ *(.{k}) }}' for k,v in sorted(sections.items(),key=lambda x:x[1]))
            (d/'test.s').write_text(asm)
            (d/'test.ld').write_text(f'ENTRY(start)\nSECTIONS {{ .main {base+0x1000} : {{ *(.main) }}\n{layout}\n.data {base+m["rva"]+0x10000} : {{ *(.data) }} }}')
            subprocess.run(['as','--32','-o',str(d/'test.o'),str(d/'test.s')],check=True)
            r=subprocess.run(['ld','-m','elf_i386','-T',str(d/'test.ld'),'-o',str(d/'test'),str(d/'test.o')],capture_output=True,text=True)
            assert r.returncode==0,r.stderr
            r=subprocess.run([str(d/'test')],timeout=10)
            assert r.returncode==0,(hex(base),r.returncode)
    print('PASS: debug panel native constructor/attach/callbacks/toggle/detach/destructor, two image bases')


def main():
    import argparse, hashlib, json
    from debug_hud import patch as hud_patch
    from debug_panel import patch as panel_patch
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--baseline',type=Path,default=Path(__file__).resolve().parents[1]/'builds/versions/0.30.1')
    ap.add_argument('--output',type=Path,default=Path(__file__).resolve().parents[1]/'analysis/debug-panel-verification.json')
    args=ap.parse_args()
    records=[]
    for name in ('WLP','WLPADD1'):
        data=(args.baseline/(name+'.EXE')).read_bytes()
        data,hm=hud_patch(data,name)
        data,pm=panel_patch(data,name,hm)
        verify(pm)
        for base in (0x400000,0x14000000):
            records.append(dict(name=name,image_base=hex(base),passed=True,
                                flags_rva=hex(pm['flags_rva']),
                                emittedcode_sha256=hashlib.sha256(pm['code']).hexdigest(),
                                scope='Native lifecycle wrappers, callback registration, caption selection, toggle isolation, geometry and ABI using engine mocks'))
    args.output.write_text(json.dumps(records,indent=2)+'\n')


if __name__=='__main__':
    main()
