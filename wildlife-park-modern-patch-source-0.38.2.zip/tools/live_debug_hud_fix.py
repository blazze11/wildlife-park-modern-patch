#!/usr/bin/env python3
"""Bounded live diagnostic: redirect 0.31.0 HUD dimensions to the active mode.

Only instruction operands inside the verified injected HUD are changed. The
running game and its save data are retained; restart loads the permanent fix.
"""
import argparse, json, os, socket, struct, subprocess, time
from pathlib import Path
import pefile
from live_tps_test import ROOT, WINE, PREFIX

def run(pid, tag, inspect_only=False):
    meta=next(x for x in json.loads((ROOT/'builds/versions/0.31.0/debug-metadata.json').read_text()) if x['name']==tag)
    # Preserve the immutable 0.31.0 metadata even after a newer build is made.
    p=pefile.PE(str(ROOT/'builds/versions/0.31.0'/f'{tag}.EXE'))
    hud=next(s for s in p.sections if s.Name.rstrip(b'\0')==b'.wlphud')
    rva=hud.VirtualAddress
    old_width,old_height,mode,widths,heights=(0x33abb8,0x33abbc,0x33ac48,0x33ac4c,0x33ac5c) if tag=='WLP' else (0x36dd68,0x36dd6c,0x36ddf8,0x36ddfc,0x36de0c)
    base=p.OPTIONAL_HEADER.ImageBase
    expected=p.get_data(rva,meta['hud']['symbols']['flags'])
    env=dict(os.environ,WINEPREFIX=PREFIX)
    log=(ROOT/'analysis/debug-live-winedbg.log').open('w')
    proc=subprocess.Popen([WINE,'winedbg','--gdb','--no-start','--port','31379',hex(pid)],env=env,stdout=log,stderr=log)
    sock=None;changed=[];report=dict(name=tag,pid=hex(pid),writes=[])
    try:
        deadline=time.monotonic()+15
        while time.monotonic()<deadline:
            if proc.poll() is not None: raise RuntimeError('WineDbg exited before connection')
            try:
                sock=socket.create_connection(('127.0.0.1',31379),timeout=1);break
            except ConnectionRefusedError: time.sleep(.1)
        if sock is None: raise RuntimeError('No debugger connection')
        sock.settimeout(10)
        def packet(cmd):
            raw=cmd.encode();sock.sendall(b'$'+raw+b'#'+f'{sum(raw)&255:02x}'.encode())
            while sock.recv(1)!=b'$': pass
            data=bytearray()
            while (ch:=sock.recv(1))!=b'#':
                if not ch: raise RuntimeError('Closed connection')
                data.extend(ch)
            check=sock.recv(2)
            while len(check)<2:check+=sock.recv(2-len(check))
            assert sum(data)&255==int(check,16)
            sock.sendall(b'+');return data.decode()
        def read(addr,n):
            result=bytes.fromhex(packet(f'm{addr:x},{n:x}'));assert len(result)==n;return result
        def word(addr):return struct.unpack('<I',read(addr,4))[0]
        def write(addr,value):
            assert packet(f'M{addr:x},{len(value):x}:{value.hex()}')=='OK'
            assert read(addr,len(value))==value
        packet('?')
        selected=word(base+mode);assert 0<=selected<4
        width,height=word(base+widths+selected*4),word(base+heights+selected*4)
        assert width in (1280,1920,2560) and height in (720,800,1080,1440)
        def state():
            sy=meta['hud']['symbols'];cs=meta['console']['symbols'];cr=meta['console']['rva']
            return {**{k:word(base+rva+sy[k]) for k in ('flags','console_visible','last_width','last_height')},
                    **{k:word(base+cr+cs[k]) for k in ('focused','held','mapkey','foreground')}}
        report.update(mode=selected,actual_dimensions=[width,height],before=state(),
                      bad_dimensions=[word(base+old_width),word(base+old_height)])
        owner=word(base+meta['hud']['feedback']['owner'])
        if owner:
            label=owner+0x620
            report['label_address']=hex(label)
            report['label_memory']=read(label,0x330).hex()
            report['owner_bounds']=read(owner+0xa8,16).hex()
            for field in (0x30c,0x31c):
                pointer=word(label+field)
                report[f'text_{field:x}']=read(pointer,128).split(b'\0')[0].decode('cp1252',errors='replace') if pointer else ''
        if not inspect_only:
            assert read(base+rva,len(expected))==expected,'Unexpected running HUD code'
            for old,new in ((old_width,widths+selected*4),(old_height,heights+selected*4)):
                needle=struct.pack('<I',old);pos=0
                while (pos:=expected.find(needle,pos))>=0:
                    addr=base+rva+pos;value=struct.pack('<I',new)
                    changed.append((addr,read(addr,4)))
                    write(addr,value)
                    report['writes'].append(dict(address=hex(addr),before=needle.hex(),after=value.hex()))
                    pos+=4
            assert len(changed)==7
        report['status']='inspected' if inspect_only else 'live-instruction-operands-corrected'
    except Exception:
        if sock is not None:
            for addr,value in reversed(changed):write(addr,value)
        raise
    finally:
        if sock is not None:
            report['detached']=packet('D')=='OK';sock.close()
        proc.wait(timeout=10);log.close()
    path=ROOT/('analysis/debug-live-state.json' if inspect_only else 'analysis/debug-live-fix.json')
    path.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--pid',type=lambda v:int(v,0),required=True)
    ap.add_argument('--tag',choices=('WLP','WLPADD1'),required=True);ap.add_argument('--inspect',action='store_true')
    a=ap.parse_args();run(a.pid,a.tag,a.inspect)
