#!/usr/bin/env python3
"""Use real elapsed time for toolbar holds, including work-area +/- actions."""
import argparse
import hashlib
import os
import shutil
import struct
import subprocess
import tempfile
from pathlib import Path
from workspace_paths import artifact, backup_path
import pefile
from patch_addon_widescreen import append_section, next_rva

PROFILES={
 '8e967b4baa6bcd1d92cb5365d569ba4264b42fcadce9dfa009485b97e69f0f5d':
     dict(hook=0x113308,allow=0x11331b,skip=0x113377,counter=0x8ca0be),
 'e55b3ab73ab532c32122072b94360f27b0e3444925078dbdb4329980f0e11b66':
     dict(hook=0x125338,allow=0x12534b,skip=0x1253a7,counter=0xa578a6),
}

def patch(src):
    profile=PROFILES[hashlib.sha256(src).hexdigest()]
    p=pefile.PE(data=src)
    rva=next_rva(src)
    tick=next(i.address-0x400000 for d in p.DIRECTORY_ENTRY_IMPORT
              for i in d.imports if i.name==b'timeGetTime')
    asm=f'''.intel_syntax noprefix
.code32
.global _start
_start:
 pushfd
 pushad
 call base
 lea ebp,[ebx+{rva}+state-_start]
 mov esi,[esp+24]
 mov edi,[esp]
 call DWORD PTR [ebx+{tick}]
 movzx edx,WORD PTR [esi+0x34]
 cmp DWORD PTR [esi+0x4c],0
 je first
 cmp [ebp],edi
 jne first
 cmp [ebp+4],edx
 jne first
 mov ecx,eax
 sub ecx,[ebp+8]
 cmp ecx,[ebp+12]
 jb skip
 mov DWORD PTR [ebp+12],120
 jmp allow
first:
 mov [ebp],edi
 mov [ebp+4],edx
 mov DWORD PTR [ebp+12],400
allow:
 mov [ebp+8],eax
 popad
 popfd
 jmp _start+{profile['allow']-rva}
skip:
 popad
 popfd
 jmp _start+{profile['skip']-rva}
base:
 call anchor
anchor:
 pop ebx
 sub ebx,{rva}+anchor-_start
 ret
.balign 4
state: .zero 16
'''
    with tempfile.TemporaryDirectory() as tmp:
        d=Path(tmp)
        (d/'repeat.s').write_text(asm)
        subprocess.run(['as','--32','-o',str(d/'repeat.o'),str(d/'repeat.s')],check=True)
        assert 'R_386' not in subprocess.check_output(['objdump','-r',str(d/'repeat.o')],text=True)
        subprocess.run(['objcopy','-O','binary','-j','.text',str(d/'repeat.o'),str(d/'repeat.bin')],check=True)
        code=(d/'repeat.bin').read_bytes()
    b=bytearray(src)
    h=profile['hook']
    old=b'\xa0'+struct.pack('<I',0x400000+profile['counter'])+b'\xfe\xc0\xa2'+struct.pack('<I',0x400000+profile['counter'])
    off=p.get_offset_from_rva(h)
    assert b[off:off+12]==old
    b[off:off+12]=b'\xe9'+struct.pack('<i',rva-h-5)+b'\x90'*7
    reloc_offsets=[]
    for block in p.DIRECTORY_ENTRY_BASERELOC:
        for e in block.entries:
            if e.type and h<=e.rva<h+12:
                off=e.struct.get_file_offset()
                struct.pack_into('<H',b,off,struct.unpack_from('<H',b,off)[0]&0xfff)
                reloc_offsets.append(off)
    assert len(reloc_offsets)==2
    append_section(b,b'.wlptbar',code)
    np=pefile.PE(data=b)
    struct.pack_into('<I',b,np.sections[-1].get_file_offset()+36,0xe0000020)
    return bytes(b),dict(rva=rva,code=code,tick=tick,profile=profile,reloc_offsets=reloc_offsets)

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--install',action='store_true')
    args=parser.parse_args()
    for name in ('WLP','WLPADD1'):
        src=artifact(f'{name}_widescreen_button_repeat.EXE').read_bytes()
        out,m=patch(src)
        artifact(f'{name}_widescreen_toolbar_repeat.EXE').write_bytes(out)
        print(name,hashlib.sha256(out).hexdigest())
        if args.install:
            root=Path('/path/to/Wildlife Park Gold/Int/Win32/Program/VC6')
            target=root/f'{name}.EXE'
            assert target.read_bytes()==src
            backup=backup_path(target.with_name(target.name+'.pre-toolbar-repeat.bak'))
            if backup.exists():
                assert backup.read_bytes()==src
            else:
                shutil.copy2(target,backup)
            staged=target.with_name(target.name+'.toolbar-repeat.tmp')
            staged.write_bytes(out)
            staged.chmod(target.stat().st_mode)
            os.replace(staged,target)
            assert target.read_bytes()==out
            print('Installed',target)
