#!/usr/bin/env python3
"""Normalize the calendar's eight minutes/tick to the original 25 TPS rate."""
import hashlib
import json
import struct
import subprocess
import tempfile
from pathlib import Path
import pefile
from patch_addon_widescreen import append_section, next_rva

ROOT = Path(__file__).resolve().parents[1]
PROFILES = {
    '2fe9f1d75866c80096a369e9c705736677178f4f7529c54323ed0f4d24eee882':
        dict(name='WLP', hook=0xeb069, tps=0x33ac89),
    '2673b3f647f8c3f0f3362c0791c6ddb0f236bc02d8c273d3f9d6d706accaf42b':
        dict(name='WLPADD1', hook=0xfaa39, tps=0x36de35),
}

def patch(src):
    profile = PROFILES[hashlib.sha256(src).hexdigest()]
    pe = pefile.PE(data=src)
    h = profile['hook']
    original = bytes.fromhex('8a561d80c2088ac288561d')
    off = pe.get_offset_from_rva(h)
    assert src[off:off+13] == original + bytes.fromhex('3c3c')
    # Validate the profile's TPS address against config read/write references
    # before using it in generated code.
    assert pe.get_data(profile['tps'], 1) == b'\x19'
    rva = next_rva(src)
    asm = f'''.intel_syntax noprefix
.code32
.global entry
entry:
 pushfd
 pushad
 call anchor
anchor:
 pop ebx
 sub ebx,{rva}+anchor-entry
 lea edi,[ebx+{rva}+state-entry]
 movzx ecx,BYTE PTR [ebx+{profile['tps']}]
 # For unsupported low/zero rates, retain native eight minutes/tick.
 cmp ecx,25
 jb native
 cmp [edi],esi
 jne reset
 cmp [edi+4],ecx
 je advance
reset:
 mov [edi],esi
 mov [edi+4],ecx
 mov DWORD PTR [edi+8],0
advance:
 mov eax,[edi+8]
 add eax,200
 xor edx,edx
 div ecx
 mov [edi+8],edx
 jmp apply
native:
 mov DWORD PTR [edi],0
 mov eax,8
apply:
 add al,BYTE PTR [esi+0x1d]
 mov BYTE PTR [esi+0x1d],al
 # Replay the original low-byte AL/DL outputs, retaining all other bits.
 mov BYTE PTR [esp+20],al
 mov BYTE PTR [esp+28],al
 popad
 popfd
 jmp entry+{h+11-rva}
.balign 4
state: .zero 12
'''
    with tempfile.TemporaryDirectory() as tmp:
        d = Path(tmp)
        (d/'calendar.s').write_text(asm)
        subprocess.run(['as', '--32', '-o', str(d/'calendar.o'), str(d/'calendar.s')], check=True)
        assert 'R_386' not in subprocess.check_output(['objdump', '-r', str(d/'calendar.o')], text=True)
        subprocess.run(['objcopy', '-O', 'binary', '-j', '.text', str(d/'calendar.o'), str(d/'calendar.bin')], check=True)
        code = (d/'calendar.bin').read_bytes()
    result = bytearray(src)
    result[off:off+11] = b'\xe9' + struct.pack('<i', rva-h-5) + b'\x90'*6
    assert not any(e.type and h <= e.rva < h+11
                   for block in pe.DIRECTORY_ENTRY_BASERELOC for e in block.entries)
    append_section(result, b'.wlptime', code)
    new_pe = pefile.PE(data=result)
    struct.pack_into('<I', result, new_pe.sections[-1].get_file_offset()+36, 0xe0000020)
    for section in pe.sections:
        start, end = section.PointerToRawData, section.PointerToRawData+section.SizeOfRawData
        expected = bytearray(src[start:end])
        if start <= off < end:
            expected[off-start:off-start+11] = result[off:off+11]
        assert result[start:end] == expected
    return bytes(result), dict(profile=profile, rva=rva, code=code)

if __name__ == '__main__':
    out = ROOT/'builds/versions/0.30.1'
    out.mkdir(exist_ok=True)
    records = []
    for name in ('WLP', 'WLPADD1'):
        src = (ROOT/f'builds/versions/0.30.0/{name}.EXE').read_bytes()
        data, meta = patch(src)
        target = out/f'{name}.EXE'
        if target.exists():
            assert target.read_bytes() == data, 'Immutable candidate differs'
        else:
            target.write_bytes(data)
        records.append(dict(name=name, source_sha256=hashlib.sha256(src).hexdigest(),
                            sha256=hashlib.sha256(data).hexdigest(), bytes=len(data),
                            path=str(target), hook_rva=hex(meta['profile']['hook']),
                            section_rva=hex(meta['rva'])))
    (ROOT/'analysis/tps-calendar-candidate.json').write_text(json.dumps(records, indent=2)+'\n')
    print(json.dumps(records, indent=2))
