#!/usr/bin/env python3
"""Execute the actual HUD x86 against bounded mocked engine callbacks."""
import json
import hashlib
import subprocess
import tempfile
from pathlib import Path
import pefile
from debug_hud import patch

ROOT=Path(__file__).resolve().parents[1]

def verify(tag,base):
    src=(ROOT/'builds/versions/0.30.1'/f'{tag}.EXE').read_bytes()
    out,m=patch(src,tag)
    p=m['profile']; old=m['feedback']; pe=pefile.PE(data=src)
    section=next(s for s in pe.sections if s.Name.rstrip(b'\0')==b'.wlpui')
    with tempfile.TemporaryDirectory() as tmp:
        d=Path(tmp);(d/'hud.bin').write_bytes(m['code'])
        (d/'old.bin').write_bytes(pe.get_data(section.VirtualAddress,section.Misc_VirtualSize))
        syms='\n'.join(f'.set {n},hud+{v}' for n,v in m['symbols'].items())
        oldsyms='\n'.join(f'.set old_{n},{base+old[n]}' for n in ['pending','active','started','owner'])
        cases=[]
        def case(code):
            cases.append(f'mov DWORD PTR [step],{len(cases)+1}\n'+code+'\ncmp esp,[saved_sp]\njne fail\n')
        case('''mov DWORD PTR [tick_now],100
mov DWORD PTR [frames],5
mov DWORD PTR [ticks],5
mov ebx,IMAGE
call sample
cmp DWORD PTR [frames],0
jne fail
cmp DWORD PTR [ticks],0
jne fail
mov DWORD PTR [frames],30
mov DWORD PTR [ticks],25
mov DWORD PTR [tick_now],600
call sample
cmp DWORD PTR [fps],60
jne fail
cmp DWORD PTR [measured_tps],50
jne fail
cmp DWORD PTR [frame_ms],16
jne fail''')
        case('''mov DWORD PTR [frames],30
mov DWORD PTR [ticks],0
mov DWORD PTR [tick_now],1100
call sample
cmp DWORD PTR [measured_tps],0
jne fail
cmp DWORD PTR [fps],60
jne fail
mov DWORD PTR [sample_start],0xffffff00
mov DWORD PTR [tick_now],0x100
mov DWORD PTR [ticks],25
call sample
cmp DWORD PTR [measured_tps],48
jne fail''')
        case('''mov DWORD PTR [sample_start],1000
mov DWORD PTR [tick_now],1500
mov DWORD PTR [frames],0
mov DWORD PTR [ticks],20
mov ebx,IMAGE
call sample
cmp DWORD PTR [fps],0
jne fail
cmp DWORD PTR [frame_ms],0
jne fail
cmp DWORD PTR [measured_tps],40
jne fail''')
        case('''mov eax,0x1234
mov ecx,0x4321
mov edx,0x7777
mov esi,OFFSET root
mov DWORD PTR [flags],0
mov DWORD PTR [old_pending],3
mov DWORD PTR [tick_now],10000
call update
cmp eax,0x1234
jne fail
cmp ecx,0x4321
jne fail
cmp edx,0x7777
jne fail
cmp DWORD PTR [old_active],3
jne fail
cmp DWORD PTR [shown],1
jne fail
cmp DWORD PTR [rect_x],10
jne fail
cmp DWORD PTR [rect_y],1340
jne fail
cmp DWORD PTR [rect_w],2540
jne fail
cmp DWORD PTR [rect_h],100
jne fail''')
        case('''mov DWORD PTR [tick_now],13999
call update
cmp DWORD PTR [old_active],3
jne fail
mov DWORD PTR [tick_now],14000
call update
cmp DWORD PTR [old_active],0
jne fail
cmp DWORD PTR [shown],0
jne fail
mov eax,[last_text]
cmp BYTE PTR [eax],32
jne fail
cmp BYTE PTR [eax+1],0
jne fail''')
        case('''mov DWORD PTR [old_pending],9
call update
cmp DWORD PTR [old_pending],0
jne fail
cmp DWORD PTR [old_active],0
jne fail
cmp DWORD PTR [shown],0
jne fail''')
        case('''mov DWORD PTR [old_pending],4
mov DWORD PTR [tick_now],0xffffff00
call update
mov DWORD PTR [tick_now],0x00000e9f
call update
cmp DWORD PTR [old_active],4
jne fail
mov DWORD PTR [tick_now],0x00000ea0
call update
cmp DWORD PTR [old_active],0
jne fail''')
        case('''mov DWORD PTR [old_pending],5
mov esi,OFFSET other_root
call update
cmp DWORD PTR [old_owner],OFFSET other_root
jne fail
cmp DWORD PTR [old_active],5
jne fail
mov esi,OFFSET root
call update
cmp DWORD PTR [old_active],0
jne fail''')
        case('''mov DWORD PTR [flags],7
call update
cmp DWORD PTR [shown],1
jne fail
mov DWORD PTR [console_visible],1
call update
cmp DWORD PTR [rect_y],1280
jne fail
cmp DWORD PTR [rect_h],160
jne fail''')
        case('''mov DWORD PTR [console_visible],0
mov DWORD PTR [root+0x620+0x28c],0x00ffffff
mov DWORD PTR [root+0x620+0x2c8],1
mov DWORD PTR [root+0x620+0x2cc],3
mov DWORD PTR [root+0x620+0x2d0],0x20
mov DWORD PTR [draw_count],0
mov DWORD PTR [green_count],0
push OFFSET notice
push OFFSET dummyrect
mov ecx,OFFSET root+0x620
call draw_hook
cmp DWORD PTR [draw_count],4
jne fail
cmp DWORD PTR [green_count],3
jne fail
cmp DWORD PTR [root+0x620+0x28c],0x00ffffff
jne fail
cmp DWORD PTR [root+0x620+0x2c8],1
jne fail
cmp DWORD PTR [root+0x620+0x2cc],3
jne fail
cmp DWORD PTR [root+0x620+0x2d0],0x20
jne fail''')
        case('''mov DWORD PTR [console_visible],1
mov DWORD PTR [draw_count],0
push OFFSET notice
push OFFSET dummyrect
mov ecx,OFFSET root+0x620
call draw_hook
cmp DWORD PTR [draw_count],7
jne fail
mov DWORD PTR [chain_count],0
push OFFSET notice
push OFFSET dummyrect
mov ecx,OFFSET other_root+0x620
call draw_hook
cmp DWORD PTR [chain_count],1
jne fail''')
        case('''mov DWORD PTR [sample_start],0x1000
mov DWORD PTR [tick_now],0x1001
mov DWORD PTR [frames],0
push 0xaaaa
push 0xbbbb
mov ecx,0x12345678
call frame_hook
cmp eax,0x2468
jne fail
cmp ecx,0x1357
jne fail
cmp edx,0x3579
jne fail
cmp DWORD PTR [frames],1
jne fail''')
        case('''mov esi,OFFSET simulation
mov DWORD PTR [simulation+0x40],0x1234
mov DWORD PTR [simulation+0x68],0x4321
mov DWORD PTR [ticks],0
call tick_hook
cmp eax,0x1234
jne fail
cmp ecx,0x4321
jne fail
cmp DWORD PTR [ticks],1
jne fail''')
        asm=f'''.intel_syntax noprefix
.code32
{syms}
{oldsyms}
.set IMAGE,{base}
.global start
.section .main,"ax"
start:
mov [saved_sp],esp
{chr(10).join(cases)}
mov eax,1
xor ebx,ebx
int 0x80
fail:
mov eax,1
mov ebx,[step]
int 0x80
.section .time_mock,"ax"
time_mock:
mov eax,[tick_now]
ret
.section .time,"aw"
.long time_mock
.section .mode,"aw"
video_mode: .long 3
.section .widths,"aw"
.long 1280,1280,1920,2560
.section .heights,"aw"
.long 720,800,1080,1440
.section .tps,"aw"
.byte 50
.section .continuation,"ax"
ret
.section .tick_continuation,"ax"
ret
.section .setter,"ax"
mov eax,[esp+4]
mov [last_text],eax
ret 4
.section .visible,"ax"
mov eax,[esp+4]
mov [shown],eax
ret 4
.section .bounds,"ax"
mov eax,[esp+4]
mov [rect_x],eax
mov eax,[esp+8]
mov [rect_y],eax
mov eax,[esp+12]
mov [rect_w],eax
mov eax,[esp+16]
mov [rect_h],eax
ret 16
.section .draw,"ax"
inc DWORD PTR [draw_count]
cmp DWORD PTR [ecx+0x28c],0x0000ff00
jne ordinary_color
inc DWORD PTR [green_count]
ordinary_color:
mov eax,[esp+4]
cmp DWORD PTR [eax],10
jl fail
cmp DWORD PTR [eax+8],2550
jne fail
mov edx,[eax+12]
sub edx,[eax+4]
cmp edx,16
jne fail
mov eax,0xdead
mov ecx,0xbeef
mov edx,0xcafe
ret 8
.section .chain,"ax"
inc DWORD PTR [chain_count]
ret 8
.section .frame,"ax"
cmp ecx,0x12345678
jne fail
cmp DWORD PTR [esp+4],0xbbbb
jne fail
cmp DWORD PTR [esp+8],0xaaaa
jne fail
mov eax,0x2468
mov ecx,0x1357
mov edx,0x3579
ret 8
.section .old,"aw"
.incbin "{d/'old.bin'}"
.section .hud,"awx"
hud: .incbin "{d/'hud.bin'}"
.section .data,"aw"
saved_sp: .long 0
step: .long 0
tick_now: .long 0
last_text: .long 0
shown: .long 0
rect_x: .long 0
rect_y: .long 0
rect_w: .long 0
rect_h: .long 0
draw_count: .long 0
green_count: .long 0
chain_count: .long 0
notice: .asciz "Park gespeichert"
dummyrect: .long 0,0,0,0
root: .zero 0xc00
other_root: .zero 0xc00
simulation: .zero 0x100
'''
        sections=dict(time=p['time'],mode=p['mode'],widths=p['widths'],heights=p['heights'],tps=p['tps'],
                      continuation=p['update']+45,tick_continuation=p['tick_hook']+6,
                      setter=p['setter'],visible=p['visible'],bounds=p['bounds'],draw=p['draw'],
                      chain=m['draw_chain'],frame=p['frame'],old=old['section_rva'],hud=m['rva'])
        layout='\n'.join(f'.{n} {base+r} : {{ *(.{n}) }}' for n,r in sorted(sections.items(),key=lambda x:x[1]))
        (d/'test.s').write_text(asm)
        (d/'test.ld').write_text(f'ENTRY(start)\nSECTIONS {{\n.main {base+0x1000} : {{ *(.main) }}\n{layout}\n.data : {{ *(.data) }}\n.time_mock : {{ *(.time_mock) }}\n}}\n')
        subprocess.run(['as','--32','-o',str(d/'test.o'),str(d/'test.s')],check=True)
        subprocess.run(['ld','-m','elf_i386','-T',str(d/'test.ld'),'-o',str(d/'test'),str(d/'test.o')],check=True)
        run=subprocess.run([str(d/'test')],timeout=10)
        assert run.returncode==0,(tag,hex(base),'case',run.returncode)
    return dict(name=tag,image_base=hex(base),cases=len(cases),status='passed',
                emittedcode_sha256=hashlib.sha256(m['code']).hexdigest(),
                checks=['sampling','pause','time wrapping','message expiry','owner changes',
                        'bottom bounds','green draws','style restoration','fallback chain','frame and tick ABI'])

if __name__=='__main__':
    results=[verify(tag,base) for tag in ['WLP','WLPADD1'] for base in [0x400000,0x14000000]]
    (ROOT/'analysis/debug-hud-verification.json').write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps(results,indent=2))
