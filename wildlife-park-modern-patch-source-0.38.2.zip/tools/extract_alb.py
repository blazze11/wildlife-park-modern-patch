#!/usr/bin/env python3
"""Extract Wildlife Park 16-bit ALB frames using the game's LZW variant."""
import argparse, hashlib, json, struct
from pathlib import Path
from PIL import Image

def decompress(data, expected):
    table={i:bytes([i]) for i in range(256)}
    next_code=258; width=9; bit=0; previous=None; result=bytearray()
    while len(result)<expected:
        if bit+width>len(data)*8: raise ValueError('Truncated LZW frame')
        pos,shift=divmod(bit,8)
        code=(int.from_bytes(data[pos:pos+4],'little')>>shift)&((1<<width)-1)
        bit+=width
        if code==256:
            table={i:bytes([i]) for i in range(256)}
            next_code=258; width=9; previous=None
            continue
        if code in table: value=table[code]
        elif code==next_code and previous is not None: value=previous+previous[:1]
        else: raise ValueError(f'Invalid LZW code {code}/{next_code}')
        result.extend(value)
        if previous is not None:
            table[next_code]=previous+value[:1]
            next_code+=1
            if next_code==(1<<width)-1:
                if width<12: width+=1
                else: next_code=258; width=9
        previous=value
    if len(result)!=expected: raise ValueError('Decoded size mismatch')
    return bytes(result)

def extract(source, destination):
    data=source.read_bytes()
    version,count,flags,unused,table_start,table_size=struct.unpack_from('<HHIIII',data)
    if version!=200 or flags!=272: raise ValueError('Only verified version-200 RGB565 ALB supported')
    offsets=struct.unpack_from(f'<{table_size//4}I',data,table_start)
    if offsets[-1]!=len(data): raise ValueError('Unexpected final offset')
    records=[];frame_index=0
    destination.mkdir(parents=True,exist_ok=False)
    for entry in range(count):
        record_offset=255+entry*64
        frames,w,h,raw_size,total_size,identifier=struct.unpack_from('<HHHIII',data,record_offset)
        if raw_size!=w*h*2 or total_size!=raw_size*frames: raise ValueError('Unexpected image layout')
        record={'entry':entry,'id':identifier,'width':w,'height':h,'frames':[],
                'header_hex':data[record_offset:record_offset+64].hex()}
        for frame in range(frames):
            raw=decompress(data[offsets[frame_index]:offsets[frame_index+1]],raw_size)
            rgb=bytearray()
            for (pixel,) in struct.iter_unpack('<H',raw):
                rgb.extend(((pixel>>11)*255//31,((pixel>>5)&63)*255//63,(pixel&31)*255//31))
            name=f'entry_{entry:03d}_frame_{frame:03d}.png'
            Image.frombytes('RGB',(w,h),bytes(rgb)).save(destination/name)
            # Preserve exact source pixels for a future repacker, avoiding RGB quantization loss.
            raw_name=f'entry_{entry:03d}_frame_{frame:03d}.rgb565'
            (destination/raw_name).write_bytes(raw)
            record['frames'].append({'png':name,'rgb565':raw_name,'offset':offsets[frame_index],
                                     'compressed_size':offsets[frame_index+1]-offsets[frame_index]})
            frame_index+=1
        records.append(record)
    if frame_index+1!=len(offsets): raise ValueError('Frame count mismatch')
    manifest={'source':str(source),'sha256':hashlib.sha256(data).hexdigest(),
              'format':'RGB565; PNGs retain visible pixel colors; transparency metadata remains in headers',
              'entries':records}
    (destination/'manifest.json').write_text(json.dumps(manifest,indent=2))
    (destination/'README.txt').write_text('Extracted Wildlife Park GUI images.\n\n'
        'Wide backgrounds:\nentry_000_frame_000.png: bottom bar, 1600 x 115\n'
        'entry_001_frame_000.png: bottom-bar upper overlay, 1600 x 50\n'
        'entry_104_frame_000.png: top bar, 1600 x 49\n\n'
        'Edit PNG copies. Keep filenames/IDs in manifest.json. Preserve .rgb565 files and headers.\n'
        'PNGs are RGB previews with original transparency-key pixels intact; no alpha was inferred.\n'
        'Import/repacking is not implemented yet. Enlarged images will also need placement validation.\n')
    print(f'Exported {count} entries / {frame_index} frames to {destination}')

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('source',type=Path);p.add_argument('destination',type=Path)
    a=p.parse_args();extract(a.source,a.destination)
