#!/usr/bin/env python3
"""Swap only the two frame immediates in the accepted 0.37.5 close hook."""
import json
import pefile
from patch_debug_tools import ROOT,digest,public
VERSION='0.37.6'
def check_preservation(before,after,m):
 assert len(before)==len(after)
 p=pefile.PE(data=before)
 expected=bytearray(before)
 for rva,length in m['changes']:
  off=p.get_offset_from_rva(rva);expected[off:off+length]=after[off:off+length]
 assert bytes(expected)==after
 assert sum(a!=b for a,b in zip(before,after))==2

def patch(data,name):
 record=next(x for x in json.loads((ROOT/'analysis/f2-button-style-candidate.json').read_text()) if x['name']==name)
 assert digest(data)==record['sha256']
 m=record['patch'];p=pefile.PE(data=data)
 start=m['rva']+m['symbols']['update'];end=m['rva']+m['symbols']['frame_ready']
 block=p.get_data(start,end-start)
 pattern=bytes.fromhex('b802000000f6819c020000017405b801000000')
 assert block.count(pattern)==1
 rva=start+block.index(pattern)
 changes=[(rva+1,1),(rva+15,1)]
 b=bytearray(data)
 for (at,_),old,new in zip(changes,(2,1),(1,2)):
  off=p.get_offset_from_rva(at);assert b[off]==old;b[off]=new
 code=p.get_data(m['rva'],m['code']['bytes']);newcode=pefile.PE(data=b).get_data(m['rva'],len(code))
 result=dict(name=name,code=bytes(newcode),changes=changes,reloc_offsets=[],hover_frame=1,pressed_frame=2)
 check_preservation(data,b,result);return bytes(b),result
if __name__=='__main__':
 out=ROOT/'builds/versions'/VERSION;out.mkdir(exist_ok=True);records=[];checks=[]
 for name in ('WLP','WLPADD1'):
  source=ROOT/'builds/versions/0.37.5'/f'{name}.EXE';data,m=patch(source.read_bytes(),name);f=out/source.name
  if f.exists():assert f.read_bytes()==data
  else:f.write_bytes(data)
  records.append(dict(name=name,sha256=digest(data),patch=public(m)))
  checks.append(dict(name=name,passed=True,sha256=digest(data),code_sha256=digest(m['code']),changed_bytes=2,hover_frame=1,pressed_frame=2))
 (ROOT/'analysis/f2-close-states-candidate.json').write_text(json.dumps(records,indent=2)+'\n')
 (ROOT/'analysis/f2-close-states-verification.json').write_text(json.dumps(checks,indent=2)+'\n')
 print(json.dumps(checks,indent=2))
