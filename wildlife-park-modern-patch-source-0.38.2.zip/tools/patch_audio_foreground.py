#!/usr/bin/env python3
"""Experimental v8: recover stale audio suspension after the main message pump."""
import hashlib
import struct
from pathlib import Path
from workspace_paths import artifact
import pefile
from patch_audio_startup import V6


def patch(src, expected_hash=V6, *, hook=0x244295, audio=0xa42730,
          foreground_window=0xa52fb0, regain=0x2735a0,
          module_api=0x304114, proc_api=0x304168, debug_api=0x30423c):
    if hashlib.sha256(src).hexdigest() != expected_hash:
        raise ValueError('Requires verified v6')
    p = pefile.PE(data=src)
    out = bytearray(src)
    align = lambda n, a: (n+a-1)//a*a
    last = p.sections[-1]
    rva = align(last.VirtualAddress + max(last.Misc_VirtualSize,last.SizeOfRawData),
                p.OPTIONAL_HEADER.SectionAlignment)
    raw = align(len(out),p.OPTIONAL_HEADER.FileAlignment)
    original = bytes.fromhex('5e5d5b83c45c')
    assert out[hook:hook+6] == original
    code = bytearray(b'\x9c\x60\xe8\x00\x00\x00\x00\x5b')
    anchor = rva+7
    code.extend(b'\x81\xeb'+struct.pack('<I',anchor))
    fixups = []
    exits = []

    def emit(data):
        code.extend(data)

    def data_ref(opcode,label):
        emit(opcode)
        fixups.append((len(code),label))
        emit(bytes(4))

    def branch(opcode,exit=False):
        emit(opcode+bytes(4))
        pos=len(code)-4
        if exit: exits.append(pos)
        return pos

    def resolve(pos):
        struct.pack_into('<i',code,pos,len(code)-pos-4)

    data_ref(b'\x83\xbb','busy');emit(b'\x00');branch(b'\x0f\x85',True)
    emit(b'\x8d\xb3'+struct.pack('<I',audio))
    emit(bytes.fromhex('f6460804'));branch(b'\x0f\x84',True) # Sound enabled
    emit(bytes.fromhex('83be9000000000'));branch(b'\x0f\x84',True) # Suspended
    emit(bytes.fromhex('83be8c00000000'));branch(b'\x0f\x84',True) # Initialized
    data_ref(b'\x8b\x83','foreground_api')
    emit(b'\x85\xc0');cached=branch(b'\x0f\x85')
    data_ref(b'\x8d\x83','user32');emit(b'\x50\xff\x93'+struct.pack('<I',module_api))
    emit(b'\x85\xc0');branch(b'\x0f\x84',True)
    data_ref(b'\x8d\x93','api_name');emit(b'\x52\x50\xff\x93'+struct.pack('<I',proc_api))
    emit(b'\x85\xc0');branch(b'\x0f\x84',True)
    data_ref(b'\x89\x83','foreground_api')
    resolve(cached)
    emit(b'\xff\xd0\x85\xc0');branch(b'\x0f\x84',True)
    emit(b'\x3b\x83'+struct.pack('<I',foreground_window));branch(b'\x0f\x85',True)
    data_ref(b'\xc7\x83','busy');emit(struct.pack('<I',1))
    data_ref(b'\x8d\x83','notice');emit(b'\x50\xff\x93'+struct.pack('<I',debug_api))
    emit(b'\x6a\x02\x8b\xce')
    emit(b'\xe8'+struct.pack('<i',regain-(rva+len(code)+5)))
    data_ref(b'\xc7\x83','busy');emit(bytes(4))
    for pos in exits: resolve(pos)
    emit(b'\x61\x9d'+original)
    emit(b'\xe9'+struct.pack('<i',hook+6-(rva+len(code)+5)))
    code_size=len(code)
    data={}
    for name,value in [('foreground_api',bytes(4)),('busy',bytes(4)),
                       ('user32',b'user32.dll\0'),('api_name',b'GetForegroundWindow\0'),
                       ('notice',b'WLP_AUDIO recovering suspended audio in foreground\n\0')]:
        data[name]=rva+len(code);emit(value)
    for pos,name in fixups:struct.pack_into('<I',code,pos,data[name])
    out[hook:hook+6]=b'\xe9'+struct.pack('<i',rva-hook-5)+b'\x90'
    header=p.sections[0].get_file_offset()+40*p.FILE_HEADER.NumberOfSections
    assert header+40<=p.OPTIONAL_HEADER.SizeOfHeaders and not any(out[header:header+40])
    size=align(len(code),p.OPTIONAL_HEADER.FileAlignment)
    out[header:header+40]=struct.pack('<8sIIIIIIHHI',b'.wlpaud',len(code),rva,size,raw,0,0,0,0,0xe0000060)
    struct.pack_into('<H',out,p.FILE_HEADER.get_field_absolute_offset('NumberOfSections'),p.FILE_HEADER.NumberOfSections+1)
    for field,value in [('SizeOfImage',align(rva+len(code),p.OPTIONAL_HEADER.SectionAlignment)),
                        ('SizeOfCode',p.OPTIONAL_HEADER.SizeOfCode+size),('CheckSum',0)]:
        struct.pack_into('<I',out,p.OPTIONAL_HEADER.get_field_absolute_offset(field),value)
    out.extend(bytes(raw-len(out))+code+bytes(size-len(code)))
    return bytes(out),code_size


if __name__=='__main__':
    out,size=patch(artifact('WLP_widescreen_v6.EXE').read_bytes())
    with artifact('WLP_widescreen_v8_audio_test.EXE').open('xb') as stream:stream.write(out)
    print('Code bytes:',size)
    print('SHA256:',hashlib.sha256(out).hexdigest())
