#!/usr/bin/env python3
"""Port the verified base-game widescreen/focus/audio fixes to Wild Creatures.

Only the SHA-256-identified expansion build is accepted. Input is preserved.
Offsets were mapped independently from the expansion's code and descriptors.
"""
import argparse
import hashlib
import struct
from pathlib import Path
import pefile
from patch_audio_foreground import patch as patch_audio

SOURCE_HASH = 'd3506449f81cc1358a140fa53e1512c01d04d8d5f71d51f27cb5ffee683f1250'
MODES = ((1280, 720), (1280, 800), (1920, 1080), (2560, 1440))
OLD = ((800, 600), (1024, 768), (1280, 1024), (1600, 1200))
GROUPS = ((32, 0xa2f1e8, 85), (24, 0xa2f758, 70),
          (15, 0xa2fca0, 40), (16, 0xa30150, 55), (8, 0xa30698, 25))
LABEL_CALLS = ((0x164438, 0), (0x16445d, 2), (0x164482, 1), (0x1644a7, 3))


def align(n, a):
    return (n + a - 1) // a * a


def next_rva(b):
    p = pefile.PE(data=b)
    s = p.sections[-1]
    return align(s.VirtualAddress + max(s.Misc_VirtualSize, s.SizeOfRawData),
                 p.OPTIONAL_HEADER.SectionAlignment)


def append_section(b, name, code):
    p = pefile.PE(data=b)
    rva = next_rva(b)
    raw = align(len(b), p.OPTIONAL_HEADER.FileAlignment)
    size = align(len(code), p.OPTIONAL_HEADER.FileAlignment)
    header = p.sections[0].get_file_offset() + 40 * p.FILE_HEADER.NumberOfSections
    assert header + 40 <= p.OPTIONAL_HEADER.SizeOfHeaders
    assert not any(b[header:header + 40])
    b[header:header + 40] = struct.pack('<8sIIIIIIHHI', name, len(code), rva,
                                      size, raw, 0, 0, 0, 0, 0x60000020)
    struct.pack_into('<H', b, p.FILE_HEADER.get_field_absolute_offset('NumberOfSections'),
                     p.FILE_HEADER.NumberOfSections + 1)
    for field, value in [('SizeOfImage', align(rva + len(code), p.OPTIONAL_HEADER.SectionAlignment)),
                         ('SizeOfCode', p.OPTIONAL_HEADER.SizeOfCode + size), ('CheckSum', 0)]:
        struct.pack_into('<I', b, p.OPTIONAL_HEADER.get_field_absolute_offset(field), value)
    b.extend(bytes(raw - len(b)) + code + bytes(size - len(code)))


def redirect(b, hook, original, target):
    assert b[hook:hook + len(original)] == original
    b[hook:hook + len(original)] = (b'\xe9' + struct.pack('<i', target - hook - 5)
                                   + b'\x90' * (len(original) - 5))


def patch(src):
    if hashlib.sha256(src).hexdigest() != SOURCE_HASH:
        raise ValueError('Unsupported WLPADD1.EXE SHA-256')
    b = bytearray(src)
    assert struct.unpack_from('<4I', b, 0x36ddfc) == tuple(w for w, h in OLD)
    assert struct.unpack_from('<4I', b, 0x36de0c) == tuple(h for w, h in OLD)
    struct.pack_into('<4I', b, 0x36ddfc, *(w for w, h in MODES))
    struct.pack_into('<4I', b, 0x36de0c, *(h for w, h in MODES))
    slots = {}
    for depth, last, last_index in GROUPS:
        found = set()
        for off in range(last - 14 * 80, last + 1, 80):
            w, h, d = struct.unpack_from('<III', b, off)
            if (w + 1, h + 1) not in OLD:
                continue
            assert d == depth
            choice = OLD.index((w + 1, h + 1))
            found.add(choice)
            nw, nh = MODES[choice]
            struct.pack_into('<II', b, off, nw - 1, nh - 1)
            slots[last_index - (last - off) // 80] = (nw, nh)
        assert found == set(range(4))
    assert len(slots) == 20

    # Bounded DirectDraw mode enumeration, identical to the working base filter.
    rva = next_rva(b)
    code = bytearray(bytes.fromhex('8b442404'))
    branches = []
    for width in (320, 640, 800, 1024, 1152, 1280, 1920, 2560):
        code += bytes.fromhex('81780c') + struct.pack('<I', width)
        branches.append(len(code))
        code += b'\x74\x00'
    code += bytes.fromhex('b801000000c20800')
    accepted = len(code)
    code += bytes.fromhex('83fa46')
    code += b'\x0f\x8c' + struct.pack('<i', 0x2bcfa0 - (rva + len(code) + 6))
    code += bytes.fromhex('33c0c20800')
    for branch in branches:
        code[branch + 1] = accepted - branch - 2
    redirect(b, 0x2bcf96, bytes.fromhex('83fa467c0533c0'), rva)
    append_section(b, b'.wlpmode', code)

    # Reapply the current RGB565 mode before restoring the primary surface.
    rva = next_rva(b)
    code = bytearray(bytes.fromhex('9c6085ff7400'))
    j1 = len(code) - 1
    code += bytes.fromhex('e8000000005a')
    anchor = rva + len(code) - 1
    code += b'\x81\xc2' + struct.pack('<i', 0xc3f964 - anchor)
    code += bytes.fromhex('8b0285c07400')
    j2 = len(code) - 1
    code += bytes.fromhex('6a006a00ffb7b80100008b8fb401000041518b8fb001000041518b1050ff5254')
    resume = len(code)
    original = bytes.fromhex('8b0850ff516c')
    code += bytes.fromhex('619d') + original
    code += b'\xe9' + struct.pack('<i', 0x2adce4 - (rva + len(code) + 5))
    for j in (j1, j2):
        code[j] = resume - j - 1
    redirect(b, 0x2adcde, original, rva)
    append_section(b, b'.wlpfoc', code)

    # Keep the abstract mode stack table consistent with the driver descriptors.
    rva = next_rva(b)
    code = bytearray()
    original = bytes.fromhex('8b942420040000')
    for index, (w, h) in sorted(slots.items()):
        for delta, value in ((0, w), (4, h)):
            code += bytes.fromhex('c78424') + struct.pack('<II', 0x10 + index * 12 + delta, value)
    code += original
    code += b'\xe9' + struct.pack('<i', 0x2acf1b - (rva + len(code) + 5))
    redirect(b, 0x2acf14, original, rva)
    for call, choice in LABEL_CALLS:
        assert b[call] == 0xe8
        assert call + 5 + struct.unpack_from('<i', b, call + 1)[0] == 0x216d50
        target = rva + len(code)
        code += bytes.fromhex('e8000000005883c005c3')
        w, h = MODES[choice]
        code += f'{w}x{h}'.encode('ascii') + b'\0'
        b[call:call + 5] = b'\xe8' + struct.pack('<i', target - call - 5)
    append_section(b, b'.wlpwide', code)

    # Audio object, focus callback, HWND and IAT mapped from expansion code.
    out, _ = patch_audio(bytes(b), hashlib.sha256(b).hexdigest(),
                         hook=0x272435, audio=0xc2f0b8, foreground_window=0xc3f938,
                         regain=0x2a11a0, module_api=0x334134, proc_api=0x334164,
                         debug_api=0x33422c)
    return out


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    result = patch(args.input.read_bytes())
    with args.output.open('xb') as stream:
        stream.write(result)
    print(f'Created {args.output}: {hashlib.sha256(result).hexdigest()}')
