#!/usr/bin/env python3
"""Execute skin thunks against native-ABI mocks, including failure paths."""
import json,subprocess,tempfile
from pathlib import Path
from f2_texture_skin import ROOT,build,VERSION
from patch_debug_tools import digest
def verify(m):
 for base in (0x400000,0x14000000):
  p=m['profile'];s=m['symbols'];r=m['rva']
  checks='\n'.join(f'cmp DWORD PTR [root+{b}],{base+r+s["button_vtable"]}\njne fail' for b in m['buttons'])
  calls=''
  for mode,locks,unlocks,blits in ((0,1,1,1),(1,1,0,0),(2,1,1,0),(3,1,1,0),(4,0,0,0)):
   for widget,entry in (('root',81),('root+0x1624',89)):
    calls+=f'''mov DWORD PTR [mode],{mode}
mov DWORD PTR [expected_widget],OFFSET {widget}
mov DWORD PTR [expected_entry],{entry}
mov DWORD PTR [locks],0
mov DWORD PTR [unlocks],0
mov DWORD PTR [blits],0
mov DWORD PTR [draws],0
mov DWORD PTR [bank],OFFSET vbtable
'''
    if mode==4:calls+='mov DWORD PTR [bank],0\n'
    calls+=f'''mov ecx,OFFSET {widget}
mov eax,[ecx]
call DWORD PTR [eax+0x24]
cmp DWORD PTR [locks],{locks}
jne fail
cmp DWORD PTR [unlocks],{unlocks}
jne fail
cmp DWORD PTR [blits],{blits}
jne fail
cmp DWORD PTR [draws],1
jne fail
cmp esp,[saved_sp]
jne fail
'''
  asm=f'''.intel_syntax noprefix
.code32
.global start
.section .main,"ax"
start:
mov [saved_sp],esp
mov BYTE PTR [root+0x527],0x7b
mov ecx,OFFSET root+0xbf0
push OFFSET root
call thunk+{s['attach']}
cmp esp,[saved_sp]
jne fail
cmp DWORD PTR [root],{base+r+s['root_vtable']}
jne fail
{checks}
cmp DWORD PTR [root+0x524],0x7bd8e8f0
jne fail
mov esi,{base+p['root_vtable']}
mov edi,{base+r+s['root_vtable']}
call compare_tables
mov esi,{base+p['button_vtable']}
mov edi,{base+r+s['button_vtable']}
call compare_tables
{calls}
xor ebx,ebx
mov eax,1
int 0x80
compare_tables:
xor ecx,ecx
compare_loop:
cmp ecx,0x24
je next_slot
mov eax,[esi+ecx]
cmp eax,[edi+ecx]
jne fail
next_slot:
add ecx,4
cmp ecx,128
jb compare_loop
ret
fail:
mov ebx,1
mov eax,1
int 0x80
.section .previous_attach,"ax"
cmp DWORD PTR [esp+4],OFFSET root
jne fail
ret 4
.section .root_draw,"ax"
inc DWORD PTR [draws]
ret
.section .button_draw,"ax"
inc DWORD PTR [draws]
ret
.section .image,"ax"
cmp ecx,OFFSET bank+16
jne fail
mov eax,OFFSET image_data
cmp DWORD PTR [mode],2
jne image_done
xor eax,eax
image_done: ret
.section .rectangle,"ax"
cmp ecx,[expected_widget]
jne fail
mov eax,[esp+4]
mov DWORD PTR [eax],0
mov DWORD PTR [eax+4],0
mov DWORD PTR [eax+8],270
mov DWORD PTR [eax+12],20
cmp ecx,OFFSET root
jne rect_size
mov DWORD PTR [eax+8],300
mov DWORD PTR [eax+12],530
rect_size:
cmp DWORD PTR [mode],3
jne rect_done
mov DWORD PTR [eax+8],0
rect_done: ret 4
.section .blit,"ax"
mov eax,[expected_widget]
add eax,0x124
cmp ecx,eax
jne fail
cmp DWORD PTR [esp+4],0
jne fail
cmp DWORD PTR [esp+8],0
jne fail
mov eax,270
mov edx,20
cmp DWORD PTR [expected_entry],81
jne blit_size
mov eax,300
mov edx,530
blit_size:
cmp [esp+12],eax
jne fail
cmp [esp+16],edx
jne fail
cmp DWORD PTR [esp+20],OFFSET image_data
jne fail
inc DWORD PTR [blits]
ret 20
.section .root_vtable,"aw"
.rept 9
.long 0x12345678
.endr
.long {base+p['root_draw']}
.rept 22
.long 0x12345678
.endr
.section .button_vtable,"aw"
.rept 9
.long 0x98765432
.endr
.long {base+p['button_draw']}
.rept 22
.long 0x98765432
.endr
.section .bank,"aw"
bank: .long vbtable
.zero 12
.long bank_vtable
.section .thunk,"axw"
thunk: .incbin "CODEPATH"
.section .data,"awx"
lock:
cmp ecx,OFFSET bank+16
jne fail
cmp DWORD PTR [esp+4],0
jne fail
mov eax,[expected_entry]
cmp [esp+8],eax
jne fail
inc DWORD PTR [locks]
mov eax,1
cmp DWORD PTR [mode],1
jne lock_done
xor eax,eax
lock_done: ret 8
unlock:
cmp ecx,OFFSET bank+16
jne fail
cmp DWORD PTR [esp+4],0
jne fail
mov eax,[expected_entry]
cmp [esp+8],eax
jne fail
inc DWORD PTR [unlocks]
ret 8
bank_vtable: .long lock,unlock
vbtable: .zero 12
.long 16
saved_sp: .long 0
expected_widget: .long 0
expected_entry: .long 0
mode: .long 0
locks: .long 0
unlocks: .long 0
blits: .long 0
draws: .long 0
image_data: .zero 16
root: .zero 0x229c
'''
  sec={k:p[k] for k in ('previous_attach','root_draw','button_draw','image','rectangle','blit','root_vtable','button_vtable','bank')};sec['thunk']=r
  with tempfile.TemporaryDirectory() as tmp:
   d=Path(tmp);(d/'code.bin').write_bytes(m['code']);(d/'test.s').write_text(asm.replace('CODEPATH',str(d/'code.bin')))
   layout='\n'.join(f'.{k} {base+a} : {{ *(.{k}) }}' for k,a in sorted(sec.items(),key=lambda x:x[1]))
   (d/'test.ld').write_text(f'ENTRY(start)\nSECTIONS {{ .main {base+0x1000} : {{ *(.main) }}\n{layout}\n.data {base+r+0x10000} : {{ *(.data) }} }}')
   subprocess.run(['as','--32','-o',str(d/'test.o'),str(d/'test.s')],check=True)
   subprocess.run(['ld','-m','elf_i386','-T',str(d/'test.ld'),'-o',str(d/'test'),str(d/'test.o')],check=True,capture_output=True)
   result=subprocess.run([str(d/'test')],timeout=10)
   assert result.returncode==0,(m['name'],hex(base),result.returncode)
 print('PASS '+m['name']+': native table preservation, texture arguments, failure cleanup and stack balance at two image bases')
if __name__=='__main__':
 checks=[]
 for name in ('WLP','WLPADD1'):
  data,m=build(name);assert data==(ROOT/'builds/versions'/VERSION/f'{name}.EXE').read_bytes();verify(m)
  checks.append(dict(name=name,passed=True,sha256=digest(data),code_sha256=digest(m['code']),image_bases=['0x400000','0x14000000']))
 (ROOT/'analysis/f2-texture-verification.json').write_text(json.dumps(checks,indent=2)+'\n')
