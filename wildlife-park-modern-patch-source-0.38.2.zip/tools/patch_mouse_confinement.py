#!/usr/bin/env python3
"""Confine the mouse to focused windowed gameplay; release it on focus loss.

Chain the existing message-pump audio fix and preserve every prior patch.
Use the game-world lifetime pointer to leave the launcher unconstrained.
ClipCursor/GetForegroundWindow/ClientToScreen resolve from user32 at runtime.
"""
import argparse
import hashlib
import struct
from pathlib import Path
import pefile
from patch_addon_widescreen import append_section, next_rva, redirect

PROFILES = {
    'e828e5d3e0c2ee9a44e767bb3a7154d0bd87ac7307034bec5346ac99ad72ea10':
        (0, 0x244295, 0x2735a0),
    '91d0ccfb7d185fdc35e92ddf0e2b08d8f4203ef0b75255e744fddf160c82581f':
        (0x1ec988, 0x272435, 0x2a11a0),
}


def patch(src, window_events=False, focused_gameplay=False, cache_rectangle=False, lifecycle=False,
          background_filter=False):
    if background_filter and not lifecycle:
        raise ValueError('Background filtering requires lifecycle handling')
    if lifecycle and not (window_events and focused_gameplay and cache_rectangle):
        raise ValueError('Lifecycle handling requires window events, focused gameplay and rectangle cache')
    profile = PROFILES.get(hashlib.sha256(src).hexdigest())
    if profile is None:
        raise ValueError('Requires known launcher-fixed executable')
    delta, pump, focus = profile
    p = pefile.PE(data=src)
    imports = {i.name.decode(): i.address - p.OPTIONAL_HEADER.ImageBase
               for dll in p.DIRECTORY_ENTRY_IMPORT for i in dll.imports if i.name}
    b = bytearray(src)
    assert b[pump] == 0xe9
    old_audio = pump + 5 + struct.unpack_from('<i', b, pump + 1)[0]
    assert old_audio == next(s.VirtualAddress for s in p.sections
                             if s.Name.rstrip(b'\0') == b'.wlpaud')
    rva = next_rva(b)
    mouse_dispatch = 0x278ed0 if delta else 0x24edf0
    assert src[mouse_dispatch:mouse_dispatch + 6] == bytes.fromhex('568bf15733ff')
    code, refs, branches, labels = bytearray(), [], [], {}

    def emit(data):
        code.extend(data)

    def ref(op, name):
        emit(op)
        refs.append((len(code), name))
        emit(bytes(4))

    def api(name):
        emit(b'\xff\x93' + struct.pack('<I', imports[name]))

    def jump(op, name):
        emit(op)
        branches.append((len(code), name))
        emit(bytes(4))

    def label(name):
        labels[name] = len(code)

    def begin():
        emit(bytes.fromhex('9c60e8000000005b'))
        anchor = rva + len(code) - 1
        emit(b'\x81\xeb' + struct.pack('<I', anchor))
        emit(bytes.fromhex('83ec18'))  # RECT + saved last error; local to each invocation
        api('GetLastError')
        emit(bytes.fromhex('89442414'))

    def finish(target=None):
        emit(bytes.fromhex('ff742414'))
        api('SetLastError')
        emit(bytes.fromhex('83c418619d'))
        if target is None:
            emit(b'\xc3')
        else:
            emit(b'\xe9' + struct.pack('<i', target - (rva + len(code) + 5)))

    begin()
    ref(b'\x83\xbb', 'busy'); emit(b'\x00')
    jump(b'\x0f\x85', 'pump_done')
    ref(b'\xc7\x83', 'busy'); emit(struct.pack('<I', 1))
    # Resolve all three APIs once; imported functions retain the original IAT.
    for name in ('ClipCursor', 'GetForegroundWindow', 'ClientToScreen'):
        ref(b'\x83\xbb', name); emit(b'\x00')
        jump(b'\x0f\x85', 'ready_' + name)
        ref(b'\x8d\x83', 'user32'); emit(b'\x50')
        api('GetModuleHandleA')
        emit(b'\x85\xc0'); jump(b'\x0f\x84', 'release')
        ref(b'\x8d\x93', 'name_' + name); emit(b'\x52\x50')
        api('GetProcAddress')
        emit(b'\x85\xc0'); jump(b'\x0f\x84', 'release')
        ref(b'\x89\x83', name)
        label('ready_' + name)
    ref(b'\xff\x93', 'GetForegroundWindow')
    emit(b'\x85\xc0'); jump(b'\x0f\x84', 'release')
    if window_events:
        # Same choice as the game's own GetWindow routine: object-specific
        # window first, global fullscreen window only as a fallback.
        emit(b'\x8b\xf0')  # foreground HWND
        emit(b'\x8b\x83' + struct.pack('<I', 0xa423a4 + delta))
        emit(b'\x85\xc0'); jump(b'\x0f\x85', 'have_window')
        emit(b'\x8b\x83' + struct.pack('<I', 0xa52fb0 + delta))
        label('have_window')
        emit(b'\x3b\xc6'); jump(b'\x0f\x85', 'release')
    else:
        emit(b'\x3b\x83' + struct.pack('<I', 0xa52fb0 + delta))
        jump(b'\x0f\x85', 'release')
        emit(b'\x8b\xf0')  # ESI = HWND; callee-saved through Win32 calls
    emit(b'\x83\xbb' + struct.pack('<I', 0xa56980 + delta) + b'\x00')
    jump(b'\x0f\x84', 'release')
    if not focused_gameplay:
        # Legacy experiment only. Runtime tracing showed flags 0x6200 during
        # native windowed gameplay, so bit 0x80 is not a valid capture guard.
        emit(b'\xf6\x83' + struct.pack('<I', 0xa39368 + delta) + b'\x80')
        jump(b'\x0f\x84', 'release')
    emit(bytes.fromhex('8d04245056'))
    api('GetClientRect')
    emit(b'\x85\xc0'); jump(b'\x0f\x84', 'release')
    emit(bytes.fromhex('8b4424083b0424')); jump(b'\x0f\x8e', 'release')
    emit(bytes.fromhex('8b44240c3b442404')); jump(b'\x0f\x8e', 'release')
    # Map both RECT corners to desktop coordinates (accounts for borders/DPI).
    for offset in (0, 8):
        emit(bytes.fromhex('8d4424') + bytes([offset]) + b'\x50\x56')
        ref(b'\xff\x93', 'ClientToScreen')
        emit(b'\x85\xc0'); jump(b'\x0f\x84', 'release')
    if cache_rectangle:
        # Reapplying ClipCursor for every mouse message/pump can repeatedly
        # update Wine's host pointer grab. Keep the existing grab when the
        # desktop rectangle is unchanged; release clears owned so refocus
        # always reacquires it even when the rectangle is identical.
        ref(b'\x83\xbb', 'owned'); emit(b'\x00')
        jump(b'\x0f\x84', 'capture_rect')
        if lifecycle:
            ref(b'\x83\xbb', 'rect_valid'); emit(b'\x00')
            jump(b'\x0f\x84', 'capture_rect')
            ref(b'\x3b\xb3', 'captured_window')
            jump(b'\x0f\x85', 'capture_rect')
        for offset in (0, 4, 8, 12):
            emit(bytes.fromhex('8b4424') + bytes([offset]))
            ref(b'\x3b\x83', 'rect_' + str(offset))
            jump(b'\x0f\x85', 'capture_rect')
        jump(b'\xe9', 'pump_clear_busy')
        label('capture_rect')
    emit(bytes.fromhex('8d042450'))
    ref(b'\xff\x93', 'ClipCursor')
    emit(b'\x85\xc0'); jump(b'\x0f\x84', 'release')
    if cache_rectangle:
        for offset in (0, 4, 8, 12):
            emit(bytes.fromhex('8b4424') + bytes([offset]))
            ref(b'\x89\x83', 'rect_' + str(offset))
    ref(b'\xc7\x83', 'owned'); emit(struct.pack('<I', 1))
    if lifecycle:
        ref(b'\x89\xb3', 'captured_window')
        ref(b'\xc7\x83', 'rect_valid'); emit(struct.pack('<I', 1))
    jump(b'\xe9', 'pump_clear_busy')
    label('release')
    # Never clear cursor confinement belonging to some other application.
    ref(b'\x83\xbb', 'owned'); emit(b'\x00')
    jump(b'\x0f\x84', 'pump_clear_busy')
    ref(b'\x83\xbb', 'ClipCursor'); emit(b'\x00')
    jump(b'\x0f\x84', 'pump_clear_busy')
    emit(b'\x6a\x00'); ref(b'\xff\x93', 'ClipCursor')
    emit(b'\x85\xc0'); jump(b'\x0f\x84', 'pump_clear_busy')
    ref(b'\xc7\x83', 'owned'); emit(bytes(4))
    label('pump_clear_busy')
    if lifecycle:
        jump(b'\xe8', 'neutral_mouse')
    ref(b'\xc7\x83', 'busy'); emit(bytes(4))
    label('pump_done')
    finish(None if window_events else old_audio)
    pump_code_size = len(code)

    # Immediate release on the existing audio focus-loss path, even if the
    # main loop suspends while the application is inactive.
    focus_target = rva + len(code)
    begin()
    emit(bytes.fromhex('837c244001'))  # original argument at PUSHAD+flags+locals+4
    jump(b'\x0f\x85', 'focus_done')
    ref(b'\x83\xbb', 'owned'); emit(b'\x00')
    jump(b'\x0f\x84', 'focus_done')
    ref(b'\x83\xbb', 'ClipCursor'); emit(b'\x00')
    jump(b'\x0f\x84', 'focus_done')
    emit(b'\x6a\x00'); ref(b'\xff\x93', 'ClipCursor')
    emit(b'\x85\xc0'); jump(b'\x0f\x84', 'focus_done')
    ref(b'\xc7\x83', 'owned'); emit(bytes(4))
    label('focus_done')
    if lifecycle:
        jump(b'\xe8', 'neutral_mouse')
    emit(bytes.fromhex('ff742414')); api('SetLastError')
    emit(bytes.fromhex('83c418619d'))
    original = bytes.fromhex('8b44240456')
    emit(original)
    emit(b'\xe9' + struct.pack('<i', focus + 5 - (rva + len(code) + 5)))
    code_size = len(code)
    pump_target = rva
    event_target = None
    event_hook = 0x29f657 if delta else 0x271a47
    if window_events:
        # Separate release helper for deactivation/window destruction. This
        # does not synthesize audio or focus events in the original engine.
        release_target = rva + len(code)
        begin()
        ref(b'\x83\xbb', 'owned'); emit(b'\x00')
        jump(b'\x0f\x84', 'event_release_done')
        ref(b'\x83\xbb', 'ClipCursor'); emit(b'\x00')
        jump(b'\x0f\x84', 'event_release_done')
        emit(b'\x6a\x00'); ref(b'\xff\x93', 'ClipCursor')
        emit(b'\x85\xc0'); jump(b'\x0f\x84', 'event_release_done')
        ref(b'\xc7\x83', 'owned'); emit(bytes(4))
        label('event_release_done')
        if lifecycle:
            jump(b'\xe8', 'neutral_mouse')
        finish()

        if lifecycle:
            # Deliver a neutral mouse position through the original GUI mouse
            # dispatcher, without moving the desktop pointer or pausing time.
            # Its signature is (surface, client_x, client_y, source_kind).
            label('neutral_mouse')
            neutral_target = rva + len(code)
            begin()
            emit(b'\x83\xbb' + struct.pack('<I', 0xa56980 + delta) + b'\x00')
            jump(b'\x0f\x84', 'neutral_done')
            ref(b'\x83\xbb', 'GetForegroundWindow'); emit(b'\x00')
            jump(b'\x0f\x84', 'neutral_done')
            emit(b'\x8b\xb3' + struct.pack('<I', 0xa423a4 + delta))
            emit(b'\x85\xf6'); jump(b'\x0f\x85', 'neutral_window')
            emit(b'\x8b\xb3' + struct.pack('<I', 0xa52fb0 + delta))
            label('neutral_window')
            emit(b'\x85\xf6'); jump(b'\x0f\x84', 'neutral_done')
            ref(b'\xff\x93', 'GetForegroundWindow')
            emit(b'\x3b\xc6'); jump(b'\x0f\x84', 'neutral_done')
            emit(bytes.fromhex('8d04245056')); api('GetClientRect')
            emit(b'\x85\xc0'); jump(b'\x0f\x84', 'neutral_done')
            emit(bytes.fromhex('8b442408d1e88b54240cd1ea'))
            gui = 0xa42868 + delta
            emit(b'\x8d\xbb' + struct.pack('<I', gui))
            emit(bytes.fromhex('8b772485f6')); jump(b'\x0f\x84', 'neutral_done')
            emit(bytes.fromhex('3b4728')); jump(b'\x0f\x85', 'neutral_dispatch')
            emit(bytes.fromhex('3b572c')); jump(b'\x0f\x84', 'neutral_done')
            label('neutral_dispatch')
            emit(bytes.fromhex('6a005250568bcf'))
            emit(b'\xe8' + struct.pack('<i', mouse_dispatch - (rva + len(code) + 5)))
            label('neutral_done')
            finish()
            neutral_return = rva + len(code) - 1

        def call(target):
            emit(b'\xe8' + struct.pack('<i', target - (rva + len(code) + 5)))

        pump_target = rva + len(code)
        call(rva)
        emit(b'\xe9' + struct.pack('<i', old_audio - (rva + len(code) + 5)))
        event_target = rva + len(code)
        emit(bytes.fromhex('9c60'))
        if lifecycle:
            emit(bytes.fromhex('e8000000005b'))
            anchor = rva + len(code) - 1
            emit(b'\x81\xeb' + struct.pack('<I', anchor))
            # Defer layout changes until after the original WndProc has run.
            for msg in (1, 3, 5, 0x18, 0x47, 0x7e):
                emit(bytes.fromhex('817c2434') + struct.pack('<I', msg))
                jump(b'\x0f\x84', 'event_layout')
        # Hook is after two original SEH pushes (8 bytes). With our 36-byte
        # save frame, original uMsg/wParam are now at +52/+56.
        for msg in (2, 8, 0x1f, 0x82, 0x231):
            emit(bytes.fromhex('817c2434') + struct.pack('<I', msg))
            jump(b'\x0f\x84', 'event_lost')
        for msg in (6, 0x1c):
            emit(bytes.fromhex('817c2434') + struct.pack('<I', msg))
            jump(b'\x0f\x85', 'event_after_' + str(msg))
            emit(bytes.fromhex('8b44243825ffff000085c0'))
            jump(b'\x0f\x84', 'event_lost')
            label('event_after_' + str(msg))
        call(rva)
        if lifecycle:
            # WM_SETCURSOR / HTCLIENT: keep the game's drawn cursor and hide
            # the system cursor, without changing ShowCursor's global count.
            emit(bytes.fromhex('817c243420000000'))
            jump(b'\x0f\x85', 'event_done')
            emit(bytes.fromhex('8b44243c25ffff000083f801'))
            jump(b'\x0f\x85', 'event_done')
            ref(b'\x83\xbb', 'owned'); emit(b'\x00')
            jump(b'\x0f\x84', 'event_done')
            api('GetLastError'); emit(bytes.fromhex('8bf86a00')); api('SetCursor')
            emit(b'\x57'); api('SetLastError')
            emit(bytes.fromhex('619d'))
            event_consumed = rva + len(code)
            emit(bytes.fromhex('83c408b801000000c21000'))
        jump(b'\xe9', 'event_done')
        if lifecycle:
            label('event_layout')
            ref(b'\xc7\x83', 'rect_valid'); emit(bytes(4))
            jump(b'\xe9', 'event_done')
        label('event_lost')
        call(release_target)
        label('event_done')
        event_original = rva + len(code) + 2
        emit(bytes.fromhex('619d64a100000000'))
        emit(b'\xe9' + struct.pack('<i', event_hook + 6 - (rva + len(code) + 5)))
    if background_filter:
        # The native WM_MOUSEMOVE branch creates and dispatches the internal
        # mouse event BEFORE DispatchMessage/WndProc and our post-pump update.
        # Filter there so inactive hover never reaches gameplay subscribers.
        mouse_hook = 0x2722c0 if delta else 0x244120
        mouse_skip = 0x272411 if delta else 0x244271
        mouse_filter_target = rva + len(code)
        begin()
        emit(b'\x83\xbb' + struct.pack('<I', 0xa56980 + delta) + b'\x00')
        jump(b'\x0f\x84', 'mouse_filter_pass')
        ref(b'\x83\xbb', 'GetForegroundWindow'); emit(b'\x00')
        jump(b'\x0f\x84', 'mouse_filter_pass')
        emit(b'\x8b\xb3' + struct.pack('<I', 0xa423a4 + delta))
        emit(b'\x85\xf6'); jump(b'\x0f\x85', 'mouse_filter_window')
        emit(b'\x8b\xb3' + struct.pack('<I', 0xa52fb0 + delta))
        label('mouse_filter_window')
        emit(b'\x85\xf6'); jump(b'\x0f\x84', 'mouse_filter_pass')
        ref(b'\xff\x93', 'GetForegroundWindow')
        emit(b'\x3b\xc6'); jump(b'\x0f\x84', 'mouse_filter_pass')
        jump(b'\xe8', 'neutral_mouse')
        finish(mouse_skip)
        label('mouse_filter_pass')
        emit(bytes.fromhex('ff742414')); api('SetLastError')
        emit(bytes.fromhex('83c418619d'))
        mouse_filter_original = rva + len(code)
        emit(bytes.fromhex('b820000000'))
        emit(b'\xe9' + struct.pack('<i', mouse_hook + 5 - (rva + len(code) + 5)))
    data = {}
    for name, value in [('busy', bytes(4)), ('owned', bytes(4)), ('user32', b'user32.dll\0')]:
        data[name] = rva + len(code)
        emit(value)
    if cache_rectangle:
        for offset in (0, 4, 8, 12):
            data['rect_' + str(offset)] = rva + len(code)
            emit(bytes(4))
    if lifecycle:
        for name in ('rect_valid', 'captured_window'):
            data[name] = rva + len(code); emit(bytes(4))
    for name in ('ClipCursor', 'GetForegroundWindow', 'ClientToScreen'):
        data[name] = rva + len(code); emit(bytes(4))
        data['name_' + name] = rva + len(code); emit(name.encode() + b'\0')
    for pos, name in refs:
        struct.pack_into('<I', code, pos, data[name])
    for pos, name in branches:
        struct.pack_into('<i', code, pos, labels[name] - pos - 4)
    b[pump:pump + 5] = b'\xe9' + struct.pack('<i', pump_target - pump - 5)
    redirect(b, focus, original, focus_target)
    if window_events:
        redirect(b, event_hook, bytes.fromhex('64a100000000'), event_target)
    if background_filter:
        redirect(b, mouse_hook, bytes.fromhex('b820000000'), mouse_filter_target)
    append_section(b, b'.wlpmous', code)
    # Cached function pointers and ownership flag live beside the code.
    output_pe = pefile.PE(data=b)
    struct.pack_into('<I', b, output_pe.sections[-1].get_file_offset() + 36, 0xe0000060)
    return bytes(b), {'pump_bytes': pump_code_size, 'code_bytes': code_size,
                      'rva': rva, 'focus_target': focus_target, 'data': data,
                      'pump_target': pump_target, 'event_target': event_target,
                      'event_original': event_original if window_events else None,
                      'event_hook': event_hook, 'update_return': rva + pump_code_size - 1,
                      'neutral_target': neutral_target if lifecycle else None,
                      'neutral_return': neutral_return if lifecycle else None,
                      'mouse_dispatch': mouse_dispatch if lifecycle else None,
                      'event_consumed': event_consumed if lifecycle else None,
                      'mouse_filter_target': mouse_filter_target if background_filter else None,
                      'mouse_filter_original': mouse_filter_original if background_filter else None,
                      'mouse_filter_hook': mouse_hook if background_filter else None,
                      'mouse_filter_skip': mouse_skip if background_filter else None,
                      'release_target': release_target if window_events else None}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--window-events', action='store_true')
    parser.add_argument('--focused-gameplay', action='store_true')
    parser.add_argument('--cache-rectangle', action='store_true')
    parser.add_argument('--lifecycle', action='store_true')
    parser.add_argument('--background-filter', action='store_true')
    args = parser.parse_args()
    result, _ = patch(args.source.read_bytes(), window_events=args.window_events,
                      focused_gameplay=args.focused_gameplay,
                      cache_rectangle=args.cache_rectangle, lifecycle=args.lifecycle,
                      background_filter=args.background_filter)
    with args.output.open('xb') as f:
        f.write(result)
    print(hashlib.sha256(result).hexdigest())
