#!/usr/bin/env python3
"""Execute actual zoom hooks/scaler with 32-bit engine mocks at two image bases."""
import subprocess,tempfile,argparse,struct
from pathlib import Path
from workspace_paths import artifact
import pefile
from patch_zoom_steps import patch

def verify(name,build_only=False):
 src=artifact(name+'_widescreen_weather_menu.EXE').read_bytes();new,m=patch(src)
 assert new==artifact(name+'_widescreen_zoom_steps.EXE').read_bytes()
 p=pefile.PE(data=src);np=pefile.PE(data=new);expected=bytearray(src)
 for h,n in m['changes']:
  off=p.get_offset_from_rva(h);expected[off:off+n]=new[off:off+n]
 for off in m['reloc_offsets']:expected[off:off+2]=new[off:off+2]
 for s in p.sections:
  off=s.PointerToRawData;assert new[off:off+s.SizeOfRawData]==expected[off:off+s.SizeOfRawData]
 for block in np.DIRECTORY_ENTRY_BASERELOC:
  for e in block.entries:assert not e.type or not any(h<=e.rva<h+n for h,n in m['changes'])
 pr=m['profile'];sy=m['symbols']
 core=Path('tools/zoom_steps.c').read_text().split('static float scale')[0]
 for base in (0x400000,0x14000000):
  with tempfile.TemporaryDirectory() as tmp:
   d=Path(tmp);(d/'blob').write_bytes(m['code']);ctx=base+m['rva']+sy['context']
   test=core+f'''
#define CTX ((Context *){ctx}u)
#define VIEW ((void *)view)
#define CTRL ((void *)control)
#define CALL_STEP ((void (THIS *)(void *,int)){base+m['rva']+sy['select_hook']}u)
#define CALL_FINISH ((void (THIS *)(void *)){base+m['rva']+sy['finish_call']}u)
#define CALL_FRAME ((void (THIS *)(void *,int,int)){base+m['rva']+sy['frame_hook']}u)
#define REQUIRE(x) do {{if(!(x))quit(line);line++;}} while(0)
static U line=1,phase,expected_step,draws,calcs,allocs,frees,fail_alloc;
static U view[256],control[64],renderer[65590],overlay[20],delegate[20],vtable[3],weather_blits,weather_binds,image_tag,batch[24],command[4],worker[4],worker_vt[1],use_worker,pending_weather;
static P queued_pixel=0x1234;
static P output[240],memory[200000];
static Surface target;
__attribute__((section(".globals"))) U globals[128];
static void quit(U code) {{ __asm__ volatile("int $0x80"::"a"(1),"b"(code)); __builtin_unreachable(); }}
static int rounded(float v) {{return (int)(v*10.0f+0.5f);}}
void *mock_alloc(U n) {{allocs++;if(fail_alloc)return (void *)0;REQUIRE(n<sizeof(memory));return memory;}}
void mock_free(void *p) {{REQUIRE(p==memory);frees++;}}
void THIS mock_calc(void *v) {{
 REQUIRE(v==VIEW);REQUIRE(!CTX->active);REQUIRE(rounded(FIELD(v,0x14,float))==(int)expected_step);
 REQUIRE(GLOBAL(CTX,CTX->widths)==16);REQUIRE(GLOBAL(CTX,CTX->heights)==136);
 REQUIRE(GLOBAL(CTX,CTX->screenw)==16);REQUIRE(GLOBAL(CTX,CTX->screenh)==136);calcs++;
}}
void THIS mock_draw(void *v,int x,int y) {{
 Surface *s=FIELD(v,0x18,Surface *);draws++;phase=1;pending_weather=0;
 if(expected_step!=5&&expected_step!=10&&expected_step!=20&&!fail_alloc) {{
  U w=(160+expected_step-1)/expected_step,h=(120+expected_step-1)/expected_step;
  REQUIRE(CTX->active);if(FIELD(v,0x10,void *)){{REQUIRE(!FIELD(renderer,CTX->weatherflags,unsigned char)&&!FIELD(renderer,CTX->weatherflags+1,unsigned char));}}REQUIRE(s!=&target);REQUIRE(s->w==w&&s->h==h);
  REQUIRE(GLOBAL(CTX,CTX->widths)==w&&GLOBAL(CTX,CTX->heights)==h+(1240+expected_step-1)/expected_step);
  REQUIRE(GLOBAL(CTX,CTX->screenh)==h+(1240+expected_step-1)/expected_step);
  REQUIRE((s->pitch&3)==0);
  REQUIRE(s->pitch>=w*2);
  // Native culling uses full-window height minus HUD, unlike target surface.
  REQUIRE(GLOBAL(CTX,CTX->heights)-((1240+expected_step-1)/expected_step)==s->h);
  for(U yy=0;yy<s->h;yy++){{P *r=(P *)((char *)s->pixels+yy*s->pitch);for(U xx=0;xx<s->w;xx++)REQUIRE(r[xx]==0);}}
  REQUIRE(rounded(FIELD(v,0x14,float))==10);
  REQUIRE(x==(int)(15*w/16));REQUIRE(y==(int)(11*h/12));
  REQUIRE(CTX->hud>1239.0f/expected_step&&CTX->hud<1241.0f/expected_step);
 }} else {{REQUIRE(s==&target);REQUIRE(x==15&&y==11);}}
 for(U yy=0;yy<s->h;yy++){{P *row=(P *)((char *)s->pixels+yy*s->pitch);for(U xx=0;xx<s->w;xx++)row[xx]=(P)(yy*37+xx+1);}}
 if(CTX->active&&FIELD(v,0x10,void *)){{
  command[0]=(U)&queued_pixel;command[1]=(U)s->pixels;command[2]=1;command[3]=0;
  FIELD(batch,0x44,U *)=command;FIELD(batch,0x48,U *)=command+4;
  FIELD(batch,0x34,void *)=use_worker?worker:0;FIELD(renderer,CTX->queue,void *)=batch;
  CALL_FINISH(renderer);
  REQUIRE(CTX->done==1);REQUIRE(FIELD(batch,0x48,U *)==command);REQUIRE(!FIELD(batch,0x34,void *));
  // Native deferred overlay flush takes place after the hook, before release.
  if(pending_weather)output[1]=(P)pending_weather;
  // Native cleanup frees the delegated drawing object at the end of this call.
  FIELD(renderer,0x10,void *)=(void *)0xdeadbeef;
 }}
 phase=0;
}}
void THIS mock_bind(void *o,void *t,void *rect) {{REQUIRE(phase==1&&CTX->active);REQUIRE(o==overlay||o==delegate);REQUIRE(t==&target);REQUIRE(((U *)rect)[3]==16&&((U *)rect)[4]==12);weather_binds++;}}
void *THIS mock_lookup(void *manager,void *desc) {{REQUIRE(phase==1&&CTX->active);REQUIRE(manager==(void *)1);REQUIRE(desc==(void *)(CTX->base+CTX->raindesc)||desc==(void *)(CTX->base+CTX->snowdesc));return &image_tag;}}
void THIS mock_bounds(void *o,int x,int y,int w,int h) {{REQUIRE(o==overlay&&x==0&&y==0&&w==16&&h==12);}}
void THIS mock_blit(void *o,void *image,int x,int y) {{REQUIRE(phase==1&&CTX->active);pending_weather=0xabcd;REQUIRE(o==overlay&&image==&image_tag&&x==0&&y==0);REQUIRE(FIELD(o,0x34,void *)==delegate);weather_blits++;}}
void THIS mock_flush(void *w) {{REQUIRE(w==worker&&phase==1);REQUIRE(FIELD(w,8,U)==1);U *cmd=FIELD(w,4,U *);*(P *)cmd[1]=*(P *)cmd[0];}}
void start_test(void) {{
 CTX->base={base}u;
 FIELD(CTRL,0x64,void *)=VIEW;FIELD(CTRL,0xc0,float)=1.0f;FIELD(VIEW,0x14,float)=1.0f;
 target.w=16;target.h=12;target.pitch=40;target.pixels=output;
 FIELD(VIEW,0x18,Surface *)=&target;
 GLOBAL(CTX,{pr['mode']})=0;GLOBAL(CTX,{pr['widths']})=16;GLOBAL(CTX,{pr['heights']})=136;
 GLOBAL(CTX,{pr['screenw']})=16;GLOBAL(CTX,{pr['screenh']})=136;
 for(int i=11;i<=20;i++){{CALL_STEP(CTRL,1);REQUIRE(rounded(FIELD(CTRL,0xc0,float))==i);}}
 CALL_STEP(CTRL,1);REQUIRE(rounded(FIELD(CTRL,0xc0,float))==20);
 for(int i=19;i>=5;i--){{CALL_STEP(CTRL,2);REQUIRE(rounded(FIELD(CTRL,0xc0,float))==i);}}
 CALL_STEP(CTRL,2);REQUIRE(rounded(FIELD(CTRL,0xc0,float))==5);
 CALL_STEP(CTRL,0);REQUIRE(rounded(FIELD(CTRL,0xc0,float))==10);
 REQUIRE(rounded(FIELD(VIEW,0x14,float))==10);
 for(U i=5;i<=20;i++){{
  expected_step=i;FIELD(VIEW,0x14,float)=(float)i/10.0f;
  for(U j=0;j<240;j++)output[j]=0xcafe;
  U oldcalcs=calcs;CALL_FRAME(VIEW,15,11);
  REQUIRE(rounded(FIELD(VIEW,0x14,float))==(int)i);REQUIRE(FIELD(VIEW,0x18,Surface *)==&target);
  REQUIRE(!CTX->active&&CTX->hud==124.0f);
  U w=(160+i-1)/i,h=(120+i-1)/i;
  for(U yy=0;yy<12;yy++)for(U xx=0;xx<16;xx++){{
   U value=(i==5||i==10||i==20)?yy*37+xx+1:(yy*h/12)*37+xx*w/16+1;
   REQUIRE(output[yy*20+xx]==value);
  }}
  for(U yy=0;yy<12;yy++)for(U xx=16;xx<20;xx++)REQUIRE(output[yy*20+xx]==0xcafe);
  REQUIRE(calcs-oldcalcs==((i==5||i==10||i==20)?0:1));
 }}
 REQUIRE(draws==16);REQUIRE(calcs==13);REQUIRE(allocs==1);
 CTX->lookup=(U)mock_lookup-{base}u;CTX->bind=(U)mock_bind-{base}u;CTX->manager={pr['screenw']+256}u;
 GLOBAL(CTX,CTX->manager)=1;FIELD((void *)(CTX->base+CTX->weatherenabled),0,unsigned char)=1;
 FIELD(VIEW,0x10,void *)=renderer;FIELD(renderer,0x10,void *)=delegate;FIELD(renderer,0x28,void *)=overlay;
 vtable[1]=(U)mock_bounds;vtable[2]=(U)mock_blit;FIELD(overlay,0,U *)=vtable;
 FIELD(renderer,CTX->weatherflags,unsigned char)=1;FIELD(renderer,CTX->weatherflags+1,unsigned char)=1;
 worker_vt[0]=(U)mock_flush;FIELD(worker,0,U *)=worker_vt;
 for(U i=6;i<20;i++)if(i!=10){{
  use_worker=i&1;expected_step=i;FIELD(VIEW,0x14,float)=(float)i/10.0f;
  FIELD(renderer,0x10,void *)=delegate;CALL_FRAME(VIEW,15,11);
  REQUIRE(output[0]==0x1234&&output[1]==0xabcd);
  REQUIRE(FIELD(renderer,CTX->weatherflags,unsigned char)==1&&FIELD(renderer,CTX->weatherflags+1,unsigned char)==1);
  REQUIRE(FIELD(renderer,0x20,void *)==&target);
  REQUIRE(!CTX->target&&!CTX->renderer&&!CTX->active);
 }}
 REQUIRE(weather_blits==26&&weather_binds==26);
 // Weather disabled still flushes the world safely without using a freed delegate.
 FIELD((void *)(CTX->base+CTX->weatherenabled),0,unsigned char)=0;
 expected_step=11;FIELD(VIEW,0x14,float)=1.1f;FIELD(renderer,0x10,void *)=delegate;CALL_FRAME(VIEW,15,11);
 REQUIRE(output[0]==0x1234&&weather_blits==26&&weather_binds==26);
 quit(0);
}}
'''
   (d/'test.c').write_text(test)
   asm='.intel_syntax noprefix\n.code32\n.global start\n.section .main,"ax"\nstart: call start_test\n'
   asm+=f'.section .blob,"awx"\n.incbin "{d/"blob"}"\n'
   for section,func in [('render','mock_draw'),('calc','mock_calc'),('alloc','mock_alloc'),('release','mock_free')]:asm+=f'.section .{section},"ax"\njmp {func}\n'
   (d/'test.s').write_text(asm)
   sections={'render':pr['render'],'calc':pr['calc'],'alloc':pr['alloc'],'release':pr['release'],'globals':min(pr['screenw'],pr['screenh'],pr['mode']),'blob':m['rva']}
   layout='\n'.join(f'.{k} {base+v} : {{ *(.{k}) }}' for k,v in sorted(sections.items(),key=lambda x:x[1]))
   (d/'test.ld').write_text(f'ENTRY(start)\nSECTIONS {{ .main {base+0x1000} : {{ *(.main) }}\n{layout}\n.text : {{ *(.text*) *(.rodata*) *(.got*) }} .data : {{ *(.data*) *(.bss*) }} /DISCARD/ : {{ *(.comment) *(.note*) *(.eh_frame*) }} }}')
   subprocess.run(['gcc','-m32','-O2','-fPIC','-ffreestanding','-fno-stack-protector','-fno-asynchronous-unwind-tables','-c',str(d/'test.c'),'-o',str(d/'testc.o')],check=True)
   subprocess.run(['as','--32','-o',str(d/'testa.o'),str(d/'test.s')],check=True)
   subprocess.run(['ld','-m','elf_i386','-T',str(d/'test.ld'),'-o',str(d/'test'),str(d/'testa.o'),str(d/'testc.o')],check=True,capture_output=True)
   if not build_only:
    r=subprocess.run([str(d/'test')],timeout=20)
    if r.returncode:
     import shutil
     shutil.copyfile(d/'test','/tmp/zoom-native-debug')
    assert r.returncode==0,(name,hex(base),r.returncode)
 print(name,'PASS: zoom limits/reset, all16 levels, RGB565 resampling/padding, inverse mouse mapping, viewport restoration, deferred-world flush, weather before object release; two image bases')
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('--build-only',action='store_true');args=a.parse_args()
 for n in ('WLP','WLPADD1'):verify(n,args.build_only)
