#!/usr/bin/env python3
"""Capture real mouse guards and ClipCursor results without changing policy.

64-byte records append to MouseCaptureTrace-base.bin / addon.bin in game root.
The pump snapshot runs before the current cursor update. Clip stubs capture
calls/results so the following snapshot records them. Preserve original APIs.
"""
import argparse
import hashlib
import struct
from pathlib import Path
import pefile
from patch_mouse_confinement import patch as mouse_patch, PROFILES
from patch_addon_widescreen import next_rva, append_section

FIELDS = ('magic', 'foreground', 'global_window', 'object_window', 'world',
          'active_flags', 'owned', 'busy', 'clip_api', 'clip_calls',
          'clip_result', 'clip_error', 'clip_argument')


def patch(baseline, current, name):
    expected, meta = mouse_patch(baseline, window_events=True)
    assert expected == current
    delta, pump, _ = PROFILES[hashlib.sha256(baseline).hexdigest()]
    p = pefile.PE(data=current)
    imports = {i.name.decode(): i.address - p.OPTIONAL_HEADER.ImageBase
               for dll in p.DIRECTORY_ENTRY_IMPORT for i in dll.imports if i.name}
    b = bytearray(current)
    rva = next_rva(b)
    code, refs = bytearray(), []
    def emit(x): code.extend(x)
    def ref(op, key):
        emit(op); refs.append((len(code), key)); emit(bytes(4))
    def api(n): emit(b'\xff\x93' + struct.pack('<I', imports[n]))
    def store(i): emit(bytes.fromhex('898424') + struct.pack('<I', i * 4))
    def jump(target): emit(b'\xe9' + struct.pack('<i', target - (rva + len(code) + 5)))
    previous = pump + 5 + struct.unpack_from('<i', b, pump + 1)[0]
    emit(bytes.fromhex('9c60e8000000005b'))
    emit(b'\x81\xeb' + struct.pack('<I', rva + 7))
    emit(bytes.fromhex('83ec48fc8bfc33c0b912000000f3ab'))
    api('GetLastError'); emit(bytes.fromhex('89442444'))
    emit(b'\xb8' + b'WCM2'); store(0)
    emit(b'\x8b\x83' + struct.pack('<I', meta['data']['GetForegroundWindow']))
    emit(bytes.fromhex('85c07402ffd0')); store(1)
    sources = [0xa52fb0 + delta, 0xa423a4 + delta, 0xa56980 + delta,
               0xa39368 + delta, meta['data']['owned'], meta['data']['busy'],
               meta['data']['ClipCursor']]
    for i, source in enumerate(sources, 2):
        emit(b'\x8b\x83' + struct.pack('<I', source)); store(i)
    for i, key in enumerate(('calls', 'result', 'error', 'argument'), 9):
        ref(b'\x8b\x83', key); store(i)
    emit(bytes.fromhex('6a0068800000006a046a006a036a04'))
    ref(b'\x8d\x83', 'filename'); emit(b'\x50'); api('CreateFileA')
    emit(bytes.fromhex('8bf883f8ff0f84')); skip = len(code); emit(bytes(4))
    emit(bytes.fromhex('8bd48d4c24406a00516a405257')); api('WriteFile')
    emit(b'\x57'); api('CloseHandle')
    struct.pack_into('<i', code, skip, len(code) - skip - 4)
    emit(bytes.fromhex('ff742444')); api('SetLastError')
    emit(bytes.fromhex('83c448619d')); jump(previous)
    b[pump:pump + 5] = b'\xe9' + struct.pack('<i', rva - pump - 5)
    s = next(s for s in p.sections if s.Name.rstrip(b'\0') == b'.wlpmous')
    sig = b'\xff\x93' + struct.pack('<I', meta['data']['ClipCursor'])
    start = s.PointerToRawData
    sites = []
    for off in range(start, start + s.Misc_VirtualSize - 5):
        if current[off:off + 6] == sig: sites.append(off)
    assert len(sites) == 4
    for off in sites:
        target = rva + len(code)
        hook_rva = p.get_rva_from_offset(off)
        emit(bytes.fromhex('8b0c24')); ref(b'\x89\x8b', 'argument')
        ref(b'\xff\x83', 'calls')
        emit(sig); ref(b'\x89\x83', 'result')
        emit(b'\x50'); api('GetLastError'); ref(b'\x89\x83', 'error'); emit(b'\x58')
        jump(hook_rva + 6)
        b[off:off + 6] = b'\xe9' + struct.pack('<i', target - hook_rva - 5) + b'\x90'
    labels = {}
    for key in ('calls', 'result', 'error', 'argument'):
        labels[key] = rva + len(code); emit(bytes(4))
    labels['filename'] = rva + len(code)
    emit(('C:\\Program Files (x86)\\Deep Silver\\Wildlife Park Gold\\MouseCaptureTrace-'
          + name + '.bin\0').encode())
    for off, key in refs: struct.pack_into('<I', code, off, labels[key])
    append_section(b, b'.wlpmtrc', code)
    out = pefile.PE(data=b)
    struct.pack_into('<I', b, out.sections[-1].get_file_offset() + 36, 0xe0000060)
    return bytes(b)


def decode(path):
    b = path.read_bytes()
    assert len(b) % 64 == 0
    previous = None
    for off in range(0, len(b), 64):
        values = struct.unpack_from('<16I', b, off)
        assert values[0] == int.from_bytes(b'WCM2', 'little')
        row = dict(zip(FIELDS, values))
        # Condense unchanged guards/results; call count still records attempts.
        key = tuple(v for k, v in row.items() if k not in ('clip_calls', 'clip_argument'))
        if key != previous:
            print(off // 64, ' '.join(f'{k}={v:#x}' for k, v in row.items() if k != 'magic'))
            previous = key
    print('Records:', len(b) // 64)


if __name__ == '__main__':
    a = argparse.ArgumentParser(description=__doc__)
    a.add_argument('source', type=Path)
    a.add_argument('current', nargs='?', type=Path)
    a.add_argument('output', nargs='?', type=Path)
    a.add_argument('--name', choices=['base', 'addon'])
    args = a.parse_args()
    if args.current is None: decode(args.source)
    else:
        result = patch(args.source.read_bytes(), args.current.read_bytes(), args.name)
        with args.output.open('xb') as f: f.write(result)
        print(hashlib.sha256(result).hexdigest())
