#!/usr/bin/env python3
"""Owned main-menu control switching between the two installed executables."""
import struct, subprocess, tempfile
from pathlib import Path
import pefile
from patch_addon_widescreen import append_section, next_rva
from patch_keybind_panel import asm_string

PROFILES = {
 'WLP': dict(setup_hook=0x104f0a, setup=0x13a870, dtor_hook=0x13a370,
             dtor=0x13a3c0, visibility_hooks=(0x13c99a,0x13cd99),
             visible=0x1ea340, end_menu=0x1ec590, button_ctor=0x267700,
             button_dtor=0x108050, bounds=0x1f5fc0, caption=0x267de0,
             register=0x244490, enabled=0x1ed540, attach=0x268270, detach=0x268290),
 'WLPADD1': dict(setup_hook=0x1155d1, setup=0x14ef10, dtor_hook=0x14e9e0,
             dtor=0x14ea30, visibility_hooks=(0x15104a,0x151457),
             visible=0x217e80, end_menu=0x21a0f0, button_ctor=0x2958e0,
             button_dtor=0x11a320, bounds=0x2241c0, caption=0x295fc0,
             register=0x272630, enabled=0x21afe0, attach=0x296450, detach=0x296470),
}

def patch(data, name):
    pr=PROFILES[name]; p=pefile.PE(data=data); rva=next_rva(data)
    imports={i.name.decode():i.address-p.OPTIONAL_HEADER.ImageBase
             for dll in p.DIRECTORY_ENTRY_IMPORT for i in dll.imports if i.name}
    target='WLPADD1.EXE' if name=='WLP' else 'WLP.EXE'
    caption='Wild Creatures' if name=='WLP' else 'Wildlife Park'
    def call(n): return f'.byte 0xe8\n.long {pr[n]}-({rva}+.-_start+4)'
    def addr(n): return f'[ebx+{rva}+{n}-_start]'
    def api(n): return f'call DWORD PTR [ebx+{imports[n]}]'
    asm=f'''.intel_syntax noprefix
.code32
.global _start
_start:
get_base:
 call anchor
anchor:
 pop ebx
 sub ebx,{rva}+anchor-_start
 ret
setup:
 push esi
 mov esi,ecx
 push DWORD PTR [esp+8]
 {call('setup')}
 pushfd
 pushad
 call get_base
 cmp DWORD PTR {addr('ready')},0
 jne setup_done
 mov DWORD PTR {addr('owner')},esi
 lea edi,{addr('button')}
 push 1
 mov ecx,edi
 {call('button_ctor')}
 mov DWORD PTR {addr('ready')},1
 push 38
 push 232
 push 540
 push 30
 mov ecx,edi
 {call('bounds')}
 lea eax,{addr('caption_text')}
 push eax
 mov ecx,edi
 {call('caption')}
 push 0
 push 0
 push 0
 lea eax,{addr('switch_game')}
 push eax
 push esi
 push 0x0e
 mov ecx,edi
 {call('register')}
 push 1
 mov ecx,edi
 {call('enabled')}
 push esi
 mov ecx,edi
 {call('attach')}
setup_done:
 popad
 popfd
 pop esi
 ret 4
destructor:
 pushfd
 pushad
 call get_base
 lea eax,[ecx-0x129b0]
 cmp eax,DWORD PTR {addr('owner')}
 jne destructor_done
 cmp DWORD PTR {addr('ready')},1
 jne destructor_done
 mov DWORD PTR {addr('ready')},0
 mov DWORD PTR {addr('owner')},0
 mov DWORD PTR {addr('pending')},0
 lea ecx,{addr('button')}
 {call('detach')}
 lea ecx,[ebx+{rva}+button-_start+0x630]
 {call('button_dtor')}
destructor_done:
 popad
 popfd
 jmp _start+{pr['dtor']-rva}
visibility:
 push ebp
 mov ebp,esp
 push ecx
 push DWORD PTR [ebp+8]
 {call('visible')}
 pushfd
 pushad
 call get_base
 cmp DWORD PTR {addr('ready')},1
 jne visibility_done
 mov eax,DWORD PTR {addr('owner')}
 add eax,0x5a0
 cmp eax,[ebp-4]
 jne visibility_done
 push DWORD PTR [ebp+8]
 lea ecx,{addr('button')}
 {call('visible')}
visibility_done:
 popad
 popfd
 add esp,4
 pop ebp
 ret 4
switch_game:
 pushfd
 pushad
 cld
 call get_base
 cmp DWORD PTR {addr('pending')},0
 jne switch_done
 cmp DWORD PTR {addr('ready')},1
 jne switch_done
 cmp ecx,DWORD PTR {addr('owner')}
 jne switch_done
 lea esi,{addr('path')}
 push 1024
 push esi
 push 0
 {api('GetModuleFileNameA')}
 test eax,eax
 je switch_failed
 cmp eax,1024
 jae switch_failed
 lea edi,[esi+eax]
 mov edx,edi
find_separator:
 cmp edi,esi
 je switch_failed
 dec edi
 cmp BYTE PTR [edi],0x5c
 je found_separator
 cmp BYTE PTR [edi],0x2f
 jne find_separator
found_separator:
 inc edi
 mov eax,edi
 sub eax,esi
 cmp eax,{1024-len(target)-1}
 ja switch_failed
 lea esi,{addr('target_text')}
 mov ecx,{len(target)+1}
 rep movsb
 lea eax,{addr('kernel_text')}
 push eax
 {api('GetModuleHandleA')}
 test eax,eax
 je switch_failed
 lea edx,{addr('create_text')}
 push edx
 push eax
 {api('GetProcAddress')}
 test eax,eax
 je switch_failed
 mov esi,eax
 lea edi,{addr('startup')}
 xor eax,eax
 mov ecx,21
 rep stosd
 mov DWORD PTR {addr('startup')},68
 lea eax,{addr('process')}
 push eax
 lea eax,{addr('startup')}
 push eax
 push 0
 push 0
 push 0
 push 0
 push 0
 push 0
 push 0
 lea eax,{addr('path')}
 push eax
 call esi
 test eax,eax
 je switch_failed
 mov DWORD PTR {addr('pending')},1
 push DWORD PTR [ebx+{rva}+process-_start+4]
 {api('CloseHandle')}
 push DWORD PTR {addr('process')}
 {api('CloseHandle')}
 # Identical result and close operation to the native Beenden button.
 mov ecx,DWORD PTR {addr('owner')}
 mov DWORD PTR [ecx+0x3130],6
 {call('end_menu')}
 jmp switch_done
switch_failed:
 push 0x10
 lea eax,{addr('caption_text')}
 push eax
 lea eax,{addr('failure_text')}
 push eax
 push 0
 {api('MessageBoxA')}
switch_done:
 popad
 popfd
 mov al,1
 ret 8
{asm_string('caption_text',caption)}
{asm_string('target_text',target)}
{asm_string('kernel_text','kernel32.dll')}
{asm_string('create_text','CreateProcessA')}
{asm_string('failure_text','Das andere Spiel konnte nicht gestartet werden.')}
.balign 4
ready: .long 0
owner: .long 0
pending: .long 0
startup: .zero 68
process: .zero 16
path: .zero 1024
button: .zero 0x638
'''
    with tempfile.TemporaryDirectory() as tmp:
        d=Path(tmp); (d/'switch.s').write_text(asm)
        subprocess.run(['as','--32','-o',str(d/'switch.o'),str(d/'switch.s')],check=True)
        assert 'R_386' not in subprocess.check_output(['objdump','-r',str(d/'switch.o')],text=True)
        subprocess.run(['objcopy','-O','binary','-j','.text',str(d/'switch.o'),str(d/'switch.bin')],check=True)
        code=(d/'switch.bin').read_bytes()
        symbols={a[2]:int(a[0],16) for line in subprocess.check_output(['nm',str(d/'switch.o')],text=True).splitlines() if len(a:=line.split())==3}
    b=bytearray(data); changes=[]
    for h,symbol,expected in [(pr['setup_hook'],'setup',pr['setup']),
                              (pr['dtor_hook'],'destructor',pr['dtor'])]+[
                              (h,'visibility',pr['visible']) for h in pr['visibility_hooks']]:
        old=p.get_data(h,5)
        assert old==b'\xe8'+struct.pack('<i',expected-h-5),(hex(h),old.hex())
        off=p.get_offset_from_rva(h)
        b[off:off+5]=b'\xe8'+struct.pack('<i',rva+symbols[symbol]-h-5)
        changes.append((h,5))
    append_section(b,b'.wlpswap',code)
    np=pefile.PE(data=b)
    struct.pack_into('<I',b,np.sections[-1].get_file_offset()+36,0xe0000020)
    return bytes(b),dict(profile=pr,imports=imports,rva=rva,code=code,symbols=symbols,
                         changes=changes,reloc_offsets=[],target=target,caption=caption)
