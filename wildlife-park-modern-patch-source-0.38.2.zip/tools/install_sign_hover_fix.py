#!/usr/bin/env python3
"""Install the verified 0.35.1 pointer-hover correction; preserve texture assets."""
import json,os,shutil,hashlib
from pathlib import Path
from fix_sign_hover import ROOT,patch
from patch_debug_tools import check_preservation
from workspace_paths import GAME

VERSION='0.35.1'
def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        while b:=f.read(1024*1024):h.update(b)
    return h.hexdigest()
if __name__=='__main__':
    ip=ROOT/'builds/versions.json';index=json.loads(ip.read_text())
    assert index['current']=='0.35.0' and not any(e['version']==VERSION for e in index['versions'])
    checks=json.loads((ROOT/'analysis/sign-hover-fix-verification.json').read_text())
    plan=[]
    for name in ('WLP','WLPADD1'):
        source=ROOT/'builds/versions/0.35.0'/f'{name}.EXE'
        candidate=ROOT/'builds/versions'/VERSION/source.name
        built,m=patch(source.read_bytes(),name);assert candidate.read_bytes()==built
        check_preservation(source.read_bytes(),built,m)
        assert any(c['name']==name and c['passed'] and c['sha256']==sha(candidate) and c['code_sha256']==hashlib.sha256(m['code']).hexdigest() for c in checks)
        target=GAME/'Int/Win32/Program/VC6'/source.name
        assert sha(target)==sha(source)==sha(ROOT/'builds/current'/source.name)
        plan.append(dict(target=target,candidate=candidate,before=sha(source),after=sha(candidate)))
    targets={p['target'] for p in plan}
    def inventory():
        return {str(p.relative_to(GAME)):sha(p) for p in GAME.rglob('*') if p.is_file() and p not in targets and not any(s.startswith('.') for s in p.relative_to(GAME).parts)}
    before=inventory();installed=[]
    for p in plan:
        p['backup']=ROOT/'archive/game-backups/0.35.0/pre-hover-fix'/p['target'].relative_to(GAME)
        p['backup'].parent.mkdir(parents=True,exist_ok=True)
        if not p['backup'].exists():shutil.copy2(p['target'],p['backup'])
        assert sha(p['backup'])==p['before']
    try:
        for p in plan:
            stage=p['target'].with_name(p['target'].name+'.sign-switch.tmp')
            shutil.copy2(p['candidate'],stage)
            assert sha(stage)==p['after'] and sha(p['target'])==p['before']
            os.replace(stage,p['target']);installed.append(p)
            assert sha(p['target'])==p['after']
        assert inventory()==before,'Other game files changed during installation'
    except Exception:
        for p in reversed(installed):
            stage=p['target'].with_name(p['target'].name+'.sign-rollback.tmp')
            shutil.copy2(p['backup'],stage);os.replace(stage,p['target'])
        raise
    for p in plan:
        if p['target'].suffix=='.EXE':shutil.copy2(p['target'],ROOT/'builds/current'/p['target'].name)
        else:shutil.copy2(p['target'],ROOT/'assets/current'/p['target'].name)
    (ROOT/'builds/current/VERSION').write_text(VERSION+'\n')
    for e in index['versions']:
        if e['version']=='0.35.0':e['status']='superseded; textures user-confirmed; glow incorrectly activated on mouse-down'
    files=[dict(path=str(p['candidate'].relative_to(ROOT)),sha256=p['after'],bytes=p['candidate'].stat().st_size) for p in plan]
    index['current']=VERSION
    index['versions'].append(dict(version=VERSION,based_on='0.35.0',description='Fix logo glow to use native pointer-enter and pointer-leave callbacks; preserve 0.35.0 textures and accepted handoff',status='current; native regression checks passed; in-game hover validation pending',asset_version='0.35.0',files=files))
    ip.write_text(json.dumps(index,indent=2)+'\n')
    report=dict(version=VERSION,based_on='0.35.0',status='installed; restart required; in-game validation pending',date='2026-10-13',
        files=[dict(path=str(p['target']),backup=str(p['backup']),before_sha256=p['before'],sha256=p['after']) for p in plan],
        other_game_files_verified_unchanged=len(before),config_changed=False,saves_changed=False)
    (ROOT/'analysis/sign-hover-fix-installation.json').write_text(json.dumps(report,indent=2)+'\n')
    invp=ROOT/'analysis/edited-files-inventory.json';inv=json.loads(invp.read_text())
    for p in plan:
        entries=inv['installed_changed_files'];entry=next((e for e in entries if e.get('path')==str(p['target'])),None)
        if entry is None:entry=dict(path=str(p['target']));entries.append(entry)
        entry.update(sha256=p['after'],bytes=p['target'].stat().st_size)
        if str(p['backup']) not in inv['installed_patch_backups']:inv['installed_patch_backups'].append(str(p['backup']))
    for key,folder,names in [('tools','tools',['fix_sign_hover.py','verify_sign_hover_fix.py','install_sign_hover_fix.py']),
                             ('analysis_files','analysis',['sign-hover-fix.md','sign-hover-fix-candidate.json','sign-hover-fix-verification.json','sign-hover-fix-rea-evidence.json','sign-hover-fix-installation.json'])]:
        for name in names:
            value=str(ROOT/folder/name)
            if value not in inv[key]:inv[key].append(value)
    invp.write_text(json.dumps(inv,indent=2)+'\n')
    print(json.dumps(report,indent=2))
