#!/usr/bin/env python3
"""Install 0.31.1 only after candidate and native verification agree."""
import json
import os
import shutil
from pathlib import Path
from patch_debug_tools import ROOT, VERSION, BASELINE, digest
from workspace_paths import GAME

SOURCE_VERSION = '0.31.0'
INSTALLED_BASELINE = {
    'WLP': '5b8e2ce8845ca5a3f972d5a1618b3046d9d841b3662bde73bb2c23666ab817e6',
    'WLPADD1': '995d7321760ef176f0848b8cdd15f6bbb449f4f4e87333b9563af24bd01c8919',
}

if __name__ == '__main__':
    records = json.loads((ROOT/'analysis/debug-tools-candidate.json').read_text())
    assert {r['name'] for r in records} == set(BASELINE)
    for component in ('hud', 'panel', 'console'):
        checks = json.loads((ROOT/f'analysis/debug-{component}-verification.json').read_text())
        assert {(r['name'], r['image_base']) for r in checks} == {
            (name, base) for name in BASELINE for base in ('0x400000', '0x14000000')}
        assert all(r.get('passed') is True or r.get('status') == 'passed' for r in checks)
        expected_hashes = {r['name']: r[component]['code']['sha256'] for r in records}
        assert all(r['emittedcode_sha256'] == expected_hashes[r['name']] for r in checks)
        if component == 'console':
            candidates = {r['name']: r['sha256'] for r in records}
            assert all(r['sha256'] == candidates[r['name']] for r in checks)
    plan = []
    for record in records:
        name = record['name']+'.EXE'
        source = (ROOT/'builds/versions'/SOURCE_VERSION/name).read_bytes()
        candidate = (ROOT/'builds/versions'/VERSION/name).read_bytes()
        target = GAME/'Int/Win32/Program/VC6'/name
        assert record['source_sha256'] == BASELINE[record['name']]
        assert digest(source) == INSTALLED_BASELINE[record['name']]
        assert digest(candidate) == record['sha256']
        assert target.read_bytes() == source, 'Installed executable differs from baseline'
        assert (ROOT/'builds/current'/name).read_bytes() == source
        backup = ROOT/'archive/game-backups'/SOURCE_VERSION/'pre-debug-layout-fix'/name
        if backup.exists():
            assert backup.read_bytes() == source
        plan.append((target, backup, source, candidate))
    installed = []
    try:
        for target, backup, source, candidate in plan:
            backup.parent.mkdir(parents=True, exist_ok=True)
            if not backup.exists():
                backup.write_bytes(source)
            stage = target.with_name(target.name+'.debug-tools.tmp')
            stage.write_bytes(candidate)
            stage.chmod(target.stat().st_mode)
            assert target.read_bytes() == source
            os.replace(stage, target)
            installed.append((target, source))
            assert target.read_bytes() == candidate
    except Exception:
        for target, source in reversed(installed):
            stage = target.with_name(target.name+'.debug-tools-rollback.tmp')
            stage.write_bytes(source)
            stage.chmod(target.stat().st_mode)
            os.replace(stage, target)
        raise
    for target, backup, source, candidate in plan:
        shutil.copy2(target, ROOT/'builds/current'/target.name)
    (ROOT/'builds/current/VERSION').write_text(VERSION+'\n')
    index_path = ROOT/'builds/versions.json'
    index = json.loads(index_path.read_text())
    assert index['current'] == SOURCE_VERSION
    assert not any(entry['version'] == VERSION for entry in index['versions'])
    for entry in index['versions']:
        if entry['version'] == index['current']:
            entry['status'] = 'historical; user reported off-screen HUD and console'
    index['current'] = VERSION
    index['versions'].append(dict(version=VERSION,
        description='Fix off-screen notifications, debug readouts and console by reading the active display mode dimensions',
        status='current; native checks passed, gameplay validation pending',
        files=[dict(path=f'builds/versions/{VERSION}/{r["name"]}.EXE', sha256=r['sha256'], bytes=r['bytes']) for r in records]))
    index_path.write_text(json.dumps(index, indent=2)+'\n')
    report = dict(version=VERSION, status='installed; restart required; gameplay validation pending',
        files=[dict(path=str(target), backup=str(backup), before_sha256=digest(source), sha256=digest(candidate))
               for target, backup, source, candidate in plan], config_changed=False, saves_changed=False)
    (ROOT/'analysis/debug-tools-installation.json').write_text(json.dumps(report, indent=2)+'\n')
    inv_path = ROOT/'analysis/edited-files-inventory.json'
    inv = json.loads(inv_path.read_text())
    for target, backup, source, candidate in plan:
        for entry in inv.get('installed_changed_files', []):
            if entry.get('path') == str(target):
                entry.update(sha256=digest(candidate), bytes=len(candidate))
        if str(backup) not in inv['installed_patch_backups']:
            inv['installed_patch_backups'].append(str(backup))
    inv['date'] = '2026-10-13'
    for name in ('debug_hud.py', 'debug_panel.py', 'debug_console.py',
                 'verify_debug_hud.py', 'verify_debug_panel.py', 'verify_debug_console.py',
                 'patch_debug_tools.py', 'install_debug_tools.py'):
        path = str(ROOT/'tools'/name)
        if path not in inv['tools']:
            inv['tools'].append(path)
    for name in ('developer-leftovers.md', 'debug-tools.md', 'debug-tools-candidate.json',
                 'debug-hud-verification.json', 'debug-panel-verification.json',
                 'debug-console-verification.json', 'debug-tools-installation.json'):
        path = str(ROOT/'analysis'/name)
        if path not in inv['analysis_files']:
            inv['analysis_files'].append(path)
    inv_path.write_text(json.dumps(inv, indent=2)+'\n')
    print(json.dumps(report, indent=2))
