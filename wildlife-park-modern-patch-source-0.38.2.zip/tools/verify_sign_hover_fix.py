#!/usr/bin/env python3
"""Check native pointer transitions without mouse-down, and press independence."""
import json,subprocess,tempfile
from pathlib import Path
from fix_sign_hover import ROOT,build
from patch_debug_tools import digest
def verify(m):
 for base in (0x400000,0x14000000):
  s=m['symbols'];v=base+m['vtable'];bt=base+m['button'];ready=base+m['ready'];owner=base+m['owner']
  asm=f'''.intel_syntax noprefix
.code32
.global start
.section .main,"ax"
start:
 mov [saved_sp],esp
 mov ecx,OFFSET root
 push 0x12345678
 call thunk+{s['setup']}
 cmp eax,0x55667788
 jne fail
 cmp DWORD PTR [{v}+0x3c],{base+m['targets']['pressed']}
 jne fail
 cmp DWORD PTR [{v}+0x60],{base+m['rva']+s['enter']}
 jne fail
 cmp DWORD PTR [{v}+0x64],{base+m['rva']+s['leave']}
 jne fail
 # Simulate hit-test enter with no button-down/capture state.
 mov DWORD PTR [{bt}+0x270],0
 mov DWORD PTR [{bt}+0x240],0
 mov DWORD PTR [packet+0x30],9
 mov ecx,{bt}
 push OFFSET packet
 call DWORD PTR [{v}+0x60]
 cmp eax,0xabcdef01
 jne fail
 cmp DWORD PTR [frame],1
 jne fail
 # Mouse-down/up uses the original native slot and cannot change texture.
 mov ecx,{bt}
 push 1
 call DWORD PTR [{v}+0x3c]
 mov ecx,{bt}
 push 0
 call DWORD PTR [{v}+0x3c]
 cmp DWORD PTR [frame],1
 jne fail
 cmp DWORD PTR [frame_calls],1
 jne fail
 # Leave clears glow even when the button is pressed/captured.
 mov DWORD PTR [{bt}+0x270],1
 mov DWORD PTR [{bt}+0x240],1
 mov DWORD PTR [packet+0x30],10
 mov ecx,{bt}
 push OFFSET packet
 call DWORD PTR [{v}+0x64]
 cmp eax,0xabcdef02
 jne fail
 cmp DWORD PTR [frame],0
 jne fail
 cmp DWORD PTR [frame_calls],2
 jne fail
 mov DWORD PTR [{ready}],0
 mov DWORD PTR [packet+0x30],9
 mov ecx,{bt}
 push OFFSET packet
 call DWORD PTR [{v}+0x60]
 cmp DWORD PTR [frame_calls],2
 jne fail
 mov DWORD PTR [{ready}],1
 mov DWORD PTR [{owner}],0
 mov ecx,{bt}
 push OFFSET packet
 call DWORD PTR [{v}+0x60]
 cmp DWORD PTR [frame_calls],2
 jne fail
 cmp esp,[saved_sp]
 jne fail
 xor ebx,ebx
 mov eax,1
 int 0x80
fail:
 mov ebx,1
 mov eax,1
 int 0x80
.section .previous,"ax"
 cmp ecx,OFFSET root
 jne fail
 cmp DWORD PTR [esp+4],0x12345678
 jne fail
 mov eax,0x55667788
 ret 4
.section .enter,"ax"
 cmp ecx,{bt}
 jne fail
 mov eax,[esp+4]
 cmp eax,OFFSET packet
 jne fail
 cmp DWORD PTR [eax+0x30],9
 jne fail
 mov ecx,0x88998899
 mov eax,0xabcdef01
 ret 4
.section .leave,"ax"
 cmp ecx,{bt}
 jne fail
 mov eax,[esp+4]
 cmp eax,OFFSET packet
 jne fail
 cmp DWORD PTR [eax+0x30],10
 jne fail
 mov ecx,0x77887788
 mov eax,0xabcdef02
 ret 4
.section .pressed,"ax"
 cmp ecx,{bt}
 jne fail
 mov eax,[esp+4]
 mov [ecx+0x240],eax
 ret 4
.section .setter,"ax"
 cmp ecx,OFFSET root+0x2f0
 jne fail
 mov eax,[esp+4]
 cmp eax,1
 ja fail
 mov [frame],eax
 inc DWORD PTR [frame_calls]
 ret 4
.section .vtable,"aw"
 .zero 128
.section .ready,"aw"
 .long 1
.section .owner,"aw"
 .long root
.section .button,"aw"
 .zero 0x638
.section .thunk,"ax"
thunk: .incbin "CODEPATH"
.section .data,"aw"
saved_sp: .long 0
frame: .long 0
frame_calls: .long 0
packet: .zero 0x90
root: .zero 0x129b4
'''
  sec=dict(previous=m['previous'],enter=m['targets']['enter'],leave=m['targets']['leave'],pressed=m['targets']['pressed'],setter=m['frame_setter'],vtable=m['vtable'],ready=m['ready'],owner=m['owner'],button=m['button'],thunk=m['rva'])
  with tempfile.TemporaryDirectory() as tmp:
   d=Path(tmp);(d/'code.bin').write_bytes(m['code']);(d/'test.s').write_text(asm.replace('CODEPATH',str(d/'code.bin')))
   layout='\n'.join(f'.{k} {base+a} : {{ *(.{k}) }}' for k,a in sorted(sec.items(),key=lambda x:x[1]))
   (d/'test.ld').write_text(f'ENTRY(start)\nSECTIONS {{ .main {base+0x1000} : {{ *(.main) }}\n{layout}\n.data {base+m["rva"]+0x10000} : {{ *(.data) }} }}')
   subprocess.run(['as','--32','-o',str(d/'test.o'),str(d/'test.s')],check=True)
   r=subprocess.run(['ld','-m','elf_i386','-T',str(d/'test.ld'),'-o',str(d/'test'),str(d/'test.o')],capture_output=True,text=True);assert r.returncode==0,r.stderr
   r=subprocess.run([str(d/'test')],timeout=10);assert r.returncode==0,(m['name'],hex(base),r.returncode)
 print('PASS: '+m['name']+' enter without mouse-down, press/release independence, leave while held, lifetime guards and ABI; two image bases')
if __name__=='__main__':
 checks=[]
 for name in ('WLP','WLPADD1'):
  data,m=build(name);assert data==(ROOT/'builds/versions/0.35.1'/f'{name}.EXE').read_bytes();verify(m)
  checks.append(dict(name=name,passed=True,sha256=digest(data),code_sha256=digest(m['code']),image_bases=['0x400000','0x14000000']))
 (ROOT/'analysis/sign-hover-fix-verification.json').write_text(json.dumps(checks,indent=2)+'\n')
