#!/usr/bin/env python3
"""Execute the emitted x86 cursor paths with mocked Win32 APIs, via objdump.

Small instruction interpreter limited to this thunk's instruction set. Verifies
register/stack/flag restoration and actual branches/API arguments without a
Windows GUI. It does not substitute for testing Proton's ClipCursor behavior.
"""
import argparse
import re
import struct
import subprocess
from pathlib import Path
import pefile
from patch_mouse_confinement import patch, PROFILES
import hashlib


class Machine:
    def __init__(self, binary, meta, imports, delta, entry, stop, scenario):
        self.mem = {}
        p = pefile.PE(data=binary)
        self.base = p.OPTIONAL_HEADER.ImageBase
        for s in p.sections:
            if s.Name.rstrip(b'\0') != b'.wlpmous':
                continue
            for i, v in enumerate(binary[s.PointerToRawData:s.PointerToRawData + s.SizeOfRawData]):
                self.mem[self.base + s.VirtualAddress + i] = v
        self.reg = dict(zip(('eax', 'ecx', 'edx', 'ebx', 'esp', 'ebp', 'esi', 'edi'),
                            (11, 22, 33, 44, 0x20000000, 66, 77, 88)))
        self.original = dict(self.reg)
        self.flags = 0x202
        self.zf = False
        self.le = False
        self.meta = meta
        self.scenario = scenario
        self.calls = []
        self.last_error = 1234
        self.ip = self.base + entry
        self.stop = self.base + stop
        self.api_by_ptr = {}
        self.api_ptrs = {}
        for n, name in enumerate((*imports.keys(), 'ClipCursor', 'ClientToScreen', 'GetForegroundWindow')):
            ptr = 0x10000000 + n * 16
            self.api_by_ptr[ptr] = name
            self.api_ptrs[name] = ptr
        for name, addr in imports.items():
            self.write(self.base + addr, self.api_ptrs[name])
        self.write(self.base + 0xa52fb0 + delta, 0x1234)
        self.write(self.base + 0xa423a4 + delta, scenario.get('actual_window', 0x1234))
        if 'global_window' in scenario:
            self.write(self.base + 0xa52fb0 + delta, scenario['global_window'])
        self.write(self.base + 0xa56980 + delta, 1 if scenario.get('world', True) else 0)
        self.write(self.base + 0xa39368 + delta, scenario.get('active_flags',
                   0x80 if scenario.get('windowed', True) else 1))
        self.write(self.base + meta['data']['owned'], scenario.get('owned', 0))
        self.write(self.base + meta['data']['busy'], scenario.get('busy', 0))
        self.write(self.base + 0xa42868 + delta + 0x24, scenario.get('gui_surface', 0))
        self.gui = self.base + 0xa42868 + delta
        if meta.get('mouse_dispatch'):
            self.api_by_ptr[self.base + meta['mouse_dispatch']] = 'NeutralMouse'
        if scenario.get('cached', False):
            for name in ('ClipCursor', 'ClientToScreen', 'GetForegroundWindow'):
                self.write(self.base + meta['data'][name], self.api_ptrs[name])
        self.write(self.reg['esp'] + 4, scenario.get('focus_arg', 1))

    def read(self, addr, size=4):
        return sum(self.mem.get(addr + i, 0) << (8 * i) for i in range(size))

    def write(self, addr, value, size=4):
        for i in range(size):
            self.mem[addr + i] = (value >> (8 * i)) & 255

    def push(self, value):
        self.reg['esp'] -= 4
        self.write(self.reg['esp'], value)

    def pop(self):
        value = self.read(self.reg['esp'])
        self.reg['esp'] += 4
        return value

    def address(self, value):
        inner = value[value.index('[') + 1:value.index(']')]
        return sum(self.reg[x] if x in self.reg else int(x, 0) for x in inner.split('+'))

    def value(self, value):
        if '[' in value:
            return self.read(self.address(value), 1 if value.startswith('BYTE') else 4)
        return self.reg[value] if value in self.reg else int(value, 0)

    def assign(self, dest, value):
        if '[' in dest:
            self.write(self.address(dest), value)
        else:
            self.reg[dest] = value & 0xffffffff

    def cstring(self, ptr):
        result = bytearray()
        while self.read(ptr, 1):
            result.append(self.read(ptr, 1)); ptr += 1
        return result.decode()

    def api(self, name):
        count = {'GetLastError': 0, 'SetLastError': 1, 'GetModuleHandleA': 1,
                 'GetProcAddress': 2, 'GetForegroundWindow': 0, 'GetClientRect': 2,
                 'ClientToScreen': 2, 'ClipCursor': 1, 'SetCursor': 1, 'NeutralMouse': 4}[name]
        args = [self.pop() for _ in range(count)]
        ret = 1
        if name == 'GetLastError': ret = self.last_error
        elif name == 'SetLastError': self.last_error = args[0]
        elif name == 'GetModuleHandleA':
            assert self.cstring(args[0]) == 'user32.dll'
            ret = 0x7777
        elif name == 'GetProcAddress':
            ret = self.api_ptrs[self.cstring(args[1])] if not self.scenario.get('api_fail') else 0
        elif name == 'GetForegroundWindow': ret = 0x1234 if self.scenario.get('foreground', True) else 0x9999
        elif name == 'GetClientRect':
            assert args[0] == 0x1234
            ret = 0 if self.scenario.get('rect_fail') else 1
            for i, value in enumerate(self.scenario.get('rect', (0, 0, 1280, 720))):
                self.write(args[1] + i * 4, value)
        elif name == 'ClientToScreen':
            assert args[0] == 0x1234
            for i, v in enumerate(self.scenario.get('origin', (100, 200))):
                self.write(args[1] + i * 4, self.read(args[1] + i * 4) + v)
        elif name == 'ClipCursor':
            self.calls.append(None if args[0] == 0 else tuple(self.read(args[0] + i * 4) for i in range(4)))
            ret = 0 if self.scenario.get('clip_fail') else 1
        elif name == 'NeutralMouse':
            assert self.reg['ecx'] == self.gui
            assert args[0] == self.read(self.gui + 0x24) and args[3] == 0
            self.write(self.gui + 0x28, args[1])
            self.write(self.gui + 0x2c, args[2])
            self.scenario['neutral_calls'] = self.scenario.get('neutral_calls', 0) + 1
        elif name == 'SetCursor':
            assert args == [0]
            self.scenario['hidden_cursor'] = True
        if name not in ('GetLastError', 'SetLastError'): self.last_error = 5678
        # Volatile registers/flags may be clobbered by a Win32 call.
        self.reg.update(eax=ret, ecx=0xdead, edx=0xbeef)
        self.zf = False; self.le = False

    def run(self, instructions):
        for _ in range(1000):
            if self.ip == self.stop:
                assert self.reg == self.original, (self.reg, self.original)
                assert self.flags == 0x202 and self.last_error == 1234
                return self.calls
            next_ip, mnemonic, operands = instructions[self.ip]
            self.ip = next_ip
            args = operands.split(',') if operands else []
            if mnemonic == 'pushf': self.push(self.flags)
            elif mnemonic == 'pusha':
                saved_esp = self.reg['esp']
                for reg in ('eax', 'ecx', 'edx', 'ebx', 'esp', 'ebp', 'esi', 'edi'):
                    self.push(saved_esp if reg == 'esp' else self.reg[reg])
            elif mnemonic == 'popa':
                for reg in ('edi', 'esi', 'ebp', 'esp', 'ebx', 'edx', 'ecx', 'eax'):
                    v = self.pop()
                    if reg != 'esp': self.reg[reg] = v
            elif mnemonic == 'popf': self.flags = self.pop()
            elif mnemonic == 'push': self.push(self.value(args[0]))
            elif mnemonic == 'pop': self.reg[args[0]] = self.pop()
            elif mnemonic == 'mov': self.assign(args[0], self.value(args[1]))
            elif mnemonic == 'lea': self.assign(args[0], self.address(args[1]))
            elif mnemonic == 'and':
                self.assign(args[0], self.value(args[0]) & self.value(args[1]))
            elif mnemonic == 'shr':
                self.assign(args[0], self.value(args[0]) >> (self.value(args[1]) if len(args) > 1 else 1))
            elif mnemonic == 'inc':
                self.assign(args[0], self.value(args[0]) + 1)
            elif mnemonic == 'ret': self.ip = self.pop()
            elif mnemonic in ('sub', 'add'):
                a, b = self.value(args[0]), self.value(args[1])
                self.assign(args[0], a - b if mnemonic == 'sub' else a + b)
            elif mnemonic in ('cmp', 'test'):
                a, b = self.value(args[0]), self.value(args[1])
                self.zf = (a == b) if mnemonic == 'cmp' else (a & b == 0)
                signed = lambda v: v - 0x100000000 if v & 0x80000000 else v
                self.le = signed(a) <= signed(b)
            elif mnemonic in ('je', 'jne', 'jle', 'jmp'):
                if mnemonic == 'jmp' or (mnemonic == 'je' and self.zf) or (mnemonic == 'jne' and not self.zf) or (mnemonic == 'jle' and self.le):
                    self.ip = int(args[0], 16)
            elif mnemonic == 'call':
                target = self.value(args[0])
                if target in self.api_by_ptr: self.api(self.api_by_ptr[target])
                else: self.push(next_ip); self.ip = target
            else: raise AssertionError((mnemonic, operands))
        raise AssertionError('Thunk did not terminate')


def verify(source, output, window_events=False, focused_gameplay=False, cache_rectangle=False, lifecycle=False,
           background_filter=False):
    src, binary = source.read_bytes(), output.read_bytes()
    rebuilt, meta = patch(src, window_events=window_events, focused_gameplay=focused_gameplay,
                          cache_rectangle=cache_rectangle, lifecycle=lifecycle,
                          background_filter=background_filter)
    assert rebuilt == binary
    delta, pump, focus = PROFILES[hashlib.sha256(src).hexdigest()]
    p = pefile.PE(data=binary)
    imports = {i.name.decode(): i.address - p.OPTIONAL_HEADER.ImageBase
               for dll in p.DIRECTORY_ENTRY_IMPORT for i in dll.imports if i.name}
    asm = subprocess.check_output(['objdump', '-d', '-Mintel', '-j', '.wlpmous', str(output)], text=True)
    instructions = {}
    for line in asm.splitlines():
        m = re.match(r'\s*([0-9a-f]+):\s*((?:[0-9a-f]{2}\s+)+)\s*([a-z]+)\s*(.*)', line)
        if m:
            addr = int(m[1], 16)
            instructions[addr] = (addr + len(m[2].split()), m[3], m[4].strip())
    # Wrapped long instructions have continuation bytes without mnemonics.
    ordered = sorted(instructions)
    for i, addr in enumerate(ordered[:-1]):
        _, op, operands = instructions[addr]
        instructions[addr] = (ordered[i + 1], op, operands)
    old_audio = pump + 5 + struct.unpack_from('<i', src, pump + 1)[0]
    cases = [({}, [(100, 200, 1380, 920)]),
             ({'foreground': False}, []),
             ({'foreground': False, 'owned': 1}, [None]),
             ({'world': False}, []), ({'world': False, 'owned': 1}, [None]),
             ({'windowed': False}, [(100, 200, 1380, 920)] if focused_gameplay else []),
             ({'windowed': False, 'owned': 1}, [(100, 200, 1380, 920)] if focused_gameplay else [None]),
             ({'rect_fail': True, 'owned': 1}, [None]),
             ({'rect': (0, 0, 0, 0), 'owned': 1}, [None]),
             ({'api_fail': True}, []), ({'busy': 1}, []),
             ({'cached': True, 'origin': (-1200, 40)}, [(-1200 & 0xffffffff, 40, 80, 760)])]
    if window_events:
        cases.extend([({'global_window': 0x7777}, [(100, 200, 1380, 920)]),
                      ({'actual_window': 0}, [(100, 200, 1380, 920)])])
    if focused_gameplay:
        # Values observed in the expansion's real Proton trace. Both launcher
        # and park used flags 0x6200; only the world lifetime distinguishes them.
        cases.extend([({'active_flags': 0x6200, 'global_window': 0}, [(100, 200, 1380, 920)]),
                      ({'active_flags': 0x6200, 'global_window': 0, 'world': False}, []),
                      ({'active_flags': 0x6200, 'foreground': False, 'owned': 1}, [None])])
    for scenario, expected in cases:
        machine = Machine(binary, meta, imports, delta, meta['rva'],
                          meta['update_return'] if window_events else old_audio, scenario)
        assert machine.run(instructions) == expected, scenario
    for scenario, expected in [({'owned': 1, 'cached': True, 'focus_arg': 1}, [None]),
                               ({'owned': 1, 'cached': True, 'focus_arg': 2}, []),
                               ({'owned': 0, 'cached': True, 'focus_arg': 1}, [])]:
        machine = Machine(binary, meta, imports, delta, meta['focus_target'],
                          meta['rva'] + meta['code_bytes'] - 10, scenario)
        assert machine.run(instructions) == expected
    count = len(cases) + 3
    if cache_rectangle:
        machine = Machine(binary, meta, imports, delta, meta['rva'], meta['update_return'], {})
        assert machine.run(instructions) == [(100, 200, 1380, 920)]
        for _ in range(100):
            machine.ip = machine.base + meta['rva']
            assert machine.run(instructions) == [(100, 200, 1380, 920)]
        # Moving/resizing must refresh the desktop rectangle exactly once.
        machine.scenario['origin'] = (300, 400)
        machine.scenario['rect'] = (0, 0, 800, 600)
        machine.ip = machine.base + meta['rva']
        assert machine.run(instructions) == [(100, 200, 1380, 920), (300, 400, 1100, 1000)]
        machine.scenario['foreground'] = False
        machine.ip = machine.base + meta['rva']
        assert machine.run(instructions)[-1] is None
        machine.scenario['foreground'] = True
        machine.ip = machine.base + meta['rva']
        assert machine.run(instructions) == [(100, 200, 1380, 920), (300, 400, 1100, 1000),
                                             None, (300, 400, 1100, 1000)]
        count += 104
    if window_events:
        for msg, arg, expected in [(8, 0, [None]), (0x1c, 0, [None]),
                                   (6, 0, [None]), (2, 0, [None]),
                                   (0x82, 0, [None]), (0x231, 0, [None]),
                                   (0x200, 0, [(100, 200, 1380, 920)]),
                                   (0x201, 0, [(100, 200, 1380, 920)]),
                                   (7, 0, [(100, 200, 1380, 920)]),
                                   (0x1c, 1, [(100, 200, 1380, 920)]),
                                   (6, 2, [(100, 200, 1380, 920)])]:
            machine = Machine(binary, meta, imports, delta, meta['event_target'],
                              meta['event_original'], {'owned': 1, 'cached': True,
                                                       'global_window': 0x7777})
            machine.write(machine.reg['esp'] + 16, msg)
            machine.write(machine.reg['esp'] + 20, arg)
            assert machine.run(instructions) == expected, (msg, arg)
            count += 1
    if lifecycle:
        machine = Machine(binary, meta, imports, delta, meta['rva'], meta['update_return'], {})
        machine.run(instructions)
        # A recreated window with identical bounds must reacquire capture.
        machine.write(machine.base + meta['data']['captured_window'], 0x7777)
        machine.ip = machine.base + meta['rva']
        assert len(machine.run(instructions)) == 2
        # Layout invalidation must also reacquire identical bounds, once.
        machine.write(machine.base + meta['data']['rect_valid'], 0)
        machine.ip = machine.base + meta['rva']
        assert len(machine.run(instructions)) == 3
        machine.ip = machine.base + meta['rva']
        assert len(machine.run(instructions)) == 3
        count += 4
        # Background input goes through the original GUI mouse dispatcher with
        # a center position, once, while leaving the desktop cursor untouched.
        scenario = {'foreground': False, 'gui_surface': 0x7777, 'cached': True}
        machine = Machine(binary, meta, imports, delta, meta['neutral_target'], meta['neutral_return'], scenario)
        assert machine.run(instructions) == []
        assert scenario['neutral_calls'] == 1
        assert (machine.read(machine.gui + 0x28), machine.read(machine.gui + 0x2c)) == (640, 360)
        machine.ip = machine.base + meta['neutral_target']
        machine.run(instructions)
        assert scenario['neutral_calls'] == 1
        count += 2
        for msg in (1, 3, 5, 0x18, 0x47, 0x7e):
            machine = Machine(binary, meta, imports, delta, meta['event_target'], meta['event_original'], {'cached': True})
            machine.write(machine.reg['esp'] + 16, msg)
            machine.write(machine.base + meta['data']['rect_valid'], 1)
            assert machine.run(instructions) == []
            assert machine.read(machine.base + meta['data']['rect_valid']) == 0
            count += 1
        for hit in (1, 2):
            scenario = {'cached': True}
            stop = meta['event_consumed'] if hit == 1 else meta['event_original']
            machine = Machine(binary, meta, imports, delta, meta['event_target'], stop, scenario)
            machine.write(machine.reg['esp'] + 16, 0x20)
            machine.write(machine.reg['esp'] + 24, hit)
            machine.run(instructions)
            assert scenario.get('hidden_cursor', False) == (hit == 1)
            count += 1
    if background_filter:
        for scenario, blocked in [({'cached': True}, False),
                                  ({'cached': True, 'foreground': False}, True),
                                  ({'cached': True, 'foreground': False, 'world': False}, False),
                                  ({'cached': True, 'foreground': False, 'actual_window': 0}, True),
                                  ({'cached': True, 'foreground': False, 'actual_window': 0, 'global_window': 0}, False),
                                  ({'foreground': False}, False)]:
            stop = meta['mouse_filter_skip'] if blocked else meta['mouse_filter_original']
            machine = Machine(binary, meta, imports, delta, meta['mouse_filter_target'], stop, scenario)
            assert machine.run(instructions) == []
            count += 1
        scenario = {'cached': True, 'foreground': False, 'gui_surface': 0x7777}
        machine = Machine(binary, meta, imports, delta, meta['mouse_filter_target'], meta['mouse_filter_skip'], scenario)
        for _ in range(100):
            machine.ip = machine.base + meta['mouse_filter_target']
            assert machine.run(instructions) == []
            assert scenario['neutral_calls'] == 1
            assert (machine.read(machine.gui + 0x28), machine.read(machine.gui + 0x2c)) == (640, 360)
        count += 100
    for block in p.DIRECTORY_ENTRY_BASERELOC:
        for entry in block.entries:
            assert not entry.type or not focus <= entry.rva < focus + 5
            if window_events:
                assert not entry.type or not meta['event_hook'] <= entry.rva < meta['event_hook'] + 6
            if background_filter:
                assert not entry.type or not meta['mouse_filter_hook'] <= entry.rva < meta['mouse_filter_hook'] + 5
    assert all(s.PointerToRawData + s.SizeOfRawData <= len(binary) for s in p.sections)
    for section in pefile.PE(data=src).sections:
        if section.Name.rstrip(b'\0') in (b'.wlpaud', b'.wlpfoc', b'.wlpmode', b'.wlpwide', b'.wlplnch'):
            off, size = section.PointerToRawData, section.SizeOfRawData
            assert src[off:off + size] == binary[off:off + size]
    print(output.name, f'PASS: {count} emitted-code scenarios; registers/stack/flags/last error preserved; prior fixes intact')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--window-events', action='store_true')
    parser.add_argument('--focused-gameplay', action='store_true')
    parser.add_argument('--cache-rectangle', action='store_true')
    parser.add_argument('--lifecycle', action='store_true')
    parser.add_argument('--background-filter', action='store_true')
    args = parser.parse_args()
    verify(args.source, args.output, window_events=args.window_events,
           focused_gameplay=args.focused_gameplay, cache_rectangle=args.cache_rectangle,
           lifecycle=args.lifecycle, background_filter=args.background_filter)
