#!/usr/bin/env python3
"""Restore verified pre-zoom builds, retaining all other installed fixes."""
import hashlib,json,os
from pathlib import Path
from workspace_paths import artifact, backup_path
import pefile

root=Path('/path/to/Wildlife Park Gold')
program=root/'Int/Win32/Program/VC6'
profiles=[('WLP','676951470191bd312fca07ca0f9699d8c9d78b08d390f76662e6b7842dcdfdc1','2fe9f1d75866c80096a369e9c705736677178f4f7529c54323ed0f4d24eee882'),
          ('WLPADD1','b7f2a6ee1a4ac6556e8abfe08f85de864154d3269024bfd0843b8d9442fa625d','8951a55ded77c912aad4ed2688677b5aa9fc880861373ce6b95620176e6c15a6')]
digest=lambda data:hashlib.sha256(data).hexdigest()
assets=[root/'Int/All/Pictures.cont',root/'Int/All/Pictures/GUI.alb',root/'Config.ini']
unchanged={str(p):digest(p.read_bytes()) for p in assets}
pending=[]
for name,expected,target_hash in profiles:
 target=program/(name+'.EXE');old=target.read_bytes()
 assert digest(old)==expected
 new=backup_path(target.with_name(target.name+'.pre-zoom-steps.bak')).read_bytes()
 assert digest(new)==target_hash
 assert new==artifact(name+'_widescreen_weather_menu.EXE').read_bytes()
 assert not any(s.Name.rstrip(b'\0') in (b'.wlpzoom',b'.wlpdtim') for s in pefile.PE(data=new).sections)
 backup=backup_path(target.with_name(target.name+'.pre-revert-zoom.bak'))
 if backup.exists():assert backup.read_bytes()==old
 pending.append((target,old,new,backup))
records=[]
for target,old,new,backup in pending:
 if not backup.exists():
  with backup.open('xb') as f:f.write(old)
 staged=target.with_name(target.name+'.revert-zoom.tmp')
 with staged.open('xb') as f:f.write(new)
 staged.chmod(target.stat().st_mode)
 assert target.read_bytes()==old
 os.replace(staged,target)
 assert target.read_bytes()==new
 records.append(dict(path=str(target),backup=str(backup),previous_sha256=digest(old),sha256=digest(new),bytes=len(new)))
assert unchanged=={str(p):digest(p.read_bytes()) for p in assets}
Path('analysis/zoom-rollback-installation.json').write_text(json.dumps(dict(executables=records,unchanged_files=unchanged),indent=2)+'\n')
inventory=Path('analysis/edited-files-inventory.json');doc=json.loads(inventory.read_text())
for r in records:
 entry=next(x for x in doc['installed_changed_files'] if x['path']==r['path'])
 entry.update(sha256=r['sha256'],bytes=r['bytes'])
 if r['backup'] not in doc['installed_patch_backups']:doc['installed_patch_backups'].append(r['backup'])
inventory.write_text(json.dumps(doc,indent=2)+'\n')
print(json.dumps(records,indent=2))
