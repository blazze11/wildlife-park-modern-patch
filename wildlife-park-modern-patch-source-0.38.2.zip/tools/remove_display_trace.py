#!/usr/bin/env python3
"""Preserve timing captures and restore exact pre-diagnostic executables."""
import hashlib,json,os
from pathlib import Path
from workspace_paths import artifact

records=json.loads(Path('analysis/display-transition-installation.json').read_text())
pending=[]
for r in records:
 target=Path(r['path']);old=target.read_bytes();new=artifact(r['backup']).read_bytes()
 assert hashlib.sha256(old).hexdigest()==r['sha256']
 assert hashlib.sha256(new).hexdigest()==r['previous_sha256']
 pending.append((target,old,new))
root=Path(records[0]['path']).parents[4]
for name in ('base','addon'):
 trace=root/f'DisplayTransition-{name}.bin'
 if trace.exists():Path(f'analysis/DisplayTransition-{name}-first.bin').write_bytes(trace.read_bytes())
for target,old,new in pending:
 staged=target.with_name(target.name+'.remove-display-trace.tmp')
 with staged.open('xb') as f:f.write(new)
 staged.chmod(target.stat().st_mode)
 assert target.read_bytes()==old
 os.replace(staged,target)
 assert target.read_bytes()==new
 print(target.name,hashlib.sha256(new).hexdigest())
Path('analysis/display-transition-restoration.json').write_text(json.dumps([
 dict(path=str(t),sha256=hashlib.sha256(n).hexdigest(),size=len(n)) for t,o,n in pending],indent=2)+'\n')
