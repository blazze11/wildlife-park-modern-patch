#!/usr/bin/env python3
"""Move the three shared F2 caption bounds up three pixels, one byte per EXE."""
import json
import pefile
from patch_debug_tools import ROOT,digest,public
VERSION='0.38.2'
def check_preservation(before,after,m):
 assert len(before)==len(after)
 p=pefile.PE(data=before);expected=bytearray(before)
 for rva,n in m['changes']:
  off=p.get_offset_from_rva(rva);expected[off:off+n]=after[off:off+n]
 assert bytes(expected)==after
 assert sum(a!=b for a,b in zip(before,after))==1

def patch(data,name):
 record=next(x for x in json.loads((ROOT/'analysis/f2-button-labels-candidate.json').read_text()) if x['name']==name)
 assert digest(data)==record['sha256']
 old=record['patch'];p=pefile.PE(data=data)
 start=old['rva']+old['symbols']['update'];end=old['rva']+old['symbols']['centered']
 block=p.get_data(start,end-start)
 # x=4, y=0, w=112, h=28, native thiscall bounds setter.
 pattern=bytes.fromhex('6a1c6a706a006a0489f9e8');assert block.count(pattern)==1
 at=start+block.index(pattern)+5;off=p.get_offset_from_rva(at);b=bytearray(data)
 assert b[off]==0;b[off]=0xfd # push imm8 sign-extends to -3
 newcode=bytes(pefile.PE(data=b).get_data(old['rva'],old['code']['bytes']))
 m=dict(name=name,code=newcode,changes=[(at,1)],reloc_offsets=[],caption_y=-3,previous_caption_y=0)
 check_preservation(data,b,m);return bytes(b),m
if __name__=='__main__':
 out=ROOT/'builds/versions'/VERSION;out.mkdir(exist_ok=True);records=[];checks=[]
 for name in ('WLP','WLPADD1'):
  source=ROOT/'builds/versions/0.38.1'/f'{name}.EXE';data,m=patch(source.read_bytes(),name);target=out/source.name
  if target.exists():assert target.read_bytes()==data
  else:target.write_bytes(data)
  records.append(dict(name=name,sha256=digest(data),patch=public(m)))
  checks.append(dict(name=name,passed=True,sha256=digest(data),code_sha256=digest(m['code']),changed_bytes=1,caption_y=-3))
 (ROOT/'analysis/f2-label-height-candidate.json').write_text(json.dumps(records,indent=2)+'\n')
 (ROOT/'analysis/f2-label-height-verification.json').write_text(json.dumps(checks,indent=2)+'\n')
 print(json.dumps(checks,indent=2))
