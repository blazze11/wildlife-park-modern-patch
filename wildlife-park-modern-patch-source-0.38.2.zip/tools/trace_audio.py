#!/usr/bin/env python3
"""Build a v6 diagnostic executable that logs audio transitions without changing them."""
import hashlib
import struct
from pathlib import Path
from workspace_paths import artifact
import pefile
from patch_audio_startup import V6


def patch(src):
    assert hashlib.sha256(src).hexdigest() == V6
    p = pefile.PE(data=src)
    out = bytearray(src)
    align = lambda n, a: (n + a - 1) // a * a
    last = p.sections[-1]
    rva = align(last.VirtualAddress + max(last.Misc_VirtualSize, last.SizeOfRawData),
                p.OPTIONAL_HEADER.SectionAlignment)
    raw = align(len(out), p.OPTIONAL_HEADER.FileAlignment)
    code = bytearray()
    messages = []

    def emit(data):
        code.extend(data)

    def message(text):
        emit(b'\x8d\x83')
        messages.append((len(code), ('WLP_AUDIO ' + text + '\n\0').encode('ascii')))
        emit(bytes(4) + b'\x50\xff\x93' + struct.pack('<I', 0x30423c))

    def branch(opcode):
        emit(opcode + bytes(4))
        return len(code) - 4

    def resolve(pos):
        struct.pack_into('<i', code, pos, len(code) - pos - 4)

    def state(offset, mask, label):
        if mask:
            emit(b'\xf6\x86' + struct.pack('<I', offset) + bytes([mask]))
        else:
            emit(b'\x83\xbe' + struct.pack('<I', offset) + b'\x00')
        zero = branch(b'\x0f\x84')
        message(label + '=1')
        done = branch(b'\xe9')
        resolve(zero)
        message(label + '=0')
        resolve(done)

    sites = [
        (0x2735a0, bytes.fromhex('8b44240456'), 'focus', True),
        (0x273670, bytes.fromhex('8b44240456'), 'enable', True),
        (0x2736a0, bytes.fromhex('56578bf933f6'), 'playback-start', False),
        (0x2737a0, bytes.fromhex('568bf18b8694000000'), 'playback-stop', False),
    ]
    for hook, original, event, arg in sites:
        assert out[hook:hook + len(original)] == original
        entry = rva + len(code)
        emit(b'\x9c\x60\x8b\xf1')  # Save flags/registers, ESI = audio engine.
        emit(b'\xe8\x00\x00\x00\x00\x5b')
        anchor = rva + len(code) - 1
        emit(b'\x81\xeb' + struct.pack('<I', anchor))
        message('event=' + event)
        if arg:
            emit(bytes.fromhex('837c242801'))  # Original argument at saved ESP + 40.
            other = branch(b'\x0f\x85')
            message('argument=1')
            done = branch(b'\xe9')
            resolve(other)
            emit(bytes.fromhex('837c242802'))
            not_two = branch(b'\x0f\x85')
            message('argument=2')
            end_two = branch(b'\xe9')
            resolve(not_two)
            message('argument=other')
            resolve(end_two)
            resolve(done)
        state(8, 4, 'enabled-before')
        state(0x90, 0, 'suspended-before')
        state(0x8c, 0, 'initialized-before')
        state(0x94, 0, 'playback-before')
        emit(b'\x61\x9d' + original)
        emit(b'\xe9' + struct.pack('<i', hook + len(original) - (rva + len(code) + 5)))
        out[hook:hook + len(original)] = (b'\xe9' + struct.pack('<i', entry - hook - 5)
                                         + b'\x90' * (len(original) - 5))
    executable_size = len(code)
    for pos, msg in messages:
        struct.pack_into('<I', code, pos, rva + len(code))
        code.extend(msg)
    header = p.sections[0].get_file_offset() + 40 * p.FILE_HEADER.NumberOfSections
    assert header + 40 <= p.OPTIONAL_HEADER.SizeOfHeaders and not any(out[header:header+40])
    size = align(len(code), p.OPTIONAL_HEADER.FileAlignment)
    out[header:header+40] = struct.pack('<8sIIIIIIHHI', b'.wlpatrc', len(code), rva,
                                       size, raw, 0, 0, 0, 0, 0x60000020)
    struct.pack_into('<H', out, p.FILE_HEADER.get_field_absolute_offset('NumberOfSections'),
                     p.FILE_HEADER.NumberOfSections + 1)
    for field, value in [('SizeOfImage', align(rva + len(code), p.OPTIONAL_HEADER.SectionAlignment)),
                         ('SizeOfCode', p.OPTIONAL_HEADER.SizeOfCode + size), ('CheckSum', 0)]:
        struct.pack_into('<I', out, p.OPTIONAL_HEADER.get_field_absolute_offset(field), value)
    out.extend(bytes(raw - len(out)) + code + bytes(size - len(code)))
    return bytes(out), executable_size


if __name__ == '__main__':
    src = artifact('WLP_widescreen_v6.EXE').read_bytes()
    out, code_size = patch(src)
    dest = artifact('WLP_widescreen_audio_diagnostic.EXE')
    with dest.open('xb') as stream:
        stream.write(out)
    print('Code bytes:', code_size)
    print('SHA256:', hashlib.sha256(out).hexdigest())
