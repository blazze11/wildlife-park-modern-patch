#!/usr/bin/env python3
"""Change verified v3 gameplay display requests from 16 to 32-bit color."""
import argparse,hashlib
from pathlib import Path
V3='3942a2372e425ea0431cfed2ba0cf925618eabdbed94df16d8f455e9bbbb16ef'
SITES=(0x1039ea,0x104eb3,0x1050c5,0x1054db,0x105b60,0x105eb1,0x10650c,0x144d69)
def patch(data):
    if hashlib.sha256(data).hexdigest()!=V3:raise ValueError('Requires exact verified v3 input')
    output=bytearray(data)
    for offset in SITES:
        if data[offset:offset+2]!=b'\x6a\x10':raise ValueError('Display depth instruction mismatch')
        output[offset+1]=32
    return bytes(output)
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('input',type=Path);p.add_argument('output',type=Path);a=p.parse_args()
    result=patch(a.input.read_bytes())
    with a.output.open('xb') as f:f.write(result)
    print(hashlib.sha256(result).hexdigest())
