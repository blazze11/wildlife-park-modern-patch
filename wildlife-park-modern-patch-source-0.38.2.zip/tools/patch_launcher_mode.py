#!/usr/bin/env python3
"""Restore the launcher's 800x600 mode alongside the four widescreen choices.

Reuse the unused 512x384 DirectDraw slot at each depth. The existing width
filter excludes 512, so those slots were already unavailable. Retain 87 table
entries, the 70-record driver bound, and all widescreen/focus/audio fixes.
"""
import argparse
import hashlib
import struct
from pathlib import Path
import pefile
from patch_addon_widescreen import GROUPS as ADDON_GROUPS, append_section, next_rva
from patch_resolution_choices import GROUPS as BASE_GROUPS

PROFILES = {
    '864fd20600dd5f84d0655712f4475e55ef6f04c6f5c969d32f941e58a0ed8d18':
        (BASE_GROUPS, 0x27f324),
    'bd5208c96fe99bbbc7b3e38df491df3223869ca33863aa4d7116ef8b5cd6f938':
        (ADDON_GROUPS, 0x2acf14),
}


def patch(src):
    profile = PROFILES.get(hashlib.sha256(src).hexdigest())
    if profile is None:
        raise ValueError('Requires known working widescreen build, without diagnostics')
    groups, hook = profile
    b = bytearray(src)
    p = pefile.PE(data=src)
    wide = next(s for s in p.sections if s.Name.rstrip(b'\0') == b'.wlpwide')
    assert b[hook] == 0xe9
    target = hook + 5 + struct.unpack_from('<i', b, hook + 1)[0]
    assert target == wide.VirtualAddress
    code = bytearray()
    for depth, last, index in groups:
        off = last - 9 * 80
        assert struct.unpack_from('<III', src, off) == (511, 383, depth)
        struct.pack_into('<II', b, off, 799, 599)
        slot = index - 9
        for delta, value in ((0, 800), (4, 600)):
            code += bytes.fromhex('c78424') + struct.pack('<II', 0x10 + slot * 12 + delta, value)
    rva = next_rva(b)
    # Execute these MOVs before the existing widescreen table thunk. Neither
    # changes registers, flags or stack depth; all original checks still run.
    code += b'\xe9' + struct.pack('<i', target - (rva + len(code) + 5))
    b[hook:hook + 5] = b'\xe9' + struct.pack('<i', rva - hook - 5)
    append_section(b, b'.wlplnch', code)
    return bytes(b)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    result = patch(args.source.read_bytes())
    with args.output.open('xb') as f:
        f.write(result)
    print(hashlib.sha256(result).hexdigest())
