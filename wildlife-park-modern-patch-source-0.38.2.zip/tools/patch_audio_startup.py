#!/usr/bin/env python3
"""Experimental v7: reconcile audio suspension once after audio initialization."""
import argparse
import hashlib
import struct
from pathlib import Path
import pefile

V6 = '6c7792ffdf3fd93a24a540bd2c73554def617201b181a1389b08e800b2a0efee'


def patch(src):
    if hashlib.sha256(src).hexdigest() != V6:
        raise ValueError('Requires verified WLP_widescreen_v6.EXE')
    p = pefile.PE(data=src)
    out = bytearray(src)
    align = lambda n, a: (n + a - 1) // a * a
    last = p.sections[-1]
    rva = align(last.VirtualAddress + max(last.Misc_VirtualSize, last.SizeOfRawData),
                p.OPTIONAL_HEADER.SectionAlignment)
    raw = align(len(out), p.OPTIONAL_HEADER.FileAlignment)
    hook = 0x2451b0
    original = bytes.fromhex('e8bbe40200')  # CALL audio enable, ECX = audio engine
    assert out[hook:hook + 5] == original
    code = bytearray()

    def call(target):
        code.extend(b'\xe8' + struct.pack('<i', target - (rva + len(code) + 5)))

    code.extend(b'\xff\x74\x24\x04')  # Forward enable argument across wrapper frame.
    call(0x273670)  # Original callee consumes the forwarded argument.
    code.extend(b'\x9c\x60')  # Preserve original return value, registers and flags.
    code.extend(b'\xe8\x00\x00\x00\x00\x5b')
    anchor = rva + len(code) - 1
    # EBX becomes the module base without requiring relocation entries.
    code.extend(b'\x81\xeb' + struct.pack('<I', anchor))
    code.extend(b'\xff\x93' + struct.pack('<I', 0x304290))  # GetActiveWindow()
    code.extend(b'\x85\xc0\x74\x00')
    no_window = len(code) - 1
    code.extend(b'\x3b\x83' + struct.pack('<I', 0xa52fb0))  # Graphics HWND
    code.extend(b'\x75\x00')
    other_window = len(code) - 1
    code.extend(b'\x6a\x02\x8d\x8b' + struct.pack('<I', 0xa42730))
    call(0x2735a0)  # Existing focus-regain routine: clear suspension and update.
    done = len(code)
    for branch in (no_window, other_window):
        code[branch] = done - branch - 1
    code.extend(b'\x61\x9d\xc2\x04\x00')  # Consume original enable argument.
    out[hook:hook + 5] = b'\xe8' + struct.pack('<i', rva - hook - 5)
    header = p.sections[0].get_file_offset() + 40 * p.FILE_HEADER.NumberOfSections
    assert header + 40 <= p.OPTIONAL_HEADER.SizeOfHeaders
    assert not any(out[header:header + 40])
    size = align(len(code), p.OPTIONAL_HEADER.FileAlignment)
    out[header:header + 40] = struct.pack('<8sIIIIIIHHI', b'.wlpaud', len(code),
                                         rva, size, raw, 0, 0, 0, 0, 0x60000020)
    struct.pack_into('<H', out, p.FILE_HEADER.get_field_absolute_offset('NumberOfSections'),
                     p.FILE_HEADER.NumberOfSections + 1)
    for field, value in (
        ('SizeOfImage', align(rva + len(code), p.OPTIONAL_HEADER.SectionAlignment)),
        ('SizeOfCode', p.OPTIONAL_HEADER.SizeOfCode + size), ('CheckSum', 0)):
        struct.pack_into('<I', out, p.OPTIONAL_HEADER.get_field_absolute_offset(field), value)
    out.extend(bytes(raw - len(out)) + code + bytes(size - len(code)))
    return bytes(out)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    result = patch(args.input.read_bytes())
    with args.output.open('xb') as stream:
        stream.write(result)
    print(hashlib.sha256(result).hexdigest())
