#!/usr/bin/env python3
"""0.35.2: correct native first-frame indices after the inserted menu frame."""
import json,struct,hashlib,shutil
from pathlib import Path
from workspace_paths import ROOT,GAME
VERSION='0.35.2'
OUT=ROOT/'assets/versions'/VERSION
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while b:=f.read(1048576):h.update(b)
 return h.hexdigest()
def fix(data,entry):
 version,count,flags,unused,table,size=struct.unpack_from('<HHIIII',data)
 assert version==200 and flags in (272,528)
 assert struct.unpack_from('<H',data,255+entry*64)[0]==2
 offsets=struct.unpack_from(f'<{size//4}I',data,table)
 assert offsets[-1]==len(data)
 result=bytearray(data);first=0;changes=[]
 for i in range(count):
  r=255+i*64;nf=struct.unpack_from('<H',data,r)[0]
  stored=struct.unpack_from('<I',data,r+15)[0]
  assert stored==first-(i>entry),(i,stored,first)
  if stored!=first:
   struct.pack_into('<I',result,r+15,first);changes.append(dict(entry=i,offset=r+15,old=stored,new=first))
  first+=nf
 assert first==len(offsets)-1
 assert result[table:]==data[table:], 'Offsets and texture payloads must stay exact'
 # Reconstruct original bytes from declared changes: nothing else can differ.
 before=bytearray(result)
 for c in changes:struct.pack_into('<I',before,c['offset'],c['old'])
 assert before==data
 # Follow each native record's actual index, not a separately computed index.
 first=0
 for i in range(count):
  r=255+i*64;nf,w,h,raw,total=struct.unpack_from('<HHHII',result,r)
  stored=struct.unpack_from('<I',result,r+15)[0]
  assert stored==first and stored+nf<len(offsets)
  assert raw==w*h*2 and total==raw*nf
  for f in range(stored,stored+nf):assert offsets[f]<offsets[f+1]<=len(result)
  first+=nf
 return bytes(result),dict(entry=entry,corrected_records=len(changes),total_records=count,
                           total_frames=first,payload_and_offset_table_unchanged=True,changes=changes)
def container(source,target,member,entry):
 with source.open('rb') as f:
  head=f.read(28);stride,count,directory,start=struct.unpack_from('<4I',head,12)
  assert head[:4]==b'cont' and stride==328
  f.seek(directory);metadata=f.read(count*stride)
  matches=[]
  for i in range(count):
   r=i*stride
   if metadata[r+44:r+304].split(b'\0')[0]==member.encode():
    matches.append((struct.unpack_from('<Q',metadata,r+320)[0],struct.unpack_from('<I',metadata,r+32)[0]))
  assert len(matches)==1
  pos,size=matches[0];f.seek(pos);old=f.read(size)
 replacement,info=fix(old,entry);assert len(replacement)==size
 shutil.copy2(source,target)
 with target.open('r+b') as f:f.seek(pos);f.write(replacement)
 # Verify the entire container except the declared bank header words.
 absolute={pos+c['offset']:struct.pack('<I',c['old']) for c in info['changes']}
 with source.open('rb') as a,target.open('rb') as b:
  cursor=0
  while old_chunk:=a.read(1048576):
   new_chunk=bytearray(b.read(len(old_chunk)))
   for off,oldbytes in absolute.items():
    for j,value in enumerate(oldbytes):
     if cursor<=off+j<cursor+len(new_chunk):new_chunk[off+j-cursor]=value
   assert old_chunk==new_chunk
   cursor+=len(old_chunk)
  assert not b.read(1)
 info.update(container_member=member,other_container_bytes_unchanged=True)
 return info
def read_member(source,member):
 with source.open('rb') as f:
  h=f.read(28);stride,count,directory,start=struct.unpack_from('<4I',h,12)
  f.seek(directory);meta=f.read(count*stride)
  for i in range(count):
   r=i*stride
   if meta[r+44:r+304].split(b'\0')[0]==member.encode():
    pos=struct.unpack_from('<Q',meta,r+320)[0];size=struct.unpack_from('<I',meta,r+32)[0]
    f.seek(pos);return f.read(size)
 raise AssertionError(member)
def verify_native_lookup(baseline,candidate,menu):
 # Use each record's stored native index. This would reject the 0.35 banks
 # despite their unchanged payloads and mathematically valid offset tables.
 n=struct.unpack_from('<H',baseline,2)[0];assert n==struct.unpack_from('<H',candidate,2)[0]
 tables=[]
 for data in (baseline,candidate):
  t,sz=struct.unpack_from('<II',data,12);tables.append(struct.unpack_from(f'<{sz//4}I',data,t))
 checked=0
 for entry in range(n):
  r=255+entry*64
  if entry==menu:continue
  assert baseline[r:r+14]==candidate[r:r+14]
  oldfirst=struct.unpack_from('<I',baseline,r+15)[0]
  newfirst=struct.unpack_from('<I',candidate,r+15)[0]
  nf=struct.unpack_from('<H',baseline,r)[0]
  for frame in range(nf):
   a,b=tables[0][oldfirst+frame:oldfirst+frame+2]
   c,d=tables[1][newfirst+frame:newfirst+frame+2]
   assert baseline[a:b]==candidate[c:d],(entry,frame)
   checked+=1
 return checked
if __name__=='__main__':
 OUT.mkdir(parents=True,exist_ok=True);reports=[]
 for entry,rel,ct in [(44,'Int/All/Pictures/GUI.alb','Pictures.cont'),(22,'Int/All/Pictures/Addon1/GUI_AddOn1.alb','Pictures_Addon1.cont')]:
  source=GAME/rel;target=OUT/source.name;data,info=fix(source.read_bytes(),entry)
  baseline=ROOT/'archive/game-backups/0.34.0/pre-sign-switch'/rel
  checked=verify_native_lookup(baseline.read_bytes(),data,entry)
  target.write_bytes(data);info.update(path=rel,candidate=str(target),source_sha256=sha(source),sha256=sha(target),native_lookup_frames_verified=checked);reports.append(info)
  source=GAME/'Int/All'/ct;target=OUT/ct;info=container(source,target,Path(rel).name,entry)
  baseline=ROOT/'archive/game-backups/0.34.0/pre-sign-switch/Int/All'/ct
  checked=verify_native_lookup(read_member(baseline,Path(rel).name),read_member(target,Path(rel).name),entry)
  info.update(path='Int/All/'+ct,candidate=str(target),source_sha256=sha(source),sha256=sha(target),native_lookup_frames_verified=checked);reports.append(info)
 (ROOT/'analysis/menu-frame-index-candidate.json').write_text(json.dumps(reports,indent=2)+'\n')
 print(json.dumps([{k:r[k] for k in ('path','corrected_records','total_records','total_frames','sha256')} for r in reports],indent=2))
