#!/usr/bin/env python3
"""Use existing GUI panel/button artwork for F2 without altering archives."""
import struct,subprocess,tempfile,json
from pathlib import Path
import pefile
from patch_addon_widescreen import append_section,next_rva
from patch_debug_tools import ROOT,digest,public,check_preservation
from patch_weather_menu import PROFILES as WEATHER
from theme_panel import BUTTONS
VERSION='0.36.0'
def patch(data,name):
 addon=name=='WLPADD1';pr=dict(list(WEATHER.values())[int(addon)])
 pr.update(bank=0xa64954 if addon else 0x8d329c,
           image=0x29ad70 if addon else 0x248de0,
           rectangle=0x223de0 if addon else 0x1f5be0,
           blit=0x225e60 if addon else 0x1f7ea0,
           root_vtable=0x339d0c if addon else 0x3095e4,
           button_vtable=0x339d94 if addon else 0x3096f4)
 p=pefile.PE(data=data);rva=next_rva(data)
 h=pr['attach_hook'];raw=p.get_data(h,5);assert raw[0]==0xe8
 pr['previous_attach']=h+5+struct.unpack('<i',raw[1:])[0]
 for k in ('root','button'):
  pr[k+'_draw']=struct.unpack('<I',p.get_data(pr[k+'_vtable']+0x24,4))[0]-p.OPTIONAL_HEADER.ImageBase
 buttons=(0x5b8,0xbf0,0x1624,BUTTONS[0])
 def call(n):return f'.byte 0xe8\n.long {pr[n]}-({rva}+.-_start+4)'
 assignments='\n'.join(f'mov [esi+{b}],eax' for b in buttons)
 asm=f'''.intel_syntax noprefix
.code32
.global _start
_start:
get_base:
 call anchor
anchor:
 pop ebx
 sub ebx,{rva}+anchor-_start
 ret
attach:
 push esi
 mov esi,[esp+8]
 push esi
 {call('previous_attach')}
 pushfd
 pushad
 cld
 call get_base
 push esi
 lea esi,[ebx+{pr['root_vtable']}]
 lea edi,[ebx+{rva}+root_vtable-_start]
 mov ecx,32
 rep movsd
 lea esi,[ebx+{pr['button_vtable']}]
 lea edi,[ebx+{rva}+button_vtable-_start]
 mov ecx,32
 rep movsd
 pop esi
 lea eax,[ebx+{rva}+root_draw-_start]
 mov [ebx+{rva}+root_vtable-_start+0x24],eax
 lea eax,[ebx+{rva}+button_draw-_start]
 mov [ebx+{rva}+button_vtable-_start+0x24],eax
 lea eax,[ebx+{rva}+root_vtable-_start]
 mov [esi],eax
 lea eax,[ebx+{rva}+button_vtable-_start]
 {assignments}
 # Native label RGB field: light cream on wood; preserve its alpha/style fields.
 mov BYTE PTR [esi+0x288+0x29c],240
 mov BYTE PTR [esi+0x288+0x29d],232
 mov BYTE PTR [esi+0x288+0x29e],216
 popad
 popfd
 pop esi
 ret 4
root_draw:
 push esi
 mov esi,ecx
 {call('root_draw')}
 pushfd
 pushad
 mov ecx,esi
 mov eax,81
 call texture
 popad
 popfd
 pop esi
 ret
button_draw:
 push esi
 mov esi,ecx
 {call('button_draw')}
 pushfd
 pushad
 mov ecx,esi
 mov eax,89
 call texture
 popad
 popfd
 pop esi
 ret
texture:
 pushfd
 pushad
 sub esp,24
 mov esi,ecx
 mov [esp+16],eax
 call get_base
 # Use the common GUI bank's native virtual-base interface, as native windows do.
 mov eax,[ebx+{pr['bank']}]
 test eax,eax
 je texture_done
 mov eax,[eax+0xc]
 lea edi,[ebx+{pr['bank']}]
 add edi,eax
 mov edx,[edi]
 push DWORD PTR [esp+16]
 push 0
 mov ecx,edi
 call DWORD PTR [edx]
 test eax,eax
 je texture_done
 mov ecx,edi
 {call('image')}
 mov ebp,eax
 test ebp,ebp
 je unlock
 lea eax,[esp]
 push eax
 mov ecx,esi
 {call('rectangle')}
 mov eax,[esp+8]
 sub eax,[esp]
 mov edx,[esp+12]
 sub edx,[esp+4]
 test eax,eax
 jle unlock
 test edx,edx
 jle unlock
 # Canvas has the widget's native clipping/position; use its local rectangle.
 mov ecx,[esp]
 mov ebx,[esp+4]
 push ebp
 push edx
 push eax
 push ebx
 push ecx
 lea ecx,[esi+0x124]
 {call('blit')}
unlock:
 mov edx,[edi]
 push DWORD PTR [esp+16]
 push 0
 mov ecx,edi
 call DWORD PTR [edx+4]
texture_done:
 add esp,24
 popad
 popfd
 ret
.balign 4
root_vtable: .zero 128
button_vtable: .zero 128
'''
 with tempfile.TemporaryDirectory() as tmp:
  d=Path(tmp);(d/'skin.s').write_text(asm)
  subprocess.run(['as','--32','-o',str(d/'skin.o'),str(d/'skin.s')],check=True)
  assert 'R_386' not in subprocess.check_output(['objdump','-r',str(d/'skin.o')],text=True)
  subprocess.run(['objcopy','-O','binary','-j','.text',str(d/'skin.o'),str(d/'skin.bin')],check=True)
  code=(d/'skin.bin').read_bytes();sy={a[2]:int(a[0],16) for line in subprocess.check_output(['nm',str(d/'skin.o')],text=True).splitlines() if len(a:=line.split())==3}
 b=bytearray(data);off=p.get_offset_from_rva(h)
 b[off:off+5]=b'\xe8'+struct.pack('<i',rva+sy['attach']-h-5)
 append_section(b,b'.wlpf2sk',code);q=pefile.PE(data=b)
 struct.pack_into('<I',b,q.sections[-1].get_file_offset()+36,0xe0000020)
 m=dict(name=name,profile=pr,rva=rva,code=code,symbols=sy,buttons=buttons,changes=[(h,5)],reloc_offsets=[])
 check_preservation(data,b,m)
 return bytes(b),m
def build(name):
 src=ROOT/'builds/versions/0.35.2'/f'{name}.EXE'
 expected=next(f['sha256'] for e in json.loads((ROOT/'builds/versions.json').read_text())['versions'] if e['version']=='0.35.2' for f in e['files'] if f['path'].endswith('/'+src.name))
 assert digest(src.read_bytes())==expected
 return patch(src.read_bytes(),name)
if __name__=='__main__':
 out=ROOT/'builds/versions'/VERSION;out.mkdir(exist_ok=True);records=[]
 for name in ('WLP','WLPADD1'):
  data,m=build(name);target=out/f'{name}.EXE'
  if target.exists():assert target.read_bytes()==data
  else:target.write_bytes(data)
  records.append(dict(name=name,sha256=digest(data),bytes=len(data),patch=public(m)))
 (ROOT/'analysis/f2-texture-candidate.json').write_text(json.dumps(records,indent=2)+'\n')
 print(json.dumps([dict(name=r['name'],sha256=r['sha256']) for r in records],indent=2))
