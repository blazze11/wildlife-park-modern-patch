#!/usr/bin/env python3
"""Execute F2 thunks against native GUI ABI mocks at two image bases."""
import json,tempfile,subprocess
from pathlib import Path
from f2_objective_fix import ROOT,build,VERSION,ROWS
from patch_debug_tools import digest

def verify(m):
 for base in (0x400000,0x14000000):
  p=m['profile'];s=m['symbols'];r=m['rva'];v=lambda n:base+r+s[n]
  object_checks='\n'.join(f'cmp DWORD PTR [root+{b}+4],OFFSET vbtable\njne fail' for b,k in m['objects'])
  modes=''
  for index,(w,h) in enumerate(((800,600),(1280,720),(1920,1080),(2560,1440))):
   modes+=f'''mov DWORD PTR [{base+p['mode']}],{index}
+mov ecx,OFFSET root
+push 100
+push 300
+push 0
+push 0
+call thunk+{s['root_bounds']}
+cmp DWORD PTR [root+0xa8],{(w-524)//2}
+jne fail
+cmp DWORD PTR [root+0xac],{(h-378)//2}
+jne fail
+cmp DWORD PTR [root+0xb0],{(w-524)//2+524}
+jne fail
+cmp DWORD PTR [root+0xb4],{(h-378)//2+378}
+jne fail
+'''.replace('\n+','\n')
  hover=''
  for i,b in enumerate(m['buttons']):
   hover+=f'''mov ecx,OFFSET root+{b}
+mov eax,[ecx]
+push OFFSET packet
+call DWORD PTR [eax+0x60]
+cmp eax,0xabcdef01
+jne fail
+mov ecx,OFFSET root+{b}
+mov eax,[ecx]
+call DWORD PTR [eax+0x24]
+cmp WORD PTR [root+{b}+0x52c],0xffff
+jne fail
+cmp BYTE PTR [root+{b}+0x52e],0x40
+jne fail
+cmp BYTE PTR [root+{b}+0x52f],0x7b
+jne fail
+mov ecx,OFFSET root+{b}
+mov eax,[ecx]
+push 1
+call DWORD PTR [eax+0x3c]
+cmp DWORD PTR [{v('hover')}],{1<<i}
+jne fail
+mov ecx,OFFSET root+{b}
+mov eax,[ecx]
+push OFFSET packet
+call DWORD PTR [eax+0x64]
+cmp eax,0xabcdef02
+jne fail
+mov ecx,OFFSET root+{b}
+mov eax,[ecx]
+call DWORD PTR [eax+0x24]
+cmp DWORD PTR [root+{b}+0x52c],0x7bffffff
+jne fail
+cmp DWORD PTR [{v('hover')}],0
+jne fail
+'''.replace('\n+','\n')
  tables=''
  for amount,expected in ((0,1),(10,11),(22,23),(-5,1),(999,23)):
   tables+=f'''mov DWORD PTR [root+{m['scrolls'][1]}+0x288],{amount}
+mov DWORD PTR [expected_start],{expected}
+mov DWORD PTR [text_calls],0
+mov ecx,OFFSET root+0x288
+push {v('marker')}
+push OFFSET rectangle
+call thunk+{s['table_draw']}
+cmp DWORD PTR [text_calls],18
+jne fail
+cmp esp,[saved_sp]
+jne fail
+'''.replace('\n+','\n')
  constructors=[]
  for k in ('picture_ctor','label_ctor','scroll_ctor','state_ctor'):
   constructors.append(f'.section .{k},"ax"\nmov DWORD PTR [ecx],OFFSET generic_vtable\nmov DWORD PTR [ecx+4],OFFSET vbtable\nmov eax,ecx\ninc DWORD PTR [constructs]\nret 4')
  setters=[]
  for k,off in (('state_normal',0x0c),('state_pressed',0x30),('state_hover',0x78),('state_disabled',0x54)):
   setters.append(f'''.section .{k},"ax"
+cmp DWORD PTR [esp+4],{base+p['bank']+16}
+jne fail
+mov eax,[esp+8]
+cmp eax,15
+ja fail
+mov [ecx+{off}],eax
+mov eax,[esp+12]
+cmp eax,41
+je state_{k}_ok
+cmp eax,42
+jne fail
+state_{k}_ok:
+mov [ecx+{off}+4],eax
+inc DWORD PTR [state_calls]
+ret 12
+'''.replace('\n+','\n'))
  asm=f'''.intel_syntax noprefix
.code32
.global start
.section .main,"ax"
start:
 mov [saved_sp],esp
 mov ecx,OFFSET root
 push 1
 call thunk+{s['constructor']}
 cmp eax,OFFSET root
 jne fail
 cmp DWORD PTR [constructs],10
 jne fail
 cmp DWORD PTR [root+{m['ready']}],1
 jne fail
 {object_checks}
 {modes}
 mov ecx,OFFSET root+0xbf0
 push OFFSET root
 call thunk+{s['attach']}
 cmp DWORD PTR [prev_attaches],1
 jne fail
 cmp DWORD PTR [attaches],4
 jne fail
 cmp DWORD PTR [state_calls],24
 jne fail
 cmp DWORD PTR [root],{v('root_vtable')}
 jne fail
 cmp DWORD PTR [root+{m['picture']}],OFFSET generic_vtable
 jne fail
 cmp DWORD PTR [root+{m['picture']}+0x298],{base+p['bank']+16}
 jne fail
 cmp DWORD PTR [root+{m['picture']}+0x2a0],39
 jne fail
 cmp DWORD PTR [root+0x514],0x00ffffff
 jne fail
 cmp DWORD PTR [root+{m['title']}+0x28c],0x00ffffff
 jne fail
 cmp DWORD PTR [root+{m['scrolls'][0]}+0x290],0
 jne fail
 cmp DWORD PTR [root+{m['scrolls'][1]}+0x290],22
 jne fail
 mov esi,{base+p['root_vtable']}
 mov edi,{v('root_vtable')}
 mov DWORD PTR [skip_hover],0
 call compare_tables
 mov esi,{base+p['button_vtable']}
 mov edi,{v('button_vtable')}
 mov DWORD PTR [skip_hover],1
 call compare_tables
 mov ecx,OFFSET root
 mov eax,[ecx]
 call DWORD PTR [eax+0x24]
 cmp DWORD PTR [picture_calls],0
 jne fail
 mov ecx,OFFSET root+{m['picture']}
 call {base+p['picture_draw']}
 cmp DWORD PTR [picture_calls],1
 jne fail
 {hover}
 {tables}
 mov ecx,OFFSET root+0x288
 push OFFSET ordinary_text
 push OFFSET rectangle
 call thunk+{s['table_draw']}
 cmp DWORD PTR [ordinary_calls],1
 jne fail
 mov ecx,OFFSET root
 push OFFSET packet
 push OFFSET packet
 call thunk+{s['scrolled']}
 cmp DWORD PTR [invalidates],10
 jne fail
 mov DWORD PTR [root+{m['scrolls'][1]}+0x288],10
 mov ecx,OFFSET root+{m['scrolls'][1]}
 mov eax,[ecx]
 push 1
 call DWORD PTR [eax+8]
 cmp DWORD PTR [invalidates],12
 jne fail
 cmp DWORD PTR [scroll_invalidates],1
 jne fail
 mov ecx,OFFSET root+{m['scrolls'][1]}
 mov eax,[ecx]
 push 1
 call DWORD PTR [eax+8]
 cmp DWORD PTR [invalidates],12
 jne fail
 cmp DWORD PTR [scroll_invalidates],2
 jne fail
 mov ecx,OFFSET root+0x1228
 call thunk+{s['detach']}
 cmp DWORD PTR [detaches],5
 jne fail
 cmp DWORD PTR [prev_detaches],1
 jne fail
 mov ecx,OFFSET root+0x1620
 call thunk+{s['destructor']}
 cmp DWORD PTR [destroys],10
 jne fail
 cmp DWORD PTR [{v('owner')}],0
 jne fail
 cmp DWORD PTR [root+{m['ready']}],0
 jne fail
 mov ecx,OFFSET root+0x1620
 call thunk+{s['destructor']}
 cmp DWORD PTR [destroys],10
 jne fail
 cmp esp,[saved_sp]
 jne fail
 xor ebx,ebx
 mov eax,1
 int 0x80
compare_tables:
 xor ecx,ecx
compare_loop:
 cmp ecx,0x24
 je next_slot
 cmp DWORD PTR [skip_hover],0
 je compare_slot
 cmp ecx,0x20
 je next_slot
 cmp ecx,0x60
 je next_slot
 cmp ecx,0x64
 je next_slot
compare_slot:
 mov eax,[esi+ecx]
 cmp eax,[edi+ecx]
 jne fail
next_slot:
 add ecx,4
 cmp ecx,128
 jb compare_loop
 ret
fail:
 mov ebx,1
 mov eax,1
 int 0x80
.section .previous_ctor,"ax"
 cmp DWORD PTR [esp+4],1
 jne fail
 mov DWORD PTR [ecx],{base+p['root_vtable']}
 mov DWORD PTR [ecx+4],OFFSET vbtable
 mov DWORD PTR [ecx+0x288],OFFSET generic_vtable
 mov eax,ecx
 ret 4
.section .previous_attach,"ax"
 cmp DWORD PTR [esp+4],OFFSET root
 jne fail
 cmp ecx,OFFSET root+0xbf0
 jne fail
 inc DWORD PTR [prev_attaches]
 ret 4
.section .previous_detach,"ax"
 cmp ecx,OFFSET root+0x1228
 jne fail
 inc DWORD PTR [prev_detaches]
 ret
.section .previous_dtor,"ax"
 cmp ecx,OFFSET root+0x1620
 jne fail
 ret
.section .bounds,"ax"
 mov eax,[esp+4]
 mov [ecx+0xa8],eax
 add eax,[esp+12]
 mov [ecx+0xb0],eax
 mov eax,[esp+8]
 mov [ecx+0xac],eax
 add eax,[esp+16]
 mov [ecx+0xb4],eax
 ret 16
.section .enabled,"ax"
 cmp DWORD PTR [esp+4],1
 ja fail
 ret 4
.section .attach,"ax"
 cmp DWORD PTR [esp+4],OFFSET root
 jne fail
 ret 4
.section .detach,"ax"
 ret
.section .generic_attach,"ax"
 cmp DWORD PTR [esp+4],OFFSET root
 jne fail
 inc DWORD PTR [attaches]
 ret 4
.section .generic_detach,"ax"
 cmp ecx,OFFSET root+0x288
 je detach_ok
 cmp ecx,OFFSET root+0xbf0+0x2a0
 je detach_ok
 cmp ecx,OFFSET root+{m['picture']}
 jb fail
 cmp ecx,OFFSET root+{m['ready']}
 jae fail
detach_ok:
 inc DWORD PTR [detaches]
 ret
.section .label_set,"ax"
 mov eax,[esp+4]
 mov [ecx+0x308],eax
 ret 4
.section .caption,"ax"
 cmp ecx,OFFSET root+0xbf0
 jne fail
 mov eax,[esp+4]
 cmp BYTE PTR [eax],0
 jne fail
 ret 4
.section .register,"ax"
 cmp DWORD PTR [esp+4],0x18
 jne fail
 cmp DWORD PTR [esp+8],OFFSET root
 jne fail
 cmp DWORD PTR [esp+12],{v('scrolled')}
 jne fail
 ret 24
.section .picture_draw,"ax"
 cmp ecx,OFFSET root+{m['picture']}
 jne fail
 cmp DWORD PTR [ecx+0x2a0],39
 jne fail
 cmp DWORD PTR [ecx+0x29c],0
 jne fail
 cmp DWORD PTR [ecx+0xb0],524
 jne fail
 cmp DWORD PTR [ecx+0xb4],378
 jne fail
 inc DWORD PTR [picture_calls]
 ret
.section .button_update,"ax"
 ret
.section .scroll_invalidate,"ax"
 inc DWORD PTR [scroll_invalidates]
 ret 4
.section .scroll_vtable,"aw"
.long invalidate,invalidate
.long {base+p['scroll_invalidate']}
.rept 29
.long invalidate
.endr
.section .button_enter,"ax"
 mov eax,[esp+4]
 cmp eax,OFFSET packet
 jne fail
 mov eax,0xabcdef01
 ret 4
.section .button_leave,"ax"
 mov eax,[esp+4]
 cmp eax,OFFSET packet
 jne fail
 mov eax,0xabcdef02
 ret 4
.section .previous_draw,"ax"
 cmp DWORD PTR [esp+8],OFFSET ordinary_text
 jne fail
 inc DWORD PTR [ordinary_calls]
 ret 8
.section .text_draw,"ax"
 cmp ecx,OFFSET root+0x288
 jne fail
 mov edx,[text_calls]
 mov eax,edx
 shr eax,1
 test eax,eax
 jz row_expected
 add eax,[expected_start]
 dec eax
row_expected:
 lea eax,[eax*8+{v('strings')}]
 test edx,1
 jz key_expected
 add eax,4
key_expected:
 mov eax,[eax]
 add eax,{base+r}
 cmp [esp+8],eax
 jne fail
 mov eax,[esp+4]
 mov ecx,edx
 shr ecx,1
 imul ecx,12
 cmp [eax+4],ecx
 jne fail
 add ecx,12
 cmp [eax+12],ecx
 jne fail
 test edx,1
 jnz action_bounds
 cmp DWORD PTR [eax],0
 jne fail
 cmp DWORD PTR [eax+8],135
 jne fail
 jmp text_ok
action_bounds:
 cmp DWORD PTR [eax],139
 jne fail
 cmp DWORD PTR [eax+8],426
 jne fail
text_ok:
 inc DWORD PTR [text_calls]
 ret 8
.section .state_tile,"ax"
 ret 4
{chr(10).join(constructors)}
{chr(10).join(setters)}
.section .root_vtable,"aw"
.rept 32
.long invalidate
.endr
.section .button_vtable,"aw"
.rept 15
.long invalidate
.endr
.long pressed
.rept 8
.long invalidate
.endr
.long {base+p['button_enter']},{base+p['button_leave']}
.rept 6
.long invalidate
.endr
.section .picture_vtable,"aw"
.rept 32
.long invalidate
.endr
.section .mode,"aw"
.long 0
.section .widths,"aw"
.long 800,1280,1920,2560
.section .heights,"aw"
.long 600,720,1080,1440
.section .bank,"aw"
.long bank_vbase
.zero 12
.long 0
.section .thunk,"axw"
thunk: .incbin "CODEPATH"
.section .mockdata,"awx"
invalidate:
 inc DWORD PTR [invalidates]
 ret 4
pressed:
 ret 4
destroy:
 cmp DWORD PTR [esp+4],0
 jne fail
 inc DWORD PTR [destroys]
 ret 4
vbtable: .long destroy,0
bank_vbase: .zero 12
.long 16
generic_vtable:
.long 0,0,invalidate
.zero 116
skip_hover: .long 0
saved_sp: .long 0
constructs: .long 0
prev_attaches: .long 0
attaches: .long 0
state_calls: .long 0
picture_calls: .long 0
text_calls: .long 0
expected_start: .long 0
ordinary_calls: .long 0
scroll_invalidates: .long 0
invalidates: .long 0
detaches: .long 0
prev_detaches: .long 0
destroys: .long 0
rectangle: .long 0,0,426,108
ordinary_text: .asciz "A different game label"
packet: .zero 64
root: .zero {m['size']}
'''
  # Existing objects are initialized by the native constructor, represented here by sentinels.
  initial='\n'.join(f'mov BYTE PTR [root+{b}+0x52f],0x7b\nmov DWORD PTR [root+{b}+0x2a0],OFFSET generic_vtable' for b in m['buttons'])
  asm=asm.replace(' {object_checks}',object_checks).replace(' {modes}',modes)
  asm=asm.replace(' mov ecx,OFFSET root+0xbf0\n push OFFSET root',initial+'\n mov ecx,OFFSET root+0xbf0\n push OFFSET root',1)
  names=('previous_ctor','previous_attach','previous_detach','previous_dtor','bounds','enabled','generic_attach','generic_detach','label_set','caption','register','picture_draw','button_enter','button_leave','previous_draw','text_draw','state_tile','button_update','scroll_invalidate','scroll_vtable','attach','detach','picture_ctor','label_ctor','scroll_ctor','state_ctor','state_normal','state_pressed','state_hover','state_disabled','root_vtable','button_vtable','picture_vtable','mode','widths','heights','bank')
  sec={k:p[k] for k in names};sec['thunk']=r
  with tempfile.TemporaryDirectory() as tmp:
   d=Path(tmp);(d/'code.bin').write_bytes(m['code']);(d/'test.s').write_text(asm.replace('CODEPATH',str(d/'code.bin')))
   layout='\n'.join(f'.{k} {base+a} : {{ *(.{k}) }}' for k,a in sorted(sec.items(),key=lambda x:x[1]))
   (d/'test.ld').write_text(f'ENTRY(start)\nSECTIONS {{ .main {base+0x1000} : {{ *(.main) }}\n{layout}\n.mockdata {base+r+0x10000} : {{ *(.mockdata) }} }}')
   subprocess.run(['as','--32','-o',str(d/'test.o'),str(d/'test.s')],check=True)
   subprocess.run(['ld','-m','elf_i386','-T',str(d/'test.ld'),'-o',str(d/'test'),str(d/'test.o')],check=True,capture_output=True)
   result=subprocess.run([str(d/'test')],timeout=10)
   assert result.returncode==0,(m['name'],hex(base),result.returncode)
 print('PASS '+m['name']+': lifecycle, native frame, centering, hover/press independence, all shortcut rows and ordinary-label fallback; two image bases')
if __name__=='__main__':
 checks=[]
 for name in ('WLP','WLPADD1'):
  data,m=build(name);verify(m)
  checks.append(dict(name=name,passed=True,sha256=digest(data),code_sha256=digest(m['code']),image_bases=['0x400000','0x14000000']))
 (ROOT/'analysis/f2-objective-fix-verification.json').write_text(json.dumps(checks,indent=2)+'\n')
