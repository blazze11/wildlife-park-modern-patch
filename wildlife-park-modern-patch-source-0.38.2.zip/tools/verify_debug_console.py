#!/usr/bin/env python3
"""Execute injected console commands, key suppression and focus/edge polling."""
import hashlib
import json
import struct
import subprocess
import tempfile
from pathlib import Path
import pefile
from debug_hud import patch as hud_patch
from debug_panel import patch as panel_patch
from debug_console import patch, COMMANDS

ROOT=Path(__file__).resolve().parents[1]

def verify(tag, base):
    source=(ROOT/f'builds/versions/0.30.1/{tag}.EXE').read_bytes()
    b,h=hud_patch(source,tag)
    b,_=panel_patch(b,tag,h)
    result,m=patch(b,tag,h)
    r=m['rva']; sy=m['symbols']; pr=m['profile']
    flags=base+h['flags_rva']; visible=base+h['console_visible_rva']
    inp=base+h['console_input_rva']; out=base+h['console_output_rva']
    imp=m['imports']; low=min(imp[x] for x in ['GetModuleHandleA','GetProcAddress','GetAsyncKeyState'])
    high=max(imp[x] for x in ['GetModuleHandleA','GetProcAddress','GetAsyncKeyState'])
    istubs={'GetModuleHandleA':'module_stub','GetProcAddress':'proc_stub','GetAsyncKeyState':'async_stub'}
    importrows=[]; pos=low
    for name in sorted(istubs,key=lambda k:imp[k]):
        importrows.extend([f'.zero {imp[name]-pos}',f'.long {istubs[name]}']);pos=imp[name]+4
    hd=bytearray(h['code']); frame=h['symbols']['frame_hook'];hd[frame:frame+3]=bytes.fromhex('c20800')
    commands=[]; strings=[]
    for i,(command,mask,value,answer) in enumerate(COMMANDS):
        strings.append(f'command{i}: .asciz "{command}"')
        expected=(0x80&~mask)|value
        commands.append(f'''mov DWORD PTR [{flags}],0x80
 mov DWORD PTR [{visible}],1
 mov esi,OFFSET command{i}
 mov edi,{inp}
 call copy_string
 mov al,13
 call run_key
 cmp DWORD PTR [{flags}],{expected}
 jne fail
 cmp BYTE PTR [{inp}],0
 jne fail
 cmp DWORD PTR [{visible}],{0 if command=='close' else 1}
 jne fail
''')
    with tempfile.TemporaryDirectory() as tmp:
        d=Path(tmp);(d/'console.bin').write_bytes(m['code']);(d/'hud.bin').write_bytes(hd)
        code=f'''.intel_syntax noprefix
.code32
.global start
.section .main,"axw"
start:
 mov DWORD PTR [foreground_hwnd],0x1234
 mov DWORD PTR [{base+pr['window']}],0x1234
 mov DWORD PTR [key_down],0
 call run_frame
 cmp DWORD PTR [{visible}],0
 jne fail
 mov DWORD PTR [key_down],0x8000
 call run_frame
 cmp DWORD PTR [{visible}],1
 jne fail
 call run_frame
 cmp DWORD PTR [{visible}],1
 jne fail
 mov DWORD PTR [key_down],0
 call run_frame
 mov DWORD PTR [key_down],0x8000
 call run_frame
 cmp DWORD PTR [{visible}],0
 jne fail
 mov DWORD PTR [foreground_hwnd],0x5678
 mov DWORD PTR [key_down],0
 call run_frame
 mov DWORD PTR [key_down],0x8000
 call run_frame
 cmp DWORD PTR [{visible}],0
 jne fail
 mov DWORD PTR [foreground_hwnd],0x1234
 call run_frame
 cmp DWORD PTR [{visible}],0
 jne fail
 mov DWORD PTR [key_down],0
 call run_frame
 mov DWORD PTR [key_down],0x8000
 call run_frame
 cmp DWORD PTR [{visible}],1
 jne fail
 {''.join(commands)}
 mov DWORD PTR [{visible}],1
 mov BYTE PTR [{inp}],0
 mov BYTE PTR [{out}],90
 mov al,13
 call run_key
 cmp BYTE PTR [{out}],90
 jne fail
 mov esi,OFFSET invalid_command
 mov edi,{inp}
 call copy_string
 mov al,13
 call run_key
 cmp BYTE PTR [{out}],85
 jne fail
 mov DWORD PTR [event+0x28],0x0d
 mov al,65
 call run_key
 cmp BYTE PTR [{inp}],0
 jne fail
 mov DWORD PTR [event+0x28],0x0c
 mov al,65
 call run_key
 cmp WORD PTR [{inp}],97
 jne fail
 mov al,8
 call run_key
 cmp BYTE PTR [{inp}],0
 jne fail
 mov al,27
 call run_key
 cmp DWORD PTR [{visible}],0
 jne fail
 mov DWORD PTR [passed],0
 mov al,65
 call run_key
 cmp DWORD PTR [passed],1
 jne fail
 mov DWORD PTR [{visible}],1
 call poll_entry
 cmp DWORD PTR [polled],0
 jne fail
 mov DWORD PTR [{visible}],0
 call poll_entry
 cmp DWORD PTR [polled],1
 jne fail
 xor ebx,ebx
 mov eax,1
 int 0x80
fail:
 mov ebx,1
 mov eax,1
 int 0x80
run_frame:
 push 0
 push 0
 call frame_entry
 ret
run_key:
 mov BYTE PTR [event+0x42],al
 mov BYTE PTR [event+0x41],0x1e
 sub esp,0x44
 mov DWORD PTR [esp+0x40],OFFSET event
 call keyboard_entry
 add esp,0x44
 ret
copy_string:
 mov al,[esi]
 mov [edi],al
 inc esi
 inc edi
 test al,al
 jne copy_string
 ret
module_stub:
 mov eax,1
 ret 4
proc_stub:
 mov eax,[esp+8]
 cmp BYTE PTR [eax],77
 jne get_foreground
 mov eax,OFFSET map_stub
 ret 8
get_foreground:
 mov eax,OFFSET foreground_stub
 ret 8
map_stub:
 cmp DWORD PTR [esp+4],0x29
 jne fail
 cmp DWORD PTR [esp+8],3
 jne fail
 mov eax,0xdc
 ret 8
foreground_stub:
 mov eax,[foreground_hwnd]
 ret
async_stub:
 cmp DWORD PTR [esp+4],0xdc
 jne fail
 mov eax,[key_down]
 ret 4
.balign 4
key_down: .long 0
foreground_hwnd: .long 0
passed: .long 0
polled: .long 0
event: .zero 40
.long 0x0c
.zero 52
invalid_command: .asciz "nonexistent"
{chr(10).join(strings)}
.section .console,"axw"
console_image:
.incbin "{d/'console.bin'}"
.set frame_entry,console_image+{sy['frame']}
.set keyboard_entry,console_image+{sy['keyboard']}
.set poll_entry,console_image+{sy['poll_keyboard']}
.section .hud,"axw"
.incbin "{d/'hud.bin'}"
.section .imports,"aw"
{chr(10).join(importrows)}
.section .window,"aw"
.long 0
.section .world,"aw"
.long 0
.section .fullscreen,"aw"
.long 0
.section .keydone,"ax"
ret
.section .keypass,"ax"
inc DWORD PTR [passed]
ret
.section .pollpass,"ax"
inc DWORD PTR [polled]
pop edi
pop esi
ret
'''
        (d/'test.s').write_text(code)
        sections=[('.main',0x200000),('.console',base+r),('.hud',base+h['rva']),
                  ('.imports',base+low),('.window',base+pr['window']),('.world',base+pr['world']),
                  ('.fullscreen',base+pr['fullscreen']),('.keydone',base+pr['key_end']),
                  ('.keypass',base+pr['key_hook']+10),('.pollpass',base+pr['poll_hook']+10)]
        script='ENTRY(start)\nSECTIONS {\n'+''.join(f'{name} {va:#x} : {{ *({name}) }}\n' for name,va in sections)+'}\n'
        (d/'test.ld').write_text(script)
        subprocess.run(['as','--32','-o',str(d/'test.o'),str(d/'test.s')],check=True)
        subprocess.run(['ld','-m','elf_i386','-T',str(d/'test.ld'),'-o',str(d/'test'),str(d/'test.o')],check=True,capture_output=True)
        run=subprocess.run([str(d/'test')],capture_output=True)
        assert run.returncode==0,(tag,hex(base),run.returncode,run.stderr)
    return dict(name=tag,image_base=hex(base),passed=True,status='passed',
                sha256=hashlib.sha256(result).hexdigest(),
                emittedcode_sha256=hashlib.sha256(m['code']).hexdigest(),commands=len(COMMANDS),
                checks='actual injected x86 commands; held/release, foreground, keyboard/direct poll suppression; synthetic keyup ignored; HUD+panel+console chain')

if __name__=='__main__':
    records=[verify(t,b) for t in ['WLP','WLPADD1'] for b in [0x400000,0x14000000]]
    (ROOT/'analysis/debug-console-verification.json').write_text(json.dumps(records,indent=2)+'\n')
    print(json.dumps(records,indent=2))
