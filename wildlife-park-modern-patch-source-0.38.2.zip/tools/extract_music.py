#!/usr/bin/env python3
"""Extract Wildlife Park SDA music without changing the installed game."""
import argparse
import hashlib
import json
from pathlib import Path
import struct
import subprocess
import zipfile


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def chunk(tag, data):
    return tag + struct.pack('<I', len(data)) + data + (b'\0' if len(data) % 2 else b'')


def extract(source, output, album):
    data = source.read_bytes()
    version, groups = struct.unpack_from('<HH', data)
    start, table_size = struct.unpack_from('<II', data, 4)
    assert version == 300 and table_size % 4 == 0
    assert start - table_size == 255 + groups * 64
    offsets = struct.unpack_from('<' + 'I' * (table_size // 4), data, start - table_size)
    assert offsets[0] == start and offsets[-1] == len(data)
    assert all(a < b for a, b in zip(offsets, offsets[1:]))
    codec, channels, rate, byte_rate, block, bits = struct.unpack_from('<HHIIHH', data, 16)
    assert (codec, channels, rate, block, bits) == (17, 2, 22050, 1024, 4)
    samples_per_block = (block - channels * 4) * 2 // channels + 1
    format_data = data[16:32] + struct.pack('<HH', 2, samples_per_block)
    flac_dir = output / 'FLAC' / album
    wav_dir = output / 'Original ADPCM WAV' / album
    flac_dir.mkdir(parents=True, exist_ok=True)
    wav_dir.mkdir(parents=True, exist_ok=True)
    tracks = []
    for index, (a, b) in enumerate(zip(offsets, offsets[1:]), 1):
        original_length, length = struct.unpack_from('<II', data, a)
        assert b - a == length + 8 and length % block == 0
        payload = data[a + 8:b]
        samples = length // block * samples_per_block
        # IMA block headers contain a signed predictor, index (0..88), and reserved byte.
        for pos in range(0, length, block):
            for channel in range(channels):
                assert payload[pos + channel * 4 + 2] <= 88
                assert payload[pos + channel * 4 + 3] == 0
        body = b'WAVE' + chunk(b'fmt ', format_data)
        body += chunk(b'fact', struct.pack('<I', samples)) + chunk(b'data', payload)
        wav = wav_dir / f'Track {index:02d}.wav'
        flac = flac_dir / f'Track {index:02d}.flac'
        with wav.open('xb') as stream:
            stream.write(b'RIFF' + struct.pack('<I', len(body)) + body)
        subprocess.run(['ffmpeg', '-nostdin', '-v', 'error', '-xerror', '-n', '-i', str(wav),
                        '-c:a', 'flac', '-compression_level', '8',
                        '-metadata', f'album={album}', '-metadata', f'title=Track {index:02d}',
                        '-metadata', f'track={index}', str(flac)], check=True)
        # Fully decode both files and compare the exact PCM audio hashes.
        hashes = []
        for audio in [wav, flac]:
            result = subprocess.run(['ffmpeg', '-nostdin', '-v', 'error', '-xerror', '-i', str(audio),
                                     '-map', '0:a:0', '-c:a', 'pcm_s16le', '-f', 'hash',
                                     '-hash', 'sha256', '-'], check=True, capture_output=True, text=True)
            hashes.append(result.stdout.strip())
        assert hashes[0] == hashes[1]
        tracks.append({'track': index, 'source_record_offset': a, 'source_payload_offset': a + 8,
                       'source_payload_bytes': length, 'source_length_field': original_length,
                       'source_payload_sha256': sha256(payload), 'samples': samples,
                       'duration_seconds': samples / rate, 'decoded_pcm_hash': hashes[0],
                       'wav': str(wav.relative_to(output)), 'flac': str(flac.relative_to(output)),
                       'wav_sha256': sha256(wav.read_bytes()), 'flac_sha256': sha256(flac.read_bytes())})
        print(f'{album}: Track {index:02d}, {samples / rate:.2f}s, PCM verified', flush=True)
    assert sha256(source.read_bytes()) == sha256(data)
    return {'album': album, 'source': str(source), 'source_sha256': sha256(data),
            'format': {'codec': 'IMA ADPCM', 'channels': channels, 'sample_rate': rate,
                       'block_align': block, 'samples_per_block': samples_per_block}, 'tracks': tracks}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--game', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    music = args.game / 'Int/All/Music'
    albums = [extract(music / 'music.sda', args.output, 'Wildlife Park'),
              extract(music / 'Addon1/music.sda', args.output, 'Wild Creatures')]
    (args.output / 'manifest.json').write_text(json.dumps(albums, indent=2) + '\n')
    (args.output / 'README.txt').write_text(
        'Wildlife Park Gold music extraction\n\n'
        '15 tracks: Wildlife Park (12), Wild Creatures (3).\n'
        'FLAC contains lossless conversions for playback. Original ADPCM WAV contains\n'
        'the untouched compressed payloads with standard WAV headers added.\n'
        'All tracks are stereo, 22050 Hz. Both formats were fully decoded and their\n'
        'PCM SHA-256 hashes matched for every track. Installed archives are unchanged.\n'
        'Track numbers preserve archive order; original song titles were not recovered.\n'
        'Short tracks are included because they occur in the music archives.\n'
        'manifest.json records source offsets, lengths, durations, and hashes.\n')
    archive = args.output / 'Wildlife Park Gold - Music FLAC.zip'
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_STORED) as bundle:
        for path in sorted((args.output / 'FLAC').rglob('*.flac')):
            bundle.write(path, path.relative_to(args.output / 'FLAC'))
        for name in ['README.txt', 'manifest.json']:
            bundle.write(args.output / name, name)
    print(f'Created {archive}', flush=True)


if __name__ == '__main__':
    main()
