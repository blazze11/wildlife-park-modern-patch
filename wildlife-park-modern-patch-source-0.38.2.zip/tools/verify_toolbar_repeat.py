#!/usr/bin/env python3
"""Native x86 verification of actual toolbar hooks and original return epilogue."""
import subprocess
import tempfile
from pathlib import Path
from workspace_paths import artifact
import pefile
from patch_toolbar_repeat import patch

def verify(name):
    src=artifact(f'{name}_widescreen_button_repeat.EXE').read_bytes()
    new,m=patch(src)
    assert new==artifact(f'{name}_widescreen_toolbar_repeat.EXE').read_bytes()
    p=pefile.PE(data=src)
    h=m['profile']['hook']
    expected=bytearray(src)
    off=p.get_offset_from_rva(h)
    expected[off:off+12]=new[off:off+12]
    for off in m['reloc_offsets']:
        expected[off:off+2]=new[off:off+2]
    for s in p.sections:
        a=s.PointerToRawData
        assert expected[a:a+s.SizeOfRawData]==new[a:a+s.SizeOfRawData]
    # Includes preservation of the user's confirmed .wlprept price patch.
    np=pefile.PE(data=new)
    for block in np.DIRECTORY_ENTRY_BASERELOC:
        for e in block.entries:
            assert not e.type or not h<=e.rva<h+12
    for base in (0x400000,0x14000000):
        with tempfile.TemporaryDirectory() as tmp:
            d=Path(tmp)
            (d/'hook.bin').write_bytes(new[p.get_offset_from_rva(h):p.get_offset_from_rva(h)+12])
            (d/'code.bin').write_bytes(m['code'])
            cases=[]
            count=0
            step=0
            def case(t,repeat,increment,key=0x201,owner='root'):
                nonlocal count,step
                count+=increment
                step+=1
                cases.append(f'''mov DWORD PTR [step],{step}
 mov DWORD PTR [now],{t & 0xffffffff}
 mov DWORD PTR [event+0x4c],{repeat}
 mov WORD PTR [event+0x34],{key}
 mov ebx,0x11223344
 mov esi,0x55667788
 mov edi,0x99aabbcc
 mov ebp,0x12345678
 mov ecx,OFFSET event
 mov edx,OFFSET {owner}
 push OFFSET event
 push 0
 call entry
 cmp al,1
 jne fail
 cmp ebx,0x11223344
 jne fail
 cmp esi,0x55667788
 jne fail
 cmp edi,0x99aabbcc
 jne fail
 cmp ebp,0x12345678
 jne fail
 cmp ecx,OFFSET event
 jne fail
 cmp edx,OFFSET {owner}
 jne fail
 cmp esp,[saved_sp]
 jne fail
 cmp DWORD PTR [calls],{count}
 jne fail
''')
            case(1000,0,1)
            for t in range(1001,1400,5):
                case(t,1,0)
            case(1400,1,1)
            case(1519,1,0)
            case(1520,1,1)
            case(1521,0,1)
            case(1522,0,1)
            case(1523,1,0)
            case(50000,1,1)
            case(50000,1,0)
            case(50001,1,1,key=0x200)
            case(50002,1,0,key=0x200)
            case(50003,1,1,key=0x200,owner='other')
            case(50004,1,0,key=0x200,owner='other')
            case(0xffffff00,0,1)
            case(0x8f,1,0)
            case(0x90,1,1)
            case(0x107,1,0)
            case(0x108,1,1)
            # The real hook sits after the original sub esp,12/push esi/push edi.
            # Reproduce that frame and run the unmodified skip epilogue bytes.
            skip=m['profile']['skip']
            (d/'skip.bin').write_bytes(p.get_data(skip,10))
            asm=f'''.intel_syntax noprefix
.code32
.global start
.section .main,"ax"
start:
 mov [saved_sp],esp
 {''.join(cases)}
 xor ebx,ebx
 mov eax,1
 int 0x80
fail:
 mov ebx,[step]
 mov eax,1
 int 0x80
entry:
 sub esp,12
 push esi
 push edi
 mov edi,edx
 mov esi,edx
 jmp hook
.section .hook,"ax"
hook: .incbin "{d/'hook.bin'}"
.section .allow,"ax"
 inc DWORD PTR [calls]
 jmp skip
.section .skip,"ax"
skip: .incbin "{d/'skip.bin'}"
.section .tick,"aw"
 .long tick_mock
.section .thunk,"awx"
 .incbin "{d/'code.bin'}"
.section .data,"aw"
saved_sp: .long 0
step: .long 0
calls: .long 0
now: .long 0
event: .zero 0x88
root: .zero 4
other: .zero 4
.section .mock,"ax"
tick_mock:
 mov eax,[now]
 mov ecx,0xfeed
 mov edx,0xbeef
 ret
'''
            sections={'hook':h,'allow':m['profile']['allow'],'skip':skip,'tick':m['tick'],'thunk':m['rva']}
            layout='\n'.join(f'.{k} {base+v} : {{ *(.{k}) }}' for k,v in sorted(sections.items(),key=lambda x:x[1]))
            (d/'test.s').write_text(asm)
            (d/'test.ld').write_text(f'ENTRY(start)\nSECTIONS {{ .main {base+0x1000} : {{ *(.main) }}\n{layout}\n.data : {{ *(.data) }}\n.mock : {{ *(.mock) }} }}')
            subprocess.run(['as','--32','-o',str(d/'test.o'),str(d/'test.s')],check=True)
            subprocess.run(['ld','-m','elf_i386','-T',str(d/'test.ld'),'-o',str(d/'test'),str(d/'test.o')],check=True,capture_output=True)
            r=subprocess.run([str(d/'test')],timeout=10)
            assert r.returncode==0,(name,hex(base),r.returncode)
    print(name,'PASS',step*2,'native toolbar timing/ABI checks; previous price patch unchanged')

if __name__=='__main__':
    for name in ('WLP','WLPADD1'):
        verify(name)
