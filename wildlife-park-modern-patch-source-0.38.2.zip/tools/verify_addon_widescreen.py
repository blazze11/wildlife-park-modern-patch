#!/usr/bin/env python3
"""Independent static checks of the expansion port; requires objdump."""
import argparse
import hashlib
import re
import struct
import subprocess
from pathlib import Path
import pefile
from patch_addon_widescreen import patch, MODES, OLD, GROUPS, LABEL_CALLS


def verify(source, output):
    src, out = source.read_bytes(), output.read_bytes()
    assert patch(src) == out
    p = pefile.PE(data=out)
    assert len(p.sections) == 11
    for s in p.sections:
        assert s.PointerToRawData + s.SizeOfRawData <= len(out)
        assert s.VirtualAddress + s.Misc_VirtualSize <= p.OPTIONAL_HEADER.SizeOfImage
        assert s.PointerToRawData % p.OPTIONAL_HEADER.FileAlignment == 0
        assert s.VirtualAddress % p.OPTIONAL_HEADER.SectionAlignment == 0
    assert struct.unpack_from('<4I', out, 0x36ddfc) == tuple(w for w, h in MODES)
    assert struct.unpack_from('<4I', out, 0x36de0c) == tuple(h for w, h in MODES)
    # Read original table dimensions independently from disassembly, including
    # constants loaded into registers and then copied to stack slots.
    asm = subprocess.check_output(['objdump', '-d', '-Mintel', '--start-address=0x6ac6f0',
                                   '--stop-address=0x6acf14', str(source)], text=True)
    registers, table = {}, {}
    for line in asm.splitlines():
        reg = re.search(r'mov\s+(e[a-z]{2}|cl),0x([0-9a-f]+)', line)
        if reg:
            registers[reg[1]] = int(reg[2], 16)
        store = re.search(r'mov\s+(DWORD|BYTE) PTR \[esp\+0x([0-9a-f]+)\],(0x[0-9a-f]+|e[a-z]{2}|cl)\s*$', line)
        if store:
            value = int(store[3], 16) if store[3].startswith('0x') else registers.get(store[3])
            if value is not None:
                table[int(store[2], 16)] = value
    checked = 0
    for depth, last, index in GROUPS:
        for off in range(last - 14 * 80, last + 1, 80):
            w, h, d = struct.unpack_from('<III', src, off)
            if (w + 1, h + 1) not in OLD:
                continue
            i = index - (last - off) // 80
            assert (table[0x10 + i * 12], table[0x14 + i * 12]) == (w + 1, h + 1)
            assert table[0x18 + i * 12] == depth
            nw, nh = MODES[OLD.index((w + 1, h + 1))]
            assert struct.unpack_from('<III', out, off) == (nw - 1, nh - 1, depth)
            checked += 1
    assert checked == 20
    sections = {s.Name.rstrip(b'\0').decode(): s for s in p.sections}
    hooks = [(0x2bcf96, 7, '.wlpmode'), (0x2adcde, 6, '.wlpfoc'),
             (0x2acf14, 7, '.wlpwide'), (0x272435, 6, '.wlpaud')]
    for hook, length, name in hooks:
        assert out[hook] == 0xe9
        assert hook + 5 + struct.unpack_from('<i', out, hook + 1)[0] == sections[name].VirtualAddress
    for call, choice in LABEL_CALLS:
        target = call + 5 + struct.unpack_from('<i', out, call + 1)[0]
        offset = p.get_offset_from_rva(target)
        assert out[offset:offset + 10] == bytes.fromhex('e8000000005883c005c3')
        expected = f'{MODES[choice][0]}x{MODES[choice][1]}'.encode() + b'\0'
        assert out[offset + 10:offset + 10 + len(expected)] == expected
    for block in p.DIRECTORY_ENTRY_BASERELOC:
        for e in block.entries:
            if e.type:
                for hook, length in [(h, n) for h, n, _ in hooks] + [(c, 5) for c, _ in LABEL_CALLS]:
                    assert not hook <= e.rva < hook + length
    print('PASS: deterministic build, 20 independent engine/driver mappings and depths,')
    print('four labels, hook targets, PE section bounds/alignment and relocation checks.')
    print('SHA256:', hashlib.sha256(out).hexdigest())


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    verify(args.source, args.output)
