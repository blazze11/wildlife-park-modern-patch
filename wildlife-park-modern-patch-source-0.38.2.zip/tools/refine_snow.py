#!/usr/bin/env python3
"""Replace shaded snow with small bright native particles and slower motion."""
import argparse,hashlib,json,struct,shutil
from pathlib import Path
from workspace_paths import artifact, backup_path
import numpy as np
from PIL import Image
from expand_weather import replace_container,verify_container,rows
from revise_snow import sparse,preview,build,atomic_copy,digest
WIDTH,HEIGHT,FRAMES=2560,1440,10
EXPECTED='fbae6e90ced025577c56762831a77294dfe82929170ae6fe899d572b5dce9e4a'
SEED=20261012

def make_particles():
    # All colors come from the original native snow; no shaded bitmap edges.
    source=Path('analysis/weather/Misc_original.alb').read_bytes()
    table,size=struct.unpack_from('<II',source,12)
    offsets=struct.unpack_from(f'<{size//4}I',source,table)
    index=sum(struct.unpack_from('<H',source,255+i*64)[0] for i in range(6))
    colors=np.unique(np.concatenate([np.frombuffer(v,'<u2') for row in rows(source[offsets[index]:offsets[index+1]],1600,1200) for _,v in row]))
    assert all(((int(v)>>11)&31)>=28 and ((int(v)>>5)&63)>=56 and (int(v)&31)>=28 for v in colors)
    rng=np.random.default_rng(SEED)
    shapes=[[(0,0)],[(0,0),(0,1)],[(0,0),(1,0),(0,1),(1,1)],[(1,0),(0,1),(1,1),(2,1),(1,2)]]
    result=[]
    for i in range(5000):
        shape=shapes[int(rng.choice(4,p=[.15,.35,.4,.1]))]
        phase=int(rng.integers(FRAMES))
        speed=int(rng.integers(4,9))
        drift=int(rng.choice([-1,0,0,0,1]))
        x=int(rng.integers(WIDTH));y=int(rng.integers(HEIGHT))
        # Brightness stays in the original light palette even at respawn.
        color=0xffff if rng.random()<.55 else int(rng.choice(colors))
        sx=np.array([p[0] for p in shape]);sy=np.array([p[1] for p in shape])
        result.append((x,y,phase,speed,drift,sx,sy,color))
    return result,colors

def render(particles,frame):
    image=np.zeros((HEIGHT,WIDTH),dtype=np.uint16)
    for x,y,phase,speed,drift,sx,sy,color in particles:
        age=(frame+phase)%FRAMES
        # Disappear for one frame between short tracks, at independent phases.
        # No darkening/fade: transparency is an actual omitted sparse pixel.
        if age==0:continue
        xx=(x+age*drift+sx)%WIDTH;yy=(y+age*speed+sy)%HEIGHT
        np.maximum.at(image,(yy,xx),color)
    return image

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--container',type=Path,default=artifact('Pictures.cont'))
    parser.add_argument('--output',type=Path,default=artifact('Pictures_snow_small.cont'))
    parser.add_argument('--install',type=Path)
    args=parser.parse_args()
    output=Path('analysis/weather');particles,palette=make_particles()
    images=[render(particles,f) for f in range(FRAMES)]
    assert np.array_equal(render(particles,FRAMES),images[0])
    for image in images:assert set(np.unique(image))<=set(palette)|{0}
    source=artifact('Misc_snow_revised_2560.alb').read_bytes()
    alb,unchanged=build(source,[sparse(image) for image in images]);assert unchanged==69
    alb_path=artifact('Misc_snow_small_2560.alb');alb_path.write_bytes(alb)
    png=output/'snow_small_2560_preview.png';preview(images[0]).save(png)
    # Composite a magnified crop over a bright background to expose dark edges.
    crop=images[0][300:500,500:900];rgb=np.asarray(preview(crop));mask=crop!=0
    background=np.full(rgb.shape,[174,150,92],dtype=np.uint8);background[mask]=rgb[mask]
    Image.fromarray(background).resize((1200,600),Image.Resampling.NEAREST).save(output/'snow_small_edges_preview.png')
    frames=[preview(image).resize((1280,720),Image.Resampling.NEAREST) for image in images]
    frames[0].save(output/'snow_small_animation.gif',save_all=True,append_images=frames[1:],duration=100,loop=0)
    assert digest(args.container)==EXPECTED
    replace_container(args.container,alb,args.output,expected_original=source)
    verified=verify_container(args.container,args.output,alb)
    report=dict(seed=SEED,particles=len(particles),size_pixels='1–3',downward_pixels_per_frame='4–8',frames=FRAMES,
                palette=[hex(int(v)) for v in palette],unchanged_alb_frames=unchanged,unchanged_container_members=verified,
                previous_container_sha256=EXPECTED,container_sha256=digest(args.output),alb_sha256=digest(alb_path),
                container_bytes=args.output.stat().st_size,pixels_per_frame=[int(np.count_nonzero(image)) for image in images],
                frame0_pixels_per_80px_column=[int(np.count_nonzero(images[0][:,x:x+80])) for x in range(0,WIDTH,80)])
    if args.install:
        assert digest(args.install)==EXPECTED
        backup=backup_path(args.install.with_name(args.install.name+'.pre-small-snow.bak'));assert not backup.exists()
        with backup.open('xb') as dest,args.install.open('rb') as original:shutil.copyfileobj(original,dest,1024*1024)
        assert digest(backup)==EXPECTED and digest(args.install)==EXPECTED
        atomic_copy(args.output,args.install);assert digest(args.install)==report['container_sha256']
        workspace=artifact('Pictures.cont');assert digest(workspace)==EXPECTED
        atomic_copy(args.output,workspace);assert digest(workspace)==report['container_sha256']
        report.update(installed=str(args.install.resolve()),backup=str(backup.resolve()))
    (output/'snow-small.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))
if __name__=='__main__':main()
