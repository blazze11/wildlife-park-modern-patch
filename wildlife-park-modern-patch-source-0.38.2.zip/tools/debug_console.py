#!/usr/bin/env python3
"""Owned ASCII diagnostics console; physical scan-code 0x29, no cheat state."""
import struct
import subprocess
import tempfile
from pathlib import Path
import pefile
from patch_addon_widescreen import append_section, next_rva
from patch_keybind_panel import asm_string

PROFILES = {
    'WLP': dict(key_hook=0x1194e6, key_end=0x11b9ab, world=0xa56988,
                poll_hook=0x88d0, window=0xa423a4, fullscreen=0xa52fb0),
    'WLPADD1': dict(key_hook=0x12bcc6, key_end=0x12e328, world=0xc43308,
                    poll_hook=0x8660, window=0xc2ed2c, fullscreen=0xc3f938),
}

COMMANDS = [
    ('help', 0, 0, '^ / Esc: close | fps, tps, timing, debug on/off | status | clear'),
    ('status', 0, 0, 'HUD commands: fps/tps/timing/debug on or off. TPS commands only change the display.'),
    ('clear', 0, 0, ''),
    ('close', 0, 0, ''),
]
for name, mask in [('fps', 1), ('tps', 2), ('timing', 4), ('debug', 7)]:
    COMMANDS.extend([(name+' on', mask, mask, name.upper()+' display enabled'),
                     (name+' off', mask, 0, name.upper()+' display disabled')])


def patch(data, tag, hudmetadata):
    """Chain HUD frame call and intercept gameplay key callback. Return PE/meta."""
    p = pefile.PE(data=data)
    profile = PROFILES[tag]
    rva = next_rva(data)
    imports = {i.name.decode(): i.address-p.OPTIONAL_HEADER.ImageBase
               for dll in p.DIRECTORY_ENTRY_IMPORT for i in dll.imports if i.name}
    flags = hudmetadata['flags_rva']
    visible = hudmetadata['console_visible_rva']
    inp = hudmetadata['console_input_rva']
    out = hudmetadata['console_output_rva']
    frame_hook = hudmetadata.get('console_frame_hook_rva',hudmetadata['profile']['frame_hook'])
    frame_target = hudmetadata.get('console_frame_target_rva',hudmetadata['rva']+hudmetadata['symbols']['frame_hook'])
    frame_opcode = hudmetadata.get('console_frame_opcode', 0xe8)
    def addr(label): return f'[ebx+{rva}+{label}-_start]'
    def iat(name): return f'call DWORD PTR [ebx+{imports[name]}]'
    rows = '\n'.join(f'.long cmd{i}-_start, {mask}, {value}, answer{i}-_start'
                     for i, (_, mask, value, _) in enumerate(COMMANDS))
    strings = '\n'.join(asm_string('cmd'+str(i), command)+'\n'+asm_string('answer'+str(i), answer)
                        for i, (command, _, _, answer) in enumerate(COMMANDS))
    status_rows = '.long '+', '.join(f'status{i}-_start' for i in range(8))
    status_strings = '\n'.join(asm_string('status'+str(i),
        ' | '.join(name+(': on' if i & mask else ': off')
                   for name,mask in [('FPS',1),('TPS',2),('Frame',4)])) for i in range(8))
    asm = f'''.intel_syntax noprefix
.code32
.global _start
_start:
get_base:
 call anchor
anchor:
 pop ebx
 sub ebx,{rva}+anchor-_start
 ret
frame:
 pushfd
 pushad
 call get_base
 cmp DWORD PTR {addr('mapkey')},0
 jne map_ready
 lea eax,{addr('user32')}
 push eax
 {iat('GetModuleHandleA')}
 test eax,eax
 jz frame_done
 lea edx,{addr('mapname')}
 push edx
 push eax
 {iat('GetProcAddress')}
 test eax,eax
 jz frame_done
 mov DWORD PTR {addr('mapkey')},eax
map_ready:
 cmp DWORD PTR {addr('foreground')},0
 jne foreground_ready
 lea eax,{addr('user32')}
 push eax
 {iat('GetModuleHandleA')}
 test eax,eax
 jz frame_done
 lea edx,{addr('fgname')}
 push edx
 push eax
 {iat('GetProcAddress')}
 test eax,eax
 jz frame_done
 mov DWORD PTR {addr('foreground')},eax
foreground_ready:
 call DWORD PTR {addr('foreground')}
 test eax,eax
 jz inactive
 mov edx,[ebx+{profile['window']}]
 test edx,edx
 jnz window_ready
 mov edx,[ebx+{profile['fullscreen']}]
window_ready:
 cmp eax,edx
 jne inactive
 cmp DWORD PTR {addr('focused')},0
 jne focused_ready
 mov DWORD PTR {addr('held')},1
 mov DWORD PTR {addr('focused')},1
focused_ready:
 push 3
 push 0x29
 call DWORD PTR {addr('mapkey')}
 test eax,eax
 jz frame_done
 push eax
 {iat('GetAsyncKeyState')}
 test ax,0x8000
 jnz key_held
 mov DWORD PTR {addr('held')},0
 jmp frame_done
key_held:
 cmp DWORD PTR {addr('held')},0
 jne frame_done
 mov DWORD PTR {addr('held')},1
 xor DWORD PTR [ebx+{visible}],1
 mov BYTE PTR [ebx+{inp}],0
 lea esi,{addr('welcome')}
 lea edi,[ebx+{out}]
 call copy_output
 jmp frame_done
inactive:
 mov DWORD PTR {addr('focused')},0
 mov DWORD PTR {addr('held')},1
frame_done:
 popad
 popfd
 jmp _start+{frame_target-rva}
keyboard:
 mov edi,[esp+0x44]
 pushfd
 pushad
 call get_base
 cmp BYTE PTR [edi+0x41],0x29
 je consumed
 cmp DWORD PTR [ebx+{visible}],0
 je pass_key
 # Registered event 0x0c is the keyboard-input path. Ignore any other type,
 # including synthetic key-release events, rather than appending a duplicate.
 cmp DWORD PTR [edi+0x28],0x0c
 jne consumed
 movzx eax,BYTE PTR [edi+0x42]
 cmp al,27
 je close_console
 cmp al,13
 je submit
 lea esi,[ebx+{inp}]
 xor ecx,ecx
find_end:
 cmp BYTE PTR [esi+ecx],0
 je end_found
 inc ecx
 cmp ecx,127
 jb find_end
end_found:
 cmp al,8
 je backspace
 cmp al,32
 jb consumed
 cmp al,126
 ja consumed
 cmp ecx,127
 jae consumed
 cmp al,65
 jb append_char
 cmp al,90
 ja append_char
 add al,32
append_char:
 mov [esi+ecx],al
 mov BYTE PTR [esi+ecx+1],0
 jmp consumed
backspace:
 test ecx,ecx
 jz consumed
 mov BYTE PTR [esi+ecx-1],0
 jmp consumed
close_console:
 mov DWORD PTR [ebx+{visible}],0
 mov BYTE PTR [ebx+{inp}],0
 jmp consumed
submit:
 cmp BYTE PTR [ebx+{inp}],0
 je consumed
 call execute
 mov BYTE PTR [ebx+{inp}],0
 jmp consumed
pass_key:
 popad
 popfd
 jmp pass_world
consumed:
 popad
 popfd
 jmp _start+{profile['key_end']-rva}
pass_world:
 push ebx
 call get_base
 mov esi,[ebx+{profile['world']}]
 pop ebx
 jmp _start+{profile['key_hook']+10-rva}
poll_keyboard:
 pushfd
 pushad
 call get_base
 cmp DWORD PTR [ebx+{visible}],0
 je original_poll
 popad
 popfd
 ret
original_poll:
 popad
 popfd
 push esi
 mov esi,ecx
 push edi
 push ebx
 call get_base
 mov edi,[ebx+{imports['GetAsyncKeyState']}]
 pop ebx
 jmp _start+{profile['poll_hook']+10-rva}
execute:
 lea edx,{addr('commands')}
 mov ebp,{len(COMMANDS)}
compare_next:
 mov esi,[edx]
 lea esi,[ebx+{rva}+esi]
 lea edi,[ebx+{inp}]
compare_char:
 mov al,[esi]
 cmp al,[edi]
 jne mismatch
 inc esi
 inc edi
 test al,al
 jne compare_char
 mov eax,[edx+4]
 not eax
 and DWORD PTR [ebx+{flags}],eax
 mov eax,[edx+8]
 or DWORD PTR [ebx+{flags}],eax
 # close is table index three; clear and close output empty by design.
 lea eax,{addr('commands')}
 add eax,48
 cmp edx,eax
 jne response
 mov DWORD PTR [ebx+{visible}],0
response:
 lea eax,{addr('commands')}
 add eax,16
 cmp edx,eax
 jne normal_response
 mov eax,[ebx+{flags}]
 and eax,7
 lea edx,{addr('statuses')}
 mov esi,[edx+eax*4]
 lea esi,[ebx+{rva}+esi]
 jmp output
normal_response:
 mov esi,[edx+12]
 lea esi,[ebx+{rva}+esi]
 jmp output
mismatch:
 add edx,16
 dec ebp
 jnz compare_next
 lea esi,{addr('unknown')}
output:
 lea edi,[ebx+{out}]
copy_output:
 mov ecx,255
copy_char:
 mov al,[esi]
 mov [edi],al
 inc esi
 inc edi
 test al,al
 je copy_done
 loop copy_char
 mov BYTE PTR [edi],0
copy_done:
 ret
.balign 4
mapkey: .long 0
foreground: .long 0
focused: .long 0
held: .long 0
commands:
{rows}
statuses:
{status_rows}
{strings}
{status_strings}
{asm_string('user32','user32.dll')}
{asm_string('mapname','MapVirtualKeyA')}
{asm_string('fgname','GetForegroundWindow')}
{asm_string('welcome','Debug console: help lists commands. Esc or ^ closes.')}
{asm_string('unknown','Unknown command. Type help.')}
'''
    with tempfile.TemporaryDirectory() as tmp:
        d = Path(tmp)
        (d/'console.s').write_text(asm)
        subprocess.run(['as','--32','-o',str(d/'console.o'),str(d/'console.s')],check=True)
        assert 'R_386' not in subprocess.check_output(['objdump','-r',str(d/'console.o')],text=True)
        subprocess.run(['objcopy','-O','binary','-j','.text',str(d/'console.o'),str(d/'console.bin')],check=True)
        code = (d/'console.bin').read_bytes()
        symbols = {a[2]:int(a[0],16) for line in subprocess.check_output(['nm',str(d/'console.o')],text=True).splitlines() if len(a:=line.split())==3}
    b = bytearray(data)
    changes = []
    def replace(h, old, new):
        off = p.get_offset_from_rva(h)
        assert b[off:off+len(old)] == old, hex(h)
        assert len(old) == len(new)
        b[off:off+len(old)] = new
        changes.append((h,len(old)))
    h = profile['key_hook']
    original = bytes.fromhex('8b7c24448b35')+struct.pack('<I',p.OPTIONAL_HEADER.ImageBase+profile['world'])
    replace(h, original, b'\xe9'+struct.pack('<i',rva+symbols['keyboard']-h-5)+b'\x90'*5)
    replace(frame_hook, bytes([frame_opcode])+struct.pack('<i',frame_target-frame_hook-5),
            bytes([frame_opcode])+struct.pack('<i',rva+symbols['frame']-frame_hook-5))
    h = profile['poll_hook']
    original = bytes.fromhex('568bf1578b3d')+struct.pack('<I',p.OPTIONAL_HEADER.ImageBase+imports['GetAsyncKeyState'])
    replace(h,original,b'\xe9'+struct.pack('<i',rva+symbols['poll_keyboard']-h-5)+b'\x90'*5)
    reloc_offsets = []
    for block in p.DIRECTORY_ENTRY_BASERELOC:
        for e in block.entries:
            if e.type and any(h <= e.rva < h+n for h,n in changes):
                off = e.struct.get_file_offset()
                struct.pack_into('<H',b,off,struct.unpack_from('<H',b,off)[0]&0xfff)
                reloc_offsets.append(off)
    assert len(reloc_offsets)==2
    append_section(b,b'.wlpcnsl',code)
    np = pefile.PE(data=b)
    struct.pack_into('<I',b,np.sections[-1].get_file_offset()+36,0xe0000020)
    return bytes(b),dict(rva=rva,code=code,symbols=symbols,profile=profile,
                        hud=hudmetadata,imports=imports,changes=changes,reloc_offsets=reloc_offsets)
