#!/usr/bin/env python3
"""One-time non-destructive organization of patch artifacts and game backups."""
import ast, hashlib, json, os, shutil
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
GAME=Path('/path/to/Wildlife Park Gold')
def digest(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def files(root):
    for parent,dirs,names in os.walk(root):
        dirs[:]=[d for d in dirs if not d.startswith('.')]
        for name in names:
            p=Path(parent)/name
            if not p.is_symlink():yield p

manifest=ROOT/'analysis/workspace-cleanup.json'
assert not manifest.exists(),'Cleanup already recorded; inspect its manifest before another run'
moves=[]
def plan(src,dst):
    assert src!=dst and not dst.exists(),str(dst)
    moves.append(dict(source=str(src),destination=str(dst),bytes=src.stat().st_size,sha256=digest(src)))

# Capture every retained game file so moving extras cannot mask data changes.
game_files=list(files(GAME))
extras=[]
for p in game_files:
    lower=p.name.lower()
    if lower.endswith('.bak') or lower.startswith(('videomodetrace-','mousecapturetrace-','displaytransition-')) or lower in ('error.log','displaymodes.log'):
        extras.append(p)
        group='game-backups' if lower.endswith('.bak') else 'runtime-logs'
        plan(p,ROOT/'archive'/group/p.relative_to(GAME))
retained={str(p):dict(bytes=p.stat().st_size,sha256=digest(p)) for p in game_files if p not in extras}
assert retained[str(GAME/'Int/Win32/Program/VC6/WLP.EXE')]['sha256']=='2fe9f1d75866c80096a369e9c705736677178f4f7529c54323ed0f4d24eee882'
assert retained[str(GAME/'Int/Win32/Program/VC6/WLPADD1.EXE')]['sha256']=='2673b3f647f8c3f0f3362c0791c6ddb0f236bc02d8c273d3f9d6d706accaf42b'

originals={'WLP_T.EXE','WLPADD1_original.EXE','WLP_.EXE'}
for p in sorted(ROOT.iterdir()):
    if not p.is_file():continue
    if p.suffix.lower()=='.exe' or p.name.endswith('.EXE.json'):
        group='originals' if p.name in originals else 'archive'
        plan(p,ROOT/'builds'/group/p.name)
    elif p.name in ('Pictures.cont','GUI.alb','Misc_snow_small_2560.alb'):
        plan(p,ROOT/'assets/current'/p.name)
    elif p.suffix.lower() in ('.alb','.cont'):
        plan(p,ROOT/'assets/archive'/p.name)
    elif p.suffix.lower()=='.png':
        plan(p,ROOT/'assets/previews'/p.name)
    elif p.suffix.lower()=='.zip':
        plan(p,ROOT/'assets/reference'/p.name)

for m in moves:
    src=Path(m['source']);dst=Path(m['destination']);dst.parent.mkdir(parents=True,exist_ok=True)
    assert digest(src)==m['sha256']
    shutil.move(str(src),str(dst))
    assert digest(dst)==m['sha256'] and not src.exists()

cache=ROOT/'tools/__pycache__'
if cache.exists():
    dst=ROOT/'archive/caches/tools-__pycache__';dst.parent.mkdir(parents=True,exist_ok=True)
    assert not dst.exists();shutil.move(str(cache),str(dst))

copies=[]
for name in ('WLP.EXE','WLPADD1.EXE'):
    src=GAME/'Int/Win32/Program/VC6'/name;dst=ROOT/'builds/current'/name
    dst.parent.mkdir(parents=True,exist_ok=True);assert not dst.exists();shutil.copy2(src,dst)
    assert digest(src)==digest(dst)
    copies.append(dict(source=str(src),destination=str(dst),sha256=digest(dst),bytes=dst.stat().st_size))

for path,info in retained.items():
    p=Path(path);assert p.exists() and digest(p)==info['sha256'],path
assert not any(p in set(files(GAME)) for p in extras)
report=dict(date='2026-10-12',moves=moves,current_builds=copies,retained_game_files=retained,
            note='All moved files verified by SHA-256. Game files retained byte-for-byte. No files deleted; framework-managed hidden directories left in place.')
manifest.write_text(json.dumps(report,indent=2)+'\n')

# Update hard-coded workspace artifact paths, leaving explicit CLI paths intact.
names={Path(m['source']).name for m in moves if Path(m['source']).parent==ROOT}
updated=[]
for script in (ROOT/'tools').glob('*.py'):
    if script.name in ('organize_workspace.py','workspace_paths.py'):continue
    text=script.read_text();tree=ast.parse(text);lines=text.splitlines(keepends=True)
    offsets=[0]
    for line in lines:offsets.append(offsets[-1]+len(line))
    edits=[]
    for node in ast.walk(tree):
        if not isinstance(node,ast.Call) or not isinstance(node.func,ast.Name) or node.func.id!='Path' or not node.args:continue
        constants=[n.value for n in ast.walk(node.args[0]) if isinstance(n,ast.Constant) and isinstance(n.value,str)]
        if any(s in names or ('.EXE' in s and '/' not in s and '\\' not in s) for s in constants):
            pos=offsets[node.func.lineno-1]+node.func.col_offset;edits.append(pos)
    if not edits:continue
    for pos in sorted(edits,reverse=True):text=text[:pos]+'artifact'+text[pos+4:]
    assert 'from pathlib import Path' in text
    text=text.replace('from pathlib import Path','from pathlib import Path\nfrom workspace_paths import artifact',1)
    compile(text,str(script),'exec');script.write_text(text);updated.append(str(script))

# Repair actual workspace links and the live inventory, retaining historical
# reports as records of the original installations and their former paths.
mapping={m['source']:m['destination'] for m in moves}
summary=ROOT/'CHANGE_SUMMARY.md';text=summary.read_text()
for old,new in sorted(mapping.items(),key=lambda x:len(x[0]),reverse=True):text=text.replace(old,new)
summary.write_text(text)
inv=ROOT/'analysis/edited-files-inventory.json';data=json.loads(inv.read_text())
def remap(v):
    if isinstance(v,str):return mapping.get(v,v)
    if isinstance(v,list):return [remap(x) for x in v]
    if isinstance(v,dict):return {k:remap(x) for k,x in v.items()}
    return v
data=remap(data)
for entry in data['installed_changed_files']:
    p=Path(entry['path']);entry.update(sha256=digest(p),bytes=p.stat().st_size)
data['date']='2026-10-12';data['cleanup_manifest']=str(manifest)
inv.write_text(json.dumps(data,indent=2)+'\n')
report['updated_tools']=updated;manifest.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(moved_files=len(moves),archived_game_files=len(extras),retained_game_files=len(retained),updated_tools=len(updated),current_builds=copies),indent=2))
